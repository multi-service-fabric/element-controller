"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from collections import OrderedDict
from network_docopt import NetworkDocopt, sort_for_humans
from network_docopt.match import ifname_is_glob
from nclu import globify_interface_commands, ifname_expand_glob
from nclu.capturing import Capturing
from nclu.plugins.frr.core import (
    ETC_FRR_CONF,
    SERVICE_NAME,
    frr_reload_exception_to_string,
    show_linux_command,
)
from nclu.plugins.frr.frr_docstring import __doc__
from nclu.wrappers.ifupdown2 import EtcNetworkInterface
from pprint import pformat
from subprocess import CalledProcessError, check_output, STDOUT
import doctest
import logging
import os
import re
import sys

# use __import__ for files with a hyphen in the name
sys.path.append("/usr/lib/frr/")
frr_reload = __import__("frr-reload")


log = logging.getLogger("netd")


def show_config_commands(user_may_edit, ifupdown2_wrapper):
    """
    net show configuration commands

    Return a 2-tuple of (list, list).  The first list includes supported commands; the second, unsupported commands.
    """

    interface_commands = []
    commands = []
    supported = []
    not_supported = []

    if os.path.exists(ETC_FRR_CONF):
        try:
            frr_conf = frr_reload.Config()
            frr_conf.load_from_file(ETC_FRR_CONF)
        except frr_reload.VtyshMarkException as e:
            msg = frr_reload_exception_to_string(ETC_FRR_CONF, e)
            log.error(msg)
            return (supported, not_supported)

        for context in frr_conf.contexts.itervalues():

            if len(context.keys) == 1:
                key = context.keys[0]

                if key.startswith("router bgp"):
                    printf_alt = "{0}\\n".format(key)
                    asn = key.split()[2]

                    if "vrf" in key:
                        # router bgp 100 vrf RED
                        vrf = key.split()[4]
                    else:
                        vrf = None

                    if vrf:
                        commands.append((printf_alt, "net add bgp vrf {0} autonomous-system {1}".format(vrf, asn)))
                    else:
                        commands.append((printf_alt, "net add bgp autonomous-system {0}".format(asn)))

                    for line in context.lines:
                        printf_alt = "{0}\\n  {1}\\n".format(key, line)
                        cmd = "net add bgp {0}".format(line)
                        cmd = cmd.replace(' bgp bgp ', ' bgp ')

                        if vrf:
                            cmd = cmd.replace("net add bgp", "net add bgp vrf {0}".format(vrf))

                        if 'no bgp default ipv4-unicast' in cmd:
                            cmd = cmd.replace('no bgp default ipv4-unicast', 'default ipv4-unicast')
                            cmd = cmd.replace('net add', 'net del')
                        elif 'no bgp network import-check' in cmd:
                            cmd = cmd.replace('no bgp network import-check', 'network import-check')
                            cmd = cmd.replace('net add', 'net del')
                        elif 'timers bgp' in cmd:
                            cmd = cmd.replace('timers bgp', 'timers')

                        commands.append((printf_alt, cmd))

                elif key.startswith('router ospf6'):
                    for line in context.lines:
                        printf_alt = "{0}\\n  {1}\\n".format(key, line)
                        cmd = "net add ospf6 {0}".format(line)
                        cmd = cmd.replace(' ospf6 ospf6 ', ' ospf6 ')
                        commands.append((printf_alt, cmd))

                elif key.startswith('router ospf'):
                    if 'vrf' in key:
                        # router ospf vrf RED
                        vrf = key.split()[3]
                    else:
                        vrf = None

                    if vrf is not None:
                        commands.append((printf_alt, 'net add ospf vrf %s' % (vrf)))

                    for line in context.lines:
                        printf_alt = '%s\\n  %s\\n' % (key, line)
                        cmd = 'net add ospf %s' % line
                        cmd = cmd.replace(' ospf ospf ', ' ospf ')

                        # If the ospf config contains a 'no passive-interface swpX' it means
                        # 'passive-interface default' is configured. We must change the
                        #
                        #   net add ospf no passive-interface swpX
                        #
                        # to
                        #
                        #   net del ospf passive-interface swpX
                        #
                        cmd = cmd.replace("net add ospf no passive-interface", "net del ospf passive-interface")

                        if vrf is not None:
                            cmd = cmd.replace("net add ospf", "net add ospf vrf {0}".format(vrf))
                            cmd = cmd.replace("net del ospf", "net del ospf vrf {0}".format(vrf))

                        commands.append((printf_alt, cmd))

                elif key.startswith('vrf'):
                    for line in context.lines:
                        printf_alt = '%s\\n  %s\\n' % (key, line)

                        # vrf BLUE
                        #  ip pim rp 1.1.1.1 224.0.0.0/4
                        #
                        # translates to "net add vrf BLUE ip pim rp 1.1.1.1 224.0.0.0/4"
                        if line.startswith('ip pim'):
                            pim_options = ' '.join(line.split()[2:])
                            cmd = 'net add pim %s %s' % (key, pim_options)
                        else:
                            cmd = 'net add %s %s' % (key, line)

                        commands.append((printf_alt, cmd))

                elif context.lines:
                    if key.startswith('interface'):
                        ifname = key.strip().split()[1]
                        iface = EtcNetworkInterface(ifname, ifupdown2_wrapper.ifquery_all)

                        # If this is a bond we must change the key from "interface IFNAME"
                        # to "bond IFNAME", etc.
                        if iface.is_bond():
                            key = key.replace('interface', 'bond')
                        elif iface.is_bridge():
                            key = key.replace('interface', 'bridge')
                        elif iface.is_loopback():
                            key = key.replace('interface', 'loopback')
                        elif iface.is_vlan_interface():
                            key = key.replace('vlan', '')
                            key = key.replace('interface', 'vlan')
                        elif iface.is_vxlan():
                            key = key.replace('interface', 'vxlan')
                        elif iface.is_vrf():
                            key = key.replace('interface', 'vrf')
                        elif ' vrf ' in key:
                            # If interface swp1 is in vrf BLUE frr will display the line as
                            # 'interface swp1 vrf BLUE', we must remove the 'vrf BLUE' from
                            # the key in this scenario.
                            key = 'interface %s' % ifname

                        for line in context.lines:

                            if line == 'no ipv6 nd suppress-ra':
                                interface_commands.append('net del %s ipv6 nd suppress-ra' % key)

                            elif line == 'no ptm-enable':
                                interface_commands.append('net del %s ptm-enable' % key)

                            elif line.startswith('ip ospf'):
                                line = line.replace('ip ospf', 'ospf')
                                interface_commands.append('net add %s %s' % (key, line))

                            elif line.startswith('ipv6 ospf6'):
                                line = line.replace('ipv6 ospf6', 'ospf6')
                                interface_commands.append('net add %s %s' % (key, line))

                            elif line.startswith('ip igmp'):
                                line = line.replace('ip igmp', 'igmp')
                                interface_commands.append('net add %s %s' % (key, line))

                            elif line.startswith('ip pim'):
                                line = line.replace('ip pim', 'pim')
                                interface_commands.append('net add %s %s' % (key, line))

                            elif line.startswith('ip msdp'):
                                line = line.replace('ip msdp', 'msdp')
                                interface_commands.append('net add %s %s' % (key, line))

                            else:
                                interface_commands.append("net add {0} {1}".format(key, line if user_may_edit else sanitize_passwords(line)))
                    else:
                        if key.startswith('route-map'):
                            key = key.replace('route-map', 'routing route-map')
                        elif key.startswith('line vty'):
                            key = key.replace('line vty', 'routing line vty')

                        for line in context.lines:
                            printf_alt = "{0}\\n  {1}\\n".format(key, line if user_may_edit else sanitize_passwords(line))
                            commands.append((printf_alt, "net add {0} {1}".format(key, line if user_may_edit else sanitize_passwords(line))))

                # Global commands (no context.lines)
                else:
                    printf_alt = "{0}\\n".format(key)

                    # babelfish
                    if key.startswith('log ') or key.startswith('ptm-enable'):
                        key = 'routing ' + key

                    elif key.startswith('ip community-list'):
                        key = key.replace('ip community-list', 'routing community-list')

                    elif key.startswith('ip extcommunity-list'):
                        key = key.replace('ip extcommunity-list', 'routing extcommunity-list')

                    elif key.startswith('ip as-path'):
                        key = key.replace('ip as-path', 'routing as-path')

                    elif key.startswith('ip multicast-routing'):
                        key = key.replace('ip multicast-routing', 'routing multicast-routing')

                    elif key.startswith('ip pim '):
                        key = key.replace('ip pim', 'pim')

                    elif key.startswith('ip msdp '):
                        key = key.replace('ip msdp', 'msdp')

                    elif key.startswith('ip prefix-list'):
                        key = key.replace('ip prefix-list', 'routing prefix-list ipv4')

                    elif key.startswith('ipv6 prefix-list'):
                        key = key.replace('ipv6 prefix-list', 'routing prefix-list ipv6')

                    elif key.startswith('route-map'):
                        key = key.replace('route-map', 'routing route-map')

                    elif key.startswith('ip protocol'):
                        key = key.replace('ip protocol', 'routing protocol')

                    elif key.startswith('ip import-table'):
                        key = key.replace('ip import-table', 'routing import-table')

                    elif key.startswith('ip route'):
                        key = key.replace('ip route', 'routing route')

                    elif key.startswith('ip mroute'):
                        key = key.replace('ip mroute', 'routing mroute')

                    elif key.startswith('ipv6 route'):
                        key = key.replace('ipv6 route', 'routing route')

                    elif key.startswith('service'):
                        key = key.replace('service', 'routing service')

                    elif key.startswith('enable password'):
                        key = key.replace('enable password', 'routing enable password')

                    elif key.startswith('agentx'):
                        key = key.replace('agentx', 'routing agentx')

                    elif key.startswith('password'):
                        key = key.replace('password', 'routing password')

                    elif key.startswith('debug bgp'):
                        key = key.replace('debug bgp', 'bgp debug')

                    elif key.startswith('debug msdp'):
                        key = key.replace('debug msdp', 'msdp debug')

                    elif key.startswith('debug ospf6'):
                        key = key.replace('debug ospf6', 'ospf6 debug')

                    elif key.startswith('debug ospf'):
                        key = key.replace('debug ospf', 'ospf debug')

                    elif key.startswith('debug pim'):
                        key = key.replace('debug pim', 'pim debug')

                    elif key.startswith('debug igmp'):
                        key = key.replace('debug igmp', 'igmp debug')

                    elif key.startswith('debug zebra'):
                        key = key.replace('debug zebra', 'routing zebra debug')

                    elif key.startswith('debug mroute'):
                        key = key.replace('debug mroute', 'routing mroute debug')

                    elif key.startswith('frr defaults'):
                        key = key.replace('frr defaults', 'routing defaults')

                    # Ignore these when printing 'net' commands for the current config
                    elif (key.startswith('frr version ') or
                          key.startswith('hostname ') or
                          key == 'line vty'):
                        continue

                    cmd = "net add {0}".format(key)
                    commands.append((printf_alt, "net add {0}".format(key if user_may_edit else sanitize_passwords(key))))

            elif len(context.keys) >= 2:
                key = context.keys[0]
                subkey = context.keys[1]

                if key.startswith('router bgp'):

                    if 'vrf' in key:
                        # router bgp 100 vrf RED
                        vrf = key.split()[4]
                    else:
                        vrf = None

                    if subkey.startswith('address-family'):
                        (_, afi, safi) = subkey.strip().split()

                        if subkey == 'address-family l2vpn evpn':
                            if len(context.keys) == 3:
                                vni = '%s ' % context.keys[2]
                            else:
                                vni = ' '
                        else:
                            vni = ''

                        for line in context.lines:
                            printf_alt = "{0}\\n  {1}\\n  {2}\\n".format(key, subkey, line if user_may_edit else sanitize_passwords(line))
                            add_del = "add"

                            if re.search('no neighbor \S+ activate', line):
                                line = line.replace('no neighbor', 'neighbor')
                                add_del = 'del'

                            if vrf:
                                commands.append((printf_alt, "net {0} bgp vrf {1} {2} {3} {4}{5}".format(add_del, vrf, afi, safi, vni, line if user_may_edit else sanitize_passwords(line))))
                            else:
                                commands.append((printf_alt, "net {0} bgp {1} {2} {3}{4}".format(add_del, afi, safi, vni, line if user_may_edit else sanitize_passwords(line))))

                    else:
                        log.info("%s show_config_commands() unsupported BGP subkey %s" % (SERVICE_NAME, subkey))
                else:
                    log.info("%s show_config_commands() unsupported key %s" % (SERVICE_NAME, pformat(context.keys)))
            else:
                log.info("%s show_config_commands() unsupported key %s" % (SERVICE_NAME, pformat(context.keys)))

    # Create a temporary NetworkDocopt object so we can see which 'commands' are supported.
    # We need to replace the 'frr' in our __doc__ with 'net'.
    cli = NetworkDocopt(__doc__.replace('    frr ', '    net '))

    interface_commands = globify_interface_commands(interface_commands)
    for cmd in interface_commands:

        # We do not want the user to see the "Command not found" error if this is an unsupported command.
        with Capturing():
            cli.run(cmd.split())

        if cli.match:
            supported.append(cmd)
        else:
            cmd = cmd.split()
            ifname_glob = cmd[3]
            ifnames = []
            cmd = ' '.join(cmd[4:])

            if ifname_is_glob(ifname_glob):
                ifnames = ifname_expand_glob(ifname_glob)
            else:
                ifnames.append(ifname_glob)

            for ifname in ifnames:
                log.info("%s interface command '%s' has not been wrappered" % (SERVICE_NAME, cmd))
                echo_cmd = "sudo printf 'interface %s\\n%s\\n' >> %s" % (ifname, cmd, ETC_FRR_CONF)
                not_supported.append(echo_cmd)
        cli.re_init()

    for protocol_commands in (False, True):

        for (printf_alt, cmd) in commands:

            if protocol_commands:
                if cmd.startswith('net add routing'):
                    continue
            else:
                if not cmd.startswith('net add routing'):
                    continue

            if cmd == '#':
                supported.append(cmd)
                continue

            # We do not want the user to see the "Command not found" error if this is an unsupported command.
            with Capturing():
                cli.run(cmd.split())

            if cli.match:
                supported.append(cmd)
            else:
                log.info("%s protocol command '%s' has not been wrappered" % (SERVICE_NAME, cmd))
                echo_cmd = "sudo printf '%s' >> %s" % (printf_alt, ETC_FRR_CONF)
                not_supported.append(echo_cmd)
            cli.re_init()

    return (supported, not_supported)


def show_config_summary(user_may_edit, summary):
    """
    net show configuration

    Populate the "summary" dictionary with information about the frr configuration.
    """

    assert isinstance(summary, dict)

    if not os.path.exists(ETC_FRR_CONF) or os.path.getsize(ETC_FRR_CONF) == 0:
        # There's nothing to do.
        return

    try:
        frr_conf = frr_reload.Config()
        frr_conf.load_from_file(ETC_FRR_CONF)

    except frr_reload.VtyshMarkException as e:
        msg = frr_reload_exception_to_string(ETC_FRR_CONF, e)
        log.error(msg)
        return

    for context in frr_conf.contexts.itervalues():

        if len(context.keys) == 1:
            key = context.keys[0]

            # If interface swp1 is in vrf BLUE, frr will display the line as
            # "interface swp1 vrf BLUE".  Remove the "vrf BLUE" from the key
            # in this scenario.
            if key.startswith('interface') and ' vrf ' in key:
                ifname = key.strip().split()[1]
                key = "interface {0}".format(ifname)

            if key.startswith('interface '):
                key = key.replace('interface ', 'INTERFACE:')

            # Redact passwords in the key, if necessary.
            key_redacted = key if user_may_edit else sanitize_passwords(key)

            if key_redacted not in summary:
                summary[key_redacted] = OrderedDict()

            if context.lines:
                if 'COMMAND_LIST' not in summary[key_redacted]:
                    summary[key_redacted]['COMMAND_LIST'] = []

                if user_may_edit:
                    summary[key_redacted]['COMMAND_LIST'].extend(context.lines)
                else:
                    # Redact passwords in the context lines, if necessary.
                    for line in context.lines:
                        summary[key_redacted]['COMMAND_LIST'].append(sanitize_passwords(line))

                if key.startswith('INTERFACE:'):
                    summary[key_redacted]['COMMAND_LIST'] = sort_for_humans(summary[key_redacted]['COMMAND_LIST'])

        elif len(context.keys) >= 2:
            key = context.keys[0]
            subkey = context.keys[1]

            # Redact passwords in the key, if necessary.
            key_redacted = key if user_may_edit else sanitize_passwords(key)
            subkey_redacted = subkey if user_may_edit else sanitize_passwords(subkey)

            if key_redacted not in summary:
                summary[key_redacted] = OrderedDict()

            if len(context.keys) == 2:
                if subkey_redacted not in summary[key_redacted]:
                    summary[key_redacted][subkey_redacted] = OrderedDict()
                summary[key_redacted][subkey_redacted]['COMMAND_LIST'] = context.lines

            # "address-family l2vpn evpn" "vni 10" is the only place we have this many keys
            elif len(context.keys) == 3:
                subsubkey = context.keys[2]
                subsubkey_redacted = subsubkey if user_may_edit else sanitize_passwords(subsubkey)

                if subkey_redacted not in summary[key_redacted]:
                    summary[key_redacted][subkey_redacted] = OrderedDict()

                if subsubkey_redacted not in summary[key_redacted][subkey_redacted]:
                    summary[key_redacted][subkey_redacted][subsubkey_redacted] = []

                if user_may_edit:
                    summary[key_redacted][subkey_redacted][subsubkey_redacted] = context.lines
                else:
                    # Redact passwords.
                    for line in context.lines:
                        summary[key_redacted][subkey_redacted][subsubkey_redacted].append(sanitize_passwords(line))

            else:
                log.info("{0} show_config_commands() unsupported key {1}".format(SERVICE_NAME, pformat(context.keys)))
        else:
            log.info("{0} show_config_commands() unsupported key {1}".format(SERVICE_NAME, pformat(context.keys)))


def ip_route_show(vtysh_args, zebra_output):
    result = []

    def get_routing_entry_for():
        if zebra_output:
            for line in zebra_output.splitlines():
                if line.startswith('Routing entry for'):
                    return line.strip().split()[3]
        return None

    # show ip route x.x.x.x/24
    # ip route show x.x.x.x/24
    #
    # show ip route x.x.x.x
    # ip route show
    if vtysh_args.startswith('show ip route'):
        re_prefix_prefixlen = re.search('^show ip route.* (\d+\.\d+\.\d+\.\d+\/\d+)$', vtysh_args)
        re_prefix = re.search('^show ip route.* (\d+\.\d+\.\d+\.\d+)$', vtysh_args)
        use_ipv6 = False

    elif vtysh_args.startswith('show ipv6 route'):
        re_prefix_prefixlen = re.search('^show ipv6 route.* ([0-9a-fA-F]\S+\/\d+)$', vtysh_args)
        re_prefix = re.search('^show ipv6 route.* ([0-9a-fA-F]\S+:\S+)$', vtysh_args)
        use_ipv6 = True

    else:
        re_prefix_prefixlen = None
        re_prefix = None
        use_ipv6 = False

    if re_prefix_prefixlen:
        ip = re_prefix_prefixlen.group(1)

    elif re_prefix:
        ip = re_prefix.group(1)
        ip = get_routing_entry_for()
    else:
        ip = None

    if ip:
        re_vrf = re.search('vrf (\S+)', vtysh_args)
        vrf = re_vrf.group(1) if re_vrf else None

        header = "FIB entry for %s" % vtysh_args.split()[-1]
        if vrf:
            header += " in vrf %s" % vrf

        result.append("{0}\n{1}".format(header, '=' * len(header)))

        command = ["/sbin/ip"]

        if use_ipv6:
            command.append('-6')

        command.append('route')
        command.append('show')

        if vrf:
            command.append('vrf')
            command.append(vrf)

        command.append(ip)

        if show_linux_command:
            result.append("exec: ''" % ' '.join(command))

        try:
            result.append(check_output(command))
        except CalledProcessError:
            pass

    return '\n'.join(result)


def exec_vtysh_show_or_clear(args, vtysh_args):
    result = []

    # In frr, bgp allows the user to do "show ip bgp" or "show bgp"
    # but ospf only allows "show ip ospf".  This is a bit awkward for
    # the user if they are working with both so we made "show ospf" but
    # we need to change that to "show ip ospf"
    vtysh_args = vtysh_args.replace('show ospf6', 'show ipv6 ospf6')
    vtysh_args = vtysh_args.replace('show ospf', 'show ip ospf')
    vtysh_args = vtysh_args.replace('show igmp', 'show ip igmp')
    vtysh_args = vtysh_args.replace('show mroute', 'show ip mroute')
    vtysh_args = vtysh_args.replace('show pim', 'show ip pim')
    vtysh_args = vtysh_args.replace('show msdp', 'show ip msdp')

    vtysh_args = vtysh_args.replace('clear ospf', 'clear ip ospf')
    vtysh_args = vtysh_args.replace('clear bgp', 'clear ip bgp')
    vtysh_args_list = []
    bgp_summary_combined = False
    bgp_vrf_summary_combined = None
    route_vrf_json_combined = False

    if vtysh_args.startswith('show bgp'):
        re_show_bgp_vrf_summary = re.search('show bgp vrf (\S+) summary', vtysh_args)
        re_show_bgp_vrf_neighbor = re.search('show bgp vrf (\S+) neighbor', vtysh_args)

        # FRR is deprecating the "show bgp evpn" tree in favor of "show bgp l2vpn evpn"
        if 'evpn' in vtysh_args and not 'l2vpn evpn' in vtysh_args:
            vtysh_args = vtysh_args.replace('evpn', 'l2vpn evpn')

        # Have this dump both IPv4 and IPv6 tables
        if vtysh_args == 'show bgp':
            vtysh_args_list.append('show bgp ipv4 unicast')
            vtysh_args_list.append('show bgp ipv6 unicast')

        # Have this dump both IPv4 and IPv6 summary
        elif vtysh_args == 'show bgp summary':
            vtysh_args_list.append('show bgp ipv4 unicast summary')
            vtysh_args_list.append('show bgp ipv6 unicast summary')
            vtysh_args_list.append('show bgp l2vpn evpn summary')

        elif vtysh_args == 'show bgp summary json':
            bgp_summary_combined = True

        elif vtysh_args == 'show bgp update-groups':
            vtysh_args_list.append('show bgp ipv4 unicast update-groups')
            vtysh_args_list.append('show bgp ipv6 unicast update-groups')

        # 'net show bgp neighbor' variations handled here
        elif vtysh_args.startswith('show bgp neighbor') or re_show_bgp_vrf_neighbor:

            # FRR is a bit odd on this command, if you specify an afi/safi
            # such as "ipv4 unicast" then you must also specify
            # "advertised-routes", "received-routes", or "routes". This
            # oddity is enforced in the NCLU parse tree.

            # If the user did NOT specify an afi/safi but they are trying
            # to view advertised-routes, etc for a peer we must default
            # that to "ipv4 unicast" to be consistent with other bgp
            # show/configuration behavior.
            if ((not args.get('ipv4') and not args.get('ipv6')) and
                (args.get('advertised-routes') or args.get('received-routes') or args.get('routes'))):
                vtysh_args = vtysh_args.replace('neighbor', 'ipv4 unicast neighbor')

            vtysh_args_list.append(vtysh_args)

        # Nothing special for these, just run as they are
        elif (vtysh_args.startswith('show bgp ipv4 unicast') or
              vtysh_args.startswith('show bgp ipv4 labeled-unicast') or
              vtysh_args.startswith('show bgp ipv6 unicast') or
              vtysh_args.startswith('show bgp neighbor')):
            vtysh_args_list.append(vtysh_args)

        # Nothing special for show bgp evpn commands, just run as they are
        elif (vtysh_args.startswith('show bgp l2vpn evpn')):
            vtysh_args_list.append(vtysh_args)

        elif re_show_bgp_vrf_summary:
            vrf = re_show_bgp_vrf_summary.group(1)

            if 'json' in vtysh_args:
                bgp_vrf_summary_combined = vrf
            else:
                vtysh_args_list.append('show bgp vrf %s ipv4 unicast summary' % vrf)
                vtysh_args_list.append('show bgp vrf %s ipv6 unicast summary' % vrf)
                vtysh_args_list.append('show bgp vrf %s l2vpn evpn summary' % vrf)

        # If we are here then we are running this command:
        # frr show bgp (<ipv4>|<ipv4/prefixlen>|<ipv6>|<ipv6/prefixlen>) [bestpath|multipath] [json]
        #
        # So we must look to see if we are dealing with an IPv4 prefix or an IPv6 prefix
        # and add 'ipv4 unicast' or 'ipv6 unicast' to the command
        else:

            # For now vrf is ipv4 only but you can only do
            if args.get('vrf'):

                if args.get('ipv4') and args.get('unicast'):
                    vtysh_args_list.append(vtysh_args)

                elif args.get('ipv6') and args.get('unicast'):
                    vtysh_args_list.append(vtysh_args)

                elif args.get('<ipv4>') or args.get('<ipv4/prefixlen>'):
                    tmp = vtysh_args.split()
                    vtysh_args = ' '.join(tmp[0:4] + ['ipv4', 'unicast'] + tmp[4:])
                    vtysh_args_list.append(vtysh_args)

                elif args.get('<ipv6>') or args.get('<ipv6/prefixlen>'):
                    tmp = vtysh_args.split()
                    vtysh_args = ' '.join(tmp[0:4] + ['ipv6', 'unicast'] + tmp[4:])
                    vtysh_args_list.append(vtysh_args)

                elif args.get("update-groups"):
                    vtysh_args_list.append(vtysh_args)

                else:
                    # show bgp vrf <vrfname> appending with ipv4/ipv6
                    if '<text>' in args:
                        vtysh_args_list.append(vtysh_args + ' ipv4 unicast')
                        vtysh_args_list.append(vtysh_args + ' ipv6 unicast')
                    # This covers 'show bgp vrfs', configured vrfs list.
                    else:
                        vtysh_args_list.append(vtysh_args)

            elif args.get('<ipv4>') or args.get('<ipv4/prefixlen>'):
                vtysh_args = vtysh_args.replace('show bgp', 'show bgp ipv4 unicast')
                vtysh_args_list.append(vtysh_args)

            elif args.get('<ipv6>') or args.get('<ipv6/prefixlen>'):
                vtysh_args = vtysh_args.replace('show bgp', 'show bgp ipv6 unicast')
                vtysh_args_list.append(vtysh_args)

            else:
                vtysh_args_list.append(vtysh_args)

    # frr show route [vrf <text>] [<ipv4>|<ipv4/prefixlen>|<ipv6>|<ipv6/prefixlen>|bgp|connected|ospf|static|summary]
    # frr show route [vrf <text>] (<ipv4/prefixlen>|<ipv6/prefixlen>) longer-prefixes
    elif vtysh_args.startswith('show route') and not vtysh_args.startswith('show route-map'):
        re_show_route_vrf = re.search('^show route vrf (\S+)(.*)', vtysh_args)
        vrf = re_show_route_vrf.group(1) if re_show_route_vrf else None

        if vtysh_args == 'show route summary':
            vtysh_args_list.append('show ip route summary')
            vtysh_args_list.append('show ipv6 route summary')

        elif vtysh_args == 'show route':
            vtysh_args_list.append('show ip route')
            vtysh_args_list.append('show ipv6 route')

        elif vtysh_args == 'show route ipv4':
            vtysh_args_list.append('show ip route')

        elif vtysh_args == 'show route ipv4 json':
            vtysh_args_list.append('show ip route json')

        elif vtysh_args == 'show route ipv6':
            vtysh_args_list.append('show ipv6 route')

        elif vtysh_args == 'show route ipv6 json':
            vtysh_args_list.append('show ipv6 route json')

        elif re_show_route_vrf and not (args.get('<ipv4>') or args.get('<ipv4/prefixlen>') or args.get('<ipv6>') or args.get('<ipv6/prefixlen>')):
            show_options = re_show_route_vrf.group(2).strip()

            if show_options == 'ipv4':
                vtysh_args_list.append('show ip route vrf %s' % vrf)

            elif show_options == 'ipv4 json':
                vtysh_args_list.append('show ip route vrf %s json' % vrf)

            elif show_options == 'ipv6':
                vtysh_args_list.append('show ipv6 route vrf %s' % vrf)

            elif show_options == 'ipv6 json':
                vtysh_args_list.append('show ipv6 route vrf %s json' % vrf)

            else:
                vtysh_args_list.append('show ip route vrf %s %s' % (vrf, show_options))
                vtysh_args_list.append('show ipv6 route vrf %s %s' % (vrf, show_options))

                if 'json' in vtysh_args:
                    route_vrf_json_combined = True

        else:
            if args.get('<ipv6>') or args.get('<ipv6/prefixlen>') or args.get('ospf6') or args.get('ripng') or args.get('ipv6'):
                vtysh_args = vtysh_args.replace('show route', 'show ipv6 route')

            else:
                vtysh_args = vtysh_args.replace('show route', 'show ip route')

            if 'json' not in vtysh_args:
                # When ip_route_show() is called we will print the kernel entry for this route
                # so print a little header here so the user can tell which is which
                header = "RIB entry for %s" % vtysh_args.split()[-1]
                if vrf:
                    header += " in vrf %s" % vrf
                result.append("%s\n%s" % (header, '=' * len(header)))
            vtysh_args_list.append(vtysh_args)

    # Change "clear ip bgp all" to "clear ip bgp *"
    elif 'clear' in vtysh_args and 'bgp' in vtysh_args and 'all' in vtysh_args:
        vtysh_args_list.append(vtysh_args.replace(' all', ' *'))

    elif vtysh_args == 'show debugs':
        vtysh_args_list.append('show debugging')

    else:
        vtysh_args_list.append(vtysh_args)

    if bgp_vrf_summary_combined:
        vrf = bgp_vrf_summary_combined

        try:
            ipv4_output = check_output(['/usr/bin/vtysh', '-c', 'show ip bgp vrf %s summary json' % vrf])
            ipv6_output = check_output(['/usr/bin/vtysh', '-c', 'show bgp vrf %s summary json' % vrf])

            if 'No such BGP instance exist' in ipv4_output:
                ipv4_output = '{}'

            if 'No such BGP instance exist' in ipv6_output:
                ipv6_output = '{}'

            result.append("""{
"ipv4 unicast" : %s,
"ipv6 unicast" : %s
}
""" % (ipv4_output, ipv6_output))

        except CalledProcessError as e:
            log.debug("bgp_summary_combined returned with error:\n%s\n" % e)
            result.append("{}")

    elif bgp_summary_combined:
        try:
            ipv4_output = check_output(['/usr/bin/vtysh', '-c', 'show bgp ipv4 unicast summary json'])
            ipv6_output = check_output(['/usr/bin/vtysh', '-c', 'show bgp ipv6 unicast summary json'])
            evpn_output = check_output(['/usr/bin/vtysh', '-c', 'show bgp l2vpn evpn summary json'])
            result.append("""{
"ipv4 unicast" : %s,
"ipv6 unicast" : %s,
"l2vpn evpn" : %s
}
""" % (ipv4_output, ipv6_output, evpn_output))
        except CalledProcessError as e:
            log.info("bgp_summary_combined returned with error:\n%s\n" % e)
            result.append("{}")

    elif route_vrf_json_combined:

        try:
            ipv4_output = check_output(['/usr/bin/vtysh', '-c', vtysh_args_list[0]])
            ipv6_output = check_output(['/usr/bin/vtysh', '-c', vtysh_args_list[1]])

            result.append("""{
"ipv4 unicast" : %s,
"ipv6 unicast" : %s
}
""" % (ipv4_output, ipv6_output))

        except CalledProcessError as e:
            log.info("bgp_summary_combined returned with error:\n%s\n" % e)
            result.append("{}")

    else:
        print_header = True if len(vtysh_args_list) > 1 else False

        for vtysh_args in vtysh_args_list:
            command = ['/usr/bin/vtysh', '-c', vtysh_args]

            if show_linux_command and 'json' not in vtysh_args:
                result.append("exec 'vtysh -c \"%s\"'\n" % vtysh_args)

            if print_header:
                result.append("\n%s\n%s" % (vtysh_args, '=' * len(vtysh_args)))

            try:
                output = check_output(command, stderr=STDOUT)
                result.append(output)
            except CalledProcessError as e:
                # This is the execution path if frr.service is not running or if /usr/bin/vtysh fails
                # for some reason.
                #
                # This is not the execution path if a relevant service other than frr.service, such
                # as pimd or ospfd, is not running.
                output = "The call to /usr/bin/vtysh failed.  Is frr.service running?."

            # For "show route" also show the kernel route
            if vtysh_args.startswith("show ip route") or vtysh_args.startswith("show ipv6 route"):
                result.append(ip_route_show(vtysh_args, output))

    return "\n".join(result)


def execute_command_show_clear(net_daemon, ifnames, bgppeers):
    cli = net_daemon.nclu_parser
    tokens = net_daemon.nclu_parser.args
    command = []
    messages = {"output": ''}

    for node in cli.match[1:]:
        if node.value:
            if node.value.text == "<interface>":
                command.append(node.value.text)
            elif node.value.text.startswith('<'):
                command.append(node.value.value)
            else:
                command.append(node.value.text)

        # Default afi to "ipv4" and safi to "unicast".
        else:
            if str(node) == "[ipv4|ipv6]":
                command.append("ipv4")
            elif str(node) == "[unicast|multicast]":
                command.append("unicast")
            elif str(node) == "[ipv4 unicast|ipv6 unicast]":
                command.append("ipv4")
                command.append("unicast")

    vtysh_args = ' '.join(map(str, command))

    # Support show commands with globs of interfaces.
    # Ex: net show ospf interface swp3-4
    if ifnames:
        for ifname in ifnames:
            vtysh_args_for_ifname = vtysh_args.replace("<interface>", ifname)
            messages["output"] += exec_vtysh_show_or_clear(tokens, vtysh_args_for_ifname)
    elif bgppeers:
        for peer in bgppeers:
            vtysh_args_for_bgppeer = vtysh_args.replace("<bgppeer>", peer)
            messages["output"] += exec_vtysh_show_or_clear(tokens, vtysh_args_for_bgppeer)
    else:
        messages["output"] += exec_vtysh_show_or_clear(tokens, vtysh_args)

    return (True, messages)


def sanitize_passwords(text):
    """
    Use this function to remove FRR passwords from the given text.  According to vtysh, the
    relevant syntax includes:

    ubuntu-bionic# find passw
      (config)  service password-encryption
      (config)  no service password-encryption
      (config)  password [(8-8)] LINE
      (config)  no password
      (config)  enable password [(8-8)] LINE
      (config)  no enable password
      (config)  username WORD nopassword
      (interface)  isis password <md5|clear> WORD
      (interface)  no isis password [<md5|clear> WORD]
      (bgp)  neighbor <A.B.C.D|X:X::X:X|WORD> password LINE
      (bgp)  no neighbor <A.B.C.D|X:X::X:X|WORD> password [LINE]
      (ldp)  [no] neighbor A.B.C.D$neighbor password WORD$password
      (isis)  area-password clear WORD [authenticate snp <send-only|validate>]
      (isis)  area-password md5 WORD [authenticate snp <send-only|validate>]
      (isis)  domain-password clear WORD [authenticate snp <send-only|validate>]
      (isis)  domain-password md5 WORD [authenticate snp <send-only|validate>]
      (isis)  no <area-password|domain-password>
    """

    text = re.sub(r"""((?:enable\s+)?password(?:\s+8)?\s+)\S+$""", r"""\1XXX""", text, flags=re.MULTILINE)
    text = re.sub(r"""((?:area|domain)-password\s+(?:md5|clear)\s+)\S+""", r"""\1XXX""", text, flags=re.MULTILINE)
    return text


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)7s: %(message)s")
    doctest.testmod()
