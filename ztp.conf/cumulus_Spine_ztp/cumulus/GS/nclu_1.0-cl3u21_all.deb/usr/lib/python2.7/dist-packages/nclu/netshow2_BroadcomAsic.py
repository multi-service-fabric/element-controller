"""
Copyright (C) 2017 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement
available at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

import re
from os.path import exists

PORTTAB = '/var/lib/cumulus/porttab'
BCMD = '/etc/bcm.d/config.bcm'


class BroadcomAsic(object):
    """
    class with functions to get names and initial port speed from broadcom
    This class works with Broadcom chips with multiple phys
    """

    def __init__(self):
        self.asichash = { 'name': 'broadcom' }  # interface --> asic
        self.asichash_reverse = {}              # asic --> interface

    def parse_speed_and_name_info(self):
        self.parse_ports_file()
        self.parse_initial_speed_file()
        return self.asichash

    def parse_ports_file(self):
        """
        Parse the porttab file to generate a mapping between interface
        names and asic port names.

        The resulting asichash looks like:
            {
                'name': 'broadcom',
                'swp1s0': {
                        'asicname': 'xe0.0',
                    },
                'swp1s1': {
                        'asicname': 'xe0.1',
                    },
                ...
            }

        The resulting asichash_reverse looks like:
            {
                'xe0.0': 'swp1s0',
                'xe0.1': 'swp1s1',
                ...
            }
        """

        if not exists(PORTTAB):
            # TODO - Log this.
            return

        try:
            with open(PORTTAB) as f:
                porttab = f.read()
        except IOError:
            # TODO - Log this.
            return

        # Asic names (sdk_intf; the second captured group) are letters followed by numbers.  Ex: ce1, ge0, xe8
        mappings = re.findall(r"""^(swp\d+(?:s\d+)?)\s+([a-z]+\d+)\s+(\d+)""", porttab, re.IGNORECASE | re.MULTILINE)

        for linux_intf, sdk_intf, unit in mappings:
            asicname = "{0}.{1}".format(sdk_intf, unit)
            self.asichash[linux_intf] = {'asicname': asicname}
            self.asichash_reverse[asicname] = linux_intf

    def get_asicname_for_unit(self, unit):
        """
        Given a unit number, return the associated key in self.asichash_reverse.
        This method returns the first matching key.  There should be only one
        match, but this is not tested.

        If no match is found, return None.

        unit - A string of a number (ex. '50')
        """

        if '.' not in unit:
            unit += '.0'

        asicname_re = re.compile(r"""[a-z]{0}$""".format(unit), re.IGNORECASE)

        for key in self.asichash_reverse:
            if asicname_re.search(key) is not None:
                return key

        # TODO - Log that the asic name is not in asichash_reverse.
        return None


    def parse_initial_speed_file(self):
        """
        Parses initial speed information from the broadcom initialization file,
        and add this information to the asichash attribute.
        """

        if not exists(BCMD):
            return

        try:
            with open(BCMD) as f:
                bcmd = f.read()
        except IOError:
            return

        #                                        unit    speed
        inits = re.findall(r"""^port_init_speed_([\w.]+)=(\d+)""", bcmd, re.IGNORECASE | re.MULTILINE)

        for unit, speed in inits:
            asicname = self.get_asicname_for_unit(unit)

            if asicname is not None:
                interface = self.asichash_reverse[asicname]
                self.asichash[interface]['initial_speed'] = int(speed)
