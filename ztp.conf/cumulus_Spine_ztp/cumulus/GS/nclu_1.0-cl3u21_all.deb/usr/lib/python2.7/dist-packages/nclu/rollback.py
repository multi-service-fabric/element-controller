"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from collections import OrderedDict
from nclu import tabulate_remove_unicode
from nclu.plugins import DYNAMIC_RESTART, format_messages, run_commands
from pprint import pformat
from subprocess import CalledProcessError, check_output, Popen, STDOUT
from tabulate import tabulate
from threading import Thread, Event
from time import sleep
import logging
import nclu.execute_command

log = logging.getLogger("netd")


class FutureRollback(Thread):
    """
    When the user does "net commit confirm", an instance of FutureRollback will be created.
    FutureRollback will revert the commit unless the user presses <ENTER> within "seconds".
    """

    def __init__(self, uid, gid, rollback_target, seconds, future_rollbacks):
        Thread.__init__(self)
        self.uid = uid
        self.gid = gid
        self.seconds = seconds
        self.rollback_target = rollback_target
        self.future_rollbacks = future_rollbacks
        self.shutdown_event = Event()

    def run(self):

        # Sleep for self.seconds, but wake up every 1s to see if we've been asked to terminate.
        for x in xrange(self.seconds):
            if self.shutdown_event.is_set():
                return
            sleep(1)

        log.info("The user did not press <ENTER> after \"net commit confirm\".  Rolled back to {0}.".format(self.rollback_target))
        Popen(["/usr/bin/net", "rollback", self.rollback_target])

        # Delete this instance from future_rollbacks.
        rollback_instance = self.future_rollbacks.get((self.uid, self.gid))

        if rollback_instance is not None:
            del self.future_rollbacks[(self.uid, self.gid)]


def snapper_entries():
    """
    Return a dictionary from the "snapper list" output.  For example:

    Type   | #  | Pre # | Date                            | User | Cleanup | Description           | Userdata
    -------+----+-------+---------------------------------+------+---------+-----------------------+---------
    single | 0  |       |                                 | root |         | current               |
    single | 1  |       | Tue 14 Jun 2016 01:25:52 AM UTC | root |         | first root filesystem |
    pre    | 12 |       | Thu 16 Jun 2016 11:13:22 AM UTC | root |         | net-commit-pre        |
    post   | 13 | 12    | Thu 16 Jun 2016 11:13:24 AM UTC | root |         | net-commit-post       |
    """

    last_snapshot_id = None
    entries = OrderedDict()

    try:
        output = check_output(["/usr/bin/snapper", "list"])
    except CalledProcessError:
        output = ''

    # Ignore the table header while iterating throught the lines of the output.
    for line in output.splitlines()[2:]:

        try:
            (snapshot_type, snapshot_id, pre, date, user, cleanup, desc, userdata) = map(str.strip, line.split('|'))
        except ValueError:
            log.debug("This line from the output of \"snapper list\" raised ValueError:\n{0}".format(line))
            continue

        snapshot_id = int(snapshot_id)
        pre = int(pre) if pre else None

        entries[snapshot_id] = {
            "type": snapshot_type,
            "id": snapshot_id,
            "pre": pre,
            "date": date,
            "user": user,
            "cleanup": cleanup,
            "desc": desc,
            "userdata": userdata,
        }

        last_snapshot_id = snapshot_id

    return (entries, last_snapshot_id)


def snapper_last_nclu_pre_commit():
    """
    Return the ID of the most recent pre-commit.
    """

    entries, _ = snapper_entries()
    last_nclu_pre_commit = None

    for snapshot in entries.itervalues():
        if snapshot["type"] == "pre" and snapshot["desc"].startswith("nclu "):
            last_nclu_pre_commit = snapshot["id"]

    return last_nclu_pre_commit


def snapper_show(start, stop, wrappers, plugins, color_diffs):
    """
    If the user did not specify a snapshot, return the "snapper list" output.
    Otherwise, return the delta from start->stop for all of the files managed by NCLU.
    """

    assert start is None or isinstance(start, int)
    assert stop is None or isinstance(stop, int)

    entry, _ = snapper_entries()

    if start is None:
        # Return a list of all snapshots.
        header = ('#', "Date", "Description")
        data = [(snapshot["id"], snapshot["date"], snapshot["desc"]) for snapshot in entry.itervalues() \
            if snapshot["desc"].startswith("nclu") and snapshot["type"] == "pre"]
        return (True, tabulate(tabulate_remove_unicode(data), header))

    if start not in entry:
        return (False, "Snapshot #{0} is not a NCLU related snapshot.".format(start))

    if stop is None:
        snapshot_start = entry[start]

        if snapshot_start["type"] == "post":
            stop = start
            start = entry[stop]["pre"]
        elif snapshot_start["type"] == "pre":
            for snapshot in entry.itervalues():
                if snapshot["type"] == "post" and snapshot["pre"] == start:
                    stop = snapshot["id"]
                    break
        else:
            stop = start + 1

    if stop not in entry:
        return (False, "Snapshot #{0} is not a NCLU related snapshot.".format(stop))

    managed_files = get_all_managed_files(wrappers, plugins)  # A set

    reply = ''

    for filename in managed_files:
        try:
            output = check_output(["/usr/bin/snapper", "diff", "{0}..{1}".format(start, stop), filename], stderr=STDOUT)

            if color_diffs:
                for line in output.splitlines():
                    # Display the deletes in red and the adds in green.

                    if line.startswith("---") or line.startswith("+++"):
                        reply += "\033[94m{0}\033[0m\n".format(line)
                    elif line.startswith('-'):
                        reply += "\033[91m{0}\033[0m\n".format(line)
                    elif line.startswith('+'):
                        reply += "\033[92m{0}\033[0m\n".format(line)
                    else:
                        reply += line + '\n'
            else:
                reply = output

        except CalledProcessError:
            # There was no change for the filename between the start and stop snapshots.  This is okay.
            pass

    return (True, reply)


def snapper_create_pre(description, permanent):
    """
    Using Snapper, create a "pre" snapshot, and return the snapshot number as a string.
    If the snapshot number cannot be retreived, return None.
    """

    assert isinstance(description, str)
    assert isinstance(permanent, bool)

    # Do not allow '|' in the description because we will split on that character.
    description = description.replace('|', ' ')

    command = ["/usr/bin/snapper",
               "create",
               "-d", description,
               "--type", "pre",
               "--print-number"]

    if not permanent:
        command.extend(["-c", "number"])

    # Not all systems support Snapper.
    try:
        pre_snapshot_number = check_output(command, stderr=STDOUT).strip()

        # Snapper might print some messages.  The snapshot number will be the last line of the output.
        pre_snapshot_number = pre_snapshot_number.splitlines()[-1]

        # Snapper can fail, print an error message, and still exit 0.  Only honor the output if it is a number.
        if not pre_snapshot_number.isdigit():
            log.warning("\"{0}\" returned\n\n{1}\n\n".format(pformat(command), pre_snapshot_number))
            pre_snapshot_number = None

    except CalledProcessError as e:
        pre_snapshot_number = None
        log.exception(e)

    assert isinstance(pre_snapshot_number, str) or pre_snapshot_number is None
    return pre_snapshot_number


def snapper_create_post(description, pre_snapshot_number, permanent):
    """
    Using Snapper, create a "post" snapshot, and return the snapshot number as a string.
    If the snapshot number cannot be retreived, return None.
    """

    assert isinstance(description, str)
    assert isinstance(permanent, bool)

    # Do not allow '|' in the description because we will split on that character.
    description = description.replace('|', ' ')

    cmd = ["/usr/bin/snapper",
           "create",
           "-d", description,
           "--type", "post",
           "--pre-number", pre_snapshot_number,
           "--print-number"]

    if not permanent:
        cmd.extend(["-c", "number"])

    try:
        post_snapshot_number = check_output(cmd, stderr=STDOUT).strip()
    except CalledProcessError as e:
        post_snapshot_number = None
        log.exception(e)

    # TODO - This return value is never used (or even assigned).
    return post_snapshot_number


def get_rollback_id_from_description(target_desc):
    """
    Return a 2-tuples of (True, int) or (False, str).  If True, the second element is a rollback ID.
    If False, it is an error message.
    """

    assert isinstance(target_desc, str)

    if not target_desc.startswith("nclu"):
        target_desc = "nclu " + target_desc

    entry, _ = snapper_entries()
    snapshot_ids = [snapshot_id for (snapshot_id, value) in entry.iteritems() if value.get("type") == "pre" and value.get("desc") == target_desc]

    if len(snapshot_ids) == 1:
        return (True, snapshot_ids[0])

    message = "There are {0} snapshots with that description.  Use \"net show rollback <number>\" or \"net rollback <number>\" instead.".format(len(snapshot_ids))
    return (False, message)


def rollback(rollback_target, wrappers, plugins, user):
    """
    For each file that NCLU manages, revert that file to rollback_target via "snapper undochange".
    """

    entry, last_snapshot_id = snapper_entries()

    if rollback_target not in entry:
        return (False, "Snapshot #{0} is not a NCLU related snapshot.".format(rollback_target))

    nclu.execute_command.abort_pending(wrappers, plugins)
    desc = "nclu \"{0} rollback\" (user {1})".format(rollback_target, user)
    pre_snapshot_number = snapper_create_pre(desc, False)
    commands = []
    reply = ''

    # TODO - we need a better way to control the order in which these are applied
    #
    # We apply wrappers before plugins because ifupdown2 uses the wrapper model
    # and we need to apply the changes to /etc/network/interfaces first.

    # Rollback wrapper related files, and get a list of associated restart commands.
    assert len(wrappers) > 0, "If the wrappers paradigm has been removed, edit this function."
    for _, wrapper in wrappers:
        for filename in wrapper.get_managed_files():
            snapper_command = ["/usr/bin/snapper", "undochange", "{0}..{1}".format(rollback_target, last_snapshot_id), filename]
            try:
                check_output(snapper_command, stderr=STDOUT)
                commands.extend(wrapper.get_service_cmd_for_file(filename))
            except CalledProcessError:
                # Not all managed files will be part of the snapshot.  This is okay.
                pass

    # Rollback plug-in related files, and get a list of associated restart commands.
    for plugin in plugins:
        m = __import__("nclu.plugins." + plugin, fromlist=["get_managed_files", "get_restart_commands"])

        for filename in m.get_managed_files():
            snapper_undo_command = ["/usr/bin/snapper", "undochange", "{0}..{1}".format(rollback_target, last_snapshot_id), filename]
            try:
                check_output(snapper_undo_command, stderr=STDOUT)

                # The "snapper undochange" call succeeded.  Get any associated restart commands.
                if plugin in DYNAMIC_RESTART:
                    # The plug-in has non-static restart commands depending on the specific changes.
                    snapper_diff_command = ["/usr/bin/snapper", "diff", "{0}..{1}".format(last_snapshot_id, rollback_target), filename]
                    diff_lines = check_output(snapper_diff_command, stderr=STDOUT).splitlines()

                    try:
                        if plugin == "dns":
                            filename_commands, _, _ = m.get_restart_commands(filename, diff_lines)
                        else:
                            filename_commands = m.get_restart_commands(filename, diff_lines)
                        commands.extend(filename_commands)
                    except CalledProcessError:
                        reply += "WARNING: Couldn't get the restart commands for {0}.\n".format(plugin.upper())
                else:
                    commands.extend(m.get_restart_commands(filename))
            except CalledProcessError:
                # Not all managed files will be part of the snapshot.  This is okay.
                pass

    snapper_create_post(desc, pre_snapshot_number, False)

    # Perform "ifreload -a", "systemctl reload frr", etc.
    outcome, _, messages = run_commands(commands, False)
    reply += format_messages(messages, False)

    return (outcome, reply)


def rollback_show(rollback_target, wrappers, plugins, color_diffs):
    entry, last_snapshot_id = snapper_entries()

    if rollback_target not in entry:
        return (False, "Snapshot #{0} is not a NCLU related snapshot.".format(rollback_target))

    # We need to build a list of files that we manage that have changed between
    # the current state of the filesystem (snapshot 0) and rollback_target.
    # 'snapper status 0..rollback_target' will give us a list of all files that
    # changed, look through that output for the files that we manage.
    #
    # We need said list because we have to tell 'snapper diff' which files to diff.
    # If we ask it to diff a file that hasn't changed it will return non-zero.
    nclu_managed_files = get_all_managed_files(wrappers, plugins)
    nclu_managed_files_in_snapshot = []

    command = ["/usr/bin/snapper", "status", "0..{0}".format(rollback_target)]
    try:
        output = check_output(command)
    except CalledProcessError as e:
        return (False, "\"{0}\" failed due to \"{1}\".".format(' '.join(command), e.output.strip()))

    for line in output.splitlines():
        flags, filename = line.split()
        if filename in nclu_managed_files:
            nclu_managed_files_in_snapshot.append(filename)

    command = ["/usr/bin/snapper", "diff", "0..{0}".format(rollback_target)]
    command.extend(nclu_managed_files_in_snapshot)
    reply = ''

    try:
        output = check_output(command, stderr=STDOUT)

        if color_diffs:
            # Output the deletes in red and the adds in green.
            for line in output.splitlines():
                if line.startswith("---") or line.startswith("+++"):
                    reply += "\033[94m{0}\033[0m\n".format(line)
                elif line.startswith('-'):
                    reply += "\033[91m{0}\033[0m\n".format(line)
                elif line.startswith('+'):
                    reply += "\033[92m{0}\033[0m\n".format(line)
                else:
                    reply += line + '\n'
        else:
            reply = output

    except CalledProcessError:
        return (False, "\"{0}\" failed due to \"{1}\".".format(' '.join(command), e.output.strip()))

    return (True, reply)


def get_all_managed_files(wrappers, plugins):
    """
    Return a set of all files managed by the given wrappers and plugins.
    """

    assert len(wrappers) > 0, "If the wrappers paradigm has been removed, edit this function."

    managed_files = set()

    for plugin in plugins:
        m = __import__("nclu.plugins." + plugin, fromlist=["get_managed_files"])
        managed_files.update(m.get_managed_files())

    for _, wrapper in wrappers:
        managed_files.update(wrapper.get_managed_files())

    return managed_files
