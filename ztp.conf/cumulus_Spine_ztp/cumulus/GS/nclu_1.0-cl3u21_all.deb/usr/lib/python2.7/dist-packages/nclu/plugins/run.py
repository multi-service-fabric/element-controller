"""
Copyright (C) 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt

----------------------------------------------------------------------------------------

Usage:
    net run [<ipv6>|all] license-install path <text>
    net run [<ipv6>|all] reboot
    net run [<ipv6>|all] nos-install path <text>
    net run [<ipv6>|all] daemon restart <text>
    net run [<ipv6>|all] cl-support

Options:
    run             : Execute system level commands immediately.
    <ipv6>          : IPV6 address of an endpoint in a CLOS
    license-install : Install Cumulus OS license
    reboot          : Reboot endpoint in a CLOS
    nos-install     : Install a new Cumulus Linux binary image (Destructive!!!! Please backup important files.)
    daemon          : Cumulus Linux Daemon related operations
    restart         : Systemd restart of a service
    all             : Run a command on all connected hosts
    cl-support      : Generate a cl-support
    path            : URL or local file system path
"""

import cumulus.chassis
import httplib
import json
import logging
import ssl
from nclu.NetDaemon import NetDaemon
from subprocess import CalledProcessError, check_output, STDOUT

CERT_FILE = "/etc/ssl/certs/cumulus.pem"

log = logging.getLogger("netd")


# NetDaemon.reload looks for this.
per_command_helptext = {
    "net run": {
        "<ipv6>": "IPV6 address of an endpoint in a CLOS",
        "all": "Run a command on all connected hosts",
    },
    "net run [<ipv6>|all] (license-install|nos-install)": {"path": "URL or local file system path"},
    "net run [<ipv6>|all] license-install path": {"<text>": "License file name"},
    "net run [<ipv6>|all] nos-install path": {"<text>": "Installation image name"},
    "net run [<ipv6>|all] daemon": {"restart": "Systemd restart of a service"},
    "net run [<ipv6>|all] daemon restart": {"<text>": "Systemd service name"},
}


def commit_pending(verbose):
    """
    This plug-in does not have any managed files.  There is never anything to commit.
    """

    return (True, {"output": ''})


def show_config_commands(ifupdown2_wrapper):
    """
    net show configuration commands
    """

    return ([], [])


def show_config_summary(summary):
    """
    This plug-in has no associated configuration information.
    """

    assert isinstance(summary, dict)
    return


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """

    assert isinstance(net_daemon, NetDaemon)

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert "configuration" not in tokens, "\"net show configuration run\" does not use this code path."
    assert "run" in tokens, "Why are you here?"

    cli_kwargs = {
        "path": tokens["<text>"] if ("path" in tokens) else '',
        "ipv6": True if ("ipv6" in tokens) else None,               # TODO - modify downstream to expect True or False (versus None)
        "is_all": "all" in tokens,
        "daemon-name": tokens["<text>"] if ("daemon" in tokens) else '',
    }

    try:
        if "license-install" in tokens:
            return LicenseInstall()(cli_kwargs)
        elif "reboot" in tokens:
            return EndpointReboot()(cli_kwargs)
        elif "nos-install" in tokens:
            return NosInstall()(cli_kwargs)
        elif "daemon" in tokens:
            assert "restart" in tokens
            return DaemonReload()(cli_kwargs)
        elif "cl-support" in tokens:
            return CLSupport()(cli_kwargs)
        else:
            # This is a programming error.
            return (False, {"output": '', "error": ["NCLU does not recognize the command."]})
    except Exception as e:
        log.exception(e)
        return (False, {"output": '', "error": [str(e)]})


def del_all():
    """
    net del all

    This plug-in does not manage any files so there is never anything to delete.
    """

    return


def get_config_files():
    """ This plug-in does not manage any files. """

    return ''


def get_pending(use_colors):
    """ This plug-in does not manage any files, so there are never pending changes. """

    return ''


def abort_pending():
    return


def get_managed_files():
    """ This plug-in does not manage any files. """

    return []


def get_restart_commands(filename=None):
    """
    Return a list of commands that should be called for the given file after a rollback.
    Some plug-ins use this in commit_pending as well.
    """

    assert filename is None, "This plug-in does not have any associated files."
    return []


def chassis():
    """ Return a chassis instance or None (non-chassis). """

    try:
        return cumulus.chassis.probe()
    except RuntimeError:
        log.info("The switch is not a chassis.")

    # return None implicitly


def parse_v6_hosts(chassis_instance):
    assert chassis_instance is not None

    hosts_dict = {}
    v6hosts = chassis_instance.GetV6Hosts().split('\n')

    for host_entry in v6hosts:
        if "bmc" not in host_entry and host_entry != '':
            host_entry_list = host_entry.split()
            hosts_dict[host_entry_list[1].split('-')[0]] = host_entry_list[0]
    return hosts_dict


class CliBase(object):

    def __init__(self):
        self.chassis_or_none = chassis()
        self.hosts = parse_v6_hosts(self.chassis_or_none) if (self.chassis_or_none is not None) else {}

    def hostname(self):
        assert self.chassis_or_none is not None
        return self.chassis_or_none.GetModuleName()

    def linklocalscope(self):
        assert self.chassis_or_none is not None
        return self.chassis_or_none.GetMgmtIf()

    def exec_cmd_on_localhost(self, command):
        try:
            check_output(command, stderr=STDOUT)
        except CalledProcessError as e:
            log.error(e.output)
            log.exception(e)
            return (False, {"output": '', "error": ["\"{0}\" failed.  See the log.".format(command)]})

        return (True, {"output": ''})

    def exec_cmd_on_endpoint(self, post_request, ipv6addr=None):
        """
        Make an HTTP request to an NCLU endpoint implemented in python-cumulus-restapi.
        Return a boolean indicating if the request succeeded.
        """

        header = {"Content-Type": "application/json"}
        url = "https://[{0}]:8080/nclu/v1/rpc".format(ipv6addr)
        response = None
        httpconn = None

        try:
            context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
            context.verify_mode = ssl.CERT_REQUIRED
            context.load_verify_locations(cafile=CERT_FILE)
            httpconn = httplib.HTTPSConnection(ipv6addr + '%' + self.linklocalscope(), 8080, timeout=25, context=context)
            httpconn.request("POST", url, json.dumps(post_request), headers=header)
            response = httpconn.getresponse()

            # Log the response, if any.
            if response:
                log.info(response.read())
        except Exception as e:
            # TODO - Catch specific exceptions.
            error_message = "The HTTP request to {0} failed.  See the log.".format(url)
            log.error(e.args[1])
            log.exception(e)
            log.error("POST data: {0}".format(json.dumps(post_request)))
            return (False, {"output": '', "error": [error_message]})
        finally:
            if httpconn:
                httpconn.close()

        return (True, {"output": ''})

    def exec_cmd_entire_chassis(self, post_request, command):
        ret_val = True
        messages = {"output": '', "error": []}
        header = {"Content-Type": "application/json"}

        hosts_status = {}
        for host in self.hosts.iterkeys():
            hosts_status[host] = {
                "status": '',
                "response_str": '',
                "conn_obj": None,
            }

        context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
        context.verify_mode = ssl.CERT_REQUIRED
        context.load_verify_locations(cafile=CERT_FILE)

        for host, addr in self.hosts.iteritems():
            if host != self.hostname():
                try:
                    hosts_status[host]["conn_obj"] = httplib.HTTPSConnection(addr + '%' + self.linklocalscope(),
                                                                            8080, timeout=25, context=context)
                    conn = hosts_status[host]["conn_obj"]
                    conn.request("POST", "https://[{0}]:8080/nclu/v1/rpc".format(addr), json.dumps(post_request), headers=header)
                except Exception:
                    # TODO - Catch specific exceptions.
                    hosts_status[host]["conn_obj"] = None
                    hosts_status[host]["status"] = "FAIL!"
                    ret_val = False

        for host, data in hosts_status.iteritems():
            log.info('*' * 80)
            log.info(host)
            response_str = ''

            if host != self.hostname():
                conn = data["conn_obj"]

                if conn is not None:
                    response = conn.getresponse()
                    if response.status != 200:
                        data["status"] = "FAIL!"
                        ret_val = False
                    response_str = response.read()

                if data["status"] == "FAIL!":
                    log.info("FAIL!")
                    messages["error"].append("\"{0}\" failed on host {1}.".format(command, host))
                elif response_str == '':
                    log.info("SUCCESS!")
                else:
                    log.info(response_str)
                    log.info("FAIL!")
                    messages["error"].append("\"{0}\" failed on host {1}.".format(command, host))
            else:
                if ret_val:
                    # None of the hosts have failed.  Execute on local host.
                    if self.exec_cmd_on_localhost(command):
                        log.info("SUCCESS!")
                    else:
                        log.info("FAIL!")
                        messages["error"].append("\"{0}\" failed on localhost.".format(command))
                else:
                    # At least one host failed.
                    log.info("FAIL!")
            log.info('*' * 80)

        if not messages["error"]:
            del messages["error"]

        return (ret_val, messages)

    def exec_cmd(self, ipv6addr, is_all, post_request, cmd):

        if ipv6addr is None and not is_all:
            # Execute on the local machine only.
            return self.exec_cmd_on_localhost(cmd)
        elif ipv6addr:
            # Execute on a single endpoint.
            return self.exec_cmd_on_endpoint(post_request, ipv6addr)

        # Execute on all.
        return self.exec_cmd_entire_chassis(post_request, cmd)


class LicenseInstall(CliBase):
    def __call__(self, cli_dict):
        license_path = cli_dict["path"]
        ipv6addr = cli_dict["ipv6"]
        is_all = cli_dict["is_all"]
        post_request = {"cmd": "run license-install path " + license_path}
        license_install_cmd = ["/usr/cumulus/bin/cl-license", "-i", license_path]

        return self.exec_cmd(ipv6addr, is_all, post_request, license_install_cmd)


class EndpointReboot(CliBase):
    def __call__(self, cli_dict):
        ipv6addr = cli_dict["ipv6"]
        is_all = cli_dict["is_all"]
        reboot_cmd = ["/sbin/reboot"]
        post_request = {"cmd": "run reboot"}

        return self.exec_cmd(ipv6addr, is_all, post_request, reboot_cmd)


class NosInstall(CliBase):
    def __call__(self, cli_dict):
        image_path = cli_dict["path"]
        ipv6addr = cli_dict["ipv6"]
        is_all = cli_dict["is_all"]
        post_request = {"cmd": "run nos-install path " + image_path}
        onie_install_cmd = ["/usr/cumulus/bin/onie-install", "-a", "-f", "-i", image_path]

        return self.exec_cmd(ipv6addr, is_all, post_request, onie_install_cmd)


class DaemonReload(CliBase):
    def __call__(self, cli_dict):
        daemon = cli_dict["daemon-name"]
        ipv6addr = cli_dict["ipv6"]
        is_all = cli_dict["is_all"]
        post_request = {"cmd": "run daemon restart " + daemon}
        daemon_restart_cmd = ["/bin/systemctl", "restart", daemon + ".service"]

        return self.exec_cmd(ipv6addr, is_all, post_request, daemon_restart_cmd)


class CLSupport(CliBase):
    def __call__(self, cli_dict):
        ipv6addr = cli_dict["ipv6"]
        is_all = cli_dict["is_all"]
        post_request = {"cmd": "run cl-support"}
        cl_support_cmd = ["/usr/cumulus/bin/cl-support"]

        return self.exec_cmd(ipv6addr, is_all, post_request, cl_support_cmd)
