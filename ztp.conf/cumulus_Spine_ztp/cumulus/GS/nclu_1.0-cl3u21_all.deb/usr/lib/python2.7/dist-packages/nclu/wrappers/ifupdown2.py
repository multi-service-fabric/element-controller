"""
Copyright (C) 2016, 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt


Usage:
    # Interface configuration
    iface del bond <interface>
    iface (add|del) bridge
    iface (add|del) bridge <interface>
    iface (add|del) bridge <interface> ports <interface-list>
    iface (add|del) bridge <interface> ip address <ipv4/prefixlen>
    iface (add|del) bridge <interface> ipv6 address <ipv6/prefixlen>
    iface add loopback lo
    iface (add|del) vrf <interface>
    iface (add|del) vrf mgmt

    iface (add|del) interface <interface>
    iface del vxlan <interface>
    iface (add|del) bond <interface> bridge trunk [vlans <number-range-list>]
    iface (add|del) interface <interface> bridge trunk [vlans <number-range-list>]
    iface add interface <interface> bridge voice-vlan <1-4094> [data-vlan <1-4094>]
    iface del interface <interface> bridge voice-vlan [<1-4094>] [data-vlan <1-4094>]
    iface (add|del) vlan <number-range-list>
    iface add clag peer sys-mac <mac-clag> interface <interface> (primary|secondary) [backup-ip <ipv4>]
    iface add clag peer sys-mac <mac-clag> interface <interface> (primary|secondary) [backup-ip <ipv4> vrf <text>]
    iface del clag peer
    iface add clag port bond <interface> interface <interface> clag-id <0-65535>
    iface del clag port bond <interface>

    iface show clag [our-macs|our-multicast-entries|our-multicast-router-ports|peer-macs|peer-multicast-entries|peer-multicast-router-ports|params|backup-ip|id] [verbose] [json]
    iface show clag macs [<mac>] [json]
    iface show clag neighbors [verbose]
    iface show clag peer-lacp-rate
    iface show clag verify-vlans [verbose]
    iface show clag status [verbose] [json]
    iface show bridge macs [<mac>|vlan <number>|<ip>|permanent|dynamic] [json]
    iface show bridge (link|mdb)
    iface show bridge spanning-tree [<interface>] [json]
    iface show bridge spanning-tree detail [json]
    iface show bridge vlan [<number>] [json]

Options:

    0                            : 0, False, etc
    1                            : 1, True, etc
    4096                         : 4096
    8192                         : 8192
    12288                        : 12288
    16384                        : 16384
    20480                        : 20480
    24576                        : 24576
    28672                        : 28672
    36864                        : 36864
    40960                        : 40960
    45056                        : 45056
    49152                        : 49152
    53248                        : 53248
    57344                        : 57344
    61440                        : 61440
    100                          : 100M
    1000                         : 1G
    10000                        : 10G
    25000                        : 25G
    50000                        : 50G
    100000                       : 100G
    40000                        : 40G
    <interface-as-arg>           : An interface name "swp1" or glob "swp1-4 6 10-12"
    <interface-list>             : Example: "swp1 swp2 swp3"
    <interface-range-list>       : Example: "swp1=100 swp2=100"
    <interface-yes-no-0-1-list>  : Example: "swp1=yes swp2=no swp3=1,swp4=0"
    <interface-yes-no-auto-list> : Example: "swp1=yes swp2=no swp3=auto"
    <interface-yes-no-list>      : Example: "swp1=yes swp2=no"
    <interface-on-off-list>      : Example: "swp1=on swp2=off"
    <interface>                  : An interface name "swp1" or glob "swp1-4 6 10-12"
    <ip/prefixlen>               : An IPv4 or IPv6 address and prefix length
    <ip>                         : An IPv4 or IPv6 Address
    <ipv4-vrf-text>              : Example: "<ipv4> vrf <text>"
    <ipv4/prefixlen>             : An IPv4 address and prefix length
    <ipv4>                       : An IPv4 address
    <ipv6/prefixlen>             : An IPv6 address and prefix length
    <ipv6>                       : An IPv6 address
    <mac-ip/prefixlen-list>      : Example: "00:11:22:33:44:01 10.0.0.1/24 10.0.1.2/24"
    <mac>                        : A MAC address
    <mac-clag>                   : A MAC address from the 44:38:39:FF:00:00 to 44:38:39:FF:FF:FF range
    <number-interface-list>      : Example: "4 swp1 swp2"
    <number-ipv4-list>           : Example: "100=10.0.100.1 101=10.101.1"
    <number-range-list>          : Example: "1-5,8,10-12,15"
    <number-comma-range-list>    : Example: "1-5,8,10-12,15"
    <number>                     : Any integer
    <text>                       : Any text
    auto                         : Automatically
    autoneg                      : Auto negotiation
    backup-ip                    : Displays backup link info
    baser                        : Forward error correction mode
    basic-clag                   : Introduction to CLAG/MLAG configuration
    bond                         : Bond, port-channel, etc
    bond-slaves                  : Add physical ports to a bond
    bridge                       : A layer2 bridge
    trunk                        : A layer2 trunk, 'bridge trunk' is an alias for 'bridge vids'
    clag                         : Multi-Chassis Link Aggregation
    configuration                : Settings, configuration state, etc
    detail                       : Show detailed output
    details                      : Show detailed output
    dynamic                      : MACs learned dynamically
    duplex                       : Link duplex
    fec                          : Forward Error Correction
    full                         : Full duplex
    half                         : Half duplex
    hostname                     : System hostname
    id                           : Identifier
    ip                           : Internet Protocol version 4
    ipv6                         : Internet Protocol version 6
    l2protocol-tunnel            : layer 2 protocol tunneling
    l2-with-server-vlan-trunks   : Traditional high scale L2/virtualization deployment
    l3-uplinks-virtual-address   : Modern network virtualization/containter deployment
    link                         : An interface
    link-settings                : Physical link parameters
    lo                           : The loopback interface name
    loopback                     : A loopback interface
    macs                         : Media Access Control addresses
    mdb                          : Multicast group database entry
    mgmt                         : Management VRF
    multicast-querier            : Ipv4 multicast querier
    no                           : Negative, disable, etc
    off                          : Disable
    on                           : Enable
    our-macs                     : Displays the MACs learned on this switch
    our-multicast-entries        : Displays the multicast entries learned on this switch
    our-multicast-router-ports   : Displays the multicast router ports learned on this switch
    params                       : Display the parameters in use by clagd
    peer-lacp-rate               : Displays the peer's polling rate
    peer-macs                    : Displays the MACs learned on the peer switch
    peer-multicast-entries       : Displays the multicast entries learned on the peer switch
    peer-multicast-router-ports  : Displays the multicast router ports learned on the peer switch
    permanent                    : Intended to exist or function for a long, indefinite period
    rs                           : Reed-Solomon
    spanning-tree                : STP - Spanning Tree Protocol
    speed                        : Link speed
    status                       : Status
    verbose                      : Show detailed output
    verify-vlans                 : Verifies VLAN configuration with the peer
    version                      : Version number
    vlan                         : Virtual Local Area Network
    vlan-interfaces              : IP interfaces for VLANs
    vlans                        : Virtual Local Area Networks
    voice-vlan                   : VLAN used for IP Phones
    data-vlan                    : Native Vlan used in Voice Vlan for data traffic
    vni                          : VXLAN Network Identifier
    vrf <text>                   : Virtual Routing and Forwarding
    vxlan                        : Virtual Extensible LAN
    yes                          : Positive, enable, etc

    allow-untagged               : A bridge port interface may allow untagged packets
    args                         : Command line arguments
    bpduguard                    : Bridge Protocol Data Unit guard
    down                         : Disable, turn off, etc
    enable                       : To make able
    host                         : An end station
    igmp-querier-src             : Bridge igmp querier source
    lacp-bypass-allow            : Allow LACP bypass
    lacp-rate                    : Bond LACP rate
    mcquerier                    : Multicast querier
    mcsnoop                      : Multicast snooping
    miimon                       : Bond miimon
    min-links                    : Bond minimum number of links
    peer                         : A BGP, OSPF, PIM, etc neighbor
    peer-ip                      : The IP address of our peer
    portadminedge                : Edge state of the port
    portautoedge                 : Auto transition to/from edge state of the port
    portbpdufilter               : BPDU filter on a port
    portmcfl                     : Multicast fast leave
    portmcrouter                 : Multicast ports
    portnetwork                  : Bridge assurance capability for a port
    ports                        : Interfaces
    primary                      : The first or highest in rank or importance
    pvid                         : The native VLAN
    secondary                    : Next after the first in order, place, time, etc
    slaves                       : Bond slave interfaces
    stp                          : Spanning Tree Protocol
    sys-mac                      : The system ID of the CLAG pair
    treeprio                     : STP priority
    vids                         : VLAN IDs
    vlan-aware                   : A VLAN aware bridge
    vxlan-anycast-ip             : Anycast local IP address for dual connected VxLANs
    local-tunnelip               : vxlan local tunnel ip
    purge-remotes                : vxlan purge existing remote entries
    remoteip                     : remote IP address
    svcnodeip                    : vxlan service node IP address
    updelay                      : Bond updelay
    downdelay                    : Bond downdelay
    secondary                    : The second or next highest in rank or importance
    learning                     : The bridge port learning flag
    mld-version                  : Multicast mld version
    igmp-version                 : IGMP version
    mode                         : Mode
    802.3ad                      : LACP
    balance-xor                  : Static bond
    ad-actor-sys-prio            : 802.3ad system priority
    ad-actor-system              : 802.3ad system mac address
    num-grat-arp                 : Number of gratuitous ARP packets to send on failover
    num-unsol-na                 : Number of unsolicited IPv6 NA packets to send on failover
    use-carrier                  : Bond use carrier
    xmit-hash-policy             : Bond hash policy
    multicast-flood              : Bridge port multicast flood flag
    unicast-flood                : Bridge port unicast flood flag
    ageing                       : Ageing
    vlan-protocol                : Bridge VLAN protocol
    slow                         : Bond LACP rate slow
    vlan-stats                   : VLAN statistics
    arp-nd-suppress              : ARP ND suppression
    802.1q                       : 802.1q
    802.1ad                      : 802.1ad
    forward                      : Forwarding
    nd-suppress                  : Neighbor Discovery suppress
    igmp-stats                   : IGMP statistics
    mcstats                      : Multicast statistics
    mlag                         : Multi-Chassis Link Aggregation
    pvst                         : Per-VLAN Spanning Tree
    cdp,lacp                     : cdp and lacp
    cdp,lacp,lldp                : cdp, lacp and lldp
    cdp,lacp,lldp,pvst           : cdp, lacp, lldp and pvst
    cdp,lacp,lldp,stp            : cdp, lacp, lldp and stp
    cdp,lacp,pvst                : cdp, lacp and pvst
    cdp,lacp,pvst,stp            : cdp, lacp, pvst and stp
    cdp,lacp,stp                 : cdp, lacp and stp
    cdp,lldp                     : cdp and lldp
    cdp,lldp,pvst                : cdp, lldp and pvst
    cdp,lldp,pvst,stp            : cdp, lldp, pvst and stp
    cdp,lldp,stp                 : cdp, lldp and stp
    cdp,pvst                     : cdp and pvst
    cdp,pvst,stp                 : cdp, pvst and stp
    cdp,stp                      : cdp and stp
    lacp,lldp                    : lacp and lldp
    lacp,lldp,pvst               : lacp, lldp and pvst
    lacp,lldp,pvst,stp           : lacp, lldp, pvst and stp
    lacp,lldp,stp                : lacp, lldp and stp
    lacp,pvst                    : lacp and pvst
    lacp,pvst,stp                : lacp, pvst and stp
    lacp,stp                     : lacp and stp
    lldp,pvst                    : lldp and pvst
    lldp,pvst,stp                : lldp, pvst and stp
    lldp,stp                     : lldp and stp
    pvst,stp                     : pvst and stp
    neighbors                    : CLAG neighbors
"""

# At one point we experimented with a bond-master keyword but bond that
# bonds are pretty configurable already
#
#    iface (add|del) interface <interface> bond-master <interface-bond>
#    bond-master                  : Add a physical interface to a bond

from collections import OrderedDict
from copy import deepcopy
from ipaddr import IPv6Network, IPv4Network, AddressValueError, IPNetwork
from nclu.netshow2 import get_master
from network_docopt import sort_ifaces, sort_for_humans, NetworkDocopt
from network_docopt.match import ifname_is_valid
import dot1x
from nclu import (
    make_pending_diff,
    decode_dict,
    get_interfaces,
    globify_interface_commands,
    glob_msg,
    glob_to_numbers,
    ifname_expand_glob,
    ifnames_to_glob,
    is_mac_address,
    is_number_glob,
    numbers_to_glob,
    PENDING_COMMANDS_FILE,
    get_pending_add_del_commands,
    seconds_to_hhmmss,
    tabulate_remove_unicode as tru,
    WORKING_DIRECTORIES_PERMISSIONS,
)
from pprint import pformat
from shutil import rmtree, copyfile
from subprocess import check_output, STDOUT, CalledProcessError
from tabulate import tabulate
from time import sleep
import json
import logging
import logging.handlers
import nclu.NetDaemon
import os
import re
import glob
import shlex
import shutil
import subprocess
import sys
sys.path.append("/usr/share/ifupdown2/addons/")

log = logging.getLogger("netd")
addons_cmds = []
keyword_default = {}
per_command_helptext = {"net (add|del) bridge": {"bridge": "Name of the VLAN Aware Bridge (must be bridge)",
                                                 "<interface>": "Name of a VLAN Unaware Bridge Interface" }}

all_interface_keywords = (
    "post-down",
    "post-up",
    "pre-down",
    "pre-up")

bond_interface_keywords = (
    'address',
    'address-virtual',
    'alias',
    'bond-ad-actor-sys-prio',
    'bond-ad-actor-system',
    'bond-downdelay',
    'bond-lacp-bypass-allow',
    'bond-lacp-rate',
    'bond-miimon',
    'bond-min-links',
    'bond-mode',
    'bond-num-grat-arp',
    'bond-num-unsol-na',
    'bond-slaves',
    'bond-updelay',
    'bond-use-carrier',
    'bond-xmit-hash-policy',
    'bridge-access',
    'bridge-allow-untagged',
    'bridge-multicast-flood',
    'bridge-nd-suppress',
    'bridge-l2protocol-tunnel',
    'bridge-learning',
    'bridge-pathcosts',
    'bridge-portmcfl',
    'bridge-portmcrouter',
    'bridge-pvid',
    'bridge-unicast-flood',
    'bridge-vids',
    'clag-id',
    'gateway',
    'ip-forward',
    'ip6-forward',
    'link-down',
    'mpls-enable',
    'mstpctl-bpduguard',
    'mstpctl-portadminedge',
    'mstpctl-portautoedge',
    'mstpctl-portbpdufilter',
    'mstpctl-portnetwork',
    'mstpctl-portp2p',
    'mstpctl-portpathcost',
    'mstpctl-portrestrrole',
    'mstpctl-portrestrtcn',
    'mstpctl-treeportcost',
    'mstpctl-treeportprio',
    'mtu',
    'netmask',
    'preferred-lifetime',
    'scope',
    'vlan-protocol',
    'vrf')

bridge_interface_keywords = (
    'alias',
    'bridge-ageing',
    'bridge-bridgeprio',
    'bridge-fd',
    'bridge-gcint',
    'bridge-hashel',
    'bridge-hashmax',
    'bridge-hello',
    'bridge-igmp-querier-src',
    'bridge-igmp-stats',
    'bridge-igmp-version',
    'bridge-maxage',
    'bridge-maxwait',
    'bridge-mclmc',
    'bridge-mclmi',
    'bridge-mcmi',
    'bridge-mcqi',
    'bridge-mcqifaddr',
    'bridge-mcqpi',
    'bridge-mcqri',
    'bridge-mcquerier',
    'bridge-mcqv4src',
    'bridge-mcrouter',
    'bridge-mcsnoop',
    'bridge-mcsqc',
    'bridge-mcsqi',
    'bridge-mcstats',
    'bridge-mld-version',
    'bridge-portprios',
    'bridge-ports',
    'bridge-pvid',
    'bridge-stp',
    'bridge-vids',
    'bridge-vlan-aware',
    'bridge-vlan-protocol',
    'bridge-vlan-stats',
    'bridge-waitport',
    'mstpctl-ageing',
    'mstpctl-fdelay',
    'mstpctl-forcevers',
    'mstpctl-hello',
    'mstpctl-maxage',
    'mstpctl-maxhops',
    'mstpctl-treeprio',
    'mstpctl-txholdcount')

loopback_interface_keywords = (
    'address',
    'alias',
    'clagd-vxlan-anycast-ip',
    'ip-forward',
    'ip6-forward',
    'netmask',
    'preferred-lifetime',
    'scope',
    'vxrd-src-ip',
    'vxrd-svcnode-ip',
    'vrf')

physical_interface_keywords = (
    'address',
    'address-virtual',
    'alias',
    'bridge-access',
    'bridge-allow-untagged',
    'bridge-l2protocol-tunnel',
    'bridge-learning',
    'bridge-multicast-flood',
    'bridge-nd-suppress',
    'bridge-pathcosts',
    'bridge-portmcfl',
    'bridge-portmcrouter',
    'bridge-pvid',
    'bridge-vids',
    'bridge-voice-vlan',
    'bridge-unicast-flood',
    'clagd-args',
    'clagd-backup-ip',
    'clagd-enable',
    'clagd-peer-ip',
    'clagd-priority',
    'clagd-sys-mac',
    'gateway',
    'ip-forward',
    'ip6-forward',
    'link-autoneg',
    'link-down',
    'link-duplex',
    'link-fec',
    'link-speed',
    'mpls-enable',
    'mstpctl-bpduguard',
    'mstpctl-portadminedge',
    'mstpctl-portautoedge',
    'mstpctl-portbpdufilter',
    'mstpctl-portnetwork',
    'mstpctl-portp2p',
    'mstpctl-portpathcost',
    'mstpctl-portrestrrole',
    'mstpctl-portrestrtcn',
    'mstpctl-treeportcost',
    'mstpctl-treeportprio',
    'mtu',
    'netmask',
    'preferred-lifetime',
    'scope',
    'vlan-protocol',
    'vrf')

vlan_interface_keywords = (
    'address',
    'address-virtual',
    'alias',
    'gateway',
    'hwaddress',
    'ip-forward',
    'ip6-forward',
    'link-down',
    'mpls-enable',
    'mtu',
    'netmask',
    'preferred-lifetime',
    'scope',
    'vlan-id',
    'vlan-protocol',
    'vlan-raw-device',
    'vrf')

vxlan_interface_keywords = (
    'address',
    'alias',
    'bridge-access',
    'bridge-arp-nd-suppress',
    'bridge-l2protocol-tunnel',
    'bridge-learning',
    'bridge-multicast-flood',
    'bridge-nd-suppress',
    'bridge-unicast-flood',
    'gateway',
    'ip-forward',
    'ip6-forward',
    'link-down',
    'mstpctl-bpduguard',
    'mstpctl-portbpdufilter',
    'mtu',
    'netmask',
    'preferred-lifetime',
    'scope',
    'vxlan-ageing',
    'vxlan-id',
    'vxlan-learning',
    'vxlan-local-tunnelip',
    'vxlan-port',
    'vxlan-purge-remotes',
    'vxlan-remoteip',
    'vxlan-svcnodeip')

vrf_interface_keywords = (
    'address',
    'alias',
    'ip-forward',
    'ip6-forward',
    'preferred-lifetime',
    'scope',
    'vrf-table')

all_keywords = set()

for keyword in list(set((
    ('bridge-trunk', ) +
    all_interface_keywords +
    bond_interface_keywords +
    bridge_interface_keywords +
    loopback_interface_keywords +
    physical_interface_keywords +
    vlan_interface_keywords +
    vxlan_interface_keywords +
    vrf_interface_keywords))):

    if keyword in ('post-down', 'post-up', 'pre-down', 'pre-up'):
        all_keywords.add(keyword)
    elif '-' in keyword:
        re_prefix = re.search('^(.*?)-(.*)$', keyword)

        if re_prefix is not None:
            pre = re_prefix.group(1)
            post = re_prefix.group(2)

            # We cannot treat bond, clag, etc as keywords because they also
            # exist in "net add bond", "net add clag", etc.
            if pre not in ('bond', 'clag', 'vlan', 'vxlan'):
                all_keywords.add(pre)
            all_keywords.add(post)
    else:
        all_keywords.add(keyword)


IFUPDOWN2_DIR_BACKUP = "/run/nclu/ifupdown2-backup/"
ETC_NETWORK_INTERFACES_BACKUP = "/run/nclu/ifupdown2/etc_network_interfaces.backup"
ETC_NETWORK_INTERFACES = "/etc/network/interfaces"
ETC_NETWORK_INTERFACES_D = "/etc/network/interfaces.d"
INTERFACES_TMP = "/run/nclu/ifupdown2/interfaces.tmp"


def keywords_configured(args):
    """
    Return True if a keyword under an interface is configured.

    We use this to tell if the user did:
        net add int swp1
        net del int swp2

    TODO - This docstring is not helpful.  What exactly does this function represent?
    """

    assert isinstance(args, dict)

    for keyword in all_keywords:
        if args.get(keyword) is not None:
            return True
    return False


def ifname_in_etc_network_interfaces(ifname):

    # If this file exists, the user is in the process of adding ifname.
    if os.path.exists("/run/nclu/ifupdown2/{0}".format(ifname)):
        return True
    else:
        iface_line = "iface {0}".format(ifname)
        iface_inet_line = "iface {0} inet".format(ifname)

        with open(ETC_NETWORK_INTERFACES) as f:
            for line in f:
                if line.strip() == iface_line or line.startswith(iface_inet_line):
                    return True
    return False


def ifname_prefix_in_etc_network_interfaces(ifname):
    # If this file exists, the user is in the process of adding ifname.
    if glob.glob("/run/nclu/ifupdown2/{}*".format(ifname)):
        return True
    else:
        iface_line = "iface {0}".format(ifname)
        with open(ETC_NETWORK_INTERFACES) as f:
            for line in f:
                if line.startswith(iface_line):
                    return True
    return False


def standardize_indent(line):
    """
    ETC_NETWORK_INTERFACES tends to be indented with four spaces but ifquery uses tabs.
    Note that this also strips newline characters.
    """

    indented = line.startswith(' ') or line.startswith('\t')
    line = line.strip()

    if line and indented:
        return '    ' + line
    return line


def write_new_interface(lines_to_write, prev_line, ifname, lines, persist):

    # Always have a blank line between interface stanzas
    if prev_line:
        lines_to_write.append('\n')

    for line in lines:
        lines_to_write.append(line)
    lines_to_write.append('\n')

    if persist:
        os.remove("/run/nclu/ifupdown2/{0}".format(ifname))


def get_ifnames(cli, is_delete=False):
    """
    Return interface names the user specified on the command line as a (bool, [str]) 2-tuple.
    The behavior is different for "net add ..." than it is for "net del ...".
    """

    args = cli.args
    ifnames = []
    ifname = None
    ifnames_valid = True

    if len(cli.argv_expanded) >= 4 and cli.match[3].value and cli.match[3].value.text == "<interface>":
        ifname = args.get("<interface>")

        if isinstance(ifname, list):
            # This is the case for commands with multiple <interface> components.
            ifname = ifname[0]

    # Most (add|del) commands also have <interface>, but there are exceptions.
    # For example, "add vlans 10-20".
    if ifname:
        try:
            ifnames = ifname_expand_glob(str(ifname))  # A list
        except ValueError:
            print glob_msg.replace("INTERFACE", ifname)
            ifnames_valid = False
            return (ifnames_valid, ifnames)

    else:
        # "net add bridge" is an exception.  We do not allow the user
        # to specify the bridge name, so populate ifnames with "bridge".
        if args.get("bridge") and len(cli.argv_expanded) >= 3 and cli.argv_expanded[2] == "bridge":
            ifnames.append("bridge")

        # Same for loopback...force the name to "lo".
        elif args.get("loopback") and len(cli.argv_expanded) >= 3 and cli.argv_expanded[2] == "loopback":
            ifnames.append("lo")

        # If the user does "net add vlan 10-20", do NOT create SVIs for all of those vlans.
        # If the user does "net add vlan 10-20 vrf BLUE", create SVIs for all of those vlans.
        elif args.get("vlan") and args.get("<number-range-list>"):
            if (not is_delete and len(cli.argv_expanded) > 4) or is_delete:
                vlan_numbers = glob_to_numbers(str(args.get("<number-range-list>")))

                for number in vlan_numbers:
                    ifnames.append("vlan%d" % number)

    return (ifnames_valid, ifnames)


def expand_bridge_ports_glob(cmd):
    """
    If "cmd" contains "bridge-ports glob swp1-4" expand that
    out to "bridge-ports swp1 swp2 swp3 swp4".
    """

    # compress duplicate whitespaces
    cmd = ' '.join(cmd.strip().split())

    # Make "regex swp*" a single token so we can split by whitespace
    cmd = cmd.replace("regex ", "regex-")

    # Make "glob swp1-9" a single token so we can split by whitespace
    cmd = cmd.replace("glob ", "glob-")

    final = []

    for token in cmd.split():
        if token.startswith("glob-"):
            glob_args_expanded = ifname_expand_glob(token.replace("glob-", "glob ").split()[1])
            final.extend(glob_args_expanded)
        else:
            final.append(token)

    return ' '.join(final)


def get_vlan_aware_bridge_name():
    """
    For configuration NCLU only supports the name 'bridge' for the vlan-aware bridge.
    For show commands such as 'net show bridge spanning-tree' we can easily support a
    vlan-aware bridge of any name.
    """
    with open(ETC_NETWORK_INTERFACES) as f:
        ifname = None

        for line in f:
            line = line.strip()

            if line.startswith('iface '):
                ifname = line.split()[1]
            elif line == 'bridge-vlan-aware yes':
                return ifname

    return None


class Command(object):
    """
    Base class for the various CommandXYZ classes that are used to represent
    commands supported by ifupdown2 addon modules
    """

    def __init__(self, keyword, value):
        """
        value is a dictionary of attributes for the 'keyword' command.
        value is extracted from the _modinfo dictionary for the ifupdown2
        addon that owns this command.
        """
        self.keyword = keyword
        self.keyword_original = keyword
        self.default = None
        self.validvals = None
        self.rangemin = None
        self.rangemax = None
        self.deprecated = False
        self.help = value.get('help')
        self.usage_str_add = []
        self.usage_str_del = []
        self.validvals = []
        add_string = None
        del_string = None
        global keyword_default

        # There is some weird ifupdown1 historical reason that the address.py
        # addon cannot list <ipv4> as the validvals for netmask so we hard code
        # it here to work around that
        if self.keyword == 'netmask' and 'validvals' not in value:
            value['validvals'] = ['<ipv4>', ]

        # We only support vlan aware bridges, do not provide a means to disable it
        if self.keyword == 'bridge-vlan-aware':
            value['validvals'] = ['yes', ]

        self.default = value.get('default')

        if self.default is not None:
            keyword_default[self.keyword] = self.default

        if 'deprecated' in value:
            self.deprecated = value['deprecated']

        # bridge-pathcosts and mstpctl-portpathcost support configuring the keyword
        # under the physical interface or the bridge.  We only support configuring
        # these under the physical interface where validrange is used so delete the
        # validvals entry.
        if (self.keyword in ('bridge-pathcosts', 'mstpctl-portpathcost', 'mstpctl-treeportprio') and
            'validvals' in value and 'validrange' in value):
            del value['validvals']

        # Temp work-arounds for CM-19929
        if self.keyword == 'bridge-portmcfl':
            del value['validrange']
        elif self.keyword == 'vxlan-port':
            del value['validvals']

        if 'validvals' in value:
            sorted_validvals = sorted(value['validvals'])

            # Compress the various ways of saying "yes or no" down to "yes or no"
            if (sorted_validvals == ['0', '1', 'no', 'yes'] or
                sorted_validvals == ['no', 'yes']):
                value['validvals'] = ['yes', 'no']

            # bond-mode takes a number of keyword, chop the numbers
            elif sorted_validvals == ['0', '1', '2', '3', '4', '5', '6', '802.3ad', 'active-backup', 'balance-alb', 'balance-rr', 'balance-tlb', 'balance-xor', 'broadcast']:
                # value['validvals'] = ['802.3ad', 'active-backup', 'balance-alb', 'balance-rr', 'balance-tlb', 'balance-xor', 'broadcast']
                # We only support two of the modes
                value['validvals'] = ['802.3ad', 'balance-xor']

            elif (sorted_validvals == ['0', '1', 'fast', 'slow']):
                value['validvals'] = ['fast', 'slow']

            # bridge-learning, bridge-multicast-flood and bridge-unicast-flood all
            # list <interface-on-off-list> to support the old bridge driver. We (nclu)
            # do not support the old bridge driver though so chop this option.
            elif (sorted_validvals == ['<interface-on-off-list>', 'off', 'on']):
                value['validvals'] = ['off', 'on']

            elif self.keyword == 'address-virtual4':
                value['validvals'] = ['<mac> <ipv4/prefixlen>', ]

            elif self.keyword == 'address-virtual6':
                value['validvals'] = ['<mac> <ipv6/prefixlen>', ]

            elif self.keyword == 'bridge-l2protocol-tunnel':
                value['validvals'] = [x.replace(' ', ',') for x in value['validvals']]

            # The <interface-l2protocol-tunnel-list> syntax only applies for the
            # old bridge driver which is not supported by NCLU
            if '<interface-l2protocol-tunnel-list>' in value['validvals']:
                value['validvals'].remove('<interface-l2protocol-tunnel-list>')

            # These are keywords that can be configured under the bridge via <interface-yes-no-list>
            # or under the swp via 'yes/no'. We will restrict these keywords to just the swp so change
            # the validvals to 'yes/no'
            if self.keyword in ('bridge-portmcrouter',
                                'bridge-portmcfl',
                                'mstpctl-bpduguard',
                                'mstpctl-portadminedge',
                                'mstpctl-portautoedge',
                                'mstpctl-portbpdufilter',
                                'mstpctl-portnetwork',
                                'mstpctl-portp2p',
                                'mstpctl-portrestrrole',
                                'mstpctl-portrestrtcn'):
                value['validvals'] = ['yes', 'no']

            if self.default is not None:

                if self.default in ('0', 0, 'off', 'no'):
                    options_to_remove = ['0', 0, 'off', 'no']
                elif self.default in ('1', 1, 'on', 'yes'):
                    options_to_remove = ['1', 1, 'on', 'yes']
                else:
                    options_to_remove = [self.default, ]

                for tmp_default in options_to_remove:
                    if tmp_default in value['validvals']:
                        value['validvals'].remove(tmp_default)

            for val in value['validvals']:

                if isinstance(val, str):
                    if val == '<ipaddr>':
                        self.validvals.append('<ip>')

                    elif val == '<ipaddr/prefixlen>':
                        self.validvals.append('<ip/prefixlen>')

                    elif val == '<interface>':
                        self.validvals.append('<interface-as-arg>')

                    # 1.1.1.1 or "1.1.1.1 vrf BLUE"
                    elif val == '<ipv4-vrf-text>':
                        self.validvals.append('<ipv4> vrf <text>')
                        self.validvals.append('<ipv4>')

                    else:
                        self.validvals.append(val)

                elif isinstance(val, int):
                    self.validvals.append(str(val))

                else:
                    raise Exception("Unexpected validvals type %s for %s" % (type(val), val))

            add_string = "    iface add interface <interface> %s " % self.keyword
            del_string = "    iface del interface <interface> %s " % self.keyword

            if len(self.validvals) == 1:
                if not self.auto_add_yes():
                    add_string += self.validvals[0]
                    del_string += '[' + self.validvals[0] + ']'

            # The only time validvals will be [] is if the only option for the
            # command was the default value (which we removed).
            #
            # As of today, mstpctl-forcevers is the only command that falls
            # into this bucket.
            elif self.validvals:
                # (no|yes) just looks weird so do not sort this one
                if self.validvals == ['yes', 'no']:
                    add_string += "(yes|no)"
                    del_string += "[yes|no]"
                else:
                    add_string += "(%s)" % '|'.join(sort_for_humans(self.validvals))
                    del_string += "[%s]" % '|'.join(sort_for_humans(self.validvals))

            # We only support vlan aware bridges, do not provide a means to disable it
            if self.keyword == 'bridge-vlan-aware':
                del_string = ''

        elif 'validrange' in value:
            self.rangemin = int(value['validrange'][0])
            self.rangemax = int(value['validrange'][1])
            add_string = "    iface add interface <interface> %s <%d-%d>" % (self.keyword, self.rangemin, self.rangemax)
            del_string = "    iface del interface <interface> %s [<%d-%d>]" % (self.keyword, self.rangemin, self.rangemax)

        else:
            add_string = "    iface add interface <interface> %s <wildcard>" % self.keyword
            del_string = "    iface del interface <interface> %s [<wildcard>]" % self.keyword

        # babelfish scenarios
        # This is a special case...we override 'address (<ipv4/prefixlen>|<ipv6/prefixlen>)' with
        # "[ip] address (<ipv4/prefixlen>|<ipv6/prefixlen>|dhcp)" command
        if self.keyword == 'address4':
            add_string = "    iface add interface <interface> ip address (<ipv4/prefixlen>|dhcp)"
            del_string = "    iface del interface <interface> ip address [<ipv4/prefixlen>|dhcp]"
            self.keyword_original = 'address'
            self.keyword = ['ip', 'address']
            self.validvals.append('dhcp')

        elif self.keyword == 'address6':
            add_string = "    iface add interface <interface> ipv6 address (<ipv6/prefixlen>|dhcp)"
            del_string = "    iface del interface <interface> ipv6 address [<ipv6/prefixlen>|dhcp]"
            self.keyword_original = 'address'
            self.keyword = ['ipv6', 'address']
            self.validvals.append('dhcp')

        elif self.keyword == 'address-virtual4':
            add_string = "    iface add interface <interface> ip address-virtual <mac> <ipv4/prefixlen>"
            del_string = "    iface del interface <interface> ip address-virtual [<mac> <ipv4/prefixlen>]"
            self.keyword_original = 'address-virtual'
            self.keyword = ['ip', 'address-virtual']

        elif self.keyword == 'address-virtual6':
            add_string = "    iface add interface <interface> ipv6 address-virtual <mac> <ipv6/prefixlen>"
            del_string = "    iface del interface <interface> ipv6 address-virtual [<mac> <ipv6/prefixlen>]"
            self.keyword_original = 'address-virtual'
            self.keyword = ['ipv6', 'address-virtual']

        elif self.keyword == 'gateway4':
            add_string = "    iface add interface <interface> ip gateway <ipv4>"
            del_string = "    iface del interface <interface> ip gateway [<ipv4>]"
            self.keyword_original = 'gateway'
            self.keyword = ['ip', 'gateway']

        elif self.keyword == 'gateway6':
            add_string = "    iface add interface <interface> ipv6 gateway <ipv6>"
            del_string = "    iface del interface <interface> ipv6 gateway [<ipv6>]"
            self.keyword_original = 'gateway'
            self.keyword = ['ipv6', 'gateway']

        elif self.keyword == 'netmask4':
            add_string = "    iface add interface <interface> ip netmask <ipv4>"
            del_string = "    iface del interface <interface> ip netmask [<ipv4>]"
            self.keyword_original = 'netmask'
            self.keyword = ['ip', 'netmask']

        elif self.keyword == 'netmask6':
            add_string = "    iface add interface <interface> ipv6 netmask <ipv6>"
            del_string = "    iface del interface <interface> ipv6 netmask [<ipv6>]"
            self.keyword_original = 'netmask'
            self.keyword = ['ipv6', 'netmask']

        elif self.keyword == 'bridge-stp':
            add_string = "    iface add interface <interface> stp off"
            del_string = "    iface del interface <interface> stp off"
            self.keyword_original = 'bridge-stp'
            self.keyword = ['bridge', 'stp']

        # link-autoneg, link-duplex, link-fec and link-speed
        elif self.keyword.startswith('link-'):
            add_string = add_string.replace('link-', 'link ')
            del_string = del_string.replace('link-', 'link ')
            self.keyword = ['link', '-'.join(self.keyword.split('-')[1:])]

        elif self.keyword.startswith('bond-'):
            add_string = add_string.replace('bond-', 'bond ')
            del_string = del_string.replace('bond-', 'bond ')
            self.keyword = ['bond', '-'.join(self.keyword.split('-')[1:])]

        elif self.keyword.startswith('bridge-'):
            add_string = add_string.replace('bridge-', 'bridge ')
            del_string = del_string.replace('bridge-', 'bridge ')
            self.keyword = ['bridge', '-'.join(self.keyword.split('-')[1:])]

        elif self.keyword.startswith('clag-'):
            add_string = add_string.replace('clag-', 'clag ')
            del_string = del_string.replace('clag-', 'clag ')
            self.keyword = ['clag', '-'.join(self.keyword.split('-')[1:])]

        elif self.keyword.startswith('clagd-'):
            add_string = add_string.replace('clagd-', 'clag ')
            del_string = del_string.replace('clagd-', 'clag ')
            self.keyword = ['clag', '-'.join(self.keyword.split('-')[1:])]

        elif self.keyword.startswith('ip-'):
            add_string = add_string.replace('ip-', 'ip ')
            del_string = del_string.replace('ip-', 'ip ')
            self.keyword = ['ip', 'forward']

        elif self.keyword.startswith('ip6-'):
            add_string = add_string.replace('ip6-', 'ipv6 ')
            del_string = del_string.replace('ip6-', 'ipv6 ')
            self.keyword = ['ipv6', 'forward']

        # mstpctl-bpduguard
        elif self.keyword.startswith('mstpctl-'):
            add_string = add_string.replace('mstpctl-', 'stp ')
            del_string = del_string.replace('mstpctl-', 'stp ')
            self.keyword = ['stp', '-'.join(self.keyword.split('-')[1:])]

        elif self.keyword.startswith('vxlan-'):
            add_string = add_string.replace('vxlan-', 'vxlan ')
            del_string = del_string.replace('vxlan-', 'vxlan ')
            self.keyword = ['vxlan', '-'.join(self.keyword.split('-')[1:])]

        keyword_scope_defined = False

        int_types = ('bond', 'bridge', 'loopback', 'vlan', 'vxlan', 'vrf')
        if self.keyword_original in all_interface_keywords:
            keyword_scope_defined = True
            self.usage_str_add.append(add_string)
            self.usage_str_del.append(del_string)

            for int_type in int_types:

                # bridge type is special, we restrict its name to 'bridge'
                if int_type == 'bridge':
                    tmp_add_string = add_string.replace(' interface <interface> ', ' bridge ')
                    tmp_del_string = del_string.replace(' interface <interface> ', ' bridge ')

                elif int_type == 'loopback':
                    tmp_add_string = add_string.replace(' interface <interface> ', ' loopback lo ')
                    tmp_del_string = del_string.replace(' interface <interface> ', ' loopback lo ')

                elif int_type == 'vlan':
                    tmp_add_string = add_string.replace(' interface <interface> ', ' vlan <number-range-list> ')
                    tmp_del_string = del_string.replace(' interface <interface> ', ' vlan <number-range-list> ')

                else:
                    tmp_add_string = add_string.replace(' interface ', ' %s ' % int_type)
                    tmp_del_string = del_string.replace(' interface ', ' %s ' % int_type)

                self.usage_str_add.append(tmp_add_string)
                self.usage_str_del.append(tmp_del_string)

        else:
            if self.keyword_original in bridge_interface_keywords:
                keyword_scope_defined = True
                tmp_add_string = add_string.replace(' interface <interface> ', ' bridge ')
                tmp_del_string = del_string.replace(' interface <interface> ', ' bridge ')
                self.usage_str_add.append(tmp_add_string)
                self.usage_str_del.append(tmp_del_string)

            if self.keyword_original in bond_interface_keywords:
                keyword_scope_defined = True
                tmp_add_string = add_string.replace(' interface ', ' bond ')
                tmp_del_string = del_string.replace(' interface ', ' bond ')
                self.usage_str_add.append(tmp_add_string)
                self.usage_str_del.append(tmp_del_string)

            if self.keyword_original in loopback_interface_keywords:
                keyword_scope_defined = True
                tmp_add_string = add_string.replace(' interface <interface> ', ' loopback lo ')
                tmp_del_string = del_string.replace(' interface <interface> ', ' loopback lo ')
                self.usage_str_add.append(tmp_add_string)
                self.usage_str_del.append(tmp_del_string)

            if self.keyword_original in physical_interface_keywords:
                keyword_scope_defined = True
                self.usage_str_add.append(add_string)
                self.usage_str_del.append(del_string)

            if self.keyword_original in vlan_interface_keywords:
                keyword_scope_defined = True
                tmp_add_string = add_string.replace(' interface <interface> ', ' vlan <number-range-list> ')
                tmp_del_string = del_string.replace(' interface <interface> ', ' vlan <number-range-list> ')
                self.usage_str_add.append(tmp_add_string)
                self.usage_str_del.append(tmp_del_string)

            if self.keyword_original in vxlan_interface_keywords:
                keyword_scope_defined = True
                tmp_add_string = add_string.replace(' interface ', ' vxlan ')
                tmp_del_string = del_string.replace(' interface ', ' vxlan ')
                self.usage_str_add.append(tmp_add_string)
                self.usage_str_del.append(tmp_del_string)

            if self.keyword_original in vrf_interface_keywords:
                keyword_scope_defined = True
                tmp_add_string = add_string.replace(' interface ', ' vrf ')
                tmp_del_string = del_string.replace(' interface ', ' vrf ')
                self.usage_str_add.append(tmp_add_string)
                self.usage_str_del.append(tmp_del_string)

        if not keyword_scope_defined:
            # We currently do not do anything with the deprecated commands
            # so don't bother spewing the log for these.
            if not self.deprecated:
                log.info('Where does keyword "%s" belong?' % self.keyword_original)
            self.usage_str_add.append(add_string)
            self.usage_str_del.append(del_string)

    def __str__(self):
        return str(self.keyword)

    def auto_add_yes(self):
        """
        Return True if we should automagically add "yes" to a keyword when
        writing that keyword to an interface stanza.  Otherwise, return False.
        """
        return self.validvals == ['yes']

    def value_from_args(self, args):
        args_value_keyword = None

        if self.auto_add_yes():
            args_value_keyword = 'yes'

        elif self.validvals:
            validvals_by_count = []
            for val in self.validvals:
                validvals_by_count.append((len(val.split()), val))

            for _, val in sorted(validvals_by_count, reverse=True):

                # Combos such as '<ipv4> [vrf <text>]' are a special case
                if ' ' in val:
                    values = []

                    for val_component in val.split():
                        if val_component.startswith('['):
                            val_component = val_component[1:]

                        if val_component.endswith(']'):
                            val_component = val_component[:-1]

                        tmp = args.get(val_component)
                        if tmp:
                            values.append(tmp)

                    if values:
                        return ' '.join(values)
                else:
                    if args.get(val) is not None:
                        args_value_keyword = val
                        break

        elif self.rangemax:
            args_value_keyword = "<{0}-{1}>".format(self.rangemin, self.rangemax)

        elif self.default:
            args_value_keyword = self.default

        else:
            if args.get('<wildcard>'):
                args_value_keyword = '<wildcard>'

        if args_value_keyword is None:
            return None

        return args.get(args_value_keyword) if args_value_keyword.startswith('<') else args_value_keyword

    def keywords_in_args(self, args):

        # 99% of commands have only one keyword, the exceptions are the ones
        # like "ipv6 address-virtual" where we created two Command objects
        # from a single keyword. In that scenario self.keyword is a list
        # instead of a string.
        if isinstance(self.keyword, list):
            keywords_to_check = self.keyword
        else:
            keywords_to_check = [self.keyword, ]

        args_has_all_keywords = True
        for keyword in keywords_to_check:
            if args.get(keyword) is None:
                args_has_all_keywords = False
                break
        return args_has_all_keywords


class CommandAddDelMultiLine(Command):
    """
    Commands that are allowed to appear multiple times in and interface stanza...example:

    auto swp1
    iface swp1
        address 1.1.1.1/24
        address 2.2.2.1/24
    """
    pass


class CommandAddDelMultiValue(Command):
    """
    Commands that can only appear once in an interface stanza but can have a list of values...example:

    auto br0
    iface br0
        bridge-ports swp1 swp2 swp7
    """
    pass


class CommandSetClear(Command):
    """
    Commands that can only appear one time in an interface stanza...example:

    auto vni100
    iface vni100
        vxlan-id 1.1.1.1
    """
    pass


def build_doc_string(blacklist):
    """
    Parse the _modinfo dictionary for the various ifupdownaddons modules.
     _modinfo contains information about the commands supported by the addon.

    We use this to:
    - modify __doc__ to include the CLI to support each command
    - create a Command object for each command
    """
    global __doc__

    # "/sbin/ifquery --syntax-help -o json" dumps a JSON dictionary of
    # the add-ons and all of the keywords they support.
    ifquery_command = ["/sbin/ifquery", "--syntax-help", "-o", "json"]
    try:
        output = subprocess.check_output(ifquery_command)
    except subprocess.CalledProcessError as e:
        output = "{}"
        log.warning("'{0}' failed: {1}".format(" ".join(ifquery_command), e))

    try:
        ifupdown_syntax = json.loads(output, object_hook=decode_dict)
    except ValueError:
        ifupdown_syntax = {}
        log.warning("'{0}' produced invalid json output\n{1}\n".format(" ".join(ifquery_command), pformat(output)))

    global addons_cmds
    addons_cmds = []  # A list of "Command" instances

    for addon_name in ifupdown_syntax.iterkeys():
        addon_attrs = ifupdown_syntax[addon_name].get("attrs", {})

        for (keyword, value) in addon_attrs.iteritems():

            # Some keywords are corner cases.  Do not list them in order to
            # avoid clutter when the user does TAB complete.
            if keyword in blacklist:
                continue

            # babelfish
            # This would look weird (keyword 'ip' followed by an ipv6 address)
            #   net add interface <interface> ip gateway (<ipv4>|<ipv6>)
            #
            # So we create two branches for the 'gateway' keyword
            #   net add interface <interface> ip gateway <ipv4>
            #   net add interface <interface> ipv6 gateway <ipv6>
            if keyword == "address":
                keywords = ("address4", "address6")
            elif keyword == "address-virtual":
                keywords = ("address-virtual4", "address-virtual6")
            elif keyword == "gateway":
                keywords = ("gateway4", "gateway6")
            elif keyword == "netmask":
                keywords = ("netmask4", "netmask6")
            else:
                keywords = (keyword, )

            for keyword in keywords:
                if "multiline" in value:
                    # You are allowed to have more than one of this command per interface.
                    command_instance = CommandAddDelMultiLine(keyword, value)

                # Commands like "bridge-ports" where you can have
                # "bridge-ports swp2 swp3 swp4"
                elif "multivalue" in value:
                    command_instance = CommandAddDelMultiValue(keyword, value)

                # Commands where you can only have one (vxlan-id)
                else:
                    command_instance = CommandSetClear(keyword, value)
                addons_cmds.append(command_instance)

    state = "LIMBO"
    usage = []
    options = []

    # Extract the Usage and Options lines from the global doc string.
    global __doc__
    for line in __doc__.splitlines():
        if line == "Usage:":
            state = "USAGE"
        elif line == "Options:":
            state = "OPTIONS"
        else:
            if state == "LIMBO":
                pass
            elif state == "USAGE":
                usage.append(line)
            elif state == "OPTIONS":
                options.append(line)
            else:
                raise RuntimeError("Invalid state, {0}.  The line is \"{1}\".".format(state, line))

    addon_usage = []

    # Build all of the Usage and Options lines.
    for addon_command in addons_cmds:
        if not addon_command.deprecated:
            for line in addon_command.usage_str_add:
                addon_usage.append(line)

            for line in addon_command.usage_str_del:
                addon_usage.append(line)

            if addon_command.help:
                options.append("{0} : {1}".format(addon_command.keyword_original, addon_command.help))

    addon_usage.sort()
    usage.extend(addon_usage)

    __doc__ = "\nUsage:\n" + '\n'.join(usage) + "\n\nOptions:\n" + '\n'.join(options)
    return __doc__


class EtcNetworkInterface(object):
    """
    Used to represent an interface configuration stanza in the format expected in
    ETC_NETWORK_INTERFACES.
    """

    def __init__(self, name, ifquery_all):
        """
        From the output of "ifquery -a", extract the stanza for the given interface
        (name), and store it, as a list of lines, in self.ifquery.
        """

        self.content = []
        self.name = str(name)
        self.filename = "/run/nclu/ifupdown2/{0}".format(self.name)  # Pending changes
        self.filename_del = self.filename + ".del"
        self.filename_original = self.filename + ".original"
        self.ifquery = []

        # Extract the configuration for this interface from the "ifquery -a" output, if available.
        found_auto = False
        found_iface = False
        found_name = False

        for line in ifquery_all.splitlines():
            line = standardize_indent(line)
            re_auto = re.match(r"""auto\s+{0}$""".format(self.name), line)
            re_iface = re.match(r"""iface\s+{0}$""".format(self.name), line)
            re_iface_inet = re.match(r"""iface\s+{0}\s+inet""".format(self.name), line)

            if re_auto is not None:
                found_name = True

                if not found_auto:
                    self.ifquery.append(line)
                    found_auto = True

            elif re_iface is not None or re_iface_inet is not None:
                found_name = True

                if not found_iface:
                    self.ifquery.append(line)
                    found_iface = True

            elif found_name:
                # We've started parsing the next interface.
                if line.startswith('auto ') or line.startswith('source '):
                    found_name = False
                elif line and line not in self.ifquery:
                    self.ifquery.append(line.replace('bridge_ports', 'bridge-ports'))

        if os.path.isfile(self.filename):
            # Populate self.content with the pending changes file.
            self.load_iface_state()
        else:
            # Populate self.content with self.ifquery, etc.
            self.init_iface_state()

    def __str__(self):
        return self.name

    def add_cmd(self, cmd):
        self.content.append(cmd)

    def del_cmd(self, cmd, match_exact, give_feedback):
        """ Return True if the operation succeeds; otherwise, False. """

        # If an interface is configured with "vxlan-id 500" and the user
        # does "net del int swp1 vxlan-id 500", look for this exact line.
        if match_exact:
            if cmd in self.content:
                self.content.remove(cmd)
                return True

            if give_feedback:
                print "{0}'s configuration does not have \"{1}\".".format(self, cmd.strip())
            return False

        # If the user did "net del int swp1 vxlan-id", look for
        # lines that start with "    vxlan-id "
        lines_to_remove = []

        # Do not change the size of the list as we are looping over it.
        # Store the ones to delete, and delete them later.
        for tmp_cmd in self.content:
            if tmp_cmd.startswith('%s ' % cmd):
                lines_to_remove.append(tmp_cmd)

        if lines_to_remove:
            for tmp_cmd in lines_to_remove:
                self.content.remove(tmp_cmd)
        else:
            if give_feedback:
                print "{0}'s configuration does not have \"{1}\".".format(self, cmd.strip())
            return False

        return True

    def mod_cmd(self, old_cmd, new_cmd, give_feedback):
        """ Return True if the operation succeeds; otherwise, False. """

#        TODO - This is a do_something_maybe function. :(
#        assert old_cmd != new_cmd, "Don't call this function when there's nothing to do."

        if old_cmd == new_cmd:
            if give_feedback:
                print "{0}'s configuration already has \"{1}\".".format(self, new_cmd.strip())
            return False

        for (i, line) in enumerate(self.content):
            if line == old_cmd:
                self.content[i] = new_cmd
                return True

        return False

    def get_cmd(self, keyword):
        """
        get_cmd returns the value of the config line that contains
        the config keyword.  Some config options can occur in multiple lines
        so we have to make sure to combine the multiple config lines into one
        command.
        """
        keyword = keyword.strip() + ' '
        prefix = ''
        values = []
        for line in self.content:
            if line.lstrip().startswith(keyword):
                # grab the leading space
                prefix = line.split(keyword)[0]
                # grab the values
                values.append(line.split(keyword)[1])

        if values == []:
            return None
        else:
            # remember, the prefix is spaces, the keyword has a trailing space
            # and the values will get a space between them
            return "{}{}{}".format(prefix, keyword, ' '.join(values))

    def has_cmd(self, keyword):
        return self.get_cmd(keyword) is not None

    def get_keyword_value(self, keyword):
        # line will be something like "mtu 1500" or "bridge-ports swp1 swp2" so
        # split it and return all values after the keyword
        line = self.get_cmd(keyword)

        if line:
            line = line.strip()

            if ' ' in line:
                return ' '.join(line.split()[1:])
        return None

    def get_keyword_value_list(self, keyword):
        """
        For commands like "address" where there can be multiple lines for a keyword
        """
        keyword = keyword.strip() + ' '
        results = []

        for line in self.content:
            line = line.strip()
            if line.startswith(keyword):
                results.append(line.replace(keyword, ''))
        return results

    def is_bond(self):
        return self.has_cmd('bond-slaves')

    def will_become_bond(self, cli):
        return cli.args.get('bond') is not None and cli.args.get('slaves') is not None

    def is_bridge(self):
        return self.has_cmd('bridge-ports') or self.has_cmd('bridge-vlan-aware')

    def will_become_bridge(self, cli):
        return cli.args.get('bridge') is not None and (cli.args.get('ports') is not None or cli.args.get('vlan-aware') is not None)

    def is_layer2(self):
        # FIXME fix this for traditional bridge ports
        # You also need to look at the bridge bridge-ports to see if this iface is listed
        return self.has_cmd('bridge-access') or self.has_cmd('bridge-vids')

    def is_loopback(self):
        for line in self.content:
            if line.rstrip().endswith('inet loopback'):
                return True
        return False

    def is_vxlan(self):
        return self.has_cmd('vxlan-id') or self.has_cmd('vxlan-local-tunnelip')

    def will_become_vxlan(self, cli):
        return cli.args.get('vxlan') is not None and (cli.args.get('id') is not None or cli.args.get('local-tunnelip') is not None)

    def is_vlan_interface(self):
        return self.has_cmd('vlan-raw-device') or re.search('^bridge\.\d+$', self.name)

    def will_become_vlan_interface(self, cli):
        return cli.args.get('vlan') is not None and cli.args.get('raw-device') is not None

    def is_vrf(self):
        return self.has_cmd('vrf-table')

    def exists(self):
        """
        If we are editing this interface via iface, then the interface exists.
        self.content will contain the output of ifquery.  If the interface
        is not defined in ETC_NETWORK_INTERFACES, then ifquery will return
        an error, and self.content will be empty.
        """
        return os.path.isfile(self.filename) or bool(self.content)

    def validate_net_cmd_vs_ifname(self, parent_wrapper, cli):
        """
        The user must use "net add bond" if editing a bond interface, "net add bridge"
        for the bridge interface, etc. Return True if they used the correct syntax.
        Otherwise, return False.
        """
        argv_expanded_str = ' '.join(map(str, cli.argv_expanded))

        net_add_del_bond = ("net add bond " in argv_expanded_str) or ("net del bond " in argv_expanded_str)
        net_add_del_vxlan = ("net add vxlan " in argv_expanded_str) or ("net del vxlan " in argv_expanded_str)

        # Sanity check that the correct "net (add|del) ..." syntax was used to
        # edit this type of interface.
        if self.is_bridge() or self.will_become_bridge(cli) or self.name == 'bridge':
            net_add_del_bridge = 'net add bridge' in argv_expanded_str or 'net del bridge' in argv_expanded_str

            if not net_add_del_bridge:
                return (False, "\"net (add|del) bridge ...\" must be used to edit the bridge interface.")

        elif self.is_bond() or self.will_become_bond(cli):
            net_del_clag_port = 'net del clag port' in argv_expanded_str

            if not net_add_del_bond and not net_del_clag_port:
                return (False, "\"net (add|del) bond ...\" must be used to edit a bond interface.")

        elif net_add_del_bond:
            return (False, "{0} is not a bond interface.  Use \"net add bond {0} bond slaves ...\" to make {0} a bond interface.".format(self.name))

        elif self.is_loopback() or self.name == 'lo':
            net_add_del_loopback = 'net add loopback ' in argv_expanded_str or 'net del loopback ' in argv_expanded_str

            if not net_add_del_loopback:
                return (False, "\"net (add|del) loopback ...\" must be used to edit a loopback interface.")

        elif self.is_vlan_interface() or self.will_become_vlan_interface(cli):
            net_add_del_vlan = 'net add vlan ' in argv_expanded_str or 'net del vlan ' in argv_expanded_str

            if not net_add_del_vlan:
                return (False, "\"net (add|del) vlan ...\" must be used to edit a vlan interface.")

        elif self.is_vxlan() or self.will_become_vxlan(cli):

            if not net_add_del_vxlan:
                return (False, "\"net (add|del) vxlan ...\" must be used to edit a vxlan interface.")

        elif net_add_del_vxlan:
            return (False, "\"net (add|del) interface ...\" must be used.  {0} is not a vxlan interface.".format(self.name))

        elif self.is_vrf():
            net_add_del_vrf = 'net add vrf ' in argv_expanded_str or 'net del vrf ' in argv_expanded_str

            if not net_add_del_vrf:
                return (False, "\"net (add|del) vrf ...\" must be used to edit a vrf interface.")

        # If the user enters "<name>.100", then check that the name is either a physical interface or bond
        # and not "bridge" (which indicates a SVI).  If so, return True.  Otherwise, return False.
        # TODO - Remove the bond slaves parameter.  It is a work-around for bond-slaves not being implemented, which makes tests fails.

        base_name = re.match(r"""^(?P<base>\S+?)(\.\d+)+$""", self.name)

        if base_name is not None:
            base = base_name.group('base')
            base_iface = EtcNetworkInterface(base, parent_wrapper.ifquery_all)
            bond_slaves = cli.args.get('bond') is not None and cli.args.get('slaves') is not None

            if base == 'bridge':
                return (False, "\"net (add|del) vlan ...\" must be used to edit a vlan interface.")
            elif not (self.is_physical(base) or bond_slaves or self.is_bond() or base_iface.is_bond()):
                return (False, "For interface names of the form <name>.<number>, the interface must be physical or a bond.")

        elif argv_expanded_str.startswith('net add interface'):
            # For "net add interface", the interface must be physical.
            if not self.is_physical():
                return (False, "{0} is not a physical interface on this switch.".format(self.name))

        return (True, '')

    def write_file(self):
        """
        Write self.content to a file in /run/nclu/ifupdown2/.
        """

        with open(self.filename, 'w') as f:
            commands_to_sort = []
            found_iface = False
            comments = []
            comments_for_keyword = {}

            for line in self.content:

                if found_iface:
                    if line.lstrip().startswith('#'):
                        comments.append(line)
                    else:
                        if comments:
                            comments_for_keyword[line] = comments
                            comments = []
                        commands_to_sort.append(line)

                # 99% of the time, this will only be the 'auto' and 'iface' lines.
                else:
                    f.write(line + '\n')

                if line.startswith('iface '):
                    found_iface = True

            # Sort all of the commands in this stanza.  This is
            # to make the stanza easier for the user to read.
            for line in sort_for_humans(commands_to_sort):
                # Assume that the comment for a line of configuration will be above the configuration line.
                for comment in comments_for_keyword.get(line, []):
                    f.write(comment + '\n')
                f.write(line + '\n')

    def is_swpx(self):
        return re.match(r"""^swpL?\d+(?:s\d+)?$""", self.name) is not None

    def is_physical(self, base_name=None):
        """
        Verify the interface is named like swp4, swp4s1 (breakout), or "eth0" and that it has an
        associated file in the directory /sys/class/net/.
        """
        if base_name is None:
            base_name = self.name

        if ((base_name == 'eth0' or
             base_name == 'eth1' or
             re.match(r"""swpL?\d+(?:s\d+)?$""", base_name) is not None or
             re.match(r"""fp\d+$""", base_name) is not None) and
            base_name in os.listdir('/sys/class/net/')):
            return True

        # If the user is breaking out an interface but hasn't done the commit
        # yet then the broken out interfaces will not be listed in
        # /sys/class/net/. Verify that the breakout's base interface is a
        # physical interface.
        re_breakout = re.match(r"""^(swpL?\d+)s\d+$""", base_name)

        if re_breakout is not None and re_breakout.group(1) in os.listdir('/sys/class/net/'):
            return True

        # If swp1 has been broken out then swp1 will no longer be in /sys/class/net/.
        # Look for swp1s0 and return True if it is in /sys/class/net/.
        re_swp = re.match(r"""swpL?\d+$""", base_name)

        if re_swp is not None:
            swps0 = re_swp.group(0) + "s0"

            if swps0 in os.listdir('/sys/class/net/'):
                return True

        log.info("{0} is not a physical interface on this switch.".format(base_name))
        return False

    def add_interface(self):
        """
        Add an auto/iface stanza to self.content, and write the content to a file
        of changes pending for this interface.
        """

        if self.content:
            print "{0} already exists in {1}.  No need to add it.".format(self.name, ETC_NETWORK_INTERFACES)
            return False

        if os.path.isfile(self.filename_del):
            # The user deleted the interface but wants to re-added it.  Remove the .del file.
            os.remove(self.filename_del)

        # Add the basic commands needed (auto and iface) for this interface.
        self.add_cmd("auto {0}".format(self.name))

        if self.name == 'lo':
            self.add_cmd("iface {0} inet loopback".format(self.name))
        else:
            self.add_cmd("iface {0}".format(self.name))

        self.write_file()
        return True

    def del_interface(self):
        """
        The name not withstanding, this method marks an interface for deletion by creating
        a file with the extension ".del".  No changes are made to ETC_NETWORK_INTERFACES.
        """
        self.content = []
        valid_interface = False

        if os.path.isfile(self.filename):
            if os.path.getsize(self.filename):
                valid_interface = True

            # Remove the pending changes file.
            os.remove(self.filename)

        if os.path.isfile(self.filename_original) and not os.path.getsize(self.filename_original):
            # Remove the empty .original file.
            os.remove(self.filename_original)

            if not valid_interface:
                print "{0} does not exist to delete.".format(self.name)
                return False

            return True

        if not os.path.isfile(self.filename_del):
            # Write an empty .del file so we know this is one that we are trying to delete.
            # The .del file will be deleted by commit_pending().
            open(self.filename_del, 'w').close()


        return True

    def del_interface_pending(self):
        """
        Return True if the .del file for an interace exists
        """
        return os.path.isfile(self.filename_del)

    def del_interface_abort(self):
        os.remove(self.filename_del)

    def del_interface_content(self):
        """
        Strip all uncommented content from the interface stanzas.
        """

        self.content = [line for line in self.content if line.startswith('auto ') or line.startswith('iface ') or line.startswith('#')]
        self.write_file()

    def conf_key_value_multiple_lines(self, add, key, value, tokens, give_feedback=True, existing_is_okay=False):
        """
        Add or delete a configuration command that can have multiple lines with
        the same key (but not the same value).  For example:
            address 1.1.1.1/32
            address 1.1.1.2/32

        Return True if the action succeeded.  Otherwise, return False.

        add - A boolean; if True, add the command; if False, remove the command
        tokens - A dictionary of command tokens; as generated by NetworkDocopt
        existing_is_okay - A boolean; Is it okay for the new key-value pair to equal an old key-value pair?
            For deletion, is it okay if the key-value pair is already not present?
        """

        assert isinstance(add, bool), "\"{0}\" is not a boolean.".format(add)
        assert isinstance(tokens, dict)

        iface_dhcp = "iface {0} inet dhcp".format(self.name)
        iface_dhcp6 = "iface {0} inet6 dhcp".format(self.name)
        iface_loopback = "iface {0} inet loopback".format(self.name)
        iface_loopback6 = "iface {0} inet6 loopback".format(self.name)
        iface_static = "iface {0}".format(self.name)

        if key == "address" and value == "dhcp":
            if add:
                if "ipv6" not in tokens:
                    # Add DHCP for IPv4.
                    if iface_static in self.content:
                        self.mod_cmd(iface_static, iface_dhcp, False)
                    elif iface_dhcp in self.content:
                        return existing_is_okay
                    elif iface_dhcp6 in self.content:
                        self.mod_cmd(iface_dhcp6, iface_dhcp, False)
                    elif iface_loopback in self.content:
                        self.mod_cmd(iface_loopback, iface_dhcp, False)
                    elif iface_loopback6 in self.content:
                        self.mod_cmd(iface_loopback6, iface_dhcp, False)
                    else:
                        raise RuntimeError("Every interface should have an iface line.")
                else:
                    # Add DHCP for IPv6.
                    if iface_static in self.content:
                        self.mod_cmd(iface_static, iface_dhcp6, False)
                    elif iface_dhcp in self.content:
                        self.mod_cmd(iface_dhcp, iface_dhcp6, False)
                    elif iface_dhcp6 in self.content:
                        if give_feedback:
                            # TODO - Don't print.
                            print "{0}'s configuration already has \"{1}\".".format(self, iface_dhcp6)
                        return existing_is_okay
                    elif iface_loopback in self.content:
                        self.mod_cmd(iface_loopback, iface_dhcp6, False)
                    elif iface_loopback6 in self.content:
                        self.mod_cmd(iface_loopback6, iface_dhcp6, False)
                    else:
                        raise RuntimeError("Every interface should have an iface line.")

                if self.get_cmd("address"):
                    # Delete static IPs.
                    self.del_cmd("    address", False, give_feedback)

            else:
                # del
                if iface_dhcp in self.content:
                    self.mod_cmd(iface_dhcp, iface_static, False)
                elif iface_dhcp6 in self.content:
                    self.mod_cmd(iface_dhcp6, iface_static, False)
                else:
                    if give_feedback:
                        # TODO - Don't print.
                        print "{0}'s does not use DHCP.".format(self)
                    return existing_is_okay

        else:
            if key == "address":
                # Make sure the iface line does not contain "dhcp".
                if iface_dhcp in self.content:
                    self.mod_cmd(iface_dhcp, iface_static, False)

            if add:
                cmd = "    {0} {1}".format(key, value)

                if cmd in self.content:
                    if give_feedback:
                        print "{0}'s configuration already has \"{1}\".".format(self, cmd.strip())
                    return existing_is_okay
                else:
                    self.add_cmd(cmd)
            else:
                if value:
                    cmd = "    {0} {1}".format(key, value)
                    self.del_cmd(cmd, True, give_feedback)
                else:
                    cmd = "    {0}".format(key)
                    self.del_cmd(cmd, False, give_feedback)

        # The action succeded.
        self.write_file()
        return True

    def conf_bridge_ports(self, add, value):
        new_content = []
        bridge_ports = []
        for line in self.content:
            if not line.strip().startswith("bridge-ports"):
                new_content.append(line)
            else:
                # grab all the bridge prots
                if len(line.strip().split('bridge-ports')):
                    for port in line.strip().split('bridge-ports')[1].split():
                        bridge_ports.append(port)

        # add or delete the bridge-ports
        if add:
            bridge_ports.append(value)
        else:
            # port may have already been moved due to earlier config change
            # for example, dot1x added to port then dot1x mab added
            if value in bridge_ports:
                bridge_ports.remove(value)

        if bridge_ports != []:
            new_content.append("    bridge-ports {}".format(" ".join(bridge_ports)))
            self.content = new_content




    def conf_key_value_multiple_values(self, add, key, values, give_feedback=True):
        """
        Some commands (bridge-ports for example) take a list of values from which
        we need to be able to add/del.

        values - A string of comma-separated values, or the empty string; possibly a glob
        """

        if values is None:
            # This happens for "net del bond ...".
            values = ''
        elif not isinstance(values, str):
            # This prevents undesirable downstream assertion failures.
            values = str(values)

        assert isinstance(values, str), "values={0}; type(values)={1}".format(values, type(values))
        ifaces_to_add = []

        # Return early here if we know that all we need to do is nuke all
        # lines for this keyword.  This is the case when add=False and values=''.
        if not add and not values:
            cmd = "    {0}".format(key)
            self.del_cmd(cmd, False, give_feedback)
            self.write_file()
            return ifaces_to_add

        # numeric globs...used by bridge-vids
        if is_number_glob(values):
            # CM-16899: If the user issues a command like "net add bridge bridge port 12",
            # error out because the user forgot the rest of the switchport name.  This
            # should not actually be a number glob.
            if key.lower() in ('bridge-ports', 'bond-slaves'):
                print "\"{0}\" is not a valid list of interfaces.".format(values)
                return []

            old_cmd = self.get_cmd("    {0} ".format(key))

            if old_cmd:
                values = glob_to_numbers(values)  # A sorted, deduplicated list
                old_values = ','.join(old_cmd.split()[1:])
                old_values = glob_to_numbers(old_values)

                if add:
                    if old_values:
                        final_values = old_values + values
                    else:
                        final_values = values
                else:
                    for x in values:
                        if x in old_values:
                            old_values.remove(x)
                    final_values = old_values

                if final_values:
                    glob = numbers_to_glob(final_values)
                    new_cmd = "    {0} {1}".format(key, glob.replace(',', ' '))

                    if new_cmd != old_cmd:
                        self.mod_cmd(old_cmd, new_cmd, give_feedback)
                else:
                    self.del_cmd(old_cmd, True, give_feedback)

            else:
                if add:
                    cmd = "    {0} {1}".format(key, values.replace(',', ' '))
                    self.add_cmd(cmd)

        # interfaces
        else:
            if key.startswith('address-virtual'):
                values = values.split()
            else:
                values_globs_expanded = ifname_expand_glob(values)  # A list of strings
                values = sort_for_humans(list(set(values_globs_expanded)))

            assert isinstance(values, list)

            # These two keywords accept interfaces as their argument.  Validate that
            # names beginning with "swp*" are valid physical interfaces.
            if add and key in ('bridge-ports', 'bond-slaves'):
                all_interfaces = os.listdir('/sys/class/net/')
                to_remove = []

                for ifname in values:
                    if re.match(r"""^swpL?\d+$""", ifname) and ifname not in all_interfaces:
                        to_remove.append(ifname)

                for ifname in to_remove:
                    if give_feedback:
                        print "{0} is not a physical interface on this switch.".format(ifname)
                    values.remove(ifname)

                if not values:
                    add = False

            old_cmd = self.get_cmd("    %s " % key)

            if old_cmd:
                old_cmd_expanded = expand_bridge_ports_glob(old_cmd)
                old_values = old_cmd_expanded.split()[1:]

                if add:

                    # The order of the values matters for address-virtual so we
                    # can't just create a set and convert back to a list
                    if key.startswith('address-virtual'):
                        final_values = []
                        for value in (old_values + values):
                            if is_mac_address(value):
                                continue

                            if value not in final_values:
                                final_values.append(value)
                        final_values = sorted(final_values)

                    else:
                        final_values = sort_for_humans(list(set(old_values + values)))
                else:
                    for x in values:
                        if x in old_values:
                            old_values.remove(x)
                        else:
                            if give_feedback:
                                print '"iface %s" %s does not contain %s' % (self, key, x)

                    if key.startswith('address-virtual'):
                        final_values = old_values
                    else:
                        final_values = sort_for_humans(old_values)

                if final_values:
                    new_cmd = "    %s %s" % (key, ' '.join(final_values))
                    new_cmd = new_cmd.replace('regex-', 'regex ')

                    if new_cmd != old_cmd:
                        self.mod_cmd(old_cmd, new_cmd, give_feedback)

                        if key in ('bridge-ports', 'bond-slaves'):
                            # If there is a "regex FOO" that we converted to "regex-FOO"
                            # for sorting purposes, do not try to create an interface
                            # called "regex-FOO"
                            final_values = [x for x in final_values if not x.startswith('regex')]
                            ifaces_to_add = final_values
                else:
                    self.del_cmd(old_cmd, True, give_feedback)
            else:
                if add:
                    some_enslaved = False
                    # First we check to see if a port is already enslaved to
                    # another bridge.
                    for port in values:
                        if get_master(port) and get_master(port) != self.name:
                            print("interface {} is already enslaved to {}".format(port, get_master(port)))
                            some_enslaved = True
                            break

                    if not some_enslaved:
                        cmd = "    %s %s" % (key, ' '.join(values))
                        self.add_cmd(cmd)
                        # Now we can add the port
                        if key in ('bridge-ports', 'bond-slaves'):
                            ifaces_to_add = values

        self.write_file()
        return ifaces_to_add

    def conf_key_value_solo(self, add, key, value, give_feedback=True, existing_is_okay=False):
        """
        Add or delete a configuration command that cannot have multiple lines with
        the same key.  For example: "bridge_fd 1".  Return True if the action
        succeeded.  Otherwise, return False.

        add - A boolean; if True, add the command; if False, remove the command
        existing_is_okay - A boolean; Is it okay for the new key-value pair to equal an old key-value pair?
            For deletion, is it okay if the key-value pair is already not present?
        """

        assert isinstance(add, bool), "\"{0}\" is not a boolean.".format(add)

        key = key.rstrip()

        if add:
            new_cmd = "    {0} {1}".format(key, value)
            old_cmd = self.get_cmd('    {0} '.format(key))

            if old_cmd:
                if not self.mod_cmd(old_cmd, new_cmd, give_feedback):
                    # The new command equals the old command.
                    return existing_is_okay
            else:
                self.add_cmd(new_cmd)
        else:
            command = "    {0} {1}".format(key, value) if bool(value) else "    {0}".format(key)
            if not self.del_cmd(command, bool(value), give_feedback):
                # Failed to delete the command.  Presumably, it was already not there.
                return existing_is_okay

        # The action succeded.
        self.write_file()
        return True

    def load_iface_state(self):
        """
        Populate self.content with lines from the pending changes file.
        """

        self.content = []

        if os.path.exists(self.filename):
            filename = self.filename
        elif os.path.exists(self.filename_original):
            filename = self.filename_original
        else:
            filename = None
            log.debug("{0}: {1} and {2} do not exist".format(self, self.filename, self.filename_original))

        if filename is not None:
            with open(filename) as f:
                for line in f:
                    line = standardize_indent(line)

                    # Ignore blank lines.
                    if line:
                        self.content.append(line)

    def init_iface_state(self):
        """
        Populate self.content with the current ETC_NETWORK_INTERFACES config,
        as output by "ifquery -a", for the given interface, unless a .del
        file exists.
        """

        if not os.path.isfile(self.filename + '.del'):
            self.content = self.ifquery

        # Remember the ETC_NETWORK_INTERFACES state of this interface. We
        # use this later to determine if someone is modifying the file and
        # modifying via iface (not supported).
        #
        # This file will be removed by commit_pending().
        with open(self.filename + '.original', 'w') as f:
            for line in self.content:
                f.write("{0}\n".format(line))


def show_bridge_vlan(args):
    # Build the vlans dict from the bridge json output
    try:
        vlan_show_output = check_output(['/sbin/bridge', '-c', '-j', 'vlan', 'show'])
    except Exception:
        vlan_show_output = '{}'

    try:
        vlans = json.loads(vlan_show_output)
    except Exception:
        vlans = {}

    # iproute2 does not yet support json so we must screen scrape :(
    try:
        ip_link_show_output = check_output(['/sbin/ip', '-d', 'link', 'show'])
    except Exception:
        ip_link_show_output = ''

    # Now combine the output from the two...basically just add
    # the VNI for each interface to the vlans dict
    ifname = None
    found_vni = False
    target_vlan = args.get('<number>')

    if target_vlan:
        ifnames_to_delete = []
        for ifname in vlans.keys():
            has_target_vlan = False
            vlans_to_delete = []

            for vlan_dict in vlans[ifname]:
                vlan_start = vlan_dict.get('vlan')
                vlan_end = vlan_dict.get('vlanEnd')

                if not vlan_end:
                    vlan_end = vlan_start

                if target_vlan >= vlan_start and target_vlan <= vlan_end:
                    has_target_vlan = True
                    vlan_dict['vlan'] = target_vlan
                    if 'vlanEnd' in vlan_dict:
                        del vlan_dict['vlanEnd']
                else:
                    vlans_to_delete.append(vlan_dict)

            for vlan_dict in vlans_to_delete:
                vlans[ifname].remove(vlan_dict)

            if not has_target_vlan:
                ifnames_to_delete.append(ifname)

        for ifname in ifnames_to_delete:
            del vlans[ifname]

    for line in ip_link_show_output.splitlines():
        '''
        We are interested in the 1st and 3rd lines:

        93: vxlan10101: <BROADCAST,MULTICAST,UP,LOWER_UP> ....
            link/ether 06:36:34:68:a1:1b brd ff:ff:ff:ff:ff:ff promiscuity 1
            vxlan id 10101 local 6.0.0.17 srcport 0 0 dstport 4789 nolearning ageing 300
        '''
        re_ifname = re.match('\d+: (.*?):', line)
        re_vni = re.match('\s+vxlan id (\d+)', line)

        if re_ifname:
            ifname = re_ifname.group(1)
        elif re_vni and ifname in vlans:
            vni = int(re_vni.group(1))
            found_vni = True

            for vlan_dict in vlans[ifname]:
                vlan_dict['vni'] = vni

    if args.get('json'):
        sys.stdout.write(json.dumps(vlans, indent=4) + '\n')
    else:
        header = ['Interface',
                  'VLAN',
                  'Flags']

        if found_vni:
            header.append('VNI')

        data = []
        sorted_interfaces = sort_ifaces(vlans.keys())
        for ifname in sorted_interfaces:

            for vlan_dict in vlans[ifname]:
                vlan_start = vlan_dict.get('vlan')
                vlan_end = vlan_dict.get('vlanEnd')
                flags = vlan_dict.get('flags', '')

                if flags:
                    flags = ', '.join(flags)

                if vlan_end:
                    vlan_range = "%d-%d" % (vlan_start, vlan_end)
                else:
                    vlan_range = vlan_start

                if found_vni:
                    vni = vlan_dict.get('vni', '')
                    data.append((ifname, vlan_range, flags, vni))
                else:
                    data.append((ifname, vlan_range, flags))

                # No need to repeat the ifname on every row
                ifname = ''

        sys.stdout.write('\n' + tabulate(tru(data), header) + '\n\n\n')


class ConfigWrapper(object):

    def __init__(self, show_linux_command, color_diffs):
        self.show_linux_command = show_linux_command
        self.color_diffs = color_diffs
        self.ifquery_all = None
        self.etc_network_interfaces_init_mod_time = None
        self.ifaces = {}
        self.working_dir = "/run/nclu/ifupdown2/"
        self.supported_stp_trad_bridge_attr = ["mstpctl-portautoedge", "mstpctl-portrestrrole"]
        self.init_working_dir()

        '''
        # This was causing issues where lo:1 would be deleted but the config
        # lines were not being moved under lo...commenting this out for now
        # to reduce risk for GA

        # When netd first starts we need to "add" the lo interface so that we
        # can migrate the configs that are under lo:1, lo:2, etc to be under lo
        self.get_ifquery_all()
        lo = EtcNetworkInterface('lo', self.ifquery_all)
        lo.write_file()
        '''

    def init_working_dir(self):

        if not os.path.isdir(self.working_dir):
            os.makedirs(self.working_dir, mode=WORKING_DIRECTORIES_PERMISSIONS)

    def get_managed_files(self):
        files = []
        files.append(ETC_NETWORK_INTERFACES)
        return files

    def get_service_cmd_for_file(self, filename):
        cmds = []

        if filename == ETC_NETWORK_INTERFACES:
            cmds.append(('ifreload', '-a'))

        return cmds

    def get_ifquery_all(self, refresh=False):
        if refresh or not self.ifquery_all or self.etc_network_interfaces_changed():
            MAX_ATTEMPTS = 6
            SLEEP_AMOUNT = 10

            for x in range(MAX_ATTEMPTS):
                try:
                    self.ifquery_all = check_output(["/sbin/ifquery", "-a", "--raw"], stderr=STDOUT)
                    self.etc_network_interfaces_init_mod_time = os.path.getmtime(ETC_NETWORK_INTERFACES)
                    break
                except CalledProcessError as e:
                    log.warning("Attempt {0}/{1}: \"ifquery -a\" failed.  Will sleep {2}s and try again.".format(x + 1, MAX_ATTEMPTS, SLEEP_AMOUNT))
                    sleep(SLEEP_AMOUNT)
            else:
                log.warning("\"ifquery -a\" failed due to \"{0}\".".format(e))
                sys.exit(1)  # TODO - This should be handled differently.

    def del_dot1x_trad_bridge_ports(self, iface):
        """
        for traditional bridges where bridge-ports have dot1x, we may need to
        delete special files (dot1x_bridgename_interface.intf) and this is done
        by creating a .del file.
        """

        dot1x_configwrapper = dot1x.ConfigWrapper(True, True)
        if (dot1x_configwrapper and iface.is_bridge() and (not self.is_pending_bridge_vlan_aware(iface.name) or
                not self.is_running_bridge_vlan_aware(iface.name))):
            ports = iface.get_keyword_value_list("bridge-ports")
            # Check each port for a dot1x config file.
            for port in ports:
                # we should only delete config snippets for dot1x ports
                for line in ports:
                    for ifname in line.split():
                        if dot1x_configwrapper.is_ifname_dot1x_enabled(ifname):
                            dot1x_bridge_filename = "{0}trad_bridge_dot1x_{1}_{2}.intf.del".format(self.working_dir, iface.name, ifname)
                            if not os.path.isfile(dot1x_bridge_filename):
                                # Create a new file for each dot1x bridge interface.
                                open(dot1x_bridge_filename, 'w').close()

    def add_interfaces(self, ifname):
        """
        Configure non-existent interfaces.  Return a list of interfaces that do not exist and
        could not be created.
        """

        assert isinstance(ifname, basestring), "This method takes an interface name or glob.  ifname is a {0}.".format(type(ifname))

        ifnames = ifname_expand_glob(ifname)
        self.get_ifquery_all()

        interfaces_not_created = []

        for ifname in ifnames:

            # Quagga can create a static route with these interface names as
            # the nexthop.  Do not create these interfaces.
            if ifname in ('null0', 'Null0', 'blackhole', 'reject'):
                interfaces_not_created.append(ifname)
                continue

            if not ifname_in_etc_network_interfaces(ifname):
                iface = EtcNetworkInterface(ifname, self.ifquery_all)
                if not iface.add_interface():
                    interfaces_not_created.append(ifname)
                    log.warning("ifupdown2.py:ConfigWrapper.add_interfaces: Could not add {0}.".format(ifname))

            # If the user is adding swp10.50 add swp10, if necessary.
            if '.' in ifname:
                base = ifname.split('.')[0]
                if re.match(r"""^(swpL?\d+)(?:s\d+)?$""", base) and not ifname_in_etc_network_interfaces(base):
                    iface = EtcNetworkInterface(base, self.ifquery_all)
                    if not iface.add_interface():
                        interfaces_not_created.append(ifname)
                        log.warning("ifupdown2.py:ConfigWrapper.add_interfaces: Could not add {0}.".format(ifname))

            # For each interface in a traditional bridge and in a dot1x
            # interface, we must remove the interface from the bridge
            # bridge-ports config and create a separate
            # /etc/network/interfaces.d config for the bridge with just that
            # port. This will allow hostapd/dot1x to move bridge-ports around
            # at will for traditional bridges.  This is needed because dynamic
            # vlan assignments in dot1x traditional bridge-ports might require
            # moving ports from one bridge to another.
            trad_bridge = None
            if self.get_pending_master(ifname) and not self.is_pending_bridge_vlan_aware(self.get_pending_master(ifname)):
                trad_bridge = EtcNetworkInterface(self.get_pending_master(ifname), self.ifquery_all)

            elif get_master(ifname) and not self.is_running_bridge_vlan_aware(get_master(ifname)):
                trad_bridge = EtcNetworkInterface(get_master(ifname), self.ifquery_all)

            if trad_bridge is not None:
                dot1x_configwrapper = dot1x.ConfigWrapper(True, True)
                if dot1x_configwrapper.is_ifname_dot1x_enabled(ifname):
                    # make corrections to configs if ifname is dot1x interface
                    current_ports = trad_bridge.get_keyword_value_list("bridge-ports")
                    if current_ports:
                        for line in current_ports:
                            if ifname in line.split():
                                # remove the port from the trad bridge
                                trad_bridge.conf_key_value_multiple_values(False, "bridge-ports", ifname)
                                trad_bridge.write_file()
                                # create a new config file which will be placed in
                                # /etc/network/interfaces.d/trad_bridge_dot1x_bridgename_interfacename.intf
                                dot1x_bridge_filename = "trad_bridge_dot1x_{0}_{1}.intf".format(trad_bridge.name, ifname)
                                dot1x_bridge = EtcNetworkInterface(dot1x_bridge_filename, self.ifquery_all)
                                # the file name is not the same as bridge name
                                dot1x_bridge.name = trad_bridge.name
                                dot1x_bridge.add_interface()
                                dot1x_bridge.conf_key_value_multiple_values(True, "bridge-ports", ifname)

        return interfaces_not_created

    def breakout_interface(self, args, ifname, first):
        breakout_ifname_regex = r"""{0}s\d+""".format(ifname)
        iface = EtcNetworkInterface(ifname, self.ifquery_all)
        ifaces = {}

        for line in self.ifquery_all.splitlines():
            line = standardize_indent(line)
            re_name = re.match(r"""auto\s+(\S+)\s*$""", line)

            if re_name is not None:
                tmp_ifname = re_name.group(1)
                ifaces[tmp_ifname] = EtcNetworkInterface(tmp_ifname, self.ifquery_all)

        if os.path.exists('/run/nclu/ifupdown2/'):
            for filename in os.listdir('/run/nclu/ifupdown2/'):
                if not filename.endswith('.original') and not filename.endswith('.del'):
                    if filename not in ifaces:
                        ifaces[filename] = EtcNetworkInterface(filename, self.ifquery_all)

        # delete breakout ports
        if args.get('disabled') or args.get('1x') or args.get('/4'):

            for (tmp_ifname, tmp_iface) in ifaces.iteritems():
                if re.match(breakout_ifname_regex, tmp_ifname):
                    if tmp_iface.exists():
                        tmp_iface.del_interface()

        if args.get('disabled'):
            if iface.exists():
                iface.del_interface()

        elif args.get('1x') or args.get('loopback'):
            if not iface.exists():
                iface.add_interface()

        elif args.get('2x'):
            if iface.exists():
                iface.del_interface()

            # Create the two breakout ports
            for x in xrange(2):
                tmp_ifname = "%ss%d" % (ifname, x)
                tmp_iface = EtcNetworkInterface(tmp_ifname, self.ifquery_all)

                if not tmp_iface.exists():
                    tmp_iface.add_interface()

            # If we moved for four breakout ports to two, delete #s 3 and 4
            for x in xrange(2, 4):
                tmp_ifname = "%ss%d" % (ifname, x)
                tmp_iface = EtcNetworkInterface(tmp_ifname, self.ifquery_all)

                if tmp_iface.exists():
                    tmp_iface.del_interface()

        elif args.get('4x') or args.get('4x10'):
            if iface.exists():
                iface.del_interface()

            # Create the four breakout ports.
            for x in xrange(4):
                tmp_ifname = "%ss%d" % (ifname, x)
                tmp_iface = EtcNetworkInterface(tmp_ifname, self.ifquery_all)

                if not tmp_iface.exists():
                    tmp_iface.add_interface()

        elif args.get('/4'):
            if not first:
                iface.del_interface()

        elif args.get('3/2'):
            if iface.exists():
                iface.del_interface()

            # Create the three breakout ports.
            if first:
                for x in xrange(3):
                    tmp_ifname = "%ss%d" % (ifname, x)
                    tmp_iface = EtcNetworkInterface(tmp_ifname, self.ifquery_all)

                    if not tmp_iface.exists():
                        tmp_iface.add_interface()

    def breakout_interfaces(self, args):
        assert args.get('<interface>') is not None
        ifnames = ifname_expand_glob(str(args.get('<interface>')))
        self.get_ifquery_all()
        first = True

        for ifname in ifnames:
            self.breakout_interface(args, ifname, first)
            first = False

    def abort_pending(self):
        if os.path.exists('/run/nclu/ifupdown2/'):
            for filename in os.listdir('/run/nclu/ifupdown2/'):
                full_filename = os.path.join('/run/nclu/ifupdown2/', filename)

                if os.path.isdir(full_filename):
                    rmtree(full_filename)
                else:
                    os.remove(full_filename)

        self.ifquery_all = None
        self.ifaces = {}
        self.etc_network_interfaces_init_mod_time = None

    def del_all(self, cli):
        self.get_ifquery_all()

        for ifname in get_interfaces():
            if ifname not in ("eth0", "eth1", "mgmt"):
                iface = EtcNetworkInterface(ifname, self.ifquery_all)

                if iface.exists():

                    # If this is a loopback or a physical interface, just delete the content
                    # and leave the auto/iface lines alone.  There are lots of services in
                    # linux that need a lo interface so we cannot delete it.  For the swp
                    # interfaces, we want to leave them in so the interface comes up after the
                    # net commit. This makes configuration easier because you can see who your
                    # LLDP peers are.
                    if iface.is_swpx() or iface.is_loopback():
                        iface.del_interface_content()
                    else:
                        iface.del_interface()

        # for traditional bridges, there may be a separate config file
        # for dot1x bridge-ports required by hostapd. For these, we
        # should remove any files in
        # /e/n/i.d/trad_bridge_<bridge_name>_<swX>.intf
        for trad_bridge in glob.glob(os.path.join(ETC_NETWORK_INTERFACES_D,
                                                  "trad_bridge_dot1x_*.intf")):
            filename = "/run/nclu/ifupdown2/{}.del".format(os.path.basename(trad_bridge))
            # write an empty file which will get deleted in the commit
            open(filename, "w").close()

    def commit_pending(self, verbose):
        """
        Persistent changes to ETC_NETWORK_INTERFACES.  For a successful commit, return (True, [str])
        where the list of strings indicates the files modified.  If the commit fails, return
        (False, str) where the string is an error message, if any.
        """

        # This should create INTERFACES_TMP.
        self._save_or_show_pending(persist=False, verbose=False)
        assert os.path.isfile(INTERFACES_TMP)

        # Sanity check the configuration via "ifup --syntax-check".
        problems = validate_syntax()
        if problems is not None:
            if os.path.exists(INTERFACES_TMP):
                os.remove(INTERFACES_TMP)
            return (False, problems, [])

        if os.path.exists(IFUPDOWN2_DIR_BACKUP):
            shutil.rmtree(IFUPDOWN2_DIR_BACKUP)

        if os.path.exists(ETC_NETWORK_INTERFACES_BACKUP):
            os.remove(ETC_NETWORK_INTERFACES_BACKUP)

        shutil.copyfile(ETC_NETWORK_INTERFACES, ETC_NETWORK_INTERFACES_BACKUP)
        shutil.copytree("/run/nclu/ifupdown2/", IFUPDOWN2_DIR_BACKUP)

        # TODO - This can return a non-empty message when commit_ok=True, but there is no way to return
        # non-error messages to the user right now.
        commit_ok, message = self._save_or_show_pending(persist=True, verbose=verbose)
        self.ifquery_all = None
        self.ifaces = {}
        self.etc_network_interfaces_init_mod_time = None

        if commit_ok:
            # Return a list of the files modified.  iface can only modify ETC_NETWORK_INTERFACES.

            if os.path.exists(IFUPDOWN2_DIR_BACKUP):
                shutil.rmtree(IFUPDOWN2_DIR_BACKUP)

            if os.path.exists(ETC_NETWORK_INTERFACES_BACKUP):
                os.remove(ETC_NETWORK_INTERFACES_BACKUP)

            return (True, '', [ETC_NETWORK_INTERFACES])
        else:
            # These files should always exist, but it can't hurt to check.

            if os.path.exists("/run/nclu/ifupdown2/"):
                shutil.rmtree("/run/nclu/ifupdown2/")

            if os.path.exists(IFUPDOWN2_DIR_BACKUP):
                shutil.move(IFUPDOWN2_DIR_BACKUP, "/run/nclu/ifupdown2/")

            if os.path.exists(ETC_NETWORK_INTERFACES_BACKUP):
                shutil.move(ETC_NETWORK_INTERFACES_BACKUP, ETC_NETWORK_INTERFACES)

        return (False, message, [])

    def get_pending(self):
        """
        Return the pending diff as a string.  If there are no changes, return the empty string.
        """

        self._save_or_show_pending(persist=False, verbose=False)

        the_diff = make_pending_diff(ETC_NETWORK_INTERFACES, INTERFACES_TMP, self.color_diffs)

        if os.path.isfile(INTERFACES_TMP):
            problems = validate_syntax()
            if problems is not None:
                the_diff += "\nWARNING: Committing these changes will cause problems.\n" + problems
            os.remove(INTERFACES_TMP)

        return the_diff

    def show_config_files(self, user_may_edit):
        # TODO - This method doesn't need user_may_edit.

        reply = ''

        if os.path.isfile(ETC_NETWORK_INTERFACES):
            reply += ETC_NETWORK_INTERFACES + '\n'
            reply += "=======================\n"
            with open(ETC_NETWORK_INTERFACES) as f:
                reply += f.read() + '\n'

        return reply

    def show_config_commands(self, user_may_edit, ifupdown2_wrapper):

        def command_sorter(a, b):
            """
            Commands that create bonds and vxlan interfaces must be issued first
            """
            priority_keywords = ('bond slaves', 'vxlan id')

            for keyword in priority_keywords:
                if keyword in a and keyword not in b:
                    return -1

                if keyword in b and keyword not in a:
                    return 1

            return cmp(a, b)

        commands = []
        ifaces = OrderedDict()

        # Set self.ifquery_all to the output of "ifquery -a".
        self.get_ifquery_all(True)

        name_re = re.compile(r"""^auto\s+(\S+)""")
        vlan_re = re.compile(r"""vlan-?(\d+)""")

        for line in self.ifquery_all.splitlines():
            line = standardize_indent(line)
            name_match = name_re.search(line)

            # Only consider the first line of an interface stanza.
            if name_match is None:
                continue

            ifname = name_match.group(1)
            assert not ifname.isdigit(), "Digits are not valid interface names (ifname={0}).".format(ifname)
            iface = EtcNetworkInterface(ifname, self.ifquery_all)

            if ifname not in ifaces:
                ifaces[ifname] = []

                if (not iface.content or
                    (len(iface.content) == 2 and
                     iface.content[0].startswith('auto ') and
                     'inet dhcp' not in iface.content[1] and
                     'inet6 dhcp' not in iface.content[1])):

                    # The interface does not have any content whose 'net add' will
                    # auto create the interface.  Add a 'net add'.
                    if iface.is_bridge():
                        # bridges can now have arbitrary names
                        # but the name 'bridge' is reserved for a single vlan-aware bridge.
                        commands.append('net add bridge {0}'.format(ifname))

                    elif ifname == 'lo' or iface.is_loopback():
                        commands.append('net add loopback {0}'.format(ifname))

                    elif iface.is_bond():
                        commands.append('net add bond {0}'.format(ifname))

                    elif iface.is_vxlan():
                        commands.append('net add vxlan {0}'.format(ifname))

                    elif iface.is_vlan_interface():
                        vlan_match = vlan_re.search(ifname)

                        if vlan_match:
                            commands.append('net add vlan {0}'.format(vlan_match.group(1)))
                        else:
                            commands.append('net add interface {0}'.format(ifname))

                    elif iface.is_vrf():
                        commands.append('net add vrf {0}'.format(ifname))

                    else:
                        commands.append('net add interface {0}'.format(ifname))

            # Parse the lines of the interface's stanza.
            for command in iface.content:
                foo = command.strip().split()
                key = foo[0]
                value = foo[1:]

                # ignore comments
                if key.startswith('#'):
                    continue

                # Special case:  We translate "iface eth0 inet dhcp" to "net add interface eth0 address dhcp".
                if ' '.join(value).endswith('inet dhcp'):
                    key = 'ip address'
                    value = ['dhcp', ]
                elif ' '.join(value).endswith('inet6 dhcp'):
                    key = 'ipv6 address'
                    value = ['dhcp', ]

                # Only consider stanza commands.
                if key in ('auto', 'iface'):
                    continue

                value = ' '.join(value)

                if is_number_glob(value):
                    value = numbers_to_glob(value.split())

                if key in ('bridge-ports', 'bond-slaves', 'bridge-vids'):
                    value = ','.join(value.split())

                elif key in ('post-up', 'post-down', 'up', 'down'):
                    value = "'" + value + "'"

                # If the user wrote the default for a keyword in ETC_NETWORK_INTERFACES,
                # skip it. We do this because we remove the default values from the parse
                # tree so the 'net add' for a keyword with its default value will fail.
                if key in keyword_default and keyword_default[key] == value:  # keyword_default is a global dictionary
                    continue

                # babelfish for 'net show config commands'
                if key == 'address':
                    if value != 'dhcp':
                        try:
                            IPv4Network(value)
                            key = 'ip address'
                        except AddressValueError:
                            key = 'ipv6 address'

                elif key == 'address-virtual':
                    key = 'ip address-virtual'

                elif key == 'ip-forward':
                    key = 'ip forward'

                elif key == 'gateway':
                    try:
                        IPv4Network(value)
                        key = 'ip gateway'
                    except AddressValueError:
                        key = 'ipv6 gateway'

                elif key == 'netmask':
                    try:
                        IPv4Network(value)
                        key = 'ip netmask'
                    except AddressValueError:
                        key = 'ipv6 netmask'

                # link-autoneg, link-duplex, link-fec and link-speed
                elif key.startswith('link-'):
                    key = key.replace('link-', 'link ')

                elif key.startswith('bond-'):
                    key = key.replace('bond-', 'bond ')

                elif key == 'bridge-stp':
                    key = 'stp'

                elif key.startswith('bridge-'):
                    # since we can have a bridge with any name,
                    # we need to remove the word bridge from attributes
                    key = key.replace('bridge-', '')

                elif key.startswith('mstpctl-'):
                    key = key.replace('mstpctl-', 'stp ')

                elif key.startswith('clagd-'):
                    key = key.replace('clagd-', 'clag ')

                elif key.startswith('clag-'):
                    key = key.replace('clag-', 'clag ')

                elif key.startswith('vxlan-'):
                    key = key.replace('vxlan-', 'vxlan ')

                # Now construct the actual command we will show
                if iface.is_bridge():
                    # a vlan aware bridge must be called bridge but other
                    # bridges (traditional) can be called anything.
                    ifaces[ifname].append('net add bridge {0} {1} {2}'.format(ifname, key, value))

                elif ifname == 'lo' or iface.is_loopback():
                    ifaces[ifname].append('net add loopback {0} {1} {2}'.format(ifname, key, value))

                elif iface.is_bond():
                    ifaces[ifname].append('net add bond {0} {1} {2}'.format(ifname, key, value))

                elif iface.is_vxlan():
                    ifaces[ifname].append('net add vxlan {0} {1} {2}'.format(ifname, key, value))

                elif iface.is_vlan_interface():
                    vlan_match = vlan_re.search(ifname)

                    if vlan_match:
                        ifaces[ifname].append('net add vlan {0} {1} {2}'.format(vlan_match.group(1), key, value))
                    else:
                        ifaces[ifname].append('net add interface {0} {1} {2}'.format(ifname, key, value))

                elif iface.is_vrf():
                    ifaces[ifname].append('net add vrf {0} {1} {2}'.format(ifname, key, value))

                else:
                    ifaces[ifname].append('net add interface {0} {1} {2}'.format(ifname, key, value))

                cmd_added = ifaces[ifname][-1]

                # There can be multiple IPs listed for address-virtual, but
                # these were added via multiple 'net add' commands.
                if 'address-virtual' in cmd_added:
                    up_to_mac_v4 = ' '.join(cmd_added.split()[0:7]).replace('ipv6 address-virtual', 'ip address-virtual')
                    up_to_mac_v6 = up_to_mac_v4.replace('ip address-virtual', 'ipv6 address-virtual')
                    ips = cmd_added.split()[7:]
                    ifaces[ifname].remove(cmd_added)

                    for ip in ips:
                        try:
                            IPv4Network(ip)
                            ifaces[ifname].append("{0} {1}".format(up_to_mac_v4, ip))
                        except AddressValueError:
                            ifaces[ifname].append("{0} {1}".format(up_to_mac_v6, ip))

        for ifname in sort_ifaces(ifaces.keys()):
            for command in ifaces[ifname]:
                commands.append(command)

        commands = globify_interface_commands(commands)

        # Create a temporary NetworkDocopt object so we can see
        # which 'commands' are supported. We need to replace the
        # 'iface' in our __doc__ with 'net'
        cli = NetworkDocopt(__doc__.replace('    iface ', '    net '))
        supported = []
        not_supported = []

        for command in commands:
            # We do not want the user to see the "Command not found"
            # error if this is an unsupported command so use Capturing
            # but do nothing with the output.
            with nclu.NetDaemon.Capturing():
                cli.run(shlex.split(command))

            if cli.match:
                supported.append(command)
            else:
                # For keywords like "link-down" where we automagically add the "yes"
                # we do not include the obvious "yes" in the parse tree so attempt
                # the command without that yes and see if it works
                if command.endswith(' yes'):
                    command = command[0:-4]

                    with nclu.NetDaemon.Capturing():
                        cli.run(shlex.split(command))

                    if cli.match:
                        supported.append(command)
                    else:
                        not_supported.append(command)
                else:
                    not_supported.append(command)
            cli.re_init()

        supported.sort(cmp=command_sorter)
        return (supported, not_supported)

    def show_config_summary(self, user_may_edit, summary):
        self.get_ifquery_all(True)

        name_re = re.compile("^auto\s+(\S+)\s*$")

        for line in self.ifquery_all.splitlines():
            line = standardize_indent(line)
            name_match = name_re.search(line)

            if name_match:
                ifname = name_match.group(1)
                iface = EtcNetworkInterface(ifname, self.ifquery_all)
                ifname = "INTERFACE:{0}".format(ifname)

                if ifname not in summary:
                    summary[ifname] = OrderedDict()

                if 'COMMAND_LIST' not in summary[ifname]:
                    summary[ifname]['COMMAND_LIST'] = []

                for command in iface.content:
                    foo = command.strip().split()
                    key = foo[0]
                    value = foo[1:]

                    if ' '.join(value).endswith('inet dhcp'):
                        key = 'address'
                        value = ['dhcp']
                    elif ' '.join(value).endswith('inet6 dhcp'):
                        key = 'ipv6 address'
                        value = ['dhcp']

                    if key in ('auto', 'iface'):
                        continue

                    summary[ifname]['COMMAND_LIST'].append('{0} {1}'.format(key, ' '.join(value)))

    def bridge_del(self, bridge):

        if not bridge:
            return

        # Call vlan_del() for the vlan glob in the bridge's bridge-vids
        # This will remove all references to those VLANs
        for line in bridge.content:
            if line.strip().startswith('bridge-vids'):
                vlan_glob = line.strip().replace('bridge-vids ', '')
                vlan_glob = ','.join(vlan_glob.strip().split())
                self.vlan_del(bridge, vlan_glob, True)
                break

        bridge.del_interface()

    def vlan_add(self, bridge, vlan_glob):
        bridge.conf_key_value_multiple_values(True, 'bridge-vids', vlan_glob)

    def vlan_del(self, bridge, vlan_glob, nuke_l2=False):
        if not bridge:
            return

        bridge.conf_key_value_multiple_values(False, 'bridge-vids', vlan_glob, give_feedback=False)
        vlans_to_del = glob_to_numbers(str(vlan_glob))

        for vlan in vlans_to_del:
            ifname = "vlan%d" % vlan
            iface = EtcNetworkInterface(ifname, self.ifquery_all)
            self.svi_del(iface)

        # remove any access interface in these vlans
        # remove these vlans from the bridge-vids of all trunks
        for ifquery_line in self.ifquery_all.splitlines():
            ifquery_line = standardize_indent(ifquery_line)
            re_name = re.search("^auto\s+(\S+)\s*$", ifquery_line)

            if re_name and re_name.group(1) != 'bridge':
                ifname = re_name.group(1)
                iface = EtcNetworkInterface(ifname, self.ifquery_all)

                # See if this is an SVI named "bridge.10"...if so and if
                # vlan 10 is one of the vlans we are deleting then delete
                # this interface and 'continue'
                re_strict_svi_name = re.search('^bridge\.(\d+)$', ifname)
                if re_strict_svi_name:
                    vlan_id = int(re_strict_svi_name.group(1))

                    if vlan_id in vlans_to_del:
                        iface.del_interface()
                        continue

                # We deepcopy here because we could end up deleting an
                # entry from iface.content
                for line in deepcopy(iface.content):

                    if 'bridge-access' in line:
                        # This interface is in a vlan that is being deleted.
                        # - remove the bridge-access line
                        # - remove this interface from the bridge's bridge-ports

                        bridge_access_vlan = int(line.strip().split()[1])

                        if bridge_access_vlan in vlans_to_del:
                            iface.conf_key_value_solo(False, 'bridge-access', bridge_access_vlan)
                            bridge.conf_key_value_multiple_values(False, 'bridge-ports', ifname, give_feedback=False)

                    elif 'bridge-vids' in line:
                        # Remove the vlans from the trunk's bridge-vids.
                        self.trunk_del(iface, vlan_glob)

                    # If this is a SVI for a vlan that is being deleted then delete the SVI
                    # Look for both vlan-id and vlan-raw-device to be 100% sure this is a SVI
                    elif 'vlan-id' in line:
                        vlan_id = int(line.strip().split()[1])

                        if vlan_id in vlans_to_del:
                            found_vlan_raw_device = False

                            for line2 in iface.content:
                                if 'vlan-raw-device' in line2:
                                    found_vlan_raw_device = True
                                    break

                            if found_vlan_raw_device:
                                iface.del_interface()
                                break

                    # nuke_l2 will be true if the user did 'net del bridge' and
                    # this vlan was listed under the bridge's bridge-vids
                    #
                    # Delete all of the bridge-* and mstpctl-* commands
                    elif nuke_l2 and (line.lstrip().startswith('bridge-') or line.lstrip().startswith('mstpctl-')):
                        foo = line.strip().split()
                        key = foo[0]
                        value = ' '.join(foo[1:])
                        iface.conf_key_value_solo(False, key, value)

    def access_add(self, bridge, iface, vlan):
        assert isinstance(bridge, EtcNetworkInterface)

        if iface.has_cmd('bridge-vids') or iface.has_cmd('bridge-pvid'):
            # This interface is configured as a trunk.  Remove that configuration.
            self.trunk_del(iface, None)

        # add this interface to bridge bridge-ports
        bridge.conf_key_value_multiple_values(True, 'bridge-ports', iface.name, give_feedback=False)

        # add this vlan to bridge bridge-vids
        bridge.conf_key_value_multiple_values(True, 'bridge-vids', str(vlan), give_feedback=False)

        # add bridge-access for this interface
        iface.conf_key_value_solo(True, 'bridge-access', vlan, give_feedback=False)

    def access_del(self, iface, vlan):
        """ Remove the bridge-access line for this interface. """

        iface.conf_key_value_solo(False, 'bridge-access', vlan)

    def voice_vlan_add(self, bridge, iface, voice_vlan=None, data_vlan=None):
        #if this interface is currently configured as 'access', remove that configuration
        if iface.has_cmd('bridge-access'):
            self.access_del(iface, None)

        # if this interface has a pvid configured, then remove it. The interface
        # might use the pvid conifgured for this port or the pvid could be that
        # of the bridge
        if iface.has_cmd('bridge-pvid'):
            bridge_pvid = iface.get_keyword_value('bridge-pvid')
            iface.conf_key_value_solo(False, 'bridge-pvid', bridge_pvid)

        #add this interface to bridge bridge-ports
        bridge.conf_key_value_multiple_values(True, 'bridge-ports', iface.name, give_feedback=False)

        #add the voice vlan if the voice traffic is in a voice vlan
        if voice_vlan is not None:
            #add the vlan as a trunk vlan
            iface.conf_key_value_solo(True, 'bridge-vids', voice_vlan, give_feedback=False)

            #add the vlan to the bridge bridge-vids
            bridge.conf_key_value_multiple_values(True, 'bridge-vids', voice_vlan, give_feedback=False)

        if data_vlan is not None:
            #add the data vlan as a the native vlan
            iface.conf_key_value_solo(True, 'bridge-pvid', data_vlan, give_feedback=False)

            #add the data_vlan to the bridge bridge-vids
            bridge.conf_key_value_multiple_values(True, 'bridge-vids', data_vlan, give_feedback=False)

        #add the stp configuration to the interface.
        # i. iface should be an edge port
        # ii. should have bpdugaurd enabled
        iface.conf_key_value_solo(True, 'mstpctl-bpduguard', 'yes', give_feedback=False)
        iface.conf_key_value_solo(True, 'mstpctl-portadminedge', 'yes', give_feedback=False)

    def voice_vlan_del(self, bridge, iface, voice_vlan=None, data_vlan=None):
        if bridge is not None:
            bridge.conf_key_value_multiple_values(False, 'bridge-ports', iface.name)

        #remove the vlan from the interface
        if iface.has_cmd('bridge-vids'):
            bridge_vid = iface.get_keyword_value('bridge-vids')
            iface.conf_key_value_solo(False, 'bridge-vids', bridge_vid)

        if iface.has_cmd('bridge-pvid'):
            bridge_pvid = iface.get_keyword_value('bridge-pvid')
            iface.conf_key_value_solo(False, 'bridge-pvid', bridge_pvid)

        #remove stp configuration
        if iface.has_cmd('mstpctl-bpduguard') is not None:
            iface.conf_key_value_solo(False, 'mstpctl-bpduguard', 'yes')
        if iface.has_cmd('mstpctl-portadminedge') is not None:
            iface.conf_key_value_solo(False, 'mstpctl-portadminedge', 'yes')

    def vrf_add(self, iface):
        """
        Add a VRF, "iface", if it doesn't exist.  If it doesn't exist and cannot be created,
        return False.  Otherwise, return True.
        """

        assert isinstance(iface, EtcNetworkInterface)

        if not iface.exists():
            if not iface.add_interface():
                log.warning("ifupdown2.py:ConfigWrapper.vrf_add: Could not add VRF {0}.".format(iface.name))
                return False

        iface.conf_key_value_solo(True, 'vrf-table', 'auto', give_feedback=False)
        return True

    def vrf_del(self, iface):
        iface.del_interface()

        # If any interfaces are configured to be in this vrf we must move
        # them out of this vrf and back to the default table
        for ifquery_line in self.ifquery_all.splitlines():
            ifquery_line = standardize_indent(ifquery_line)
            re_name = re.search("^auto\s+(\S+)\s*$", ifquery_line)

            if re_name:
                ifname = re_name.group(1)
                iface_tmp = EtcNetworkInterface(ifname, self.ifquery_all)
                iface_tmp_vrf = iface_tmp.get_keyword_value('vrf')

                if iface_tmp_vrf and iface_tmp_vrf == iface.name:
                    iface_tmp.del_cmd('    vrf %s' % iface.name, True, True)
                    iface_tmp.write_file()

    def trunk_add(self, bridge, iface, vlan_glob):

        # If this interface is currently configured as 'access', remove that configuration
        if iface.has_cmd('bridge-access'):
            self.access_del(iface, None)

        # add this interface to bridge bridge-ports
        bridge.conf_key_value_multiple_values(True, 'bridge-ports', iface.name, give_feedback=False)

        if vlan_glob:
            # add these vlans to the trunk bridge-vids
            iface.conf_key_value_multiple_values(True, 'bridge-vids', vlan_glob)

            # add these vlans to bridge bridge-vids
            bridge.conf_key_value_multiple_values(True, 'bridge-vids', vlan_glob, give_feedback=False)

    def trunk_del(self, iface, vlan_glob):
        deconfigure_trunk = False

        if vlan_glob:
            # Remove specific vlans from this trunk.
            initial_bridge_vids = iface.get_keyword_value('bridge-vids')
            iface.conf_key_value_multiple_values(False, 'bridge-vids', vlan_glob)
            final_bridge_vids = iface.get_keyword_value('bridge-vids')

            if initial_bridge_vids and not final_bridge_vids:
                # The last bridge-vid has been removed.  This interface should no longer be a trunk.
                deconfigure_trunk = True

        else:
            # The user did a del without specifying any vlans.  This interface should no longer be a trunk.
            deconfigure_trunk = True

        if deconfigure_trunk:
            if iface.has_cmd('bridge-vids'):
                bridge_vids = iface.get_keyword_value('bridge-vids')
                iface.conf_key_value_multiple_values(False, 'bridge-vids', bridge_vids)

            if iface.has_cmd('bridge-pvid'):
                iface.conf_key_value_solo(False, 'bridge-pvid', None)

    def svi_add(self, bridge, iface):
        re_bridge_sub_int = re.match(r"""^bridge\.(?P<sub_int>\d+)$""", iface.name, re.IGNORECASE)
        re_vlan_number = re.match(r"""^vlan-?(?P<vlan_int>\d+)$""", iface.name, re.IGNORECASE)
        assert not (re_bridge_sub_int is not None and re_vlan_number is not None), "These regexes should not both match."

        if (re_bridge_sub_int is not None or re_vlan_number is not None) and not iface.exists():
            if not iface.add_interface():
                log.warning("ifupdown2.py:ConfigWrapper.svi_add: Could not add interface {0}.".format(iface.name))
                return False

        if re_bridge_sub_int is not None:
            # The interface is a bridge subinterface.
            sub_int = int(re_bridge_sub_int.group('sub_int'))
            bridge.conf_key_value_multiple_values(True, 'bridge-vids', sub_int, give_feedback=True)
            return True

        elif re_vlan_number is not None:
            vlan_int = int(re_vlan_number.group('vlan_int'))
            iface.conf_key_value_solo(True, 'vlan-raw-device', 'bridge', give_feedback=False)
            iface.conf_key_value_solo(True, 'vlan-id', vlan_int, give_feedback=False)
            bridge.conf_key_value_multiple_values(True, 'bridge-vids', str(vlan_int), give_feedback=False)
            return True

        else:
            # This is the case when neither regular expression matches.  It indicates a programming error.
            log.error("ifupdown2.py:ConfigWrapper.svi_add should not be here.")
            return False

    def svi_del(self, iface):
        if iface.exists():
            iface.del_interface()

    def add_svi_interfaces(self, svi_ifnames):
        """
        Configure SVIs.  Return a list of interfaces that do not exist and could not be created.
        """

        self.get_ifquery_all()
        bridge = EtcNetworkInterface('bridge', self.ifquery_all)
        ### FIXME need to adjust for taditional bridges

        not_added = []

        if not bridge.exists():
            if bridge.add_interface():
                bridge.conf_key_value_solo(True, 'bridge-vlan-aware', 'yes', give_feedback=False)
            else:
                not_added.append("bridge")
                log.warning("ifupdown2.py:ConfigWrapper.add_svi_interfaces: Attempting to add SVIs, but could not add a bridge.")

        for ifname in svi_ifnames:
            iface = EtcNetworkInterface(ifname, self.ifquery_all)

            if not iface.exists():
                if not self.svi_add(bridge, iface):
                    not_added.append(ifname)
                    log.warning("ifupdown2.py:ConfigWrapper.add_svi_interfaces: Could not add interface {0}.".format(ifname))

        return not_added

    def vxlan_add(self, bridge, iface, vxlan_id):
        re_vxlan_number = re.match(r"""^vxlan-?(?P<vxlan_id>\d+)$""", iface.name, re.I)
        re_vni_number = re.match(r"""^vni-?(?P<vxlan_id>\d+)$""", iface.name, re.I)

        if vxlan_id:

            if iface.exists():
                if not iface.is_vxlan():
                    print "{0} is not a vxlan.".format(iface.name)
                    return False
            else:
                iface.add_interface()

            iface.conf_key_value_solo(True, 'vxlan-id', vxlan_id, give_feedback=False)
            iface.conf_key_value_solo(True, 'mstpctl-bpduguard', 'yes', give_feedback=False)
            iface.conf_key_value_solo(True, 'mstpctl-portbpdufilter', 'yes', give_feedback=False)
            bridge.conf_key_value_multiple_values(True, 'bridge-ports', iface.name, give_feedback=False)
            return True

        elif re_vxlan_number is not None or re_vni_number is not None:

            if re_vxlan_number is not None:
                vxlan_id = int(re_vxlan_number.group('vxlan_id'))
            elif re_vni_number is not None:
                vxlan_id = int(re_vni_number.group('vxlan_id'))

            if not iface.exists():
                iface.add_interface()

            iface.conf_key_value_solo(True, 'vxlan-id', vxlan_id, give_feedback=False)
            iface.conf_key_value_solo(True, 'mstpctl-bpduguard', 'yes', give_feedback=False)
            iface.conf_key_value_solo(True, 'mstpctl-portbpdufilter', 'yes', give_feedback=False)
            bridge.conf_key_value_multiple_values(True, 'bridge-ports', iface.name, give_feedback=False)
            return True

        else:
            print "A vxlan interface may be named \"vxlan10, vxlan-20, etc.\", or you can specify\n"\
                  "the vxlan-id via \"net add vxlan FOO vxlan id 10\".\n\n"
            return False

    def vxlan_del(self, bridge, iface, vlan):
        iface.del_interface()

        if ifname_in_etc_network_interfaces("bridge"):
            bridge = EtcNetworkInterface("bridge", self.ifquery_all)
            bridge.conf_key_value_multiple_values(False, "bridge-ports", iface.name, give_feedback=False)

    def get_iface(self, ifname):
        """
        Return an instance of EtcNetworkInterface for the given interface name.
        The data comes from "ifquery -a".
        """

        self.get_ifquery_all()

        if ifname in self.ifaces:
            iface = self.ifaces[ifname]
            iface.load_iface_state()
        else:
            self.ifaces[ifname] = EtcNetworkInterface(ifname, self.ifquery_all)
            iface = self.ifaces[ifname]

        return iface

    def get_ifaces(self, ifnames=None):
        """
        Return a list of EtcNetworkInterface instances containing each ifname in ifnames.
        """

        if ifnames is None:
            ifnames = get_interfaces()

        return [self.get_iface(ifname) for ifname in ifnames]

    def del_interface_from_bridges(self, ifaces, ifname_to_del):
        """
        Remove ifname_to_del from all bridge interfaces.
        """

        for iface in ifaces:
            if iface.has_cmd("bridge-ports"):
                iface.conf_key_value_multiple_values(False, "bridge-ports", ifname_to_del, give_feedback=False)
            elif iface.has_cmd("bridge_ports"):
                iface.conf_key_value_multiple_values(False, "bridge_ports", ifname_to_del, give_feedback=False)

    def is_running_bridge_vlan_aware(self, bridge_name):
        vlan_filtering = "/sys/class/net/{0}/bridge/vlan_filtering".format(bridge_name)
        if os.path.isfile(vlan_filtering):
            with open("/sys/class/net/{}/bridge/vlan_filtering".format(bridge_name)) as f:
                if '1' in f.read():
                    return True
        return False

    def is_pending_bridge_vlan_aware(self, bridge_name):
        """
        This method checks for a pending config for the bridge.
        The only way a bridge can be a traditional bridge is to
        have bridge-vlan-aware set to no.  The default is yes.
        """

        bridge_file = "/run/nclu/ifupdown2/{0}".format(bridge_name)
        if os.path.isfile(bridge_file):
            with open(bridge_file) as f:
                if "bridge-vlan-aware no" in f.read():
                    return False
                else:
                    return True
        else:
            return True

    def get_pending_master(self, ifname):
        """
        In the case where a bridge has been configured, we still need to
        know the pending master because some plugin or wrapper might have
        to make some config changes.  Users can combine multiple config
        changes before committing so we have to detect a master bridge.
        """

        for filename in os.listdir("/run/nclu/ifupdown2/"):
            if not filename.endswith(".original") and not filename.endswith(".del") and \
               not filename.endswith(".tmp"):
                ifname_config = "/run/nclu/ifupdown2/{0}".format(filename)
                with open(ifname_config) as f:
                    for line in f:
                        if 'bridge-ports' in line and ifname in line.strip().split(' '):
                            return filename
        return None

    def eval_command_line_args(self, cli):
        """
        - args is a dictionary produced by NetworkDocopt based on command line input from the user
        - Create an EtcNetworkInterface object for the interface we wish to modify
        - Find the Command object for the command keyword specified by the user (address, bridge-ports, etc)
        - Call the appropriate conf_XXX() function for this Command
        """

        argv_expanded_string = ' '.join(map(str, cli.argv_expanded))

        if (argv_expanded_string.startswith("net add interface eth0 vrf") and
            argv_expanded_string != "net add interface eth0 vrf mgmt"):

            print "Only \"vrf mgmt\" is allowed for eth0."
            return False

        args = cli.args
        ifnames = []
        command_ok = True

        if args.get("add") or args.get("del"):
            # Get the current configuration according to ifupdown2.
            self.get_ifquery_all()

            bridge = None
            vlan_glob = args.get("<number-range-list>") if args.get("<number-range-list>") is not None else args.get("<number-comma-range-list>")
            ifnames_valid, ifnames = get_ifnames(cli)  # (bool, [str])

            if not ifnames_valid:
                return False

            ###############################################################################
            # Test for conditions that require some preprocessing.
            ###############################################################################

            if ((args.get("clag") and (args.get("peer") or args.get("host"))) or
                args.get("bridge") or
                args.get("vlan") or
                args.get("vxlan")):

                if args.get("add"):
                    if argv_expanded_string.startswith("net add bridge") and args.get("<interface>"):
                        # The traditional bridge is not named "bridge" so for now it must be VLAN unaware
                        bridge_name = args.get("<interface>")
                        bridge = EtcNetworkInterface(bridge_name, self.ifquery_all)

                        if bridge.del_interface_pending():
                            bridge.del_interface_abort()
                            bridge.add_interface()

                        if not ifname_in_etc_network_interfaces(bridge_name):
                            # The bridge is not already configured.  Add it to the pending ETC_NETWORK_INTERFACES.
                            bridge.add_interface()

                        # Make the bridge interface vlan UNaware.
                        bridge.conf_key_value_solo(True, "bridge-vlan-aware", "no", False)

                    else:
                        # We have a single bridge named "bridge"
                        # or we could be here because the user added an
                        # interface with a bridge attribute so a vlan-aware
                        # bridge is automatically created
                        #
                        # if we are adding a bridge-port bridge attribute
                        # then check to make sure the port is not in a traditional bridge
                        # if it not then we allow creation of the vlan-aware bridge
                        vlan_aware = True
                        ifaces = args.get("<interface>")
                        if ifaces:
                            ports = ifname_expand_glob(ifaces)
                        else:
                            ports = []
                        for port in ports:
                            if port and get_master(port) and get_master(port) \
                                    and not self.is_running_bridge_vlan_aware(get_master(port)):
                                vlan_aware = False

                            elif port and self.get_pending_master(port) \
                                    and not self.is_pending_bridge_vlan_aware(self.get_pending_master(port)):
                                vlan_aware = False

                        if vlan_aware:
                            # only create a new bridge if the port being
                            # configured is not already part of a traditional
                            # bridge.
                            bridge = EtcNetworkInterface("bridge", self.ifquery_all)

                            if bridge.del_interface_pending():
                                bridge.del_interface_abort()
                                bridge.add_interface()

                            if not ifname_in_etc_network_interfaces("bridge"):
                                # The bridge is not already configured.  Add it to the pending ETC_NETWORK_INTERFACES.
                                bridge.add_interface()

                            # Make the bridge interface vlan aware.  If the bridge is already vlan aware, this is a no-op.
                            bridge.conf_key_value_solo(True, "bridge-vlan-aware", "yes", False)

                elif args.get("del") and ifname_in_etc_network_interfaces("bridge"):
                    # Create a EtcNetworkInterface instance for the existing bridge.
                    bridge = EtcNetworkInterface("bridge", self.ifquery_all)

            if args.get("vlan") and vlan_glob:
                # iface (add|del) vlan <number-range-list>

                if args.get("add"):
                    self.vlan_add(bridge, vlan_glob)
                elif args.get("del"):
                    if len(cli.argv_expanded) == 4:
                        self.vlan_del(bridge, vlan_glob)

            ###############################################################################
            # Test for "macro" commands.  These are commands that make more than one change
            # to the underlying configurations.
            ###############################################################################

            mgmt_vrf_msg = """
*********************************************************************************
NOTE: Enabling or disabling Management VRF will cause all SSH sessions to
disconnect on the next "net commit". This only happens the first time you do
a "net commit" after enabling or disabling Management VRF.

Enabling or disabling Management VRF may interfere with other previously
configured services which may previously have been using the management interface
for communication including: NTP, DNS, API, CLAG Backup IP, SNMP. See
"net example management-vrf" for more practical examples on using Management VRF
with NCLU.
*********************************************************************************
"""
            if argv_expanded_string == "net add vrf mgmt" or argv_expanded_string == "net add interface eth0 vrf mgmt":
                # Macros for Management VRF

                # "net add vrf mgmt" is a macro that does
                # - net add vrf mgmt vrf-table auto
                # - net add vrf mgmt address 127.0.0.1/8
                # - net add int eth0 vrf mgmt
                iface = EtcNetworkInterface("mgmt", self.ifquery_all)

                if not iface.exists():
                    iface.add_interface()

                iface.conf_key_value_solo(True, "vrf-table", "auto", args)
                iface.conf_key_value_multiple_lines(True, "address", "127.0.0.1/8", args)

                # Only auto add the eth0 "vrf mgmt" line if the user did "net add vrf mgmt".
                # If we were to add it here then later (when the normal code path for a "net add"
                # runs) we would print a "eth0's configuration already has 'vrf mgmt'" message
                # which would be confusing for the user.
                # TODO - Simplify this execution path.
                if argv_expanded_string == "net add vrf mgmt":
                    eth0 = EtcNetworkInterface("eth0", self.ifquery_all)

                    if not eth0.exists():
                        eth0.add_interface()
                        eth0.conf_key_value_multiple_lines(True, "address", "dhcp", args)
                    eth0.conf_key_value_solo(True, "vrf", "mgmt", args)

                print mgmt_vrf_msg
# TODO - Why not return here?
#                return True

            elif argv_expanded_string == "net del vrf mgmt" or argv_expanded_string == "net del interface eth0 vrf mgmt":
                iface = EtcNetworkInterface("mgmt", self.ifquery_all)
                if iface.exists():
                    iface.del_interface()

                if argv_expanded_string == "net del vrf mgmt":
                    eth0 = EtcNetworkInterface("eth0", self.ifquery_all)

                    if eth0.exists():
                        eth0.conf_key_value_solo(False, "vrf", "mgmt", args)

                print mgmt_vrf_msg
# TODO - Why not return here?
#                return True

            elif argv_expanded_string.startswith("net add clag peer"):
                # Macros for clag configuration

                bondname = "peerlink"
                interfaces = args.get("<interface>")
                bondname_sub = bondname + ".4094"

                if "peerlink" in interfaces:
                    print "You must specify the interfaces that will go in the \"peerlink\" bond to our fellow clag switch."
                    return False

                bond = EtcNetworkInterface(bondname, self.ifquery_all)
                if not bond.exists():
                    bond.add_interface()
                ifaces_to_add = bond.conf_key_value_multiple_values(True, "bond-slaves", interfaces)

                if ifaces_to_add:
                    self.add_interfaces(ifnames_to_glob(ifaces_to_add))

                # Add the peerlink bond to the bridge.
                bridge = EtcNetworkInterface("bridge", self.ifquery_all)
                bridge.conf_key_value_multiple_values(True, "bridge-ports", bondname)

                bondsub = EtcNetworkInterface(bondname_sub, self.ifquery_all)
                if not bondsub.exists():
                    bondsub.add_interface()

                if args.get("primary"):
                    bondsub.conf_key_value_multiple_lines(True, "address", "169.254.1.1/30", args)
                    bondsub.conf_key_value_solo(True, "clagd-peer-ip", "169.254.1.2")
                    bondsub.conf_key_value_solo(True, "clagd-priority", "1000")
                elif args.get("secondary"):
                    bondsub.conf_key_value_multiple_lines(True, "address", "169.254.1.2/30", args)
                    bondsub.conf_key_value_solo(True, "clagd-peer-ip", "169.254.1.1")
                    bondsub.conf_key_value_solo(True, "clagd-priority", "2000")

                bondsub.conf_key_value_solo(True, "clagd-sys-mac", args.get("<mac-clag>"))

                if args.get("backup-ip"):
                    if args.get("vrf"):
                        backup_ip = "{0} vrf {1}".format(args.get("<ipv4>"), args.get("<text>"))
                    else:
                        backup_ip = args.get("<ipv4>")

                    bondsub.conf_key_value_solo(True, "clagd-backup-ip", backup_ip)

                return True

            elif argv_expanded_string.startswith("net del clag peer"):
                # iface del clag peer [bond <interface>]

                bondname = "peerlink"
                bondname_sub = bondname + ".4094"

                bond = EtcNetworkInterface(bondname, self.ifquery_all)
                bondsub = EtcNetworkInterface(bondname_sub, self.ifquery_all)

                if bond.exists():
                    bond.del_interface()

                if bondsub.exists():
                    bondsub.del_interface()

                bridge = EtcNetworkInterface("bridge", self.ifquery_all)
                bridge.conf_key_value_multiple_values(False, "bridge-ports", bondname)
                return True

            elif argv_expanded_string.startswith("net add clag port"):
                # iface add clag port bond <interface> interface <interface> clag-id <0-65535>

                assert "<interface>" in args and isinstance(args["<interface>"], list) and len(args["<interface>"]) == 2
                bondname, interfaces = args.get("<interface>")
                bond = EtcNetworkInterface(bondname, self.ifquery_all)
                if not bond.exists():
                    if not ifname_is_valid(bond.name):
                        print "\"{0}\" is not a valid bond name.".format(bond.name)
                        return False
                    bond.add_interface()
                ifaces_to_add = bond.conf_key_value_multiple_values(True, "bond-slaves", interfaces)
                bond.conf_key_value_solo(True, "clag-id", args.get("<0-65535>"))

                if ifaces_to_add:
                    self.add_interfaces(ifnames_to_glob(ifaces_to_add))

                # add the host facing bond to the bridge
                bridge = EtcNetworkInterface("bridge", self.ifquery_all)
                if not bridge.exists():
                    bridge.add_interface()
                    bridge.conf_key_value_solo(True, "bridge-vlan-aware", "yes", give_feedback=False)
                bridge.conf_key_value_multiple_values(True, "bridge-ports", bondname)

                return True

            elif argv_expanded_string.startswith("net del clag port"):
                # iface del clag port bond <interface>

                bondname = args.get("<interface>")
                bond = EtcNetworkInterface(bondname, self.ifquery_all)

                if bond.exists():
                    bond.del_interface()

                # del the host facing bond from the bridge
                bridge = EtcNetworkInterface("bridge", self.ifquery_all)
                bridge.conf_key_value_multiple_values(False, "bridge-ports", bondname)
                return True

            for ifname in ifnames:
                iface = EtcNetworkInterface(ifname, self.ifquery_all)

                if args.get("add"):
                    if ((ifname.startswith("vlan") or ifname.startswith("bridge.")) and not iface.exists()):
                        if not self.svi_add(bridge, iface):
                            # TODO - This is getting logged, but that's all.  It should fail execution.
                            continue

                    if args.get("vxlan") and not iface.exists():
                        vxlan_id = args.get("<1-16777214>")

# TODO - Why is vxlan_id ORed on?
                        if not self.vxlan_add(bridge, iface, vxlan_id) or vxlan_id:
                            # TODO - This print an error message, but that's all.  It should fail execution.
                            continue

                    if args.get("bond"):
                        if args.get("slaves") or iface.is_bond():
                            # Don't need to add slave interfaces.
                            # ex. "net add bond bond1 bond slaves swp5-7"
                            pass
                        else:
                            # ex. "net add bond swp4"
                            print "{0} is not a bond.".format(ifname)
                            command_ok = False
                            continue

                    if ifname.startswith("lo:"):
                        # This is a legacy check.  Loopbacks used to be named lo:1, lo:2, etc.
                        print "The loopback interface must be named \"lo\".  Please use \"net add loopback lo\"."
                        command_ok = False
                        continue

                    if args.get("clag"):
                        # These are sanity checks to ensure clag is being configured on the right type of interface.

                        if args.get("sys-mac"):
                            if re.search(r"""\.\d+$""", ifname) is None:
                                print "\"clag sys-mac\" can only be configured on a sub-interface, such as swp1.4094."
                                command_ok = False
                                continue
                        elif args.get("peer-ip"):
                            if re.search(r"""\.\d+$""", ifname) is None:
                                print "\"clag peer-ip\" can only be configured on a sub-interface, such as swp1.4094."
                                command_ok = False
                                continue

                if args.get("add") and not iface.exists():
                    # We are doing an "add" to an interface that does not exist.  Add the interface.

                    if not iface.add_interface():
                        # TODO - This should fail the command.
                        log.debug("Failed to add interface %s." % iface.name)
                        continue

                ################################
                # These are more macro commands.
                ################################

                # The bridge-trunk, vlan, vxlan, etc., keywords are special because they are not from an ifupdown2 addon.
                # They are keywords that we explicitly added in the __doc__, so we must handle them here rather than in
                # the for loop for the addons.

                if args.get("bridge") and args.get("access"):
                    # bridge-access is from an ifupdown2 addon, but we want to overwrite it and
                    # treat it as a macro.  Handle it here.
                    vlan = args.get("<1-4094>")

                    if args.get("add"):
                        # iface add interface <interface> bridge access <1-4094>
                        self.access_add(bridge, iface, vlan)
                    elif args.get("del"):
                        # iface del interface <interface> bridge access <1-4094>
                        self.access_del(iface, vlan)

                elif args.get("bridge") and args.get("voice-vlan"):
                    # net add interface <interface> bridge voice-vlan <1-4094> [data-vlan <1-4094>]
                    # net del interface <interface> bridge voice-vlan [<1-4094>] [data-vlan <1-4094>]

                    data_vlan = None
                    voice_vlan = None
                    vlans = args.get("<1-4094>")
                    if args.get("data-vlan"):
                            if not isinstance(vlans, list):
                                data_vlan = vlans
                            else:
                                voice_vlan = vlans[0]
                                data_vlan = vlans[1]
                    else:
                        voice_vlan = vlans

                    if args.get("add"):
                        self.voice_vlan_add(bridge, iface, voice_vlan=voice_vlan, data_vlan=data_vlan)
                    elif args.get("del"):
                        self.voice_vlan_del(bridge, iface, voice_vlan=voice_vlan, data_vlan=data_vlan)

                elif (args.get("interface") or args.get("bond")) and args.get("bridge") and (args.get("trunk") or args.get("vids")):
                    # The user can configure a trunk via bridge-trunk or bridge-vids.
                    # bridge-vids can be configured on the bridge interface itself, through
                    # which is used to add support for a vlan, not configure a trunk.  Check
                    # to see if bridge-vids is being configured but not on the "bridge" interface.

                    # iface (add|del) interface <interface> bridge-trunk [vlans <number-range-list>]
                    # . . . and other commands.

                    if args.get("add"):
                        self.trunk_add(bridge, iface, vlan_glob)
                    elif args.get("del"):
                        self.trunk_del(iface, vlan_glob)

                elif args.get("vxlan") is not None and not keywords_configured(args):
                    # iface (add|del) vxlan <interface> vlan <1-4094>
                    vlan = args.get("<1-4094>")

                    if args.get("add"):
                        pass
                    elif args.get("del"):
                        self.vxlan_del(bridge, iface, vlan)

                elif args.get("del") and args.get("bridge") and len(cli.argv_expanded) == 3:
                    # iface del bridge
                    self.bridge_del(bridge)

                elif args.get("add") and args.get("vlan") and args.get("mtu"):
                    # net add vlan mtu

                    vlan_mtu = args.get("<552-9216>")
                    iface.conf_key_value_solo(True, "mtu", vlan_mtu)

                    # Get a list of bridge-ports.
                    bridge_ports = bridge.get_keyword_value("bridge-ports")

                    if bridge_ports is not None:
                        for bridge_port in bridge_ports.split():
                            bridge_port_iface = EtcNetworkInterface(bridge_port, self.ifquery_all)
                            bridge_port_iface_mtu = bridge_port_iface.get_keyword_value("mtu")

                            if not bridge_port_iface.is_vxlan() and (bridge_port_iface_mtu is None or int(bridge_port_iface_mtu) < int(vlan_mtu)):
                                bridge_port_iface.conf_key_value_solo(True, "mtu", vlan_mtu)

                elif iface and iface.is_bridge() and \
                        args.get("ports") and args.get("<interface-list>"):
                    if args.get("del"):
                        # Need to delete bridge-ports from a traditional bridge
                        # some ports may be dot1x ports so we also need to remove
                        # config snippets we add to /e/n/i.d
                        # also, we need to combine all the multiple bridge ports
                        # lines into one config line (the ifquery adds the config
                        # snippets back in
                        del_ifname_list = ifname_expand_glob(args.get("<interface-list>"))
                        dot1x_configwrapper = dot1x.ConfigWrapper(True, True)
                        all_bridge_ports = iface.get_keyword_value_list("bridge-ports")
                        bridge_ports = []
                        # sometimes, bridge-ports are all one one line so we
                        # split them up
                        for line in all_bridge_ports:
                            for port in line.split(' '):
                                bridge_ports.append(port)

                        for port in del_ifname_list:
                            # for the ports we are about to delete, we delete the
                            # dot1x ports differently
                            if port in bridge_ports:
                                bridge_ports.remove(port)
                                if not self.is_running_bridge_vlan_aware(iface.name) and \
                                   dot1x_configwrapper.is_ifname_dot1x_enabled(port):
                                    dot1x_bridge_filename = "{0}/trad_bridge_dot1x_{1}_{2}.intf.del".format(self.working_dir,iface.name, port)
                                    if not os.path.isfile(dot1x_bridge_filename):
                                        open(dot1x_bridge_filename, 'w').close()
                            else:
                                print "bridge-port {} is not in bridge {}".format(port, iface.name)
                                return False

                        # now remove dot1x ports from bridge_ports that were not
                        # deleted.  ifquery added these back into the content but
                        # they need to be removed since they have config snippets
                        # these are only deleted from the main /e/n/i file content
                        temp_ports = list(bridge_ports)
                        for port in bridge_ports:
                            if not self.is_running_bridge_vlan_aware(iface.name) and \
                               dot1x_configwrapper.is_ifname_dot1x_enabled(port):
                                # we only remove it from the iface content
                                temp_ports.remove(port)

                        new_content = []
                        for line in iface.content:
                            if not line.strip().startswith("bridge-ports"):
                                new_content.append(line)

                        # add in the bridge-ports
                        bridge_ports = temp_ports
                        if bridge_ports != []:
                            new_content.append("    bridge-ports {}".format(" ".join(bridge_ports)))

                        iface.content = new_content
                        iface.write_file()

                    elif args.get("add"):
                        # Need to add bridge-ports from a traditional bridge
                        add_ifname_list = ifname_expand_glob(args.get("<interface-list>"))
                        dot1x_configwrapper = dot1x.ConfigWrapper(True, True)
                        bridge_ports = iface.get_keyword_value_list("bridge-ports")
                        for port in add_ifname_list:
                            # for the ports we are about to add, we add the
                            # dot1x ports differently
                            if not self.is_running_bridge_vlan_aware(iface.name) and \
                               dot1x_configwrapper.is_ifname_dot1x_enabled(port):
                                temp_filename = "trad_bridge_dot1x_{0}_{1}.intf".format(iface.name, port)
                                temp_bridge = EtcNetworkInterface(temp_filename, self.ifquery_all)
                                temp_bridge.name = iface.name
                                temp_bridge.add_interface()
                                temp_bridge.conf_key_value_multiple_values(True, "bridge-ports", port)
                                temp_bridge.write_file()
                            else:
                                bridge_ports.append(port)

                        # now remove dot1x ports from bridge_ports that were not
                        # deleted.  ifquery added these back into the content but
                        # they need to be removed since they have config snippets
                        # these are only deleted from the main /e/n/i file content
                        temp_ports = list(bridge_ports)
                        for port in bridge_ports:
                            if not self.is_running_bridge_vlan_aware(iface.name) and \
                               dot1x_configwrapper.is_ifname_dot1x_enabled(port):
                                # we only remove it from the iface content
                                temp_ports.remove(port)

                        new_content = []
                        for line in iface.content:
                            if not line.strip().startswith("bridge-ports"):
                                new_content.append(line)

                        # add in the bridge-ports
                        bridge_ports = temp_ports
                        if bridge_ports != []:
                            new_content.append("    bridge-ports {}".format(" ".join(bridge_ports)))

                        iface.content = new_content
                        iface.write_file()

                # word-around for the word "vrf".  vrf is an interface type
                #   iface (add|del) vrf BLUE
                #
                # And it can be used to put an interface in a vrf
                #   iface (add)del int swp1 vrf BLUE
                #
                # If the length is 4 we know it is "iface (add|del) vrf BLUE" so handle
                # that here as a one of
                elif len(cli.argv_expanded) == 4 and cli.argv_expanded[2] == "vrf":
                    if cli.argv_expanded[1] == "add":
                        self.vrf_add(iface)
                    elif cli.argv_expanded[1] == "del":
                        self.vrf_del(iface)

                elif args.get("del") and args.get("address"):

                    if args.get("<ipv4/prefixlen>"):
                        iface.conf_key_value_multiple_lines(False, "address", args.get("<ipv4/prefixlen>"), args)
                    elif args.get("<ipv6/prefixlen>"):
                        iface.conf_key_value_multiple_lines(False, "address", args.get("<ipv6/prefixlen>"), args)
                    elif (args.get("ip") or args.get("ipv6")) and args.get("dhcp") and args.get("interface"):
                        # net del interface <interface> (ip|ipv6) address dhcp
                        assert re.match(r"""net del interface \S+ ip(v6)? address dhcp""", argv_expanded_string) is not None, \
                            "Unexpected command for this block of code."

                        # The line to modify ETC_NETWORK_INTERFACES looks like "iface <interface> inet(6) dhcp".
                        # The change is to remove the "inet(6) dhcp" ending.
                        old_cmd = "iface {0} inet{1} dhcp".format(iface.name, '6' if (" ipv6 " in argv_expanded_string) else '')
                        new_cmd = "iface {0}".format(iface.name)

                        if not iface.mod_cmd(old_cmd, new_cmd, True):
                            # Couldn't modify the appropriate line in ETC_NETWORK_INTERFACES.
                            return False

                        # Successfully deleted the configuration command.  Persist the change.
                        iface.write_file()
                    else:
                        for ip_address in iface.get_keyword_value_list("address"):
                            ip_address = IPNetwork(ip_address)

                            if args.get("ip"):
                                if isinstance(ip_address, IPv4Network):
                                    iface.conf_key_value_multiple_lines(False, "address", ip_address, args)
                            elif args.get("ipv6"):
                                if isinstance(ip_address, IPv6Network):
                                    iface.conf_key_value_multiple_lines(False, "address", ip_address, args)

                ######################
                # End macros
                ######################

                else:
                    # This is a "normal" (non macro) command that comes from an ifupdown2 addon.
                    # Find the Command object that matches.

                    # addons_cmds is a list of Command subclass instances.
                    for cmd in addons_cmds:
                        if not cmd.deprecated and cmd.keywords_in_args(args):
                            ifaces_to_add = []  # TODO - move down

                            ###########################################################
                            # keywords_in_args can yield false positives.  Detect them.
                            ###########################################################

                            # Another work-around for the "vrf" keyword collision
                            if cmd.keyword == "vrf" and len(cli.argv_expanded) >= 3 and cli.argv_expanded[2] == "vrf":
                                continue

                            # bridge-stp is split into "bridge" "stp" while mstpctl-bpduguard
                            # is split into "stp" "bpduguard" so if we only look for "stp" we
                            # will think the user configured "bridge stp" when they may have
                            # configured "stp bpduguard"
                            if "bridge" in cmd.keyword and "stp" in cmd.keyword and "bridge stp off" not in argv_expanded_string:
                                continue

                            # clag-id and vxlan-id will both have a keyord of "id" (due to
                            # splitting on the hyphen) so we must do a special check.
                            if cmd.keyword == "id":
                                if cmd.keyword_original == "clag-id":
                                    if not args.get("clag"):
                                        continue

                                elif cmd.keyword_original == "vxlan-id":
                                    if not args.get("vxlan"):
                                        continue

                            ###########################################################
                            # End false positive checks.
                            ###########################################################

                            # If this is the first time we've configured a particular
                            # vrf, we must add the "vrf-table auto" line.  This is a preprocessing step.
                            if args.get("add") and not args.get("vrf-table"):

                                # net add vrf BLUE
                                if cli.argv_expanded[2] == "vrf":
                                    self.vrf_add(iface)

                                # net add interface swp1 vrf BLUE
                                elif len(cli.argv_expanded) == 6 and cli.argv_expanded[4] == "vrf":
                                    vrf_name = args.get("<text>")
                                    vrf_iface = EtcNetworkInterface(vrf_name, self.ifquery_all)
                                    self.vrf_add(vrf_iface)

                            if args.get("add") and not iface.exists():
                                # We are adding or modifying an interface that does not exist, so add it.
                                # TODO - This already happened???
                                iface.add_interface()

                            if isinstance(cmd, CommandAddDelMultiLine):
                                iface.conf_key_value_multiple_lines(bool(args.get("add")),
                                                                    cmd.keyword_original,
                                                                    cmd.value_from_args(args),
                                                                    args)

                            elif isinstance(cmd, CommandAddDelMultiValue):

                                # address-virtual is special, there can be multiple lines of address-virtual
                                # and each of those lines is multivalue (there can be multiple IPs for the
                                # virtual MAC)
                                if cmd.keyword_original == "address-virtual":
                                    custom_keyword = "address-virtual {0}".format(args.get("<mac>"))

                                    use_multi_value = True if iface.get_cmd(custom_keyword) else False

                                    if use_multi_value:
                                        ifaces_to_add = iface.conf_key_value_multiple_values(bool(args.get("add")),
                                                                                             custom_keyword,
                                                                                             cmd.value_from_args(args))
                                    else:
                                        iface.conf_key_value_multiple_lines(bool(args.get("add")),
                                                                            cmd.keyword_original,
                                                                            cmd.value_from_args(args),
                                                                            args,
                                                                            existing_is_okay=True)
                                else:
                                    ifaces_to_add = iface.conf_key_value_multiple_values(bool(args.get("add")),
                                                                                         cmd.keyword_original,
                                                                                         cmd.value_from_args(args))

                            elif isinstance(cmd, CommandSetClear):
                                # for traditional bridges, we only allow a few STP attributes for now
                                # check the master of the port to make sure we can add the attribute
                                master = get_master(iface.name)
                                if "mstpctl-" in cmd.keyword_original and \
                                   cmd.keyword_original not in self.supported_stp_trad_bridge_attr:
                                    mstpctl_unsupported = True
                                else:
                                    mstpctl_unsupported = False

                                if mstpctl_unsupported and master and not self.is_running_bridge_vlan_aware(master):
                                    print "Traditional Bridge ({0}) ports only support: {1}".format(master,
                                                      ", ".join(self.supported_stp_trad_bridge_attr))
                                    return False

                                # we could also have a pending bridge config so
                                # we need to check that too
                                pending_master = self.get_pending_master(iface.name)
                                if mstpctl_unsupported and pending_master and not self.is_pending_bridge_vlan_aware(pending_master):
                                    print "Traditional Bridge ({0}) ports only support: {1}".format(pending_master,
                                                      ", ".join(self.supported_stp_trad_bridge_attr))
                                    return False

                                if not iface.conf_key_value_solo(bool(args.get("add")),
                                                          cmd.keyword_original,
                                                          cmd.value_from_args(args),
                                                          False,
                                                          existing_is_okay=True):
                                    return False

                            else:
                                raise TypeError("Command \"{0}\" is an invalid type: {1}".format(cmd, type(cmd)))

                            # Add the interfaces listed under bridge-ports, bond-slaves, etc.
                            self.add_interfaces(ifnames_to_glob(ifaces_to_add))
                            break
                    else:
                        # This goes with the above "for" loop.  No matching add-on command was found.
                        # net (add|del) interface <interface>

                        if args.get("add"):
                            if not iface.exists():
                                # TODO - This was already done above.
                                iface.add_interface()
                            # TODO - Else, the interface already exists.  Inform the user???
                        elif args.get("del"):
                            # TODO - Consolidate the next 2 blocks.
                            if ifname == "lo":
                                print "Deleting the loopback interface is not supported."
                                command_ok = False
                            elif ifname == "eth0" or ifname == "eth1":
                                print "Deleting the {0} interface is not supported.".format(ifname)
                                command_ok = False
                            elif args.get("vlan"):
                                # This was handled earlier via vlan_del().
                                # TODO - Should we have returned already?
                                pass
                            else:
                                ifnames = get_interfaces()
                                ifaces = self.get_ifaces(ifnames)
                                # for traditional bridges where bridge-ports have dot1x, we may need to
                                # delete special files (dot1x_bridgename_interface.intf)
                                self.del_dot1x_trad_bridge_ports(iface)

                                if iface.del_interface():

                                    self.del_interface_from_bridges(ifaces, ifname)

                                    # If there are any sub-interfaces for the interface we are deleting, delete the sub-interfaces too.
                                    for tmp_ifname in ifnames:
                                        if '.' in tmp_ifname:
                                            base = '.'.join(tmp_ifname.split('.')[0:-1])

                                            if base == iface.name:
                                                tmp_iface = EtcNetworkInterface(tmp_ifname, self.ifquery_all)

                                                if tmp_iface.exists():
                                                    tmp_iface.del_interface()
                                                    self.del_interface_from_bridges(ifaces, tmp_ifname)

        elif args.get("show"):
            if args.get("clag"):

                if args.get("macs") or args.get("our-macs") or args.get("peer-macs"):
                    # special case where we run two commands and produce our own output

                    data = []
                    ourmacs = []
                    peermacs = []
                    use_json = args.get("json")
                    target_mac = args.get("<mac>")

                    if args.get("macs") or args.get("our-macs"):
                        try:
                            ourmacs = json.loads(check_output(["/usr/bin/clagctl", "-j", "dumpourmacs"]))
                        except Exception as e:
                            ourmacs = []

                    if args.get("macs") or args.get("peer-macs"):
                        try:
                            peermacs = json.loads(check_output(["/usr/bin/clagctl", "-j", "dumppeermacs"]))
                        except Exception as e:
                            peermacs = []

                    for value in ourmacs:

                        if target_mac is not None and value['mac'] != target_mac:
                            continue

                        if use_json:
                            data.append({
                                "vlanId": int(value["vlanId"]),
                                "interface": value["outIf"],
                                "mac": value["mac"],
                                "owner": "local"
                            })
                        else:
                            data.append((int(value["vlanId"]), value["outIf"], value["mac"], "local"))

                    for value in peermacs:

                        if target_mac is not None and value['mac'] != target_mac:
                            continue

                        if use_json:
                            data.append({
                                "vlanId": int(value["vlanId"]),
                                "interface": value["outIf"],
                                "mac": value["mac"],
                                "owner": "peer"
                            })
                        else:
                            data.append((int(value["vlanId"]), value["outIf"], value["mac"], "peer"))

                    data = sorted(data)

                    if args.get("json"):
                        sys.stdout.write(json.dumps(data, indent=4) + '\n')
                    else:
                        header = ("VLAN", "Interface", "Dynamic MAC", "Owner")
                        sys.stdout.write('\n' + tabulate(tru(data), header) + "\n\n\n")

                else:
                    cmd = []
                    cmd.append("/usr/bin/clagctl")

                    if args.get("verbose"):
                        cmd.append("-v")

                    if args.get("json"):
                        cmd.append("--json")

                    if len(cli.argv_expanded) > 3:
                        for keyword in cli.argv_expanded[3:]:

                            if keyword == "json":
                                pass

                            elif keyword == "verbose":
                                pass

                            elif keyword == "our-multicast-entries":
                                cmd.append("dumpourmcast")

                            elif keyword == "our-multicast-router-ports":
                                cmd.append("dumpourrport")

                            elif keyword == "peer-multicast-entries":
                                cmd.append("dumppeermcast")

                            elif keyword == "peer-multicast-router-ports":
                                cmd.append("dumppeerrport")

                            elif keyword == "peer-lacp-rate":
                                cmd.append("peerlacprate")

                            elif keyword == "backup-ip":
                                cmd.append("showbackupip")

                            elif keyword == "id":
                                cmd.append("showclagid")

                            elif keyword == "verify-vlans":
                                cmd.append("verifyvlans")

                            elif keyword == "neighbors":
                                cmd.append("dumpneighs")
                            else:
                                cmd.append(keyword)

                    try:
                        output = check_output(cmd)
                    except CalledProcessError as e:
                        if "Unable to communicate with clagd." not in e.output.strip():
                            output = "\nWARNING: '%s' failed due to:\n%s\n" % (' '.join(cmd), e)
                        else:
                            output = ''
                    sys.stdout.write(output)

            elif args.get("bridge"):
                cmds = []
                cmd = []

                if args.get("macs"):
                    cmd.append("/sbin/bridge")
                    cmd.append("-s")
                    cmd.append("-j")
                    cmd.append("fdb")
                    cmd.append("show")
                    cmds.append(cmd)

                    target_mac = args.get("<mac>")
                    target_ip = args.get("<ip>")
                    target_permanent = args.get("permanent")
                    target_dynamic = args.get("dynamic")

                    if args.get("vlan"):
                        target_vlan = args.get("<number>")
                    else:
                        target_vlan = None

                    try:
                        bridge = json.loads(check_output(cmd))
                    except ValueError as e:
                        bridge = {}
                        output = "\nWARNING: '{0}' failed due to:\n{1}\n".format(' '.join(cmd), e)
                        print output

                    # To test output from someone's switch cut-n-paste their 'bridge -j -s fdb show' here
                    # bridge = json.loads(""" """)

                    if args.get("json"):
                        final = []

                        for row in bridge:

                            if target_mac and row.get("mac") != target_mac:
                                continue

                            if target_vlan and row.get("vlan") != target_vlan:
                                continue

                            if target_ip and row.get("dst") != target_ip:
                                continue

                            if target_permanent and row.get("state") != "permanent":
                                continue

                            if target_dynamic and row.get("state") == "permanent":
                                continue

                            final.append(row)
                        sys.stdout.write(json.dumps(final))
                    else:
                        header = ["VLAN",
                                  "Master",
                                  "Interface",
                                  "MAC",
                                  "TunnelDest",
                                  "State",
                                  "Flags",
                                  "LastSeen"]
                        data_unsorted = []

                        for row in bridge:

                            if target_mac and row.get("mac") != target_mac:
                                continue

                            if target_vlan and row.get("vlan") != target_vlan:
                                continue

                            if target_ip and row.get("dst") != target_ip:
                                continue

                            if target_permanent and row.get("state") != "permanent":
                                continue

                            if target_dynamic and row.get("state") == "permanent":
                                continue

                            # sort_for_humans needs a string so
                            # - build a tuple the represents this row
                            # - join the tuple with a ::: seperator
                            # - add that joined string to data_unsorted
                            # - sort data_unsorted via sort_for_humans
                            # - split each row on ::: and make it a tuple again
                            row_tuple = (row.get("vlan") if row.get("vlan") else "untagged",
                                         row.get("master"),
                                         row.get("dev"),
                                         row.get("mac"),
                                         row.get("dst"),
                                         row.get("state"),
                                         ", ".join(row.get("flags")) if row.get("flags") else '',
                                         seconds_to_hhmmss(row.get("updated")))
                            data_unsorted.append(":::".join(map(str, row_tuple)))

                        data = []
                        for row in sort_for_humans(data_unsorted):
                            row_list = []
                            for x in row.split(":::"):
                                if x == "None":
                                    row_list.append(None)
                                else:
                                    row_list.append(x)
                            data.append(tuple(row_list))

                        sys.stdout.write('\n' + tabulate(tru(data), header) + "\n\n")
                    cmds = []

                elif args.get("link"):
                    cmd.append("/sbin/bridge")
                    cmd.append("link")
                    cmd.append("show")
                    cmds.append(cmd)

                elif args.get("mdb"):
                    cmd.append("/sbin/bridge")
                    cmd.append("mdb")
                    cmd.append("show")
                    cmds.append(cmd)

                elif args.get("vlan"):
                    show_bridge_vlan(args)

                elif args.get("spanning-tree"):
                    bridge_name = get_vlan_aware_bridge_name()

                    if bridge_name is None:
                        print("{0} does not contain a vlan aware bridge".format(ETC_NETWORK_INTERFACES))

                    elif args.get("detail"):
                        cmd.append("/sbin/mstpctl")
                        cmd.append("showbridge")
                        if args.get("json"):
                            cmd.append("json")

                        cmd.append(bridge_name)
                        cmds.append(cmd)

                        if args.get("json"):
                            try:
                                showbridge = json.loads(check_output(cmd))
                            except (CalledProcessError, ValueError) as e:
                                showbridge = {}
                                output = "\nWARNING: '%s' failed due to:\n%s\n" % (' '.join(cmd), e)
                                sys.stdout.write(output + '\n')
                        cmd = []
                        cmd.append("/sbin/mstpctl")
                        cmd.append("showportdetail")
                        cmd.append(bridge_name)

                        if args.get("json"):
                            cmd.append("json")
                            try:
                                showportdetail = json.loads(check_output(cmd))
                            except (CalledProcessError, ValueError) as e:
                                showportdetail = {}
                                output = "\nWARNING: '%s' failed due to:\n%s\n" % (' '.join(cmd), e)
                                sys.stdout.write(output + '\n')

                            # Combine showbridge with showportdetail into one JSON object.
                            combined_json = {}
                            for i in showbridge.keys():
                                combined_json[i] = showbridge.get(i)
                            for i in showportdetail.keys():
                                combined_json[i] = showportdetail.get(i)
                            sys.stdout.write(json.dumps(combined_json) + '\n')
                            cmds = []
                        else:
                            cmds.append(cmd)
                    else:
                        ifname = args.get("<interface>")

                        if ifname:
                            if ifname == "bridge":
                                cmd.append("/sbin/mstpctl")
                                cmd.append("showbridge")

                                if args.get("json"):
                                    cmd.append("json")

                                cmd.append(bridge_name)
                                cmds.append(cmd)
                            else:
                                cmd.append("/sbin/mstpctl")
                                cmd.append("showportdetail")
                                cmd.append(bridge_name)

                                if args.get("json"):
                                    cmd.append("json")
                                cmd.append(ifname)
                                cmds.append(cmd)

                        else:
                            cmd.append("/sbin/mstpctl")
                            cmd.append("showbridge")

                            if args.get("json"):
                                cmd.append("json")

                            cmd.append(bridge_name)
                            cmds.append(cmd)

                            if args.get("json"):
                                try:
                                    showbridge = json.loads(check_output(cmd))
                                except (CalledProcessError, ValueError) as e:
                                    showbridge = {}
                                    output = "\nWARNING: '%s' failed due to:\n%s\n" % (' '.join(cmd), e)
                                    sys.stdout.write(output)
                            cmd = []
                            cmd.append("/sbin/mstpctl")
                            cmd.append("showport")
                            cmd.append(bridge_name)

                            if args.get("json"):
                                cmd.append("json")

                            cmds.append(cmd)

                            # This is a special case because we have to combined the output from two json commands
                            if args.get("json"):
                                try:
                                    showport = json.loads(check_output(cmd))
                                except (CalledProcessError, ValueError) as e:
                                    showport = {}
                                    output = "\nWARNING: '%s' failed due to:\n%s\n" % (' '.join(cmd), e)
                                    sys.stdout.write(output + '\n')

                                combined = {}
                                for (key, value) in showbridge.iteritems():
                                    if key.lower() == "bridge":
                                        combined["bridge"] = {}
                                        if isinstance(value, dict):
                                            for (k, v) in value.iteritems():
                                                # Add all the values associated with the key "bridge".
                                                combined["bridge"][k] = v

                                for (key, value) in showport.iteritems():
                                    if key in showport.keys():
                                        combined[key] = {}
                                        if isinstance(value, dict):
                                            assert len(value.keys()) == 1
                                            firstelem = value.keys()[0]  # Value should have only one key, the Port ID (like "8.002").
                                            for (k, v) in value.get(firstelem).iteritems():
                                                # Only extract the role and state.
                                                if k.lower() == "role" or k.lower() == "state":
                                                    combined[key][k] = v

                                sys.stdout.write(json.dumps(combined) + '\n')
                                cmds = []

                # Run all the show commands queued above.
                for cmd in cmds:
                    try:
                        output = check_output(cmd)
                    except (CalledProcessError, ValueError) as e:
                        output = "\nWARNING: '%s' failed due to:\n%s\n" % (' '.join(cmd), e)
                    if args.get("show") and args.get("bridge") and args.get("spanning-tree"):
                        output = self.process_spanningtree_output(output)
                    sys.stdout.write(output + '\n')

        return command_ok

    def process_spanningtree_output(self, output):
        """
        This function processes the output from 'mstpctl showport bridge' and 'mstpctl showbridge bridge'
        and returns a clean version when 'net show bridge spanning-tree' is run.
        """

        assert output != ''
        if "bridge CIST info" in output:
            # Process the output of 'mstpctl showbridge bridge'.
            # "bridge CIST info" is removed and "Bridge info" is put.
            to_return = 'Bridge info\n' + '\n'.join(output.split('\n')[1:3]) + '\n'
            # The Bridge ID and the Root ID are split into 'Priority' and 'Address'.
            # The priority value in hex is concatenated with the MAC Address, in the Bridge ID (and the Root ID).
            # These two values are split and printed separately. The Priority value is written in Decimal.
            to_return += '    Priority:\t  ' + str(self.get_decimal_from_hex(''.join(output.split('\n')[2].split()[-1].split('.')[:2]))) + '\n'
            to_return += '    Address:\t  ' + output.split('\n')[2].split()[-1].split('.')[-1] + '\n'
            # If this bridge is root, print "This bridge is the root" (Similar to Cisco's implementation).
            if self.is_this_bridge_root(output.split('\n')[2], output.split('\n')[3]):
                to_return += '  This bridge is root.\n\n'
            to_return += output.split('\n')[3] + '\n'
            to_return += '    Priority:\t  ' + str(self.get_decimal_from_hex(''.join(output.split('\n')[3].split()[-1].split('.')[:2]))) + '\n'
            to_return += '    Address:\t  ' + output.split('\n')[3].split()[-1].split('.')[-1] + '\n\n'
            to_return += '\n'.join(output.split('\n')[5:12]) + '\n'
            return to_return
        else:
            # Process the output of 'mstpctl showport bridge'.
            # Pick only the interface name, state and role from the 'mstpctl showport bridge' output passed to this function.
            spanningtree_table_re = re.compile(r"""(?:\w+\s+)?(\w+)\s+(?:\d\.\d{3})\s+(forw|disc)\s+(?:\d.\d{3}\.(?:\w\w:){5}\w\w\s+)(?:\d.\d{3}\.(?:\w\w:){5}\w\w\s+)\d\.\d{3}\s+(Root|Desg|Altn|Disa|Back)""", re.IGNORECASE)
            port_lines = spanningtree_table_re.findall(output)
            tabulate_header = ('INTERFACE', 'STATE', 'ROLE')
            tabulate_data = []
            if len(port_lines) > 0:
                for i in port_lines:
                    interface, state, role = i
                    row_to_append = (interface, state, role)
                    tabulate_data.append(row_to_append)
                return tabulate(tru(tabulate_data), tabulate_header, tablefmt="simple")
            else:
                return output

    def get_decimal_from_hex(self, hexval):
        """
        :param hexval:
        :return: Decimal representation of hexval, which is a string
        """
        hex_re = re.compile(r"""[a-f0-9]+""", re.IGNORECASE)
        if hex_re.match(hexval):
            return int(hexval, 16)
        else:
            return "None"

    def is_this_bridge_root(self, bridge_id_line, root_id_line):
        """
        :param bridge_id_line:
        :param root_id_line:
        :return: boolean

        This function takes two lines containing the Bridge ID and the Root ID. It extracts the Bridge ID and the root ID and returns True if they are equal (else False).
        """
        bridge_id = bridge_id_line.split()[-1]
        root_id = root_id_line.split()[-1]
        return bridge_id == root_id

    def etc_network_interfaces_changed(self):
        """
        Return True if some other user modified ETC_NETWORK_INTERFACES.
        Otherwise, return False.
        """

        if self.etc_network_interfaces_init_mod_time is None:
            # We haven't started making changes to ETC_NETWORK_INTERFACES yet.
            return False

        etc_network_interfaces_mod_time = os.path.getmtime(ETC_NETWORK_INTERFACES)

        if self.etc_network_interfaces_init_mod_time != etc_network_interfaces_mod_time:

            if os.path.exists(PENDING_COMMANDS_FILE):
                print "{0} was modified by another user.".format(ETC_NETWORK_INTERFACES)
                print get_pending_add_del_commands()
                return True

            # If the user hasn't staged any changes, adopt the new copy of the file.
            else:
                self.etc_network_interfaces_init_mod_time = etc_network_interfaces_mod_time

        return False

    # TODO - Revise this function.
    def _save_or_show_pending(self, persist, verbose):
        """
        If persist is True:
        - write changes to ETC_NETWORK_INTERFACES
        - delete various tmp files, such as .del and .original
        - "ifreload -a" to apply changes

        Otherwise:
        - write changes to INTERFACES_TMP

        Return a 2-tuple of (bool, str).  If the first parameter is False,
        the second parameter is an error message.
        """

        assert isinstance(persist, bool)
        assert isinstance(verbose, bool)

        if self.etc_network_interfaces_changed():
            return (False, "{0} has changed.".format(ETC_NETWORK_INTERFACES))

        if persist:
            target_filename = ETC_NETWORK_INTERFACES
        else:
            target_filename = INTERFACES_TMP
            self.init_working_dir()
            copyfile(ETC_NETWORK_INTERFACES, target_filename)

        iface_files = {}      # key:value pairs look like <filename>:[lines of file]
        iface_delete = set()  # Interfaces to delete
        iface_written = []

        # Make a first pass to:
        # - find all interfaces with a .del file
        # - remove the .original files
        dot1x_trad_bridge_delete_files = []
        dot1x_trad_bridge_add_files = []
        for ifname in os.listdir("/run/nclu/ifupdown2/"):
            filename = "/run/nclu/ifupdown2/{0}".format(ifname)

            # Ignore these. DOT1X file are special and they will be copied
            # later
            if ifname.startswith("trad_bridge_dot1x_") and ifname.endswith(".del"):
                dot1x_trad_bridge_delete_files.append(ifname)

            if filename.endswith(".del"):
                ifname = ifname[:-4]
                iface_delete.add(ifname)

                if persist:
                    os.remove(filename)

                    if os.path.isfile("/run/nclu/ifupdown2/{0}".format(ifname)):
                        os.remove("/run/nclu/ifupdown2/{0}".format(ifname))

            elif filename.endswith(".original") and persist:
                os.remove(filename)

        # Make a second pass to load the content for interfaces that have been modified
        # but are not being deleted.
        for ifname in os.listdir("/run/nclu/ifupdown2/"):

            if ifname.startswith("trad_bridge_dot1x_") and ifname.endswith(".intf"):
                continue

            if (ifname in ("interfaces_for_diff", "interfaces.tmp", "etc_network_interfaces.backup") or
                ifname.endswith(".del") or ifname.endswith(".original")):
                continue

            filename = "/run/nclu/ifupdown2/{0}".format(ifname)
            filename_del = filename + '.del'

            # If the interface will be deleted do not add this interface
            # to the iface_files dict
            if os.path.isfile(filename_del):
                continue

            # Ignore non-files.  This should only happen if a user creates one manually.
            if not os.path.isfile(filename):
                log.info("commit_pending() ignored {0}, which is not a file.".format(filename))
                continue

            with open(filename) as f:
                iface_files[ifname] = list(f)

        # Sanity check that mako templates are not in use.
        with open(ETC_NETWORK_INTERFACES) as f:
            for line in f:
                line = line.strip()
                if line.startswith("<%") or line.startswith("% "):
                    return (False, "{0} contains mako templates.  NCLU does not support mako templates.".format(ETC_NETWORK_INTERFACES))

        # Handle writing DOT1X file for traditional bridges
        if persist:
            for dot1x_filename in glob.glob("/run/nclu/ifupdown2/trad_bridge_dot1x_*.intf"):
                shutil.copy(dot1x_filename, ETC_NETWORK_INTERFACES_D)
                os.remove(dot1x_filename)
            # now make sure to delete files if any
            for del_file in dot1x_trad_bridge_delete_files:
                # the trad bridge-ports dot1x interfaces filenames just have a .del suffix so we remove it
                # they are dot1x_bridgename_port.intf.del so we remove the
                # suffix before deleting.
                del_file = re.sub(r""".del$""", '', del_file)
                filename_del = os.path.join(ETC_NETWORK_INTERFACES_D, del_file)
                if os.path.isfile(filename_del):
                    os.remove(filename_del)

        # r+ opens the file for reading and writing.
        with open(target_filename, "r+") as f:

            # Read in all lines, and reset the file handle back to the start of the file.
            lines = list(f)
            f.seek(0)

            state = "WRITE"
            prev_line = None
            lines_to_write = []

            # Write all of the lines back to the file, but update the
            # stanzas for interfaces with /run/nclu/ifupdown2/ files.
            # This will maintain the original order of the stanzas.
            for line in lines:
                line = standardize_indent(line).rstrip()
                re_auto = re.search(r"""^\s*auto\s+(\S+)\s*$""", line)

                if re_auto is not None:
                    ifname = re_auto.group(1)
                    # re_old_loopback = re.search("^\s*auto\s+lo:\d+\s*$", line)

                    # Look to see if any of the interfaces in iface_files need to be
                    # written before this interface in order to keep them sorted
                    # in ETC_NETWORK_INTERFACES.
                    ifaces_to_add_here = []
                    sorted_interfaces = sort_ifaces(iface_files.keys() + [ifname])

                    for x in sorted_interfaces:
                        if x == ifname:
                            break
                        ifaces_to_add_here.append(x)

                    # log.info("%s: line '%s'" % (ifname, line))
                    # log.info("%s: sorted_interface %s" % (ifname, sorted_interfaces))
                    # log.info("%s: interfaces to add here %s" % (ifname, ifaces_to_add_here))

                    if ifaces_to_add_here:
                        # We are at an 'auto' line, and we need to insert interfaces prior
                        # to this auto line.  What if there are comments before this auto line?
                        # We need to insert our interfaces before those comments.
                        comments = []

                        for x in reversed(lines_to_write):
                            if x.startswith('#'):
                                comments.append(x)
                            else:
                                break

                        # Remove the comments for this 'auto'.
                        if comments:
                            comments_to_chop = -1 * len(comments)
                            lines_to_write = lines_to_write[:comments_to_chop]

                        # Add the interfaces that need to go before this auto.
                        for x in ifaces_to_add_here:
                            write_new_interface(lines_to_write, prev_line, x, iface_files[x], persist)
                            del iface_files[x]
                            iface_written.append(x)

                        # Restore the comments for this 'auto'.
                        lines_to_write.extend(reversed(comments))

                    if ifname in iface_delete:
                        # Do not write any of the configuration lines for an interface we are trying to delete.
                        log.debug("{0}: remove from {1}".format(ifname, target_filename))
                        iface_delete.remove(ifname)

                        if state == "WRITE":
                            # log.debug("WRITE->SKIP: %s" % line)
                            state = "SKIP"

                    elif ifname in iface_files:

                        # This is an interface that has been modified via iface.  Write the config lines
                        # from the iface file to target_filename.
                        log.debug("{0}: update in {1}".format(ifname, target_filename))

                        for iface_line in iface_files[ifname]:
                            iface_line = iface_line.rstrip()
                            log.debug("{0}: write '{1}'".format(ifname, iface_line))
                            lines_to_write.append(iface_line + '\n')
                        lines_to_write.append('\n')

                        if persist:
                            os.remove("/run/nclu/ifupdown2/{0}".format(ifname))
                        del iface_files[ifname]
                        iface_written.append(ifname)

                        if state == "WRITE":
                            # log.debug("WRITE->SKIP: %s" % line)
                            state = "SKIP"

                    # We write interfaces in a very specific order so if this
                    # is true it means an interface was in ETC_NETWORK_INTERFACES
                    # but not in the order used by nclu.  So the first time the
                    # user makes a change we'll move the interface section to be
                    # in the correct order...avoid writing the same interface twice.
                    elif ifname in iface_written:
                        if state == "WRITE":
                            state = "SKIP"

                    else:
                        # The interface that has not been modified via iface.
                        iface_written.append(ifname)

                        if state == "SKIP":
                            # log.debug("SKIP->WRITE: %s" % line)
                            state = "WRITE"

                elif line.startswith("source "):
                    if state == "SKIP":
                        # log.debug("SKIP->WRITE: %s" % line)
                        state = "WRITE"

                elif state == "SKIP" and line.startswith('#'):
                    # We are parsing comments.  Set state back to WRITE.
                    state = "WRITE"
                    # log.debug("SKIP->WRITE: %s" % line)

                if state == "WRITE":
                    lines_to_write.append(line + '\n')
                elif state == "SKIP":
                    pass
                else:
                    raise ValueError("state = {0}".format(state))

                prev_line = line

            # Write any remaining iface files to target_filename.
            # These will be sorted in human readable order
            # log.info("%s: ifaces left to add %s\n" % (ifname, iface_files.keys()))
            for ifname in sort_ifaces(iface_files.keys()):
                write_new_interface(lines_to_write, prev_line, ifname, iface_files[ifname], persist)

            # Now that we have constructed what we want to write, write it.
            prev_line = None
            enable_vxrd = False

            # Do not print the blank line at the end.
            for index, line in enumerate(lines_to_write):
                if line.strip():
                    # Write a non-blank line.
                    f.write(line)

                    # Note if these services need to be enabled
                    if persist:
                        if not enable_vxrd and line.lstrip().startswith("vxrd-"):
                            enable_vxrd = True

                else:
                    # The line is blank.  Only write it if the previous line is not blank
                    # and the line is not the last line.
                    if prev_line is not None and prev_line.strip() and index < (len(lines_to_write) - 1):
                        f.write(line)

                prev_line = line

            # If we deleted lines, we need to truncate the rest of the f so that we
            # do not end up with the lines at the end printed twice.
            f.truncate()

        # This is the second element in the returned 2-tuple.
        message = ''

        if persist:
            commands = []

            if enable_vxrd:
                # vxrd is configured.  Enable the service prior to the ifreload, which will (re)start the service if it is enabled.
                commands.append(["/bin/systemctl", "enable", "vxrd"])

            if verbose:
                commands.append(["/sbin/ifreload", "-va"])
            else:
                commands.append(["/sbin/ifreload", "-a"])

            for command in commands:
                if self.show_linux_command:
                    message += "Updating {0}, and applying changes via \"{1}\".\n".format(ETC_NETWORK_INTERFACES, ' '.join(command))

                try:
                    message += check_output(command, close_fds=True, stderr=STDOUT)
                except CalledProcessError as e:
                    message += "\"{0}\" failed:\n{1}\n{2}\n".format(' '.join(command), e.output.strip(), e)
                    return (False, message)

        # If persist==True, the commit succeeded.
        return (True, message)

    def validate_net_cmd_vs_ifnames(self, cli):
        args = cli.args

        if args.get("add") or args.get("del"):

            if args.get("vlan-id") and args.get("<number-range-list>"):
                vlan_numbers = glob_to_numbers(str(args.get("<number-range-list>")))

                if len(vlan_numbers) > 1:
                    return (False, "Cannot assign vlan-id to a range of vlans.")

            self.get_ifquery_all()
            (ifnames_valid, ifnames) = get_ifnames(cli)

            if not ifnames_valid:
                return (False, "The interface names are not valid.")

            if ifnames:
                for ifname in ifnames:
                    iface = EtcNetworkInterface(ifname, self.ifquery_all)

                    outcome, message = iface.validate_net_cmd_vs_ifname(self, cli)
                    if not outcome:
                        return (False, message)

        return (True, '')


# This global is necessary because tab_completion.py requires an instance of ifupdown2.ConfigWrapper,
# but the parameters of the functions in that file cannot be changed to pass an instance.  (The
# functions are called from NetworkDocopt.)  NetDaemon.make_wrappers also imports this global, and it
# calls initialize_global_ifupdown2 to set the attributes that are just passed here as True.
#
# Plug-ins that need to interact with ifupdown2 should import this global immediately before it is
# used rather than at the top of the file.  Doing the latter will just get None because
# initialize_global_ifupdown2 will not have been called yet.
ifupdown2_wrapper = None


def initialize_global_ifupdown2(show_linux_commands, color_diffs):
    """
    Initialize an importable, global wrapper for this module.  Don't just do this automatically
    because ifupdown2 might not be enabled, and running "ifquery -a" in the constructor takes
    a lot of time.
    """

    global ifupdown2_wrapper
    ifupdown2_wrapper = ConfigWrapper(show_linux_commands, color_diffs)


def validate_syntax():
    """
    Return None if the pending changes to ETC_NETWORK_INTERFACES are syntactically valid.
    Otherwise, return a string describing the problems.
    """

    assert os.path.isfile(INTERFACES_TMP)

    command = ["/sbin/ifup",
               "--syntax-check",
               "--verbose",
               "--all",
               "--interfaces",
               INTERFACES_TMP]
    try:
        check_output(command, stderr=STDOUT)
    except CalledProcessError as e:
        # Return a description of the problems.
        errors_and_warnings = re.findall(r"""^(?:error|warning):\s+(\S+?:\s+.+)$""", e.output, re.MULTILINE)
        return '\n'.join(errors_and_warnings)

    return None
