"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from json import dumps
from nclu import PENDING_COMMANDS_FILE, tabulate_pending_add_del_commands
from os.path import isfile


def get_pending(wrappers, plugins, color_diffs):
    """
    net pending

    Return a string of the pending changes.

    Note that this function's "color_diffs" parameter does not override wrapper.color_diffs when
    getting the diff output, but it affects plug-ins.
    """

    assert len(wrappers) > 0, "If the wrappers paradigm has been removed, edit this function."

    pending_commands = tabulate_pending_add_del_commands()
    if pending_commands is None:
        return ''

    reply = ''

    for plugin in plugins:
        m = __import__("nclu.plugins." + plugin, fromlist=["get_pending"])
        reply += m.get_pending(color_diffs)

    for name, wrapper in wrappers:
        assert hasattr(wrapper, "get_pending"), "Wrapper {0} must implement a get_pending method.".format(name)
        try:
            the_diff = wrapper.get_pending()
            if the_diff:
                reply += the_diff + '\n'
        except RuntimeError as e:
            reply += "ERROR ({0}): {1}\n".format(name, e)

    if color_diffs:
        reply += "\n\n\033[94mnet add/del commands since the last \"net commit\"\n{0}".format('=' * 48 + "\033[0m\n\n")
    else:
        reply += "\n\nnet add/del commands since the last \"net commit\"\n{0}".format('=' * 48 + "\n\n")
    reply += pending_commands + '\n'

    # TODO - Replace this with a regex.  The only purpose is to get the unique users count.
    users = set([line.split()[0] for line in pending_commands.splitlines() if not (line.startswith("User ") or line.startswith("----"))])

    if len(users) > 1:
        if color_diffs:
            reply += "\033[91m" + '*' * 58 + '\n' + "NOTE: Multiple users are currently staging changes via net\n" + '*' * 58 + '\n' + "\033[0m"
        else:
            reply += '*' * 58 + '\n' + "NOTE: Multiple users are currently staging changes via net\n" + '*' * 58 + '\n'

    return reply


def get_pending_json(wrappers, plugins):
    """
    net pending json

    Return the pending changes as a JSON string.  Do not use colors.
    """

    assert len(wrappers) > 0, "If the wrappers paradigm has been removed, edit this function."

    data = {"diffs": [], "commands": []}

    for plugin in plugins:
        m = __import__("nclu.plugins." + plugin, fromlist=["get_pending"])
        pending_output = m.get_pending(False)
        get_pending_json_helper(data, pending_output)

    # Populate data["diffs"].
    for _, wrapper in wrappers:
        # Disable colors for the JSON output.
        orig_color_diffs = wrapper.color_diffs
        wrapper.color_diffs = False
        pending_output = wrapper.get_pending()
        wrapper.color_diffs = orig_color_diffs
        get_pending_json_helper(data, pending_output)

    # Populate data["commands"].
    if isfile(PENDING_COMMANDS_FILE):
        with open(PENDING_COMMANDS_FILE) as f:
            for line in f:
                user, timestamp, command = line.strip().split('\t')
                data["commands"].append({"user": user, "timestamp": timestamp, "command": command})

    # Remove empty list fields from the output dictionary.
    for key in ("diffs", "commands"):
        if not data[key]:
            del data[key]

    return dumps(data, indent=4)


def get_pending_json_helper(data, pending_output):
    from_file = None
    to_file = None
    content = []

    for line in pending_output.splitlines():
        if line.startswith("---"):

            if from_file:
                data["diffs"].append({
                    "fromFile": from_file,
                    "fromFileTimestamp": from_file,
                    "toFile": to_file,
                    "toFileTimestamp": to_file_timestamp,
                    "content": content
                })

            from_file, from_file_timestamp = line.split('\t')
            from_file = from_file[4:]
            to_file = None
            content = []
        elif line.startswith("+++"):
            to_file, to_file_timestamp = line.split('\t')
            to_file = to_file[4:]
        else:
            content.append(line)

    if from_file:
        data["diffs"].append({
            "fromFile": from_file,
            "fromFileTimestamp": from_file,
            "toFile": to_file,
            "toFileTimestamp": to_file_timestamp,
            "content": content
        })
