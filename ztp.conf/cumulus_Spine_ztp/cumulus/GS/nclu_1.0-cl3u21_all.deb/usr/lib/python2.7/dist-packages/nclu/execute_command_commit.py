"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from nclu import HISTORY_LOG, PENDING_COMMANDS_FILE
from nclu.pending import get_pending
from nclu.plugins import format_messages
from subprocess import CalledProcessError, check_output, STDOUT
import datetime
import logging
import nclu.rollback
import os

ROLLBACK_WAIT_TIME = 10

log = logging.getLogger("netd")


def execute_commit(net_daemon):
    """
    Execute "net commit ..." commands, and return a 2-tuple of (bool, str).  The
    boolean indicates if execution succeeded, and the string is the output.

    Relevant basic usage commands:
        net commit [verbose] [confirm] [description <wildcard>]
        net commit [verbose] confirm <number-seconds> [description <wildcard>]
        net commit delete (<number>|<number-range>)
        net commit permanent <wildcard>
    """

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert isinstance(tokens, dict)

    # "net show commit" should not take this execution path.
    assert "show" not in tokens, "This should be checked before entering this function."
    assert "commit" in tokens, "Why are you here?"

    # Look for matches with "basic usage" commands.

    if "delete" in tokens:
        # net commit delete (<number>|<number-range>)

        if "<number>" in tokens:
            assert isinstance(tokens["<number>"], int)
            return commit_delete(tokens["<number>"])
        else:
            assert isinstance(tokens.get("<number-range>"), str)
            return commit_delete(tokens["<number-range>"])

    # Special handling for the <ENTER> following a "net commit confirm"
    if net_daemon.net_commit_confirmed:
        rollback = net_daemon.future_rollbacks.get((net_daemon.uid, net_daemon.gid))

        if rollback is None:
            return (False, "The rollback already happened.")

        rollback.shutdown_event.set()
        rollback.join()
        return (True, '')

    # net commit

    changes = get_pending(net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.color_diffs)
    if not changes:
        return (True, "There are no pending changes.")

    with open(HISTORY_LOG, 'a') as f:
        f.write("{0} - net commit\n".format(datetime.datetime.now()))
        f.write('=' * 39 + '\n')
        f.write(changes + "\n\n")

    outcome, reply = commit_pending(net_daemon.nclu_parser.args, net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.uid,
                                    net_daemon.gid, net_daemon.user, net_daemon.future_rollbacks, net_daemon.color_diffs)

    return (outcome, changes + '\n' + reply)


def commit_delete(number_or_range):
    """
    Use "snapper delete" to delete snapshots.
    """

    if isinstance(number_or_range, int) or (isinstance(number_or_range, str) and number_or_range.isdigit()):
        # Delete a single commit.

        reply = "Deleting commit {0}.\n".format(number_or_range)
        try:
            check_output(["/usr/bin/snapper", "delete", str(number_or_range)], stderr=STDOUT)
        except CalledProcessError as e:
            return (False, "Failed to delete commit #{0} due to \"{1}\".\n".format(number_or_range, e.output.strip()))

    else:
        # Delete multiple commits in one shot.
        assert isinstance(number_or_range, str)

        start, stop = number_or_range.split('-')

        command = ["/usr/bin/snapper", "delete"]
        command.extend(map(str, xrange(int(start), int(stop) + 1)))

        reply = "Deleting commits {0}-{1}.\n".format(start, stop)
        try:
            check_output(command, stderr=STDOUT)
        except CalledProcessError as e:
            return (False, reply + "Failed to delete commit {0}-{1} due to \"{2}\".\n".format(start, stop, e.output.strip()))

    return (True, reply)


def commit_pending(tokens, wrappers, plugins, uid, gid, user, future_rollbacks, use_color):
    """
    Call the commit_pending method for all wrappers and plug-ins.
    """

    assert isinstance(tokens, dict)

    permanent = "permanent" in tokens

    if "description" in tokens or permanent:
        # The value of <wildcard> might not be a string.  Coerce it.
        description = "nclu " + str(tokens["<wildcard>"])
    else:
        description = "nclu \"net commit\" (user {0})".format(user)

    # Include a blank line to separate the diff output from the "Updating..." output.
    reply = '\n'

    hit_error = False
    pre_snapshot_number = nclu.rollback.snapper_create_pre(description, permanent)
    if pre_snapshot_number is None:
        reply += "WARNING: Couldn't create a pre-commit snapshot.  These changes cannot be rolled back."

    # Changes to ports must be applied first.
    if "ports" in plugins:
        m = __import__("nclu.plugins.ports", fromlist=["commit_pending"])
        commit_ok, messages = m.commit_pending("verbose" in tokens)
        assert isinstance(commit_ok, bool), "Did the commit succeed?"
        assert isinstance(messages, dict), "See execute_modular for an explanation of this value."

        if not commit_ok:
            hit_error = True
            if "error" not in messages:
                messages["error"] = []
            messages["error"].append("\"net commit\" failed for ports.  All changes will remain in \"net pending\".")

        reply += '\n' + format_messages(messages, use_color)

    if not hit_error:
        # Call each wrapper's "commit_pending" method. We apply wrappers before plugins
        # because ifupdown2 uses the wrapper model, and we need to apply the changes to
        # /etc/network/interfaces before every component except ports.
        for name, wrapper in wrappers:
            commit_ok, message, _ = wrapper.commit_pending("verbose" in tokens)
            assert isinstance(commit_ok, bool), "Did the commit succeed?"
            assert isinstance(message, str)

            if message:
                reply += '\n' + message

            if not commit_ok:
                reply += "\n\"net commit\" failed for {0}.  All changes will remain in \"net pending\".".format(name)
                hit_error = True
                break

    if not hit_error:
        # Call each plug-in's "commit_pending" method.
        for plugin in plugins:
            if plugin == "ports":
                # This is called above, before wrapper execution, because it must execute first.
                continue

            m = __import__("nclu.plugins." + plugin, fromlist=["commit_pending"])
            commit_ok, messages = m.commit_pending(bool(tokens.get("verbose")))
            assert isinstance(commit_ok, bool), "Did the commit succeed?"
            assert isinstance(messages, dict), "See execute_modular for an explanation of this value."

            if not commit_ok:
                if "error" not in messages:
                    messages["error"] = []
                messages["error"].append("\"net commit\" failed for {0}.  All changes will remain in \"net pending\".".format(plugin))

            reply += '\n' + format_messages(messages, use_color)

            if not commit_ok:
                hit_error = True
                break

    if pre_snapshot_number is not None:

        if hit_error:
            commit_delete(pre_snapshot_number)
        else:
            nclu.rollback.snapper_create_post(description, pre_snapshot_number, permanent)

            if "confirm" in tokens:
                seconds = tokens.get("<number-seconds>", ROLLBACK_WAIT_TIME)

                if seconds <= 0:
                    seconds = ROLLBACK_WAIT_TIME

                # Start a thread that will rollback this commit after "seconds".
                # The thread terminates if the user presses <ENTER> to confirm connectivity.
                rollback = nclu.rollback.FutureRollback(uid, gid, pre_snapshot_number, seconds, future_rollbacks)
                future_rollbacks[(uid, gid)] = rollback
                rollback.start()

                reply += "Press <ENTER> to confirm connectivity."

    if hit_error:
        return (False, reply)
    elif os.path.isfile(PENDING_COMMANDS_FILE):
        os.remove(PENDING_COMMANDS_FILE)

    return (True, reply)
