"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from cStringIO import StringIO
import sys


class Capturing(list):
    """
    https://stackoverflow.com/questions/16571150/how-to-capture-stdout-output-from-a-python-function-call

    This is a work-around for NCLU wrappers and Network-Docopt printing directly to standard output instead
    of returning a value.

    TODO - I would like this to be a string subclass instead.  I'm just joining the list anyways.
    """

    def __enter__(self):
        self._stdout = sys.stdout
        sys.stdout = self._stringio = StringIO()
        return self

    def __exit__(self, *args):
        self.extend(self._stringio.getvalue().splitlines())
        del self._stringio
        sys.stdout = self._stdout
