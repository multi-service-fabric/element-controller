"""
Copyright (C) 2017 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt


Usage:
    net (add|del) forwarding ecmp hash-seed <0-4294967295>

Options:
    forwarding              : Packet forwarding parameters
    ecmp                    : Equal Cost MultiPath
    hash-seed               : Hash seed for ECMP entries
"""

from collections import OrderedDict
from nclu import (
    ConfigWrapperBase,
    ConfigFileKeyValue,
    globify_interface_commands,
    platform_vendor,
)
from nclu.wrappers.ifupdown2 import get_ifnames
from network_docopt import sort_ifaces
import logging
import os
import shutil

ETC_TRAFFIC = "/etc/cumulus/datapath/traffic.conf"
ETC_DATAPATH = "/usr/lib/python2.7/dist-packages/cumulus/__chip_config/mlx/datapath.conf"

log = logging.getLogger("netd")


def build_doc_string():
    global __doc__

    # storage-optimized is only supported on MLNX platforms.
    if platform_vendor() == "mlnx":
        mlnx_doc = """
Usage:
    net (add|del) interface <interface> storage-optimized [pfc]

Options:
    pfc                          : Priority Flow Control
    storage-optimized            : Enable RoCE
"""
        __doc__ += mlnx_doc

    return __doc__


def convert_list_string_to_list(list_string, list_is_ifnames):
    """
    traffic.conf has several keywords with a list as the value but is inconsistent
    with the format it uses to store the list.  Some of them use []s while others
    do not. Parse the various formats and return a list.
    """

    if list_string is None:
        return []

    assert isinstance(list_is_ifnames, bool)
    assert isinstance(list_string, (str, unicode))

    # Standardize the format of list_string by:
    # - remove leading and trailing whitespaces
    # - remove leading and trailing []s
    # - replace commas with whitespaces
    # - split by whitespace and then rejoin with a single whitespace
    list_string = ' '.join((list_string.strip(" []").replace(',', ' ').split()))
    result = list_string.split()

    # Remove duplicate values within the list.
    result = list(set(result))

    # If these are interface names, sort accordingly.
    if list_is_ifnames:
        result = sort_ifaces(result)
    else:
        result = sorted(result)

    return result


class ConfigWrapper(ConfigWrapperBase):

    def __init__(self, show_linux_command, color_diffs):
        super(ConfigWrapper, self).__init__("traffic", show_linux_command, color_diffs)
        self.files[ETC_TRAFFIC] =\
            ConfigFileKeyValue(self, ETC_TRAFFIC,
                       [["/bin/systemctl", "enable", "switchd.service"],
                        ["/bin/systemctl", "reset-failed", "switchd.service"],
                        ["/bin/systemctl", "restart", "switchd.service"]])

        self.files[ETC_DATAPATH] =\
            ConfigFileKeyValue(self, ETC_DATAPATH,
                       [["/bin/systemctl", "enable", "switchd.service"],
                        ["/bin/systemctl", "reset-failed", "switchd.service"],
                        ["/bin/systemctl", "restart", "switchd.service"]])

    def get_conf_file_key_value(self, filename, key):
        cfg = self.files[filename]
        cfg_content = cfg.get_value()
        return cfg_content.get(key)

    def get_storage_optimzed_ifnames(self):
        """
        Return a list of ifnames that have been configured for storage-optimized
        """
        cfg_content = self.files[ETC_TRAFFIC].get_value()

        pfc_port_set = cfg_content.get("pfc.ROCE_PFC.port_set")
        pfc_port_set = convert_list_string_to_list(pfc_port_set, True)

        ecn_port_set = cfg_content.get("ecn_red.ROCE_ECN.port_set")
        ecn_port_set = convert_list_string_to_list(ecn_port_set, True)

        return (pfc_port_set, ecn_port_set)

    def show_config_commands(self, user_may_edit, ifupdown2_wrapper):
        supported = []
        interface_commands = []
        unsupported = []
        (pfc_port_set, ecn_port_set) = self.get_storage_optimzed_ifnames()

        for ifname in pfc_port_set:
            interface_commands.append("net add interface {0} storage-optimized pfc".format(ifname))

        for ifname in ecn_port_set:
            if ifname not in pfc_port_set:
                interface_commands.append("net add interface {0} storage-optimized".format(ifname))

        interface_commands = globify_interface_commands(interface_commands)
        supported.extend(interface_commands)
        ecmp_hash_seed = self.get_conf_file_key_value(ETC_TRAFFIC, "ecmp_hash_seed")

        if ecmp_hash_seed is not None:
            supported.append("net add forwarding ecmp hash-seed {0}".format(ecmp_hash_seed))

        return (supported, unsupported)

    def show_config_summary(self, user_may_edit, summary):
        (pfc_port_set, ecn_port_set) = self.get_storage_optimzed_ifnames()

        for ifname in pfc_port_set + ecn_port_set:
            ifname = "INTERFACE:{0}".format(ifname)

            if ifname not in summary:
                summary[ifname] = OrderedDict()

            if "COMMAND_LIST" not in summary[ifname]:
                summary[ifname]["COMMAND_LIST"] = []

        for ifname in pfc_port_set:
            ifname = "INTERFACE:{0}".format(ifname)
            summary[ifname]["COMMAND_LIST"].append("storage-optimized pfc")

        for ifname in ecn_port_set:
            if ifname not in pfc_port_set:
                ifname = "INTERFACE:{0}".format(ifname)
                summary[ifname]["COMMAND_LIST"].append("storage-optimized")

        ecmp_hash_seed = self.get_conf_file_key_value(ETC_TRAFFIC, "ecmp_hash_seed")

        if ecmp_hash_seed is not None:
            if "forwarding" not in summary:
                summary["forwarding"] = []

            summary["forwarding"].append("ecmp hash-seed {0}".format(ecmp_hash_seed))

    def get_pending(self):
        """
        Return the pending diff as a string.  If there are no changes, return the empty string.
        """

        result = ConfigWrapperBase.get_pending(self)

        if result:
            result += """\n\033[91m\n
********************************************************************
********************************************************************
NOTE: "net commit" will run "systemctl restart switchd" to apply the
changes to {0}. This will be service impacting.
********************************************************************
********************************************************************
\033[0m
""".format(ETC_TRAFFIC)

        return result

    def del_all(self, cli):
        """
        Remove all RoCE related configuration
        """
        for (etc_filename, cfg) in self.files.iteritems():

            if not os.path.exists(cfg.scratchpad):
                shutil.copyfile(cfg.filename,  cfg.scratchpad)

            cfg_content = cfg.get_value(True)

            # Remove RoCE configuration from traffic.conf
            if etc_filename == ETC_TRAFFIC:
                self.del_storage_optimized_traffic_conf(cfg, cfg_content)

            # Remove RoCE configuration from datapath.conf
            elif etc_filename == ETC_DATAPATH:
                self.del_storage_optimized_datapath_conf(cfg, cfg_content)

    def del_pfc_storage_optimized_traffic_conf(self, cfg, cfg_content):

        # Remove ROCE_PFC from pfc.port_group_list
        pfc_port_group_list = cfg_content.get("pfc.port_group_list")
        pfc_port_group_list = convert_list_string_to_list(pfc_port_group_list, False)

        if "ROCE_PFC" in pfc_port_group_list:
            pfc_port_group_list.remove("ROCE_PFC")

        if pfc_port_group_list:
            cfg.edit("pfc.port_group_list", "[{0}]".format(','.join(pfc_port_group_list)), give_feedback=False)
        else:
            cfg.delete("pfc.port_group_list")

        # Delete all ROCE_PFC configuration
        for (key, value) in cfg_content.items():
            if "ROCE_PFC" in key:
                cfg.delete(key)

    def del_ecn_storage_optimized_traffic_conf(self, cfg, cfg_content):

        # Remove ROCE_ECN from ecn_red.port_group_list
        ecn_red_port_group_list = cfg_content.get("ecn_red.port_group_list")
        ecn_red_port_group_list = convert_list_string_to_list(ecn_red_port_group_list, False)

        if "ROCE_ECN" in ecn_red_port_group_list:
            ecn_red_port_group_list.remove("ROCE_ECN")

        if ecn_red_port_group_list:
            cfg.edit("ecn_red.port_group_list", "[%s]" % ','.join(ecn_red_port_group_list), give_feedback=False)
        else:
            cfg.delete("ecn_red.port_group_list")

        # Delete all ROCE_ECN configuration
        for (key, value) in cfg_content.items():
            if "ROCE_ECN" in key:
                cfg.delete(key)

    def del_storage_optimized_traffic_conf(self, cfg, cfg_content):
        self.del_pfc_storage_optimized_traffic_conf(cfg, cfg_content)
        self.del_ecn_storage_optimized_traffic_conf(cfg, cfg_content)

    def del_storage_optimized_datapath_conf(self, cfg, cfg_content):
        """
        If traffic.conf has no remaining RoCE interfaces configured then put
        datapath.conf back to some sane default. The default values hardcoded
        here were the mlnx datapath.conf defaults as of CL 3.5. This is not a
        perfect solution but is better than leaving datapath.conf setup for RoCE.
        """
        # Variables that we modified when first configuring RoCE
        cfg.edit("ingress_service_pool.0.percent", "100.0", give_feedback=False)

        cfg.edit("priority_group.control.ingress_buffer.min_percent", "4.0", give_feedback=False)
        cfg.edit("priority_group.service.ingress_buffer.min_percent", "2.0", give_feedback=False)
        cfg.edit("priority_group.bulk.ingress_buffer.min_percent", "18.0", give_feedback=False)

        cfg.edit("egress_service_pool.0.percent", "100.0", give_feedback=False)

        cfg.edit("priority_group.bulk.egress_buffer.uc.min_percent", "6.0", give_feedback=False)
        cfg.edit("priority_group.service.egress_buffer.uc.min_percent", "2.0", give_feedback=False)
        cfg.edit("priority_group.control.egress_buffer.uc.min_percent", "4.0", give_feedback=False)

        cfg.edit("priority_group.bulk.egress_buffer.mc.min_percent", "5.0", give_feedback=False)
        cfg.edit("priority_group.service.egress_buffer.mc.min_percent", "2.0", give_feedback=False)
        cfg.edit("priority_group.control.egress_buffer.mc.min_percent", "3.0", give_feedback=False)

        # Variables that we added when first configuring RoCE
        cfg.delete("ingress_service_pool.0.mode")
        cfg.delete("ingress_service_pool.1.percent")
        cfg.delete("ingress_service_pool.1.mode")

        cfg.delete("priority_group.control.ingress_buffer.dynamic_quota")
        cfg.delete("priority_group.service.ingress_buffer.dynamic_quota")
        cfg.delete("priority_group.bulk.ingress_buffer.dynamic_quota")

        cfg.delete("flow_control.service_pool")
        cfg.delete("flow_control.ingress_buffer.dynamic_quota")

        cfg.delete("egress_service_pool.0.mode")
        cfg.delete("egress_service_pool.1.percent")
        cfg.delete("egress_service_pool.1.mode")

        cfg.delete("priority_group.bulk.egress_buffer.uc.dynamic_quota")
        cfg.delete("priority_group.service.egress_buffer.uc.dynamic_quota")
        cfg.delete("priority_group.control.egress_buffer.uc.dynamic_quota")

        cfg.delete("priority_group.bulk.egress_buffer.mc.dynamic_quota")
        cfg.delete("priority_group.service.egress_buffer.mc.dynamic_quota")
        cfg.delete("priority_group.control.egress_buffer.mc.dynamic_quota")

        cfg.delete("flow_control.egress_buffer.min_percent")
        cfg.delete("flow_control.egress_buffer.dynamic_quota")

    def eval_storage_optimized_traffic_conf(self, cli, ifnames):
        """
        Handle all add/del for the "storage-optimized" macro for the traffic.conf file
        """

        args = cli.args
        cfg = self.files[ETC_TRAFFIC]
        cfg_content = cfg.get_value(True)
        command_ok = False
        roce_configured = True

        pfc_port_set = cfg_content.get("pfc.ROCE_PFC.port_set")
        pfc_port_set = convert_list_string_to_list(pfc_port_set, True)

        ecn_port_set = cfg_content.get("ecn_red.ROCE_ECN.port_set")
        ecn_port_set = convert_list_string_to_list(ecn_port_set, True)

        if args.get("add"):
            command_ok = True

            # ===
            # PFC
            # ===
            if args.get("pfc"):

                # Add ROCE_PFC to pfc.port_group_list (if it isn't already there)
                pfc_port_group_list = cfg_content.get("pfc.port_group_list")
                pfc_port_group_list = convert_list_string_to_list(pfc_port_group_list, False)

                if "ROCE_PFC" not in pfc_port_group_list:
                    pfc_port_group_list.append("ROCE_PFC")

                cfg.edit("pfc.port_group_list", "[{0}]".format(','.join(pfc_port_group_list)), give_feedback=False)

                # Add each ifname to pfc.ROCE_PFC.port_set
                for ifname in ifnames:
                    if ifname not in pfc_port_set:
                        pfc_port_set.append(ifname)

                pfc_port_set = sort_ifaces(pfc_port_set)
                command_ok = cfg.edit("pfc.ROCE_PFC.port_set", ','.join(pfc_port_set))

                # set the cos_list
                cfg.edit("pfc.ROCE_PFC.cos_list", "[1]", give_feedback=False)

                # Misc PFC settings
                cfg.edit("pfc.ROCE_PFC.xoff_size", "18000", give_feedback=False)
                cfg.edit("pfc.ROCE_PFC.xon_delta", "18000", give_feedback=False)
                cfg.edit("pfc.ROCE_PFC.tx_enable", "true", give_feedback=False)
                cfg.edit("pfc.ROCE_PFC.rx_enable", "true", give_feedback=False)
                cfg.edit("pfc.ROCE_PFC.port_buffer_bytes", "70000", give_feedback=False)

            # =======
            # ECN RED
            # =======

            # Add ROCE_ECN to ecn_red.port_group_list (if it isn't already there)
            ecn_red_port_group_list = cfg_content.get("ecn_red.port_group_list")
            ecn_red_port_group_list = convert_list_string_to_list(ecn_red_port_group_list, False)

            if "ROCE_ECN" not in ecn_red_port_group_list:
                ecn_red_port_group_list.append("ROCE_ECN")

            cfg.edit("ecn_red.port_group_list", "[{0}]".format(','.join(ecn_red_port_group_list)), give_feedback=False)

            # Add each ifname to ecn_red.ROCE_ECN.port_set
            for ifname in ifnames:
                if ifname not in ecn_port_set:
                    ecn_port_set.append(ifname)

            ecn_port_set = sort_ifaces(ecn_port_set)
            cfg.edit("ecn_red.ROCE_ECN.port_set", ','.join(ecn_port_set), give_feedback=False)

            # set the cos_list
            cfg.edit("ecn_red.ROCE_ECN.cos_list", "[0,1]", give_feedback=False)

            # Misc ECN RED settings
            cfg.edit("ecn_red.ROCE_ECN.min_threshold_bytes", "150000", give_feedback=False)
            cfg.edit("ecn_red.ROCE_ECN.max_threshold_bytes", "1500000", give_feedback=False)
            cfg.edit("ecn_red.ROCE_ECN.ecn_enable", "true", give_feedback=False)
            cfg.edit("ecn_red.ROCE_ECN.red_enable", "true", give_feedback=False)
            cfg.edit("ecn_red.ROCE_ECN.probability", "100", give_feedback=False)

        elif args.get("del"):

            for ifname in ifnames:
                if ifname in pfc_port_set:
                    pfc_port_set.remove(ifname)
                    command_ok = True

                if ifname in ecn_port_set:
                    ecn_port_set.remove(ifname)
                    command_ok = True

            if not command_ok:
                print "{0} does not have storage-optimized configured for {1}.".format(ETC_TRAFFIC, ", ".join(ifnames))

            if pfc_port_set or ecn_port_set:

                if pfc_port_set:
                    cfg.edit("pfc.ROCE_PFC.port_set", ','.join(pfc_port_set), give_feedback=False)
                else:
                    self.del_pfc_storage_optimized_traffic_conf(cfg, cfg_content)

                if ecn_port_set:
                    cfg.edit("ecn_red.ROCE_ECN.port_set", ','.join(ecn_port_set), give_feedback=False)
                else:
                    self.del_ecn_storage_optimized_traffic_conf(cfg, cfg_content)

            # There are no interfaces configured for ROCE, delete RoCE related configuration.
            else:
                self.del_storage_optimized_traffic_conf(cfg, cfg_content)
                roce_configured = False

        return (command_ok, roce_configured)

    def eval_storage_optimized_datapath_conf(self, cli, roce_configured):
        """
        Handle all add/del for the "storage-optimized" macro for the datapath.conf file
        """
        args = cli.args
        cfg = self.files[ETC_DATAPATH]
        cfg_content = cfg.get_value(True)

        if args.get("add"):

            (pfc_port_set, ecn_port_set) = self.get_storage_optimzed_ifnames()

            # If any port is using pfc use these settings
            if args.get("pfc") or pfc_port_set:
                cfg.edit("flow_control.service_pool", '1', give_feedback=False)
                cfg.edit("flow_control.ingress_buffer.dynamic_quota", '9', give_feedback=False)
                cfg.edit("flow_control.egress_buffer.min_percent", "1.0", give_feedback=False)
                cfg.edit("flow_control.egress_buffer.dynamic_quota", "255", give_feedback=False)

                cfg.edit("ingress_service_pool.0.percent", "50.0", give_feedback=False)
                cfg.edit("ingress_service_pool.0.mode", '1', give_feedback=False)
                cfg.edit("ingress_service_pool.1.percent", "50.0", give_feedback=False)
                cfg.edit("ingress_service_pool.1.mode", '1', give_feedback=False)

                cfg.edit("egress_service_pool.0.percent", "50.0", give_feedback=False)
                cfg.edit("egress_service_pool.0.mode", '1', give_feedback=False)
                cfg.edit("egress_service_pool.1.percent", "50.0", give_feedback=False)
                cfg.edit("egress_service_pool.1.mode", '1', give_feedback=False)

            # If not use these
            else:
                cfg.delete("flow_control.service_pool")
                cfg.delete("flow_control.ingress_buffer.dynamic_quota")
                cfg.delete("flow_control.egress_buffer.min_percent")
                cfg.delete("flow_control.egress_buffer.dynamic_quota")

                cfg.edit("ingress_service_pool.0.percent", "100.0", give_feedback=False)
                cfg.edit("ingress_service_pool.0.mode", '1', give_feedback=False)
                cfg.delete("ingress_service_pool.1.percent")
                cfg.delete("ingress_service_pool.1.mode")

                cfg.edit("egress_service_pool.0.percent", "100.0", give_feedback=False)
                cfg.edit("egress_service_pool.0.mode", '1', give_feedback=False)
                cfg.delete("egress_service_pool.1.percent")
                cfg.delete("egress_service_pool.1.mode")

            # These are used for both pfc and non-pfc scenarios
            cfg.edit("priority_group.control.ingress_buffer.min_percent", "4.0", give_feedback=False)
            cfg.edit("priority_group.control.ingress_buffer.dynamic_quota", "11", give_feedback=False)
            cfg.edit("priority_group.service.ingress_buffer.min_percent", "4.0", give_feedback=False)
            cfg.edit("priority_group.service.ingress_buffer.dynamic_quota", "11", give_feedback=False)
            cfg.edit("priority_group.bulk.ingress_buffer.min_percent", "7.0", give_feedback=False)
            cfg.edit("priority_group.bulk.ingress_buffer.dynamic_quota", "11", give_feedback=False)

            cfg.edit("priority_group.bulk.egress_buffer.uc.min_percent", "3.0", give_feedback=False)
            cfg.edit("priority_group.service.egress_buffer.uc.min_percent", "1.0", give_feedback=False)
            cfg.edit("priority_group.control.egress_buffer.uc.min_percent", "1.0", give_feedback=False)

            cfg.edit("priority_group.bulk.egress_buffer.mc.min_percent", "1.0", give_feedback=False)
            cfg.edit("priority_group.service.egress_buffer.mc.min_percent", "1.0", give_feedback=False)
            cfg.edit("priority_group.control.egress_buffer.mc.min_percent", "1.0", give_feedback=False)

            cfg.edit("priority_group.bulk.egress_buffer.uc.dynamic_quota", "11", give_feedback=False)
            cfg.edit("priority_group.service.egress_buffer.uc.dynamic_quota", "11", give_feedback=False)
            cfg.edit("priority_group.control.egress_buffer.uc.dynamic_quota", "11", give_feedback=False)

            cfg.edit("priority_group.bulk.egress_buffer.mc.dynamic_quota", '9', give_feedback=False)
            cfg.edit("priority_group.service.egress_buffer.mc.dynamic_quota", "11", give_feedback=False)
            cfg.edit("priority_group.control.egress_buffer.mc.dynamic_quota", "11", give_feedback=False)

        elif args.get("del"):
            if not roce_configured:
                self.del_storage_optimized_datapath_conf(cfg, cfg_content)

        return True

    def eval_storage_optimized(self, cli):
        """
        Handle all add/del for the "storage-optimized" macro
        """
        command_ok = False
        (ifnames_valid, ifnames) = get_ifnames(cli)

        if not ifnames_valid:
            return command_ok

        (command_ok, roce_configured) = self.eval_storage_optimized_traffic_conf(cli, ifnames)

        if command_ok:
            command_ok = self.eval_storage_optimized_datapath_conf(cli, roce_configured)

        return command_ok

    def eval_ecmp_hash_seed(self, cli):
        """
        Handle all add/del for the "ecmp hash-seed" macro.
        """

        command_ok = False
        tokens = cli.args
        cfg = self.files[ETC_TRAFFIC]

        if tokens.get("add") is not None:
            command_ok = cfg.edit("ecmp_hash_seed", tokens.get("<0-4294967295>"))
        elif tokens.get("del"):
            command_ok = cfg.delete("ecmp_hash_seed")

        return command_ok

    def eval_command_line_args(self, cli):
        ConfigWrapperBase.eval_command_line_args(self, cli)

        if cli.args.get("storage-optimized") is not None:
            command_ok = self.eval_storage_optimized(cli)
        elif cli.args.get("forwarding") is not None and cli.args.get("ecmp") is not None and cli.args.get("hash-seed") is not None:
            command_ok = self.eval_ecmp_hash_seed(cli)
        else:
            command_ok = False

        return command_ok
