"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt

----------------------------------------------------------------------------------------

"""

#-------------------------------------------------------------------------------
#
#   Imports
#
#-------------------------------------------------------------------------------

# Standard library imports
import copy
import json
import logging
import os
import re
import subprocess
from collections import OrderedDict

# Related third party imports
from network_docopt import (
    custom_matchers,
    sort_for_humans
)
from configobj import ConfigObj, ConfigObjError

# Local application/library specific imports
from nclu import (
    WORKING_DIRECTORY,
    WORKING_DIRECTORIES_PERMISSIONS,
    glob_to_numbers,
    ifnames_to_glob,
    service_is_active,
    service_is_enabled,
)
from nclu.plugins import (
    get_config_files_helper,
    get_pending_diffs,
    make_scratchpads,
    merge_messages,
    persist_configurations,
    remove_scratch_files_and_backups,
    run_commands,
)
from nclu.plugins.ports import execute_command as ports_execute_command


#-------------------------------------------------------------------------------
#
#   Constants
#
#-------------------------------------------------------------------------------

TRANSPONDERS_INI = "/etc/cumulus/transponders.ini"
TRANSPONDERS_INI_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "transponders", "transponders.ini")


#-------------------------------------------------------------------------------
#
#   Platform Classes
#
#   Anything which is platform-specific is placed in a class for that platform
#   so that a common function can be called to retrieve any platform-specific
#   data.
#
#   NOTE: These classes violate the "don't use classes" in NCLU plug-ins. But
#   these classes do not store state. They are merely a mechanism to provide
#   a common interface to obtain platform-specific information. The base class,
#   BasePlatform represents a platform which does not have transponders. Other
#   classes, such as VoyagerPlatform, are children of the base class and
#   override the base class's methods where appropriate to provide the correct
#   information for a platform.
#
#-------------------------------------------------------------------------------

class BasePlatform(object):
    """
    This is the base class. Most of the functions in this class will be
    overridded by children of this class. This class will be used for platform
    which do not have transponders.
    """
    def has_transponders(self):
        """ Return True is the platform supports transponders, and false otherwise """
        return False

    def get_default_transponders_ini(self):
        """ Return the location of the default transponders.ini file """
        return None

    def get_net_interfaces(self):
        """
        Returns a dictionary. The keys are the transponder interface labels, and
        the values are 2-tuples: (module, index). module is the module's
        location in the system, and index is the index of the interface on the
        module.
        """
        return {}

    def get_channel_frequencies(self):
        """
        Returns a list of 3-tuples, one list entry each frequency supported. The
        3-tuple is (Channel, Frequency, Wavelength). Channel is a decimal number,
        Frequency is a float in THz, and Wavelength is a float in nanometers.
        """
        return []

    def expand_port_label_glob(self, label):
        """
        Given a port label glob (i.e. L1-4 or L1,3) expand it into a list of ports.
        If the glob is not valid on the platform then an empty list is returned. If
        the label is a valid port, but not a glob, then a list with just that port
        is returned.
        """
        return []

    def get_command_options(self):
        """
        Retrieve the command line options for the commands which take options.
        A dictionary is retruned with keys for the command (i.e. "state") and
        the value is a dictionary. The keys of the dictionary are the options
        allowed on this platform. The values are A 2-tuple. The first element in
        the tuple is the transponders.ini string for that option, and the second
        element is the help text for that option.
        """
        return {}

    def get_power_range(self):
        """
        Return a 2-tuple of floating point numbers for the minimum and maximum
        TX power, in dBm, support by the platform.
        """
        return ((0.0, 0.0))

    def get_network_mode(self, modulation):
        """ Return the network mode for a given modulation format """
        return None

    def get_coupled_interfaces(self, port, modulation):
        """
        Returns a list of interfaces which are "coupled" with this one.
        """
        return []


class VoyagerPlatform(BasePlatform):
    """
    Everything that is specific to the Voyager platform. Overrides the
    BasePlatform functions to provide specific information about this platform.
    """
    def has_transponders(self):
        return True

    def get_default_transponders_ini(self):
        """ Return the location of the default transponders.ini file """
        return "/usr/share/cumulus-platform/cel/voyager/etc/cumulus/transponders.ini"

    def get_net_interfaces(self):
        """
        Returns a dictionary. The keys are the transponder interface labels, and
        the values are 2-tuples: (module, index). module is the module's
        location in the system, and index is the index of the interface on the
        module.
        """
        return { "L1" : ("2", "0"),
                 "L2" : ("2", "1"),
                 "L3" : ("1", "0"),
                 "L4" : ("1", "1") }

    def get_channel_frequencies(self):
        """
        Returns a list of 3-tuples, one list entry each frequency supported. The
        3-tuple is (Channel, Frequency, Wavelength). Channel is a decimal number,
        Frequency is a float in THz, and Wavelength is a float in nanometers.
        """
        freq_map = []
        # AC400 supports 100 channels
        for ch in range(1,101):
            # Frequencies start at 191.15 THz and increase by 50 GHz
            freq = round(191.15 + (ch-1)*0.05, 2)
            # Wavelength in nm is inverse of frequency times 1/1000th speed of light
            wave = round(1/freq*299792.458, 2)
            freq_map.append((ch, freq, wave))
        return freq_map

    def expand_port_label_glob(self, label):
        """
        Given a port label glob (i.e. L1-4 or L1,3) expand it into a list of ports.
        If the glob is not valid on the platform then an empty list is returned. If
        the label is a valid port, but not a glob, then a list with just that port
        is returned.
        """
        expanded = []
        if re.match(r"""L[1-4]([-,][1-4])*$""", label) is not None:
            nums = glob_to_numbers(label[1:])
            intfs = self.get_net_interfaces()
            for num in nums:
                if "L{0}".format(num) not in intfs:
                    return []
                expanded.append("L{0}".format(num))
        return expanded

    def get_command_options(self):
        """
        Retrieve the command line options for the commands which take options.
        A dictionary is retruned with keys for the command (i.e. "state") and
        the value is a dictionary. The keys of the dictionary are the options
        allowed on this platform. The values are A 2-tuple. The first element in
        the tuple is the transponders.ini string for that option, and the second
        element is the help text for that option.
        """
        return { "state"        : { "reset"     : ("reset", "Module is held in reset"),
                                    "low-power" : ("low_power", "Low power configuration state"),
                                    "tx-off"    : ("tx_off", "TX and RX are turned up but not transmitting"),
                                    "ready"     : ("ready", "Fully operational state") },
                 "grid-spacing" : { "12.5" : ("12.5ghz", "12.5 GHz channel spacing"),
                                    "50"   : ("50ghz", "50 GHz channel spacing") },
                 "modulation"   : { "16-qam"  : ("16-qam", "16-QAM modulation"),
                                    "8-qam"   : ("8-qam", "8-QAM modulation"),
                                    "pm-qpsk" : ("pm-qpsk", "pm-qpsk modulation") },
                 "fec"          : { "15%"       : ("15%", "15% overhead SDFEC"),
                                    "15%_ac100" : ("15%_non_std", "15% overhead SDFEC compatible with AC100"),
                                    "25%"       : ("25%", "25% overhead SDFEC") } }

    def get_power_range(self):
        """
        Return a 2-tuple of floating point numbers for the minimum and maximum
        TX power, in dBm, support by the platform.
        """
        return ((-35.0, 10.0))

    def get_network_mode(self, modulation):
        """ Return the network mode for a given modulation format """
        mod_to_mode = { "16-qam" : "independent", "8-qam" : "coupled",
                        "pm-qpsk" : "independent" }
        return mod_to_mode.get(modulation)

    def get_coupled_interfaces(self, port, modulation):
        """
        Returns a list of interfaces which are "coupled" with this one.
        """
        pairs = []
        if modulation == "8-qam":
            paired_dict = { "L1" : ["L2"], "L2" : ["L1"],
                            "L3" : ["L4"], "L4" : ["L3"] }
            paired_intfs = paired_dict.get(port)
            if paired_intfs is not None:
                pairs.extend(paired_intfs)
        return pairs


#-------------------------------------------------------------------------------
#
#   Platform selection - The "platform" global variable is set to an instance
#   of the correct platform we are running upon.
#
#-------------------------------------------------------------------------------

log = logging.getLogger("netd")

#
# A dictionary of platform string names (as returned by cl-platform) and the
# Platform class for that string. To add a new platform, add a new class for it
# above and add an entry to this dictionary.
#
platform_dict = {
    "cel,voyager" : VoyagerPlatform,
}

#
# Determine which platform we are running upon and instantiate the correct
# platform class.
#
try:
    platform_str = subprocess.check_output("/usr/lib/cumulus/cl-platform")
except subprocess.CalledProcessError:
    platform_str = None

platform = platform_dict.get(platform_str, BasePlatform)()


#-------------------------------------------------------------------------------
#
#   Plugin functions
#
#   These are the standard plug-in functions which NCLU plug-ins must implement.
#
#-------------------------------------------------------------------------------

def build_doc_string():
    """
    Syntax for this plug-in is only available when on a platform with transponders.
    """

    # Assume there are not transponders on the platform...
    doc_str = ''

    # ...but if there are, then add to the doc string to allow their configuration
    if platform.has_transponders():

        # Get the options which are allowed on this platform.
        options = platform.get_command_options()
        state_values = "( {0} )".format(" | ".join(options.get("state", {})))
        state_options = "\n".join(["    {0:20s}: {1}".format(k,v[1]) for k,v in options.get("state", {}).iteritems()])
        grid_values = "( {0} )".format(" | ".join(options.get("grid-spacing", {})))
        grid_options = "\n".join(["    {0:20s}: {1}".format(k,v[1]) for k,v in options.get("grid-spacing", {}).iteritems()])
        modulation_values = "( {0} )".format(" | ".join(options.get("modulation", {})))
        modulation_options = "\n".join(["    {0:20s}: {1}".format(k,v[1]) for k,v in options.get("modulation", {}).iteritems()])
        fec_values = "( {0} )".format(" | ".join(options.get("fec", {})))
        fec_options = "\n".join(["    {0:20s}: {1}".format(k,v[1]) for k,v in options.get("fec", {}).iteritems()])
        doc_str = """/
Usage:
    net add interface <trans-port> state {state}
    net add interface <trans-port> transmit-disable
    net add interface <trans-port> grid-spacing {grid}
    net add interface <trans-port> frequency <trans-frequency>
    net add interface <trans-port> power <trans-dBm>
    net add interface <trans-port> modulation {modulation}
    net add interface <trans-port> non-differential
    net add interface <trans-port> fec {fec}
    net del interface <trans-port> transmit-disable
    net del interface <trans-port> non-differential
    net show transponder [module <trans-module>] [verbose]
    net show transponder [json]
    net show transponder frequency-map [json]
    net show configuration transponders

Options:
    <trans-port>        : Transponder port's front panel label
    state               : Operational state of the module
{state_options}
    transmit-disable    : Transmitter is disabled
    grid-spacing        : Distance between channel frequencies in GHz
{grid_options}
    frequency           : Frequency for the channel
    <trans-frequency>   : The channel frequency in THz
    power               : Transmit power in dBm
    <trans-dBm>         : The amount of power, a floating point number
    modulation          : Modulation technique used
{modulation_options}
    non-differential    : Use non-differential encoding
    fec                 : Forward error correction
{fec_options}
    transponder         : A DWDM optical transponder module
    module              : Restrict to just one module
    <trans-module>      : A transponder's module number
    json                : Print output in json
    verbose             : Print additional output
    frequency-map       : Print a map of supported frequencies, channels, and wavelengths
    transponders        : DWDM optical transponder modules
    """.format(state=state_values, state_options=state_options,
               grid=grid_values, grid_options=grid_options,
               modulation=modulation_values, modulation_options=modulation_options,
               fec=fec_values, fec_options=fec_options)

    return doc_str


def commit_pending(verbose):
    """
    Copy scratchpad files over configuration files, call necessary restart commands, etc.

    Return a 2-tuple of (bool, dict).  The boolean indicates if the commit succeeded.
    The dictionary is as described in nclu/plugins/__init__.py:execute_modular.
    """
    # Assume the best
    success = True
    messages = {"output": ''}

    # Are we on a platform with transponders?
    if platform.has_transponders():

        # Are there any changes?
        if get_pending_diffs(((TRANSPONDERS_INI, TRANSPONDERS_INI_SCRATCHPAD),), False) != '':

            # Copy over the scratchpad config to the real config
            persist_configurations(((TRANSPONDERS_INI, TRANSPONDERS_INI_SCRATCHPAD),))

            # Run restart commands, if any.
            restart_commands = get_restart_commands(TRANSPONDERS_INI)
            success, _, command_messages = run_commands(restart_commands, verbose)
            merge_messages(messages, command_messages)

            # Did the commit succeeded?
            if success:
                remove_scratch_files_and_backups([TRANSPONDERS_INI_SCRATCHPAD])
            else:
                # The commit failed.  Revert the configuration if a backup exists.
                if os.path.isfile(TRANSPONDERS_INI_SCRATCHPAD + ".bak"):
                    persist_configurations([(TRANSPONDERS_INI, TRANSPONDERS_INI_SCRATCHPAD + ".bak")], False)
                    revert_success, _, revert_messages = run_commands(restart_commands, verbose)
                    merge_messages(messages, revert_messages)
                    if not revert_success:
                        messages["error"].append("Reverting {0} changes failed.".format(TRANSPONDERS_INI))

    return (success, messages)


def show_config_commands(ifupdown2_wrapper):
    """
    net show configuration commands
    """
    # Does this platform have any transponders?
    if not platform.has_transponders():
        return ([], [])

    # Read in the current config file
    try:
        curr_config = ConfigObj(TRANSPONDERS_INI)
    except ConfigObjError:
        log.error("The configuration file ({0}) cannot be parsed".format(TRANSPONDERS_INI))
        return ([], [])

    # Read in the default config file
    try:
        # Get the name of the default configuration file for this platform, then
        # parse that file into a python dictionary.
        default_filename = platform.get_default_transponders_ini()
        default_config = ConfigObj(default_filename)
    except ConfigObjError:
        log.error("The configuration file ({0}) cannot be parsed".format(default_filename))
        return ([], [])

    # Also read the default config file into a list
    with open(default_filename) as f:
        default_lines = [line.rstrip('\n') for line in f]

    # Go through the current configuration and look for differences from the
    # default configuration. The curr_diff dictionary uses the configuration file
    # key as the key, and a dictionary as the value. That dictionary has the
    # configuration file value as the key and a list of interfaces as the value.
    #
    #   curr_diff = { key : { value : [ intf, ... ],
    #                         value : [ intf, ... ],
    #                         ... },
    #                 key : { value : [ intf, ... ],
    #                         value : [ intf, ... ],
    #                         ... },
    #                 ... }
    #
    curr_diff = {}
    for module_name in get_config_list(curr_config, "Modules", "Names"):
        # Get the corresponding module section in the default config
        curr_module = curr_config.get(module_name, {})
        default_module = get_module_section(default_config, curr_module.get("Location"))
        # Go through each key/value in the current module section
        for module_key, module_value in curr_module.iteritems():
            # Is the key a list of network or host interfaces?
            if module_key in ('NetworkInterfaces', 'HostInterfaces'):
                # Go through each interface name
                for intf_name in get_config_list(curr_config, module_name, module_key):
                    curr_intf = curr_config.get(intf_name, {})
                    default_intf = get_interface_section(default_config, default_module, module_key, curr_intf.get("Location"))
                    # Go through each key/value pair in the interface section
                    for intf_key, intf_value in curr_intf.iteritems():
                        if intf_value != default_intf.get(intf_key):
                            curr_diff.setdefault(intf_key,{}).setdefault(intf_value,[]).append(intf_name)

            # This is a module section's key/value pair
            else:
                if module_value != default_module.get(module_key):
                    curr_diff.setdefault(module_key,{}).setdefault(module_value,[]).append(curr_module.get("Location"))

    supported_commands = []
    remain_diff = copy.copy(curr_diff)
    # These are the keys which we support, with their handler functions
    supported_keys = { "OutputPower"          : handle_output_power,
                       "FecMode"              : handle_fec_mode,
                       "DifferentialEncoding" : handle_diff_encoding,
                       "TxEnable"             : handle_tx_enable,
                       "TxGridSpacing"        : handle_grid_spacing,
                       "OperStatus"           : handle_oper_status,
                       "ModulationFormat"     : handle_modulation,
                       "TxChannel"            : handle_tx_channel }

    # Handle the keys present in the current config and which we support
    for key in set(curr_diff) & set(supported_keys):
        # Call the handler function and then remove the key from the remaining keys
        supported_commands.extend(supported_keys[key](curr_diff, remain_diff))
        remain_diff.pop(key, None)

    # Anything left in remain_diff is an unsupported command. Add "sed" commands
    # to alter the default config file.
    unsupported_commands = []
    for key in remain_diff:
        for value in remain_diff[key]:
            for intf in remain_diff[key][value]:
                line_num = get_config_file_line(default_lines, intf, key)
                if line_num >= 0:
                    unsupported_commands.append("sed -i '{0}s/.*/{1} = {2}/' {3}".format(line_num, key, value, TRANSPONDERS_INI))

    return (supported_commands, unsupported_commands)


def show_config_summary(summary):
    """
    net show configuration transponders

    Populate the "summary" dictionary with information about the transponders configuration.
    """
    assert isinstance(summary, dict)

    # Does this platform have any transponders?
    if not platform.has_transponders():
        return

    # Read in the config file
    try:
        config = ConfigObj(TRANSPONDERS_INI)
    except ConfigObjError:
        log.error("The configuration file ({0}) cannot be parsed".format(TRANSPONDERS_INI))
        return

    # Go through each module section name in the [Modules] section
    transponders_summary = OrderedDict()
    for module_name in get_config_list(config, "Modules", "Names"):
        # Go through each key/value in the module section
        module_summary = OrderedDict()
        for module_key, module_value in config.get(module_name, {}).iteritems():
            # Is the key a list of network or host interfaces?
            if module_key in ['NetworkInterfaces', 'HostInterfaces']:
                # Go through each interface name
                for intf_name in get_config_list(config, module_name, module_key):
                    # Go through each key/value pair in the interface section
                    intf_summary = OrderedDict()
                    for intf_key, intf_value in config.get(intf_name, {}).iteritems():
                        intf_summary[intf_key] = intf_value
                    module_summary[intf_name] = intf_summary
            # This is just a normal key/value pair
            else:
                module_summary[module_key] = module_value
        transponders_summary[module_name] = module_summary
    summary['transponders'] = transponders_summary
    return


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """
    command_functions = {
    # Command line option    Function to "make it so"
        "fec"              : execute_fec_command,
        "frequency"        : execute_frequency_command,
        "grid-spacing"     : execute_grid_command,
        "modulation"       : execute_modulation_command,
        "non-differential" : execute_non_differential_command,
        "power"            : execute_power_command,
        "state"            : execute_state_command,
        "transmit-disable" : execute_transmit_disable_command
    }

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert "configuration" not in tokens, "\"net show configuration transponders\" does not use this code path."

    # Assume success
    messages = {"output" : ""}
    success = True

    # Handle the show command
    if 'show' in tokens:
        success = execute_show(tokens, messages, success)
        return (success, messages)

    # If the scratchpad file doesn't exist, create it from the existing file or default.
    if not os.path.isfile(TRANSPONDERS_INI_SCRATCHPAD):
        # Read in the default file contents
        try:
            with open(platform.get_default_transponders_ini(), 'r') as f:
                default = f.read()
        except IOError:
            merge_warning(messages, "The default transponders configuration file ({0}) cannot be read".format(platform.get_default_transponders_ini()))
            default = ""
        make_scratchpads([(TRANSPONDERS_INI, TRANSPONDERS_INI_SCRATCHPAD, default)])

    # Read in the scratchpad file
    try:
        scratch = ConfigObj(TRANSPONDERS_INI_SCRATCHPAD)
    except ConfigObjError:
        merge_error(messages, "The configuration file ({0}) cannot be parsed".format(TRANSPONDERS_INI_SCRATCHPAD))
        success = False
        return (success, messages)

    # This is an add or del command. Handle each port setting individually
    for cmd_port in platform.expand_port_label_glob(tokens.get("<trans-port>",'')):
        success, cfg_module = get_cfg_module(scratch, cmd_port, messages, success)
        success, cfg_netif  = get_cfg_netif(scratch, cfg_module, cmd_port, messages, success)
        if not success:
            merge_error(messages, "The configuration file ({0}) is not properly formatted".format(TRANSPONDERS_INI_SCRATCHPAD))
            continue

        # Execute the specific command
        found = False
        for command in command_functions:
            if command in tokens:
                success = command_functions[command](net_daemon, tokens, scratch, cfg_module, cfg_netif, 'add' in tokens, messages, success)
                found = True
                break
        if not found:
            merge_error(messages, "This command is not recognized.")
            success = False
            return (success, messages)
        if not success:
            merge_error(messages, "This command could not be executed.")
            return (success, messages)

    # Write out the new scratch file
    try:
        scratch.write()
    except ConfigObjError:
        merge_error(messages, "The configuration file ({0}) cannot be written".format(TRANSPONDERS_INI_SCRATCHPAD))
        success = False
        return (success, messages)

    return (success, messages)

def del_all():
    """
    net del all

    Revert all configuration files associated with this plug-in to their defaults.
    """
    # If the scratchpad directory doesn't exist, create it
    if not os.path.isdir(os.path.dirname(TRANSPONDERS_INI_SCRATCHPAD)):
        # Create the scratchpad directory.
        os.makedirs(os.path.dirname(TRANSPONDERS_INI_SCRATCHPAD), mode=WORKING_DIRECTORIES_PERMISSIONS)

    # Copy the default configuration file to the scratchpad
    default_filename = platform.get_default_transponders_ini()
    if default_filename is not None:
        persist_configurations(((TRANSPONDERS_INI_SCRATCHPAD, default_filename),), False)
    return


def get_config_files():
    """
    Return a string with the content of all existing, non-empty configuration files managed with this plug-in.
    """
    return get_config_files_helper(get_managed_files())


def get_pending(use_colors):
    """ Return a string of the pending changes in all managed files. """
    the_diff = get_pending_diffs([(TRANSPONDERS_INI, TRANSPONDERS_INI_SCRATCHPAD)], use_colors)

    # If there are differences, then add a warning that "net commit" may take a
    # really long time.
    if the_diff:
        if use_colors:
            the_diff += "\033[91m"

        the_diff += """

********************************************************************
********************************************************************
NOTE: "net commit" might run "taihostctl reload" to apply the change
to {0}. This can take as long as a few minutes.
********************************************************************
********************************************************************
""".format(TRANSPONDERS_INI)

        if use_colors:
            the_diff += "\033[0m"

    return the_diff


def abort_pending():
    """ Remove pending changes """
    remove_scratch_files_and_backups([TRANSPONDERS_INI_SCRATCHPAD])


def get_managed_files():
    """ Return a list of managed files. """
    return [TRANSPONDERS_INI]


def get_restart_commands(filename=None):
    """
    Return a list of commands that should be called for the given file to activate
    that configuration file's contents. Some plug-ins use this in commit_pending as well.
    """
    if filename == TRANSPONDERS_INI:
        if service_is_enabled("taihost.service") or service_is_active("taihost.service"):
            if os.access("/usr/bin/taihostctl", os.X_OK):
                return [["/usr/bin/taihostctl", "reload"]]
            else:
                log.info("transponders.py: /ust/bin/taihostctl is not an executable file.")
        else:
            log.info("transponders.py: taihost.service is disabled and will not be started.")
    return []


#-------------------------------------------------------------------------------
#
#   Helper functions
#
#   These are the additional functions which are not the "required" plugin
#   functions.
#
#-------------------------------------------------------------------------------

def merge_error(messages, error):
    """
    Merge an error message string into the messages dictionary.
    """
    merge_messages(messages, { 'output' : '', 'error' : [error] })


def merge_warning(messages, warning):
    """
    Merge a warning message string into the messages dictionary.
    """
    merge_messages(messages, { 'output' : '', 'warning' : [warning] })


def merge_info(messages, info):
    """
    Merge an informational message string into the messages dictionary.
    """
    merge_messages(messages, { 'output' : '', 'info' : [info] })


def tab_transponder_port(tokens, ended_with_space, last_argv):
    """
    Return a list of 2-tuples of strings (<Port label>, <help text>).
    This is tab completion for <trans-port>.
    """
    intfs = platform.get_net_interfaces()
    return [(l, "Transponder interface") for l in intfs if ended_with_space or l.startswith(last_argv)]


def tab_transponder_frequency(tokens, ended_with_space, last_argv):
    """
    Return a list of 2-tuples strings of (<frequency>, <channel, wave length>).
    This is tab completion for <trans-frequency>.
    """
    freqs = platform.get_channel_frequencies()
    return [("{0:.2f} THz".format(f[1]), "Channel {0:d}, Wavelength {1:.2f} nm".format(f[0], f[2])) for f in freqs if ended_with_space or str(f[1]).startswith(last_argv)]


def tab_transponder_module(tokens, ended_with_space, last_argv):
    """
    Return a list of 2-tuples of strings (<Module location>, <help text>).
    This is tab completion for <trans-module>.
    """
    mods = set()
    # Create a set of all module locations in the platform
    intfs = platform.get_net_interfaces()
    for intf in intfs:
        mods.add(intfs[intf][0])
    # Return the tuple of all modules. If we are tabbing a partial module name,
    # return module name which start with that name
    return [(m, "Transponder Module") for m in mods if ended_with_space or m.startswith(last_argv)]


def match_port_beginning(word):
    """
    Return true if word matches the beginning of a port label (or the whole
    thing), and false otherwise.
    """
    intfs = platform.get_net_interfaces()
    for intf in intfs:
        if intf.startswith(word):
            return True
    return False


def match_port_variable(word, fuzzy, for_tab_complete):
    """
    Determine if word matches a port label. When performing tab completion, the
    word just needs to be the start of a port label. The fuzzy parameter is not
    used.
    """
    # Get a list of ports which match the glob, or just the port if no glob.
    word_intfs = platform.expand_port_label_glob(word)
    # If it's not port label, return false, except if doing tab completion, and
    # in that case return true if it matches the beginning of a port label.
    if not word_intfs:
        return match_port_beginning(word) if for_tab_complete else False
    # Go through all of the port labels making sure that each one matches a
    # port label on this system, or the beginning of one when doing tab completion.
    for word_intf in word_intfs:
        intfs = platform.get_net_interfaces()
        if word_intf not in intfs:
            return match_port_beginning(word) if for_tab_complete else False
    return True


def match_dbm_variable(word, fuzzy, for_tab_complete):
    """
    Determine if word matches a valid power value. The fuzzy parameter is not
    used. The power value must be a floating point value between 0 and 6.
    """
    try:
        # Power values are floating point numbers
        value = float(word)
    except (TypeError, ValueError):
        return False
    # Make sure the value is correct for this platform
    min, max = platform.get_power_range()
    return min <= value <= max


def match_frequency_beginning(word, freqs):
    """
    Return true if word matches the beginning of a frequency number (or the
    whole thing) in the supplied list, and false otherwise.
    """
    for freq in freqs:
        if "{0:f}".format(freq).startswith(word):
            return True
    return False


def match_frequency_variable(word, fuzzy, for_tab_complete):
    """
    Determine if word matches a valid frequency. The fuzzy parameter is not
    used. The frequency must be a floating point value which is in the list
    of frequencies supported by the platform.
    """
    try:
        value = float(word)
    except (TypeError, ValueError):
        return False
    # Get the list of valid frequencies on this platform
    freqs = [ f[1] for f in platform.get_channel_frequencies() ]
    # If doing tab complation, just match the beginning, otherwise match the whole value
    return match_frequency_beginning(word, freqs) if for_tab_complete else value in freqs


def match_module_variable(word, fuzzy, for_tab_complete):
    """
    Determine if word matches a valid module identifier. The fuzzy parameter is
    not used. The module identifier must be a string which is in the list
    of modules supported by the platform.
    """
    intfs = platform.get_net_interfaces()
    for intf in intfs:
        module_name = intfs[intf][0]
        if word ==  module_name or (for_tab_complete and module_name.startswith(word)):
            return True
    return False


#
#   Hook our custom keywords into the network-docopt match_word() function which
#   allows transponders.py to extend the list of keywords supported by network-
#   docopt. See network-docopt:network-docopt/match.py match_word().
#
custom_matchers["<trans-port>"]       = match_port_variable
custom_matchers["<trans-dBm>"]        = match_dbm_variable
custom_matchers["<trans-frequency>"]  = match_frequency_variable
custom_matchers["<trans-module>"]     = match_module_variable


def get_config_file_line(file_lines, section, key):
    """
    Go through the provided file lines list, searching for the key in the
    section.
    """
    # Start by looking for the section
    search_state = "FindSection"
    line_num = 1
    for line in file_lines:
        if search_state == "FindSection":
            # Is this the section we are looking for?
            if re.match(r"""\s*\[\s*{0}\s*\]""".format(section), line) is not None:
                # Yes. Start looking for the key in this section.
                search_state = "FindKey"
        elif search_state == "FindKey":
            # Is this the key we are looking for?
            if re.match(r"""\s*{0}\s*=""".format(key), line) is not None:
                # YES! We have found our line
                return line_num
            # Is another section starting?
            elif re.match(r"""\s*\[\s*\S+\s*\]""", line) is not None:
                # We did not fund the key in the section
                return -1
        line_num += 1
    # We did not find the key in the section
    return -1


def handle_output_power(curr_diff, remain_diff):
    """
    The OutputPower has changed. Construct the NCLU command to change it.
    """
    for value, intfs in curr_diff.get("OutputPower", {}).iteritems():
        yield "net add interface {0} power {1}".format(ifnames_to_glob(intfs), value)


def handle_fec_mode(curr_diff, remain_diff):
    """
    The FecMode has changed. Construct the NCLU command to change it.
    """
    fec_options = platform.get_command_options().get('fec', {})
    for value, intfs in curr_diff.get("FecMode", {}).iteritems():
        for nclu_opt, tai_opt in fec_options.iteritems():
            if tai_opt[0] == value:
                value = nclu_opt
                break
        yield "net add interface {0} fec {1}".format(ifnames_to_glob(intfs), value)


def handle_diff_encoding(curr_diff, remain_diff):
    """
    The DifferentialEncoding has changed. Construct the NCLU command to change it.
    """
    for value, intfs in curr_diff.get("DifferentialEncoding", {}).iteritems():
        if value == "false":
            yield "net add interface {0} non-differential".format(ifnames_to_glob(intfs))


def handle_tx_enable(curr_diff, remain_diff):
    """
    The TxEnable has changed. Construct the NCLU command to change it.
    """
    for value, intfs in curr_diff.get("TxEnable", {}).iteritems():
        if value == "false":
            yield "net add interface {0} transmit-disable".format(ifnames_to_glob(intfs))


def handle_grid_spacing(curr_diff, remain_diff):
    """
    The TxGridSpacing has changed. Construct the NCLU command to change it.
    """
    grid_options = platform.get_command_options().get('grid-spacing', {})
    for value, intfs in curr_diff.get("TxGridSpacing", {}).iteritems():
        for nclu_opt, tai_opt in grid_options.iteritems():
            if tai_opt[0] == value:
                value = nclu_opt
                break
        yield "net add interface {0} grid-spacing {1}".format(ifnames_to_glob(intfs), value)


def handle_oper_status(curr_diff, remain_diff):
    """
    The OperStatus has changed. Construct the NCLU command to change it.
    """
    state_options = platform.get_command_options().get('state', {})
    for value, indexes in curr_diff.get("OperStatus", {}).iteritems():
        for nclu_opt, tai_opt in state_options.iteritems():
            if tai_opt[0] == value:
                value = nclu_opt
                break
        mod_intfs = mod_indexes_to_ifnames(indexes)
        yield "net add interface {0} state {1}".format(ifnames_to_glob(mod_intfs), value)


def handle_modulation(curr_diff, remain_diff):
    """
    The ModulationFormat has changed. Construct the NCLU command to change it.
    """
    for value, intfs in curr_diff.get("ModulationFormat", {}).iteritems():
        net_mode = platform.get_network_mode(value)
        for intf in intfs:
            mod_loc = platform.get_net_interfaces().get(intf,[None])[0]
            if mod_loc in remain_diff.get("NetworkMode",{}).get(net_mode,[]):
                remain_diff["NetworkMode"][net_mode].remove(mod_loc)
                if len(remain_diff["NetworkMode"][net_mode]) == 0:
                    del remain_diff["NetworkMode"][net_mode]
                    if len(remain_diff["NetworkMode"]) == 0:
                        del remain_diff["NetworkMode"]
        yield "net add interface {0} modulation {1}".format(ifnames_to_glob(intfs), value)


def handle_tx_channel(curr_diff, remain_diff):
    """
    The TxChannel has changed. Construct the NCLU command to change it.
    """
    freqs = platform.get_channel_frequencies()
    for value, intfs in curr_diff.get("TxChannel", {}).iteritems():
        for channel, freq, wave in freqs:
            if str(channel) == value:
                yield "net add interface {0} frequency {1}".format(ifnames_to_glob(intfs), freq)
                break


def mod_indexes_to_ifnames(indexes):
    """
    Convert the list of module indexes into a list of interface names
    """
    intfs = set()
    plat_intfs = platform.get_net_interfaces()
    for mod_index in indexes:
        for plat_intf, plat_locs in plat_intfs.iteritems():
            if plat_locs[0] == mod_index:
                intfs.add(plat_intf)
                break
    return list(intfs)


def get_cfg_module(config, port_label, messages, success):
    """
    Given a port label, find the module dictionary in a parsed config file
    structure for that port.
    """
    # Get the list of module names in the config file
    cfg_module_names = get_config_list(config, "Modules", "Names")
    if cfg_module_names is []:
        merge_error(messages, "The configuration file ({0}) does not contain a list of modules".format(TRANSPONDERS_INI_SCRATCHPAD))
        return (False, {})

    # Go through all of the module sections in the config file looking for one
    # which matches the location for the port_label
    plat_intfs = platform.get_net_interfaces()
    command_location = plat_intfs.get(port_label, ("","0"))[0]
    for cfg_module_name in cfg_module_names:
        if command_location == config.get(cfg_module_name, {}).get("Location"):
            return (success, config.get(cfg_module_name, {}))

    # Didn't find a match
    merge_error(messages, "The configuration file ({0}) does not contain module for port {1}".format(TRANSPONDERS_INI_SCRATCHPAD, port_label))
    return (False, {})


def get_cfg_netif(config, cfg_module, port_label, messages, success):
    """
    Given a port label, find the netwrk interface dictionary in the parsed
    config file structure for that port.
    """
    # Get the list of network interface names on this module
    cfg_netif_names = cfg_module.get("NetworkInterfaces")
    if cfg_netif_names is None:
        merge_error(messages, "The configuration file ({0}) module location {1} does not contain a list of network interfaces".format(TRANSPONDERS_INI_SCRATCHPAD, cfg_module.get("Location", "?")))
        return (False, {})
    # If the list of names is just one name, convert it to a list
    if isinstance(cfg_netif_names, basestring):
        cfg_netif_names = [ cfg_netif_names ]

    # Go through all of the network interface sections on the module, looking
    # for one which matches the location for that port label
    plat_intfs = platform.get_net_interfaces()
    command_index = plat_intfs.get(port_label, ("","0"))[1]
    for cfg_netif_name in cfg_netif_names:
        if command_index == config.get(cfg_netif_name, {}).get("Location"):
            return (success, config.get(cfg_netif_name, {}))

    # Didn't find a match
    merge_error(messages, "The configuration file ({0}) does not contain network interface for port {1}".format(TRANSPONDERS_INI_SCRATCHPAD, port_label))
    return (False, {})


def get_port_label(cfg_module, cfg_netif):
    """
    Given a module and network interface configuration file section dictionary
    determine the port label.
    """
    plat_intfs = platform.get_net_interfaces()
    mod_location = cfg_module.get("Location")
    netif_location = cfg_netif.get("Location")
    for plat_intf in plat_intfs:
        if (mod_location, netif_location) == plat_intfs[plat_intf]:
            return plat_intf
    return None


def get_breakout_type(modulation):
    """
    Given a modulation format, return the type of breakout (1x, 2x, ...) for
    that format.
    """
    breakout_type = { "16-qam" : "2x", "8-qam" : "3/2", "pm-qpsk" : "1x" }
    return breakout_type.get(modulation)


def get_config_list(config, section, key):
    """
    For the given config file dictionary, find the list of values in the
    provided section and key. If the key is not present, return the empty list.
    If the value is a single item, a list with one item is returned.
    """
    val_list = config.get(section, {}).get(key,[])
    if isinstance(val_list, basestring):
        val_list = [val_list]
    return val_list


def get_module_section(config, location):
    """
    Search the provided config dictionary for a module section which has a
    Location key set to the specified location.
    """
    for module_name in get_config_list(config, "Modules", "Names"):
        module_section = config.get(module_name, {})
        if location is not None and module_section.get("Location") == location:
            return module_section
    return {}


def get_interface_section(config, module, intf_type, location):
    """
    Search the provided config dictionary for an interface section off the module
    dictionary which matches the location provided.
    """
    for intf_name in module.get(intf_type, {}):
        intf_section = config.get(intf_name, {})
        if location is not None and intf_section.get("Location") == location:
            return intf_section
    return {}


def execute_show(tokens, messages, success):
    """ Show the tranponder status or the frequency map """
    if 'frequency-map' in tokens:
        # Display the frequency map supported on this platform
        freqs = platform.get_channel_frequencies()
        if "json" in tokens:
            messages["output"] += json.dumps(freqs, sort_keys=True, indent=4, separators=(",", " : "))
        else:
            messages["output"] += "Frequency   Channel   Wavelength\n"
            messages["output"] += "  (THz)       (#)        (nm)\n"
            messages["output"] += "---------   -------   ----------\n"
            for channel, freq, wave in freqs:
                messages["output"] += "{0:^9.2f}   {1:^7d}   {2:^10.2f}\n".format(freq, channel, wave)
    else:
        # Show the module status
        command = ["/usr/bin/taihostctl"]
        # JSON output or verbose output?
        if "json" in tokens:
            command.append("-j")
        if "verbose" in tokens:
            command.append("-v")
        command.append("status")
        # Only displaying the status of one module?
        if "module" in tokens and "<trans-module>" in tokens:
            command.append(str(tokens["<trans-module>"]))

        # Call taihostctl to get the status
        try:
            tai_output = subprocess.check_output(command)
        except subprocess.CalledProcessError as e:
            merge_error(messages, "Execution failed for {0}, {1!s}".format(" ".join(command), e))
            return False

        # Return the output
        messages["output"] += tai_output

    return success


def execute_fec_command(nd, tokens, config, cfg_module, cfg_netif, add_command, messages, success):
    """
    Modify the cfg_netif dictionary by setting the FecMode to the new value.
    """
    # Get the fec options supported by this platform
    options = platform.get_command_options().get("fec", {})
    # Use set intersection to find the match with the command line
    command_val = set(options) & set(tokens)
    command_val = command_val.pop() if len(command_val) == 1 else None
    # "15%_ac100 can only be enabled when pm-qpsk modulation is in use
    if command_val == "15%_ac100" and cfg_netif.get("ModulationFormat") != "pm-qpsk":
        merge_error(messages, "15%_ac100 FEC can only be set when using pm-qpsk modulation")
        merge_error(messages, "Change the modulation before changing the FEC mode.")
        return False
    # Get the new value for the config file (which might be different than the NCLU token)
    new_val = options.get(command_val, [None])[0]
    if new_val is None:
        merge_error(messages, "Invalid option supplied for the fec command.")
        return False
    # Finally, change the configuration structure
    cfg_netif['FecMode'] = new_val
    return success


def execute_frequency_command(nd, tokens, config, cfg_module, cfg_netif, add_command, messages, success):
    """
    Modify the cfg_netif dictionary by setting the TxChannel to the new value.
    """
    # Get the floating point value the user entered
    try:
        command_val = float(tokens.get('<trans-frequency>'))
    except (TypeError, ValueError):
        merge_error(messages, "The frequency is not a floating point number.")
        return False
    # Convert the frequency to a channel
    freqs = platform.get_channel_frequencies()
    for channel, freq, wave in freqs:
        if freq == command_val:
            # Change the channel
            cfg_netif['TxChannel'] = channel
            return success
    # That frequency doesn't have a coresponding channel
    merge_error(messages, "The frequency is not supported on this platform.")
    return False


def execute_grid_command(nd, tokens, config, cfg_module, cfg_netif, add_command, messages, success):
    """
    Modify the cfg_netif dictionary by setting the TxGridSpacing to the new value.
    """
    # Get the options supported by this platform
    options = platform.get_command_options().get("grid-spacing", {})
    # Use set intersection to find the match with the command line
    command_val = set(options) & set(tokens)
    command_val = command_val.pop() if len(command_val) == 1 else None
    # Get the new value for the config file (which might be different than the NCLU token)
    new_val = options.get(command_val, [None])[0]
    if new_val is None:
        merge_error(messages, "Invalid option supplied for the grid-spacing command.")
        return False
    # Finally, change the configuration structure
    cfg_netif['TxGridSpacing'] = new_val
    return success


def execute_modulation_command(nd, tokens, config, cfg_module, cfg_netif, add_command, messages, success):
    """
    Modify the cfg_netif dictionary by setting the ModulationFormat to the new value,
    and the cfg_module's NetworkMode, and perhaps some paired ports too.
    """
    # Determine the new modulation setting and set the value
    options = platform.get_command_options().get("modulation", {})
    command_val = set(options) & set(tokens)
    command_val = command_val.pop() if len(command_val) == 1 else None
    new_val = options.get(command_val, [None])[0]
    if new_val is None:
        merge_error(messages, "Invalid option supplied for the modulation command.")
        return False
    if new_val != "pm-qpsk" and cfg_netif.get('FecMode') == "15%_non_std":
        merge_error(messages, "15%_ac100 FEC mode is only valid with pm-qpsk modulation.")
        merge_error(messages, "Change the FEC mode before changing the modulation.")
        return False

    # Is the modulation changing?
    old_val = cfg_netif.get('ModulationFormat')
    if old_val != new_val:

        # If we are have paired interfaces, and any of those intefaces have the
        # same modulation as we have, warn that those interfaces may have to
        # have their modulation changed.
        port_label = get_port_label(cfg_module, cfg_netif)
        pair_labels = platform.get_coupled_interfaces(port_label, old_val)
        for pair_label in pair_labels:
            success, pair_cfg_netif = get_cfg_netif(config, cfg_module, pair_label, messages, success)
            if success and pair_cfg_netif['ModulationFormat'] == old_val:
                merge_warning(messages, "The modulation format of the {0} interface may also need to be changed from {1}".format(pair_label, pair_cfg_netif['ModulationFormat']))

        # Make the change.
        cfg_netif['ModulationFormat'] = new_val

        # Also change the setting on paired interfaces
        pair_changed = False
        pair_labels = platform.get_coupled_interfaces(port_label, new_val)
        for pair_label in pair_labels:
            success, pair_cfg_netif = get_cfg_netif(config, cfg_module, pair_label, messages, success)
            if success and pair_cfg_netif['ModulationFormat'] != new_val:
                success = execute_modulation_command(nd, tokens, config, cfg_module, pair_cfg_netif, add_command, messages, success)
                if success:
                    pair_changed = True
                    merge_info(messages, "Paired interface {0} also changed to {1}.".format(pair_label, new_val))
                else:
                    cfg_netif['ModulationFormat'] = old_val
                    return False

        # Change the ports.conf to reflect this change
        if len(pair_labels) == 0 or pair_changed:
            assert "ports" in nd.enabled_plugins, "ports.py is not an enabled plugin"
            breakout_type = get_breakout_type(new_val)
            nd.nclu_parser.args = { 'net' : 'net', 'add' : 'add', 'interface' : 'interface',
                '<interface>' : ",".join(["swp" + p for p in sort_for_humans([port_label] + pair_labels)]),
                'breakout' : 'breakout', breakout_type : breakout_type }
            ports_success, ports_messages = ports_execute_command(nd)
            nd.nclu_parser.args = tokens
            merge_messages(messages, ports_messages)
            if not ports_success:
                cfg_netif['ModulationFormat'] = old_val
                return False

        # Change the network mode for certain modulations
        mode = platform.get_network_mode(new_val)
        if mode is not None and cfg_module['NetworkMode'] != mode:
            cfg_module['NetworkMode'] = mode
            merge_info(messages, "Module's NetworkMode changed to {0}.".format(mode))

    return success


def execute_non_differential_command(nd, tokens, config, cfg_module, cfg_netif, add_command, messages, success):
    if add_command:
        cfg_netif['DifferentialEncoding'] = 'false'
    else:
        cfg_netif['DifferentialEncoding'] = 'true'
    return success


def execute_power_command(nd, tokens, config, cfg_module, cfg_netif, add_command, messages, success):
    """
    Modify the cfg_netif dictionary by setting the OutputPower to the new value.
    """
    try:
        new_val = float(tokens.get('<trans-dBm>'))
    except (TypeError, ValueError):
        merge_error(messages, "The power is not a floating point number.")
        return False
    cfg_netif['OutputPower'] = new_val
    return success


def execute_state_command(nd, tokens, config, cfg_module, cfg_netif, add_command, messages, success):
    """
    Modify the cfg_module dictionary by setting the OperStatus to the new value.
    """
    # Get the options supported by this platform
    options = platform.get_command_options().get("state", {})
    # Use set intersection to find the match with the command line
    command_val = set(options) & set(tokens)
    command_val = command_val.pop() if len(command_val) == 1 else None
    # Get the new value for the config file (which might be different than the NCLU token)
    new_val = options.get(command_val, [None])[0]
    if new_val is None:
        merge_error(messages, "Invalid option supplied for the state command.")
        return False
    # Finally, change the configuration structure
    cfg_module['OperStatus'] = new_val
    return success


def execute_transmit_disable_command(nd, tokens, config, cfg_module, cfg_netif, add_command, messages, success):
    if add_command:
        cfg_netif['TxEnable'] = 'false'
    else:
        cfg_netif['TxEnable'] = 'true'
    return success

