"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from collections import OrderedDict
from json import dumps
from nclu import ifname_expand_glob
from nclu.plugins import PERMISSIONS_SENSITIVE_COMPONENTS
from nclu.rollback import get_rollback_id_from_description, rollback_show, snapper_last_nclu_pre_commit, snapper_show


def execute_show(net_daemon):
    """
    Execute a subset of the basic usage commands commands, and return a 2-tuple of (bool, str).
    The boolean indicates if execution succeeded, and the string is the output.

    Relevant basic usage commands:
        net show commit (history|<number>|<number-range>|last)
        net show rollback (<number>|last)
        net show rollback description <wildcard-snapshot>
    """

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert isinstance(tokens, dict)
    assert "show" in tokens, "Why are you here?"

    # Look for matches with "basic usage" commands.

    if "commit" in tokens:
        # net show commit ...

        if "history" in tokens:
            # net show commit history
            return snapper_show(None, None, net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.color_diffs)
        elif tokens.get("<number>") is not None:
            return snapper_show(tokens["<number>"], None, net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.color_diffs)
        elif tokens.get("<number-range>") is not None:
            start, stop = map(int, tokens["<number-range>"].split('-'))
            return snapper_show(start, stop, net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.color_diffs)
        elif "last" in tokens:
            # net show commit last
            last_commit = snapper_last_nclu_pre_commit()
            if last_commit is None:
                return (True, "There have not been any commits made via \"net\".")
            return snapper_show(last_commit, None, net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.color_diffs)

    elif "rollback" in tokens:
        # net show rollback ...

        if "last" in tokens:
            # net show rollback last

            rollback_target = snapper_last_nclu_pre_commit()

            if rollback_target is None:
                return (True, "No commits have been made with \"net\".")
            return rollback_show(rollback_target, net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.color_diffs)

        elif tokens.get("<number>") is not None:
            # net show rollback <number>
            return rollback_show(tokens["<number>"], net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.color_diffs)

        elif "description" in tokens:
            # net show rollback description <wildcard-snapshot>
            assert tokens.get("<wildcard-snapshot>") is not None

            # This value can have different types, depending on the input.  The subsequent function call takes a string.
            description = tokens["<wildcard-snapshot>"]
            outcome, rollback_id = get_rollback_id_from_description(str(description))
            if not outcome:
                return (False, rollback_id)

            return rollback_show(rollback_id, net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.color_diffs)

    return (False, "Unrecognized command.")


def show_config_commands(net_daemon):
    """
    Return a string containing all commands needed to acheive the current configuration.
    """

    assert len(net_daemon.wrappers) > 0, "If the wrapper paradigm has been removed, edit this function."
    assert net_daemon.wrappers[0][0] == "ifupdown2", "The ifupdown2 wrapper should be first."  # TODO - What if it isn't enabled?
    ifupdown2_wrapper = net_daemon.wrappers[0][1]

    # Peform the initial 'ifquery -a' (if needed)
    ifupdown2_wrapper.get_ifquery_all()

    total_not_supported = []
    total_supported = ["net del all"]
    user_may_edit = net_daemon.user in net_daemon.users_with_edit

    for component in net_daemon.enabled_plugins:
        m = __import__("nclu.plugins." + component, fromlist=["show_config_commands"])

        if component in PERMISSIONS_SENSITIVE_COMPONENTS:
            supported, not_supported = m.show_config_commands(user_may_edit, ifupdown2_wrapper)  # Two lists
        else:
            supported, not_supported = m.show_config_commands(ifupdown2_wrapper)                 # Two lists

        if supported:
            total_supported.extend(supported)

        if not_supported:
            total_not_supported.extend(not_supported)

    for _, wrapper in net_daemon.wrappers:
        supported, not_supported = wrapper.show_config_commands(user_may_edit, ifupdown2_wrapper)  # Two lists

        if supported:
            total_supported.extend(supported)

        if not_supported:
            total_not_supported.extend(not_supported)

    reply = '\n'.join(total_supported) + "\nnet commit"

    if total_not_supported:
        reply += "\n\n# There are some configuration commands that are not yet supported by nclu.\n" + \
                 "# The following will append those commands to the appropriate files.\n" + \
                 "# ========================================================================\n" + \
                 '\n'.join(total_not_supported)

    return reply


def show_config_files(net_daemon):
    """
    Return a string of all the active configuration files.

    wrappers - A list of 2-tuples of (str, ConfigWrapper)
    plugins - A set of strings; component names
    """

    assert len(net_daemon.wrappers) > 0, "If the wrapper paradigm has been removed, edit this function."

    plugins_configs = ''
    user_may_edit = net_daemon.user in net_daemon.users_with_edit

    for component in net_daemon.enabled_plugins:
        m = __import__("nclu.plugins." + component, fromlist=["show_config_files"])

        if component in PERMISSIONS_SENSITIVE_COMPONENTS:
            plugins_configs += m.get_config_files(user_may_edit)
        else:
            plugins_configs += m.get_config_files()

    wrappers_configs = reduce(lambda accum, wrapper: accum + wrapper[1].show_config_files(user_may_edit), net_daemon.wrappers, '')

    return plugins_configs + wrappers_configs


def show_config_summary(net_daemon, component=None):
    """
    Return a string with the configuration for a given component, if any, or for all enabled components.
    """

    assert len(net_daemon.wrappers) > 0, "If the wrapper paradigm has been removed, edit this function."

    summary = OrderedDict()
    interfaces = None
    user_may_edit = net_daemon.user in net_daemon.users_with_edit

    if component is None:
        # net show configuration - Loop through all plugins and wrappers.

        # ifupdown2 and FRR both contribute entries that begin with "interface".  In the interest
        # of having these entries be adjacent to each other, get the entries for FRR, if enabled,
        # after the other plug-ins.  This ensures adjacency because, by construction, ifupdown2
        # is the first wrapper in net_daemon.wrappers.

        for plugin in net_daemon.enabled_plugins:
            if plugin == "frr":
                continue

            m = __import__("nclu.plugins." + plugin, fromlist=["show_config_summary"])

            if plugin in PERMISSIONS_SENSITIVE_COMPONENTS:
                m.show_config_summary(user_may_edit, summary)
            else:
                m.show_config_summary(summary)

        if "frr" in net_daemon.enabled_plugins:
            assert "frr" in PERMISSIONS_SENSITIVE_COMPONENTS
            m = __import__("nclu.plugins.frr", fromlist=["show_config_summary"])
            m.show_config_summary(user_may_edit, summary)

        for _, wrapper in net_daemon.wrappers:
            wrapper.show_config_summary(user_may_edit, summary)
    else:
        # net show configuration <component>

        target_wrapper = component

        if component and component.startswith("interface "):
            target_wrapper = "ifupdown2"
            interfaces = component.split()[1]
            interfaces = ifname_expand_glob(interfaces) if (interfaces != "None") else None
            assert interfaces is None or isinstance(interfaces, list)

        if target_wrapper in net_daemon.enabled_plugins:
            m = __import__("nclu.plugins." + target_wrapper, fromlist=["show_config_summary"])

            if component in PERMISSIONS_SENSITIVE_COMPONENTS:
                m.show_config_summary(user_may_edit, summary)
            else:
                m.show_config_summary(summary)
        else:
            for name, wrapper in net_daemon.wrappers:
                if name == target_wrapper:
                    # Use the target wrapper to modify the contents of "summary".
                    wrapper.show_config_summary(user_may_edit, summary)
                    break
            else:
                raise RuntimeError("Couldn't find the wrapper for {0}.".format(target_wrapper))

    if "json" in net_daemon.nclu_parser.args:
        # The user wants JSON output.
        return dumps(summary)

    # The rest of this function formats the "summary" dictionary as a string suitable for non-Json display.

    # TODO - Some of this functionality should be moved to the wrappers/plug-ins.  This
    # function should not include a bunch of if-else blocks.

    summary_list = ordered_dict_to_list(summary)

    prev_line = ''
    printed_blank_line = False
    state = None
    context = None
    prev_acl_name = None
    notice = ''

    for line in summary_list:

        if not line.startswith("  "):
            context = line

        if component is not None:
            if component == "acl":
                if "acl " in line or line.startswith("policer-template"):
                    # An acl entry under an interface
                    if line.startswith("  "):
                        if context:
                            notice += "\n{0}\n".format(context)
                            context = None
                    else:
                        acl_name = line.split()[2]

                        if acl_name != prev_acl_name:
                            notice += '\n'
                        prev_acl_name = acl_name

                    notice += "{0}\n".format(line)
                continue

            elif component == "bgp":
                if line.startswith("router bgp"):
                    notice += '\n'
                    state = "BGP"
                elif not line.startswith("  "):
                    state = None

                if state != "BGP":
                    if line.lstrip().startswith("bgp ") or line.lstrip().startswith("debug bgp "):
                        if context is not None:
                            if context != line:
                                notice += "\n{0}\n".format(context)
                            context = None
                        notice += '\n'
                    continue

            elif component == "dot1x":
                if line.startswith("dot1x"):
                    notice += '\n'
                    state = "DOT1X"
                elif not line.startswith("  "):
                    state = None

                if state != "DOT1X":
                    if line.lstrip().startswith("parking") \
                       or line.lstrip().startswith("mab") \
                       or line.lstrip().startswith("dot1x"):
                        if context is not None:
                            if context != line:
                                notice += "\n{0}\n".format(context)
                            context = None
                        notice += '\n'
                    continue

            elif component == "ospf":
                if line.startswith("router ospf") and not line.startswith("router ospf6"):
                    notice += '\n'
                    state = "OSPF"
                elif not line.startswith("  "):
                    state = None

                if state != "OSPF":
                    if line.lstrip().startswith("ip ospf ") or line.lstrip().startswith("debug ospf "):
                        if context is not None:
                            if context != line:
                                notice += "\n{0}\n".format(context)
                            context = None
                        notice += '\n'
                    continue

            elif component == "ospf6":
                if line.startswith("router ospf6"):
                    notice += '\n'
                    state = "OSPF6"
                elif not line.startswith("  "):
                    state = None

                if state != "OSPF6":
                    if line.lstrip().startswith("ipv6 ospf6 ") or line.lstrip().startswith("debug ospf6 "):
                        if context is not None:
                            if context != line:
                                notice += "\n{0}\n".format(context)
                            context = None
                        notice += line + '\n'
                    continue

            elif component == "multicast":
                if (line.lstrip().startswith("ip pim") or
                    line.lstrip().startswith("ip igmp") or
                    line.lstrip().startswith("ip mroute") or
                    line.lstrip().startswith("ip msdp") or
                    line.lstrip().startswith("debug igmp") or
                    line.lstrip().startswith("debug msdp") or
                    line.lstrip().startswith("debug pim") or
                    line == "ip multicast-routing"):

                    if context is not None:
                        if context != line:
                            notice += "\n{0}\n".format(context)
                        context = None
                    notice += line + '\n'
                continue

            elif interfaces is not None:
                if line.startswith("interface "):
                    for interface in interfaces:
                        if line == "interface {0}".format(interface):
                            state = "INTERFACE"
                            break
                    else:
                        state = None

                elif not line.startswith("  "):
                    if state == "INTERFACE":
                        notice += '\n'
                    state = None

                if state != "INTERFACE":
                    continue

        if line:
            if ((line.startswith("ip route") and not prev_line.startswith("ip route")) or
                (line.startswith("ip prefix-list") and not prev_line.startswith("ip prefix-list")) or
                (line.startswith("ipv6 route") and not prev_line.startswith("ipv6 route")) or
                (line.startswith("ipv6 prefix-list") and not prev_line.startswith("ipv6 prefix-list")) or
                (line.startswith("ipv6 prefix-list") and not prev_line.startswith("ipv6 prefix-list")) or
                (line.startswith("policer-template") and not prev_line.startswith("policer-template")) or
                (line.startswith("acl ipv4") and not prev_line.startswith("acl ipv4")) or
                (line.startswith("acl ipv6") and not prev_line.startswith("acl ipv6")) or
                (line.startswith("acl mac") and not prev_line.startswith("acl mac"))):

                if not printed_blank_line:
                    notice += '\n'

            notice += "{0}\n".format(line)
            prev_line = line
            printed_blank_line = False
        else:
            if not (prev_line.startswith("ip route") or
                    prev_line.startswith("ip prefix-list") or
                    prev_line.startswith("ipv6 route") or
                    prev_line.startswith("ipv6 prefix-list") or
                    prev_line.startswith("policer-template") or
                    prev_line.startswith("acl ipv4") or
                    prev_line.startswith("acl ipv6") or
                    prev_line.startswith("acl mac")):
                notice += "{0}\n".format(line)
                printed_blank_line = True

    if notice:
        notice += """\n
# The above output is a summary of the configuration state of the switch.
# Do not cut and paste this output into /etc/network/interfaces or any other
# configuration file.  This output is intended to be used for troubleshooting
# when you need to see a summary of configuration settings.
#
# Please use "net show configuration commands" for a configuration that
# you can back up or copy and paste into a new device.
"""

    return notice


def ordered_dict_to_list(dictionary):
    """
    Recursively format the given dictionary.
    """

    assert isinstance(dictionary, OrderedDict)
    return ordered_dict_to_list_helper(dictionary, 0)


def ordered_dict_to_list_helper(dictionary, level):

    output = []
    indent = "  " * level

    for (key, value) in dictionary.iteritems():
        if level == 0:
            output.append('')
        elif key != "COMMAND_LIST" and value:
            output.append(indent)

        if key.startswith("INTERFACE:"):
            key = key.replace("INTERFACE:", '')
            output.append("interface " + key)
        elif key == "COMMAND_LIST":
            level -= 1
        else:
            output.append(indent + key)

        if value:
            level += 1
            indent = '  ' * level

            if isinstance(value, OrderedDict):
                # Recurse!
                output.extend(ordered_dict_to_list_helper(value, level))
            elif isinstance(value, list):
                for x in value:
                    output.append(indent + str(x))
            elif isinstance(value, (str, int)):
                output.append(indent + value)
            else:
                # This is a programming error.  Wrappers/plug-ins should not return values that cause problems here.
                raise RuntimeError("ordered_dict_to_list does not know how to append \"{0}\" of type {1}.".format(value, type(value)))

            if key != "COMMAND_LIST":
                level -= 1
                indent = '  ' * level

    return output
