#!/usr/bin/env python

"""
Copyright (C) 2016, 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt

Usage:
    # dot1x RADIUS commands
    # FIXME add IPv6 later dot1x (add|del) dot1x radius server-ip <ipv4>|<ipv6>
    dot1x (add|del) dot1x radius server-ip <ipv4>
    dot1x add       dot1x radius authentication-port (default|<1-65535>)
    dot1x add       dot1x radius accounting-port (default|<1-65535>)
    dot1x add       dot1x radius accounting-port (default|<1-65535>)
    dot1x (add|del) dot1x radius shared-secret <text>
    dot1x add       dot1x mab-activation-delay (default|<5-30>)
    dot1x add       dot1x eap-reauth-period (default|<0-86400>)
    dot1x add       dot1x dynamic-vlan [require]
    dot1x add       dot1x radius client-source-ip <ipv4>
    dot1x del       dot1x radius client-source-ip
    dot1x del       dot1x dynamic-vlan
    dot1x (add|del) dot1x parking-vlan-id <1-4094>

    # dot1x del all configs and stop hostapd
    dot1x del dot1x all

    # dot1x interface enabling or disabling commands
    dot1x (add|del) interface <interface> dot1x
    dot1x (add|del) interface <interface> dot1x  mab
    dot1x (add|del) interface <interface> dot1x  mab parking-vlan
    dot1x (add|del) interface <interface> dot1x  parking-vlan
    dot1x (add|del) interface <interface> dot1x  parking-vlan mab

    # dot1x show commands
    dot1x show dot1x [json]
    dot1x show dot1x status [json]
    dot1x show dot1x macs [json]
    dot1x show dot1x macs <interface> [json]
    dot1x show dot1x port-details [json]
    dot1x show dot1x port-details <interface> [json]
    dot1x show dot1x radius-details [json]
    dot1x show dot1x radius-details <interface> [json]
    dot1x show dot1x interface <interface> [json]
    dot1x show dot1x interface <interface> details [json]
    dot1x show dot1x interface summary [json]
    dot1x example dot1x
    net show configuration dot1x

Options:
    dot1x : Configure, Enable, Delete or Show IEEE 802.1X EAPOL
    mab : Enable MAC Authentication Bypass with IEEE 802.1X EAPOL
    parking-vlan : Enable a IEEE 802.1X Parking VLAN for non-Authorized MAC Addresses.
    all : Everything
    stations : Show authenticated MAC addresses per interface
    macs : Media Access Control addresses
    port-details : Show counters from the IEEE8021-PAE-MIB for ports
    dynamic-vlan : Enable, Disable or Require Dynamic VLAN assignment from RADIUS Server.
    require : Requires RADIUS Server VLAN settings to authenticate 802.1X users.
    radius-details : Show counters from the RADIUS-CLIENT MIB (RFC 2618) for ports
    radius : IEEE 802.1X RADIUS Server Configuration
    authentication-port : RADIUS authentication port (default: 1812)
    mab-activation-delay : Seconds to wait before starting MAC Authentication Bypass (default: 30)
    eap-reauth-period : EAP Reauthentication period in seconds (0 to disable, default:0)
    parking-vlan-id : Configure a Isolated Parking VLAN ID for non-Authorized MAC Addresses.
    accounting-port : RADIUS accounting parameters (default: 1813)
    server-ip : Server IPv4 or IPv6 Address (no default, required)
    client-source-ip : Specify the client source IP address for RADIUS communication.
    shared-secret : Configure RADIUS Shared Secret (no default, required)
    summary : Show condensed output summarizing data

"""

from nclu import (
    ifname_expand_glob,
    ConfigWrapperBase,
    make_pending_diff,
    tabulate_remove_unicode as tru
)

import ifupdown2
from nclu.netshow2 import get_master
from collections import OrderedDict
from network_docopt.match import ifname_is_valid
from subprocess import CalledProcessError, check_output, STDOUT
from tabulate import tabulate
import json
import logging
import logging.handlers
import os
import pprint
import re
import shutil
import glob

log = logging.getLogger("netd")


class ConfigWrapper(ConfigWrapperBase):
    def __init__(self, show_linux_command, color_diffs):
        super(ConfigWrapper, self).__init__("dot1x", show_linux_command, color_diffs)
        self.commands = None
        # we can have only one value, e.g. ip addres, secret, port, interface
        self.values = None
        # interface may need to be expanded
        self.ifnames = None
        # we need to keep the original bridge name indexed by dot1x interface
        #    e.g.   {'swp1': 'bridge1', 'swp2':'bridge200'}
        self.original_trad_bridge_dict = {}
        self.dot1x_scratchpad = "/run/nclu/dot1x/"
        self.scratch_config_file = "/run/nclu/dot1x/hostapd.conf"
        self.temp_config_file = "/run/nclu/dot1x/temp_hostapd.conf"
        self.scratch_pending_delete_file = "/run/nclu/dot1x/pending_delete"
        self.pending_config_file = "/run/nclu/dot1x/pending_config.json"
        self.config_file = "/etc/hostapd.conf"
        self.config_attrs = ["eap_server",
                             "ieee8021x",
                             "driver",
                             "dynamic_vlan",
                             "interfaces",
                             "mab_interfaces",
                             "parking_vlan_interfaces",
                             "parking_vlan_id",
                             "mab_activation_delay",
                             "eap_reauth_period",
                             "ctrl_interface",
                             "nas_identifier",
                             "auth_server_addr",
                             "auth_server_port",
                             "auth_server_shared_secret",
                             "acct_server_addr",
                             "radius_client_addr",
                             "acct_server_port",
                             "acct_server_shared_secret"]
        self.config_defaults = OrderedDict([("ctrl_interface", "/run/hostapd"),
                                            ("eap_server", '0'),
                                            ("ieee8021x", '1'),
                                            ("driver", "wired"),
                                            ("dynamic_vlan", '0'),
                                            ("interfaces", None),
                                            ("mab_interfaces", None),
                                            ("parking_vlan_interfaces", None),
                                            ("parking_vlan_id", None),
                                            ("mab_activation_delay", "30"),
                                            ("eap_reauth_period", '0'),
                                            ("nas_identifier", "localhost"),
                                            ("auth_server_addr", None),
                                            ("auth_server_port", "1812"),
                                            ("auth_server_shared_secret", None),
                                            ("acct_server_addr", None),
                                            ("acct_server_port", "1813"),
                                            ("acct_server_shared_secret", None)])
        # attributes the user can actually change
        self.iface_array = {"interfaces": {"arg": "<interface>",
                                         "config_list": ["interfaces", "dot1x"],
                                         "default": None},
                            "mab_interfaces": {"arg": "<interface>",
                                                "config_list": ["interfaces", "mab"],
                                                "default": None},
                            "parking_vlan_interfaces": {"arg": "<interface>",
                                                         "config_list":
                                                         ["interfaces", "parking-vlan"],
                                                         "default": None}
                           }
        self.config_array =  {"mab_activation_delay": {"arg": "<5-30>",
                                                       "cli_name": "mab-activation-delay",
                                                       "show_default": True,
                                                       "default": "30"},
                              "parking_vlan_id": {"arg": "<1-4094>",
                                                   "cli_name": "parking-vlan-id",
                                                  "show_default": True,
                                                  "default": None},
                              "eap_reauth_period": {"arg": "<0-86400>",
                                                    "cli_name": "eap-reauth-period",
                                                    "show_default": True,
                                                    "default": '0'},
                              "auth_server_addr": {"arg": "<ipv4>",
                                                   "cli_name": "server-ip",
                                                   "show_default": True,
                                                   "default": None},
                              "auth_server_port": {"arg": "<1-65535>",
                                                   "cli_name": "authentication-port",
                                                   "show_default": True,
                                                   "default": "1812"},
                              "dynamic_vlan": {"arg": ["require", "del", "add"],
                                               "show_default": True,
                                               "argval": {"del": '0',
                                                          "add": '1',
                                                          "require": '2'},
                                               "status": {'0': "Disabled",
                                                          '1': "Enabled ",
                                                          '2': "Required"},
                                               "conf2nclu": {'0': None,
                                                             '1': ' ',
                                                             '2': "require"},
                                               "cli_name": "dynamic-vlan",
                                               "default": '0'},
                              "radius_client_addr": {"arg": "<ipv4>",
                                                     "cli_name": "client-source-ip",
                                                     "show_default": False,
                                                     "default": None},
                              "auth_server_shared_secret": {"arg": "<text>",
                                                            "show_default": True,
                                                            "cli_name": "shared-secret",
                                                            "default": None},
                              "acct_server_addr": {"arg": "<ipv4>",
                                                   "show_default": True,
                                                   "cli_name": "server-ip",
                                                   "default": None},
                              "acct_server_port": {"arg": "<1-65535>",
                                                   "show_default": True,
                                                   "cli_name": "accounting-port",
                                                   "default": "1813"},
                              "acct_server_shared_secret": {"arg": "<text>",
                                                            "show_default": True,
                                                            "cli_name": "shared-secret",
                                                            "default": None}
                             }
        self.cli_array =  {"dot1x": {"arg": "<interface>",
                                      "config_list": ["interfaces"],
                                      "default": None},
                           "mab": {"arg": "<interface>",
                                    "config_list": ["mab_interfaces"],
                                    "default": None},
                           "dynamic-vlan": {"arg": "<text>",
                                             "config_list": ["dynamic_vlan"],
                                             "default": "disabled"},
                           "server-ip": {"arg": "<ipv4>",
                                          "config_list": ["auth_server_addr",
                                                           "acct_server_addr"],
                                          "default": None},
                           "client-source-ip": {"arg": "<ipv4>",
                                                "config_list": ["radius_client_addr"],
                                                "default": None},
                           "mab-activation-delay": {"arg": "<5-30>",
                                                     "config_list":
                                                     ["mab_activation_delay"],
                                                     "default": "30"},
                           "parking-vlan-id": {"arg": "<1-4094>",
                                                "config_list":
                                                ["parking_vlan_id"],
                                                "default": None},
                           "eap-reauth-period": {"arg": "<0-86400>",
                                                  "config_list":
                                                  ["eap_reauth_period"],
                                                  "default": '0'},
                           "authentication-port": {"arg": "<1-65535>",
                                                    "config_list": ["auth_server_port"],
                                                    "default": "1812"},
                           "accounting-port": {"arg": "<1-65535>",
                                                "config_list": ["acct_server_port"],
                                                "default": "1813"},
                           "shared-secret": {"arg": "<text>",
                                              "config_list": ["auth_server_shared_secret",
                                                               "acct_server_shared_secret"],
                                              "default": None}
                          }
        self.radius_detail_list = ["radiusAuthServerIndex",
                                   "radiusAuthServerAddress",
                                   "radiusAuthClientServerPortNumber",
                                   "radiusAuthClientRoundTripTime",
                                   "radiusAuthClientAccessRequests",
                                   "radiusAuthClientAccessRetransmissions",
                                   "radiusAuthClientAccessAccepts",
                                   "radiusAuthClientAccessRejects",
                                   "radiusAuthClientAccessChallenges",
                                   "radiusAuthClientMalformedAccessResponses",
                                   "radiusAuthClientBadAuthenticators",
                                   "radiusAuthClientPendingRequests",
                                   "radiusAuthClientTimeouts",
                                   "radiusAuthClientUnknownTypes",
                                   "radiusAuthClientPacketsDropped",
                                   "radiusAccServerIndex",
                                   "radiusAccServerAddress",
                                   "radiusAccClientServerPortNumber",
                                   "radiusAccClientRoundTripTime",
                                   "radiusAccClientRequests",
                                   "radiusAccClientRetransmissions",
                                   "radiusAccClientResponses",
                                   "radiusAccClientMalformedResponses",
                                   "radiusAccClientBadAuthenticators",
                                   "radiusAccClientPendingRequests",
                                   "radiusAccClientTimeouts",
                                   "radiusAccClientUnknownTypes",
                                   "radiusAccClientPacketsDropped"]
        self.port_detail_list = ["dot1xPaePortProtocolVersion",
                                 "dot1xAuthPaeState",
                                 "dot1xAuthBackendAuthState",
                                 "dot1xAuthQuietPeriod",
                                 "dot1xAuthServerTimeout",
                                 "dot1xAuthReAuthPeriod",
                                 "dot1xAuthReAuthEnabled",
                                 "dot1xAuthEapolFramesRx",
                                 "dot1xAuthEapolFramesTx",
                                 "dot1xAuthEapolStartFramesRx",
                                 "dot1xAuthEapolLogoffFramesRx",
                                 "dot1xAuthEapolRespIdFramesRx",
                                 "dot1xAuthEapolRespFramesRx",
                                 "dot1xAuthEapolReqIdFramesTx",
                                 "dot1xAuthEapolReqFramesTx",
                                 "dot1xAuthInvalidEapolFramesRx",
                                 "dot1xAuthEapLengthErrorFramesRx",
                                 "dot1xAuthLastEapolFrameVersion",
                                 "dot1xAuthLastEapolFrameSource",
                                 "dot1xAuthAuthSuccessesWhileAuthenticating",
                                 "dot1xAuthAuthTimeoutsWhileAuthenticating",
                                 "dot1xAuthAuthFailWhileAuthenticating",
                                 "dot1xAuthSessionId",
                                 "dot1xAuthSessionAuthenticMethod",
                                 "dot1xAuthSessionTime",
                                 "dot1xAuthSessionTerminateCause",
                                 "dot1xAuthSessionUserName",
                                 "authMultiSessionId",
                                 "last_eap_type_as",
                                 "vlan_id",
                                 "last_eap_type_sta",
                                 "connected_time"]
        self.interface_detail_list = [("Status Flags", "flags"),
                                      ("Username", "dot1xAuthSessionUserName"),
                                      ("Authentication Type", "auth_srv_eap_type"),
                                      ("VLAN", "vlan_id"),
                                      ("Session Time (seconds)", "dot1xAuthSessionTime"),
                                      ("EAPOL Frames RX", "dot1xAuthEapolFramesRx"),
                                      ("EAPOL Frames TX", "dot1xAuthEapolFramesTx"),
                                      ("EAPOL Start Frames RX", "dot1xAuthEapolStartFramesRx"),
                                      ("EAPOL Logoff Frames RX", "dot1xAuthEapolLogoffFramesRx"),
                                      ("EAPOL Response ID Frames RX", "dot1xAuthEapolRespIdFramesRx"),
                                      ("EAPOL Response Frames RX", "dot1xAuthEapolRespFramesRx"),
                                      ("EAPOL Request ID Frames TX", "dot1xAuthEapolReqIdFramesTx"),
                                      ("EAPOL Request Frames TX", "dot1xAuthEapolReqFramesTx"),
                                      ("EAPOL Invalid Frames RX", "dot1xAuthInvalidEapolFramesRx"),
                                      ("EAPOL Length Error Frames Rx", "dot1xAuthEapLengthErrorFramesRx"),
                                      ("EAPOL Frame Version", "dot1xAuthLastEapolFrameVersion"),
                                      ("EAPOL Auth Last Frame Source", "dot1xAuthLastEapolFrameSource"),
                                      ("EAPOL Auth Backend Responses", "dot1xAuthBackendResponses"),
                                      ("RADIUS Auth Session ID", "dot1xAuthSessionId")]

    def convert(self, str):
        try:
            rc = int("".join(re.findall("\d*", str)))
        except:
            rc = 0

        return rc

    def do_show_config(self):
        """
        This shows the config files in various forms.
        """

        # if an interface is given, only show information for that interface
        running_config = self.get_config(self.config_file)
        if self.args.get("json"):
            print(json.dumps(running_config, sort_keys=True, indent=4))
        else:
            headers = ["Attribute", "Value"]
            table = []
            # need to show the existing running configs
            # all the radius configs should be the same
            # show running radius configs
            ifaces = running_config.get('interfaces', [])
            if '' in ifaces:
                ifaces.remove('')
            if len(ifaces) > 1:
                ifaces = sorted(ifaces, key=self.convert)
                ifaces = ','.join(ifaces)
            if not ifaces:
                ifaces = None
            table.append(['dot1x radius server-ip',
                          running_config.get('auth_server_addr')])
            table.append(['dot1x radius authentication-port',
                          running_config.get('auth_server_port', 1812)])
            table.append(['dot1x radius accounting-port',
                          running_config.get('acct_server_port', 1813)])
            table.append(['dot1x radius shared-secret',
                          running_config.get('auth_server_shared_secret', '')])
            table.append(['dot1x radius client-source-ip',
                          running_config.get('radius_client_addr', '')])
            table.append(['dot1x enabled interfaces', ifaces])
            print tabulate(tru(table), headers, tablefmt="simple")
        return True

    def three_column_results(self, command=None, attribute='Mac Addresses', mylist=[]):
        printbuf = ''
        if self.args.get('<interface>'):
            # check for valid interface name if given
            rc = self.invalid_interfaces()
            if rc:
                printbuf = '%s\n' % rc
            running_ifname_set = self.get_ifnames(self.args.get('<interface>'))
        else:
            # we are only showing running interface info
            running_ifname_set = self.get_running_ifnames(config_file=self.config_file)
        details = {}
        for ifname in running_ifname_set:
            details[ifname] = {}
            try:
                result = check_output(['/usr/sbin/hostapd_cli', '-i', ifname,
                                       command])
                if not result:
                    details[ifname] = {'No Data' : ''}
                    result = ''
            except:
                details[ifname] = {'802.1x not enabled on interface' : ''}
                result = ''
            for line in result.split('\n'):
                if '=' in line:
                    a,b = line.split('=')
                    if a in mylist:
                        details[ifname][a] = b
                elif line and ':' in line:
                    # MACs are just a line with the mac
                    if details[ifname].get(attribute, None):
                        details[ifname][attribute].append(line)
                    else:
                        details[ifname][attribute] = [line]

        if self.args.get('json'):
            print(json.dumps(details, sort_keys=True, indent=4))
        else:
            headers = ["Interface", "Attribute", "Value"]
            table = []
            ifnames = sorted(running_ifname_set, key=self.convert)
            for ifname in ifnames:
                # first line should have interface name
                mykeys = sorted(details[ifname].keys())
                counter = 1
                for k in mykeys:
                    myvals = details[ifname][k]
                    if isinstance(myvals, list):
                        table.append([ifname, k, myvals[0]])
                        for mac in myvals[1:]:
                            table.append(['', '', mac])
                    else:
                        if counter == 1:
                            table.append([ifname, k, myvals])
                        else:
                            table.append(['', k, myvals])
                    counter += 1
                table.append(['','',''])
            print(printbuf)
            print(tabulate(tru(table), headers, tablefmt="simple"))

    def do_show_macs(self):
        self.three_column_results(command='list_sta', attribute='MAC Addresses')
        return True

    def do_show_port_details(self):
        self.three_column_results(command='all_sta', mylist=self.port_detail_list)
        return True

    def do_show_radius_details(self):
        self.three_column_results(command='mib', mylist=self.radius_detail_list)
        return True

    def parse_allsta(self, output):
        current_mac = ''
        mac_dict = {'macs' : []}
        attr_dict = {}
        for line in output.split('\n'):
            if '=' in line:
                a,b = line.split('=')
                if a == 'mac':
                    current_mac = b
                if current_mac:
                    attr_dict.setdefault(current_mac, {})
                    attr_dict[current_mac][a] = b

        for i in attr_dict.keys():
            mac_dict['macs'].append({i : attr_dict[i]})
        return mac_dict

    def in_flag(self, flag='', key='', print_val=False):
        if key in flag:
            if print_val:
                return key
            else:
                return 'YES'
        else:
            return 'NO'

    def show_interface_details(self, ifname_dict):
        headers = ["Interface", "MAC Address", "Attribute", "Value"]
        table = []
        for iface_array in ifname_dict['interfaces']:
            # each interface array in the list
            for ifname in iface_array.keys():
                #print(ifname)
                mac_list = iface_array[ifname]['macs']
                mac_list.sort()
                for mac_array in mac_list:
                    for mac in mac_array.keys():
                        indent = '    '
                        #print('%sSupplicant: %s' % (indent, mac))
                        counter = 0
                        indent = '        '
                        for (name, key) in self.interface_detail_list:
                            counter += 1
                            if counter > 1:
                                printmac = ''
                                printifname = ''
                            else:
                                printmac = mac
                                printifname = ifname
                            val = mac_array[mac].get(key, '')
                            #print('%s%s: %s' % (indent, name, val))
                            table.append([printifname, printmac, name, mac_array[mac].get(key, '')])

        print(tabulate(tru(table), headers, tablefmt="simple"))
        return

    def do_show_interface(self):
        running_array = self.get_config(self.config_file)
        ifnames = self.get_ifnames(self.args.get('<interface>'))
        config_ifnames = running_array.get('interfaces', [])
        printbuf = ''
        if self.args.get('summary'):
            ifnames = config_ifnames
        elif ifnames:
            # we have some subset of names so we check them and take the
            # intersection
            if (set(ifnames) - set(config_ifnames)):
                printbuf = 'WARNING: Some interfaces are not configured for dot1x: %s\n' % \
                        ', '.join(set(ifnames) - set(config_ifnames))
                ifnames = list(set(ifnames) & set(config_ifnames))
            rc = self.invalid_interfaces()
            if rc:
                printbuf = '%s%s\n' % (printbuf, rc)
        else:
            # we do not have ifnames or summary, nothing to show
            printbuf = '%s%s\n' % (printbuf, 'INFO: Missing interface names')

        ifname_dict = {'interfaces' : [] }
        for ifname in ifnames:
            try:
                result = check_output(['/usr/sbin/hostapd_cli', '-i', ifname,
                                       'all_sta'])
            except:
                result = ''
            ifname_dict['interfaces'].append({ifname : self.parse_allsta(result)})

        jsonoutput = {}
        headers = ["Interface", "MAC Address", "Username", "State",
                   "Authentication Type", "MAB", "VLAN"]
        table = []
        for iface_array in ifname_dict['interfaces']:
            # each interface array in the list
            for ifname in iface_array.keys():
                jsonoutput.setdefault(ifname, {})
                mac_list = iface_array[ifname]['macs']
                mac_list.sort()
                counter = 0
                for mac_array in mac_list:
                    counter += 1
                    if len(mac_list) > 1 and counter > 1:
                        printifname = ''
                    else:
                        printifname = ifname
                    for mac in mac_array.keys():
                        jsonoutput[ifname].setdefault(mac, {})
                        flags = mac_array[mac].get('flags', '')
                        if 'PARKED_VLAN' in flags:
                            state = 'PARKING VLAN'
                        elif 'AUTHORIZED' in flags:
                            state = 'AUTHORIZED'
                        else:
                            state = 'NOT AUTHORIZED'

                        jsonoutput[ifname][mac] = {'ifname' : ifname,
                                                   'mac' : mac,
                                                   'username' :
                                                   mac_array[mac].get('dot1xAuthSessionUserName', ''),
                                                   'state' : state,
                                                   'auth_type' : mac_array[mac].get('auth_srv_eap_type', ''),
                                                   'flags' : flags,
                                                   'vlan' :
                                                   mac_array[mac].get('vlan_id', '')}
                        table.append([printifname, mac,
                                      mac_array[mac].get('dot1xAuthSessionUserName', ''),
                                      state,
                                      mac_array[mac].get('auth_srv_eap_type', ''),
                                      self.in_flag(flags, 'MAB'),
                                      mac_array[mac].get('vlan_id', '')])

        if self.args.get('details'):
            jsonoutput = ifname_dict

        if self.args.get('json'):
            print(json.dumps(jsonoutput, sort_keys=True, indent=4))
            return True

        print(printbuf)
        if self.args.get('details'):
            self.show_interface_details(ifname_dict)
        else:
            print(tabulate(tru(table), headers, tablefmt="simple"))

        return True

    def do_show_status(self):
        enabled = 'failed'
        active = 'failed'

        try:
            myshow = check_output(['/bin/systemctl', 'show', 'hostapd'])
        except CalledProcessError as ex:
            myshow = ex.output

        myshow = myshow.split('\n')
        output = {l.split('=')[0] : l.split('=')[1] for l in myshow if l}

        running_array = self.get_config(self.config_file)
        output['ifnames'] = running_array.get('interfaces', [])
        output['mab_ifnames'] = running_array.get('mab_interfaces', [])
        output['pvlan_ifnames'] = running_array.get('parking_vlan_interfaces', [])
        output['dynamic_vlan'] = self.config_array['dynamic_vlan']\
                ['status'].get(running_array.get('dynamic_vlan', 0), 'Disabled')
        #try:
        #    enabled = check_output(['/bin/systemctl', 'is-enabled', 'hostapd'])
        #except:
        #    # when disabled, the command returns 1 so we have to catch it
        #    enabled = 'disabled'
        #try:
        #    active = check_output(['/bin/systemctl', 'is-active', 'hostapd'])
        #except:
        #    # in a failed state, systemctl returns non-zero, which is ok
        #    active = 'inactive'

        #output['reload_status'] = enabled.strip()
        #output['active_status'] = active.strip()
        try:
            if output.get('ActiveState') == 'failed':
                pid = '_PID=%s' % output.get('ExecMainPID')
                myerrors = check_output(['/bin/journalctl', pid]).split('\n')
            else:
                myerrors = []
        except CalledProcessError as ex:
            myerrors = []

        headers = ["Attribute", "Value"]
        table = []
        table.append(['Current Status', '%s (%s)' % (output.get('ActiveState', None),
                                                     output.get('SubState', None))])
        table.append(['Reload Status', output.get('UnitFileState')])
        table.append(['Interfaces', ' '.join(output.get('ifnames', []))])
        table.append(['MAB Interfaces', ' '.join(output.get('mab_ifnames', []))])
        table.append(['Parking VLAN Interfaces', ' '.join(output.get('pvlan_ifnames', []))])
        table.append(['Dynamic VLAN Status', output.get('dynamic_vlan')])
        for i in range(len(myerrors)):
            if i == 0:
                table.append(['Last Logs (with Errors)', myerrors[i]])
            else:
                table.append(['', myerrors[i]])

        if self.args.get('json'):
            jsonoutput = {}
            jsonoutput['Interfaces'] = running_array.get('interfaces', [])
            jsonoutput['MAB Interfaces'] = running_array.get('mab_interfaces', [])
            jsonoutput['Parking VLAN Interfaces'] = running_array.get('parking_vlan_interfaces', [])
            jsonoutput['Dynamic VLAN'] = self.config_array['dynamic_vlan']\
                    ['status'].get(running_array.get('dynamic_vlan', 0), 'Disabled')
            jsonoutput['Description'] = output.get('Description')
            jsonoutput['Current Status'] = '%s (%s)' % (output.get('ActiveState', None),
                                                        output.get('SubState', None))
            jsonoutput['Reload Status'] = output.get('UnitFileState')
            print(json.dumps(jsonoutput, sort_keys=True, indent=4))
            return True

        print('')
        print(output.get('Description'))
        print(tabulate(tru(table), headers, tablefmt="simple"))
        return True

    def invalid_interfaces(self):
        for iface in self.get_ifnames(self.args.get('<interface>')):
            if re.match(r"""^swp\d+(?:s\d+)?$""", iface) is None:
                # has to be a physical port
                return "Interface {0} is not a physical switchport.".format(iface)

            if os.path.exists('/sys/class/net/%s/bonding_slave' % iface):
                # cannot be a bond slave
                return "Interface {1} cannot be a bond member.".format(iface)

        return None

    def handle_traditional_bridge(self, is_add=True, ifname=None):
        """
        For dot1x interfaces that are in a traditional bridge,
        we remove the interface from the bridge config in /e/n/i
        and move it to a separate file in /e/n/i.d so that files
        can be later added and removed from this directory by
        hostapd.
        """
        config_wrapper = ifupdown2.ConfigWrapper(True, True)
        config_wrapper.get_ifquery_all()
        trad_bridge = None
        if config_wrapper.get_pending_master(ifname) and not config_wrapper.is_pending_bridge_vlan_aware(config_wrapper.get_pending_master(ifname)):
            trad_bridge = ifupdown2.EtcNetworkInterface(config_wrapper.get_pending_master(ifname), config_wrapper.ifquery_all)

        elif get_master(ifname) and not config_wrapper.is_running_bridge_vlan_aware(get_master(ifname)):
            trad_bridge = ifupdown2.EtcNetworkInterface(get_master(ifname), config_wrapper.ifquery_all)

        if trad_bridge is not None:
            # make corrections to configs if ifname is dot1x interface
            all_current_ports = trad_bridge.get_keyword_value_list("bridge-ports")
            current_ports = []
            for line in all_current_ports:
                for port in line.split(' '):
                    current_ports.append(port)
            if current_ports:
                # current ports will include previously removed dot1x ports so
                # we need to remove these again for this bridge.  Otherwise, we
                # will have /e/n/i containing dot1x ports as bridge ports.  We
                # do not want that since we have to split off the configs for
                # traditional bridge dot1x ports.  This is so we can make port
                # moves cleanly without touching /e/n/i.
                # grab what is actually running
                running_array = self.get_config(self.config_file)
                # this should be a list
                current_dot1x_ifaces = running_array.get("interfaces", [])
                for port in current_ports:
                    if port in current_dot1x_ifaces:
                        # before adding and removing new port, make sure to
                        # strip any running configs dot1x ports
                        trad_bridge.conf_bridge_ports(False, port)
                        trad_bridge.write_file()
                if is_add:
                    # if we are adding dot1x, we remove the port from the
                    # bridge and create a separate config for it
                    if ifname in current_ports:
                        # remove the port from the trad bridge
                        trad_bridge.conf_bridge_ports(False, ifname)
                        self.original_trad_bridge_dict[ifname] = trad_bridge.name
                        trad_bridge.write_file()
                        # create a new config file which will be placed in
                        # /etc/network/interfaces.d/dot1x_bridgename_interfacename.intf
                        dot1x_bridge_filename = "trad_bridge_dot1x_{0}_{1}.intf".format(trad_bridge.name, ifname)
                        dot1x_bridge = ifupdown2.EtcNetworkInterface(dot1x_bridge_filename, config_wrapper.ifquery_all)
                        # the file name is not the same as bridge name
                        dot1x_bridge.name = trad_bridge.name
                        dot1x_bridge.add_interface()
                        dot1x_bridge.conf_bridge_ports(True, ifname)
                        dot1x_bridge.write_file()
                else:
                    # if we are del dot1x, we add the port to the
                    # bridge and create a separate config for it
                    if ifname in current_ports:
                        # add the port back to the original trad bridge
                        if self.original_trad_bridge_dict.get(ifname):
                            orig_bridge_name = self.original_trad_bridge_dict.get(ifname)
                            orig_bridge = ifupdown2.EtcNetworkInterface(orig_bridge_name, config_wrapper.ifquery_all)
                            # make sure to remove it from the current # bridge
                            trad_bridge.conf_bridge_ports(False, ifname)
                            trad_bridge.write_file()
                            if orig_bridge:
                                orig_bridge.conf_bridge_ports(True, ifname)
                                orig_bridge.write_file()
                            # remove the config file which is located at
                            # /etc/network/interfaces.d/dot1x_bridgename_interfacename.intf
                            dot1x_bridge_filename = "{0}/trad_bridge_dot1x_{1}_{2}.intf".format(ifupdown2.ETC_NETWORK_INTERFACES_D,
                                                                       trad_bridge.name, ifname)
                            if os.path.isfile(dot1x_bridge_filename):
                                os.remove(dot1x_bridge_filename)


    def handle_interfaces(self, running_array={}):
        # handle net add/del interface <foo> (dot1x|mab) separately
        dot1xattr = self.args.get('dot1x')
        mabattr = self.args.get('mab')
        pvlanattr = self.args.get('parking-vlan')
        add_del = self.args.get('add') or self.args.get('del')
        running_array.setdefault('interfaces', [])
        running_array.setdefault('mab_interfaces', [])
        running_array.setdefault('parking_vlan_interfaces', [])
        for iface in self.get_ifnames(self.args.get('<interface>')):
            if add_del == 'add':
                if dot1xattr:
                    # this is always there, otherwise we would not be here
                    if iface not in running_array['interfaces']:
                        running_array['interfaces'].append(iface)
                    self.handle_traditional_bridge(is_add=True, ifname=iface)

                if mabattr:
                    if iface not in running_array['mab_interfaces']:
                        running_array['mab_interfaces'].append(iface)
                if pvlanattr:
                    if iface not in running_array['parking_vlan_interfaces']:
                        running_array['parking_vlan_interfaces'].append(iface)
            if add_del == 'del':
                if (dot1xattr and not mabattr and not pvlanattr):
                    if iface in running_array['interfaces']:
                        running_array['interfaces'].remove(iface)
                    if iface in running_array['mab_interfaces']:
                        running_array['mab_interfaces'].remove(iface)
                    if iface in running_array['parking_vlan_interfaces']:
                        running_array['parking_vlan_interfaces'].remove(iface)
                    self.handle_traditional_bridge(is_add=False, ifname=iface)
                if mabattr:
                    if iface in running_array['mab_interfaces']:
                        running_array['mab_interfaces'].remove(iface)
                if pvlanattr:
                    if iface in running_array['parking_vlan_interfaces']:
                        running_array['parking_vlan_interfaces'].remove(iface)
        running_array['interfaces'] = sorted(running_array['interfaces'],
                                             key=self.convert)
        running_array['mab_interfaces'] = sorted(running_array['mab_interfaces'],
                                                 key=self.convert)
        running_array['parking_vlan_interfaces'] = sorted(running_array['parking_vlan_interfaces'],
                                                          key=self.convert)
        return running_array


    def is_ifname_dot1x_enabled(self, ifname):
        """
        is_ifname_dot1x_enabled will check a pending config
        or the running config for the existinance of the ifname
        as configured for dot1x.
        """
        if os.path.isfile(self.scratch_config_file):
            running_array = self.get_config(self.scratch_config_file)
        elif os.path.isfile(self.config_file):
            running_array = self.get_config(self.config_file)
        else:
            return False

        return ifname in running_array.get("interfaces", [])


    def do_config(self):
        """
        Save configs in a list to keep track of commands entered.
        Later on (show_pending or commit_pending) we will modify the
        current config by replaying this config file.
        """

        if os.path.isfile(self.scratch_config_file):
            running_array = self.get_config(self.scratch_config_file)
        else:
            # we always make a copy of the config if it does not exist
            if not os.path.isdir(self.dot1x_scratchpad):
                os.makedirs(self.dot1x_scratchpad)
            shutil.copyfile(self.config_file, self.scratch_config_file)
            os.chmod(self.scratch_config_file, 0o600)
            running_array = self.get_config(self.scratch_config_file)

        if self.args.get('interface'):
            rc = self.invalid_interfaces()
            if not rc:
                # handle the interface command
                running_array = self.handle_interfaces(running_array)
            else:
                print rc
                return False
        else:
            # handle all the other dot1x commands
            for k in self.config_array.keys():
                # we are looping over actual hostapd.conf config keywords
                # the actual arg value if they did not use default keyword
                if isinstance(self.config_array[k]['arg'], list):
                    # grab the value of the list index
                    for arg in self.config_array[k]['arg']:
                        if self.args.get(arg):
                            argval = self.config_array[k]['argval'][arg]
                            break
                else:
                    # retrieve the value from self.args
                    argval = self.args.get(self.config_array[k]['arg'])
                # the word default was used in the net command
                defaultcli = self.args.get('default')
                # the keyword has a default
                defaultval = self.config_array[k]['default']
                # a particular nclu keyword was used like server-ip
                cliname = self.args.get(self.config_array[k]['cli_name'])
                add_del = self.args.get('add') or self.args.get('del')
                if (defaultcli or str(argval)) and cliname:
                    # we have a value we need to deal with
                    if add_del == 'del':
                        if cliname == 'server-ip' and \
                           argval in running_array[k]:
                            # this is special in that both auth_server_addr and
                            # acct_server_addr should be added/deleted to the list
                            running_array[k].remove(argval)
                        else:
                            running_array[k] = None or defaultval
                    elif add_del == 'add':
                        if defaultcli:
                            running_array[k] = defaultval
                        elif cliname == 'server-ip':
                            # we can have up to 3 radius servers
                            # add to both auth and acct server_addr
                            if len(running_array[k]) < 3:
                                running_array[k].append(argval)
                            else:
                                print("No more then three RADIUS Servers allowed.")
                                return False

                        else:
                            running_array[k] = argval
        oldscratch = self.get_config(self.scratch_config_file)
        changed = False
        for i in running_array.keys():
            if running_array.get(i, None) != oldscratch.get(i, None):
                changed = True
        if changed:
            self.save_scratch_config(running_array)
        else:
            print("\'%s\' is already configured or does not change the config" % \
                  ' '.join(self.argv_expanded))
            return False
        return True

    def get_ifnames(self, ifstr):
        # We are either adding or deleting interfaces.
        if not ifstr:
            return
        try:
            ifnames = ifname_expand_glob(str(ifstr))
        except ValueError as e:
            print "\"{0}\" is not a valid interface name or glob.".format(ifstr)
            log.error(str(e))
            return False

        for interface in ifnames:
            if not ifname_is_valid(interface):
                print "\"{0}\" is not a valid interface name.".format(interface)
                return False

        return ifnames

    def del_all(self, cli):
        """
        Wipe the config clean in the scratch area.  Don't stop the hostapd daemon.
        """

        if not os.path.isdir("/run/nclu/dot1x"):
            # Create the directory that will hold scratchpad files.
            os.makedirs("/run/nclu/dot1x")

        self.save_scratch_config({})
        return True

    def abort_pending(self):
        # Delete the scratch pad files.
        for filename in glob.glob(os.path.join(self.run_nclu, '*')):
            os.remove(filename)
        return

    def commit_pending(self, verbose):
        """
        Persistent changes, and return a 3-tuple of (bool, str, [str]).  The boolean indicates
        if the commit succeeded.  The string includes information, including errors, for the user.
        The list contains the names of the files modified.

        First check for various missing or incorrect information.  After copying files, restart
        the hostapd daemon, if necessary.
        """
        the_diff = make_pending_diff(self.config_file, self.scratch_config_file, self.color_diffs)
        if not the_diff:
            # There are no changes to commit.  Delete the scratch pad files.
            for filename in glob.glob(os.path.join(self.run_nclu, '*')):
                os.remove(filename)
            return (True, '', [])

        newconfig = self.get_config(self.scratch_config_file)
        oldconfig = self.get_config(self.config_file)
        command = "reload"

        # If any of these attributes changed, hostapd should be restarted.
        for attr in ["auth_server_addr", "acct_server_addr",
                     "auth_server_port", "auth_server_shared_secret",
                     "radius_client_addr", "acct_server_port", "acct_server_shared_secret",
                     "dynamic_vlan", "eap_reauth_period", "mab_activation_delay", "parking_vlan_id"]:
            if newconfig.get(attr, '') != oldconfig.get(attr, ''):
                command = 'restart'

        if len(oldconfig.get("interfaces", '')) == 0 and len(newconfig.get("interfaces", '')) > 0:
            # There were no interfaces; now there are interfaces.  hostapd should be restarted.
            command = "restart"

        if len(oldconfig.get("interfaces", '')) > 0 and len(newconfig.get("interfaces", '')) == 0:
            # There were interfaces; now there are none.  hostapd should be stopped.
            command = "stop"

        if not os.path.isfile(self.config_file):
            # Create an empty configuration file.
            # TODO - When this wrapper is converted to a plug-in, do not create empty configuration files.
            open(self.config_file, 'w').close()

        # Copy the configurations to the right places.
        shutil.copyfile(self.config_file, self.temp_config_file)
        shutil.copyfile(self.scratch_config_file, self.config_file)
        os.chmod(self.config_file, 0o600)
        modified = [self.config_file]

        commit_ok = True
        hostapd_installed = True
        message = ''

        try:
            try:
                check_output(["/bin/systemctl", "is-enabled", "hostapd"], stderr=STDOUT)
            except CalledProcessError as e:
                if "No such file or directory" in e.output:
                    # TODO - We need a better approach to handling this.  Should commits for an uninstalled
                    # component really return commit_ok=True?  If the service is installed but won't start,
                    # we return commit_ok=False.
                    log.warning("hostapd.service is not installed.  Changes for dot1x will not take effect.")
                    message += "hostapd.service is not installed.  Changes for dot1x will not take effect."
                    hostapd_installed = False
                else:
                    # hostapd is not enabled.  Enable it.
                    check_output(["/bin/systemctl", "enable", "hostapd"])

            if hostapd_installed:
                try:
                    check_output(["/bin/systemctl", "is-active", "hostapd"])

                    # hostapd is running.
                    check_output(["/bin/systemctl", command, "hostapd"])
                except:
                    # hostapd is not running.
                    if command != "stop":
                        check_output(["/bin/systemctl", "restart", "hostapd"])
        except CalledProcessError as e:
            commit_ok = False
            message += "The attept to {0} hostapd failed: {1}".format(command, e)

        if commit_ok:
            # Remove the rest of the files.
            for filename in glob.glob(self.dot1x_scratchpad + '*'):
                os.remove(filename)
        elif os.path.isfile(self.temp_config_file):
                shutil.copyfile(self.temp_config_file, self.config_file)
                modified = []

        # Restart the hostapd daemon with the new interface configurations.
        return (commit_ok, message, modified)

    def get_running_ifnames(self, config_file=None, ifaces=set([])):
        # check for a running default file
        if os.path.exists(config_file):
            fd = open(config_file, 'r')
            default_lines = fd.read().strip().split('\n')
            default_lines = [l for l in default_lines
                             if l.startswith('interfaces=')]
            temp_str = default_lines[0].split('=')[1]
            if temp_str:
                temp_set = set(temp_str.strip().split(','))
                ifaces = ifaces | temp_set
            fd.close()
        return ifaces

    def get_config(self, config_file=None):
        # check for a running config in an interface config.
        config_array = {}
        config_array['auth_server_addr'] = []
        config_array['acct_server_addr'] = []
        if os.path.exists(config_file):
            config_fd = open(config_file, 'r')
            config_list = config_fd.read().strip().split('\n')
            config_list = [l for l in config_list \
                           if not l.startswith('#') and '=' in l]
            for l in config_list:
                if l.find('=') > -1:
                    i = l[:l.find('=')]
                    j = l[l.find('=') + 1:]
                    if i == 'interfaces' or i == 'mab_interfaces' or \
                        i == 'parking_vlan_interfaces':
                        # interfaces are special, they are saved as a list
                        if j == '':
                            config_array[i.strip()] = []
                        else:
                            config_array[i.strip()] = j.strip().split(',')
                    elif i == 'auth_server_addr' or i == 'acct_server_addr':
                        # we can have up to 3 radius servers
                        if j:
                            config_array[i.strip()].append(j.strip())
                    else:
                        config_array[i.strip()] = j.strip()
                else:
                    print("Invalid configuration file, {0}.".format(config_file))
            config_fd.close()
        return config_array

    def get_pending_config(self):
        pending_config = {}
        try:
            with open(self.pending_config_file) as infile:
                pending_config = json.load(infile)
        except:
            pass
        return pending_config

    def write_server_attrs(self, config_fd=None, server=None, config_array=None):
        if 'auth' in server:
            portname = 'auth_server_port'
            secretname = 'auth_server_shared_secret'
        elif 'acct' in server:
            portname = 'acct_server_port'
            secretname = 'acct_server_shared_secret'

        port = config_array.get(portname) or self.config_defaults[portname]
        secret = config_array.get(secretname) or self.config_defaults[secretname]
        if port:
            config_fd.write('%s=%s\n' % (portname, port))
        else:
            config_fd.write('%s=\n' % (portname))
        if secret:
            config_fd.write('%s=%s\n' % (secretname, secret))
        else:
            config_fd.write('%s=\n' % (secretname))
        return

    def save_scratch_config(self, config_array):
        # just overwrite it
        # enforce some parameters and reset them in the hostapd.conf file
        config_fd = open(self.scratch_config_file, 'w')
        os.chmod(self.scratch_config_file, 0o600)
        # when we save the config, we save the radius ports and secrets with the server.
        attrs = [l for l in self.config_attrs if l not in ['auth_server_port',
                                                           'auth_server_shared_secret',
                                                           'acct_server_port',
                                                           'acct_server_shared_secret']]
        for l in attrs:
            # if there is nothing there and if we do not show a default, skip it
            if config_array.get(l) is None and self.config_array.get(l) and \
               self.config_array[l].get("show_default", True) is False:
                continue
            # if the config is specified, use it
            val = config_array.get(l) or self.config_defaults[l]
            if val and ('interfaces' in l):
                # interfaces are special in that a blank interfaces line
                # will generate a '' at the beginning when split.  Remove this
                if '' in val:
                    val.remove('')
                val = ','.join(val)
            # We can have up to 3 radius servers, handle them here
            if val and ('server_addr' in l):
                # the value should be a list of ip addresses
                # need to write the ports and shared secrets
                # the same time because order matters in hostapd.conf
                for ip in val:
                    # write the auth_server_addr or acct_server_addr
                    config_fd.write('%s=%s\n' % (l, ip))
                    self.write_server_attrs(config_fd=config_fd, server=l, config_array=config_array)
            elif 'server_addr' in l:
                # we have no servers configured, so we need to write out blanks
                config_fd.write('%s=\n' % (l))
                self.write_server_attrs(config_fd=config_fd, server=l, config_array=config_array)

            elif val:
                config_fd.write('%s=%s\n' % (l, val))
            else:
                config_fd.write('%s=\n' % (l))
        config_fd.close()
        return

    def get_pending(self):
        """
        Return the pending diff as a string.  If there are no changes, return the empty string.
        """

        the_diff = make_pending_diff(self.config_file, self.scratch_config_file, self.color_diffs)
        if not the_diff:
            return ''

        newconfig = self.get_config(self.scratch_config_file)
        oldconfig = self.get_config(self.config_file)
        server_addr = newconfig.get("auth_server_addr")
        secret = newconfig.get("auth_server_shared_secret")
        ifnames = newconfig.get("interfaces")
        pvlan_ifnames = newconfig.get("parking_vlan_interfaces")
        pvlan_id = newconfig.get("parking_vlan_id")

        if ifnames and not server_addr:
            raise RuntimeError("Missing dot1x RADIUS server-ip address.")

        if server_addr and not secret:
            raise RuntimeError("Missing dot1x RADIUS shared-secret.")

        if pvlan_ifnames and not pvlan_id:
            raise RuntimeError("Parking VLAN Interfaces enabled without Parking VLAN ID.")

        warn_user = False

        # If any of these attributes changed, warn the user.
        for attr in ["auth_server_addr", "acct_server_addr",
                     "auth_server_port", "auth_server_shared_secret",
                     "radius_client_addr", "acct_server_port", "acct_server_shared_secret",
                     "dynamic_vlan", "eap_reauth_period", "mab_activation_delay", "parking_vlan_id"]:
            if newconfig.get(attr, '') != oldconfig.get(attr, ''):
                warn_user = True

        if len(oldconfig.get("interfaces", '')) == 0 and len(newconfig.get("interfaces", '')) > 0:
            # There were no interfaces; now there are interfaces.  Warn the user.
            warn_user = True

        if warn_user:
            the_diff += "\nWARNING: Committing changes will require restarting the hostapd daemon, which will deauthorize all stations."

        return the_diff

    def show_config_files(self, user_may_edit):
        # TODO - This method doesn't need user_may_edit.

        reply = ''

        if os.path.exists(self.config_file):
            reply += self.config_file + '\n'
            reply += "=======================\n"

            if user_may_edit:
                # The user has edit privileges.  Do not bother hiding passwords.
                # TODO - This code should never get executed if the user doesn't have permission.
                with open(self.config_file) as f:
                    reply += f.read()
            else:
                output = []
                with open(self.config_file) as f:
                    for line in f:
                        line = re.sub(r"""_shared_secret=(\S+)""", "_shared_secret=PASSWORD REMOVED", line)
                        output.append(line)
                reply += ''.join(output)

        return reply + '\n'

    def get_managed_files(self):
        files = []
        files.append(self.config_file)
        return files

    def show_config_commands(self, user_may_edit, ifupdown2_wrapper):
        supported = []
        unsupported = []
        running_array = self.get_config(self.config_file)
        # now show the supported commands
        for k in self.cli_array.keys():
            valkey = self.cli_array[k]['config_list'][0]
            if running_array.get(valkey, '') and \
               k != 'dot1x' and k != 'mab' and k != 'parking-vlan':
                val = running_array.get(valkey, '')
                if not user_may_edit and k == 'shared-secret':
                    supported.append('net add dot1x radius %s PASSWORD_REMOVED' % k)
                else:
                    if k == 'mab-activation-delay' or k == 'eap-reauth-period' or \
                       k == 'parking-vlan-id' or k == 'dynamic-vlan':
                        if k == 'dynamic-vlan':
                            # need to convert 0,1,2 to show nothing, just
                            # dynamic-vlan or require
                            dvlan = self.config_array['dynamic_vlan']['conf2nclu']
                            val = dvlan.get(val, '')
                            if val:
                                supported.append('net add dot1x %s %s' % (k, val))
                        else:
                            supported.append('net add dot1x %s %s' % (k, val))
                    elif k == 'server-ip':
                        # radius servers is a list
                        for ip in val:
                            supported.append('net add dot1x radius %s %s' % (k, ip))
                    else:
                        supported.append('net add dot1x radius %s %s' % (k, val))
        # interfaces is always a list
        for iface in running_array.get('interfaces', []):
            if iface in running_array.get('mab_interfaces', []) and \
               iface in running_array.get('parking_vlan_interfaces', []):
                supported.append('net add interface %s dot1x mab parking-vlan' % iface)
            elif iface in running_array.get('mab_interfaces', []):
                supported.append('net add interface %s dot1x mab' % iface)
            elif iface in running_array.get('parking_vlan_interfaces', []):
                supported.append('net add interface %s dot1x parking-vlan' % iface)
            elif iface in running_array.get('interfaces', []):
                supported.append('net add interface %s dot1x' % iface)
        return (supported, unsupported)

    def show_config_summary(self, user_may_edit, summary):
        running_array = self.get_config(self.config_file)
        for i in running_array.get('interfaces', []):
            k = 'INTERFACE:%s' % i
            summary.setdefault(k, OrderedDict())
            summary[k].setdefault('COMMAND_LIST', [])
            if i in running_array.get('mab_interfaces', []):
                summary[k]['COMMAND_LIST'].append('mab-enabled')
            if i in running_array.get('parking_vlan_interfaces', []):
                summary[k]['COMMAND_LIST'].append('parking-vlan-enabled')
            if i in running_array.get('interfaces', []):
                summary[k]['COMMAND_LIST'].append('dot1x-enabled')
        summary['dot1x'] = OrderedDict()
        if running_array.get('mab_activation_delay', ''):
            summary['dot1x']['mab-activation-delay %s' % \
                             running_array.get('mab_activation_delay', '')] = []
        if running_array.get('eap_reauth_period', ''):
            summary['dot1x']['eap-reauth-period %s' % \
                             running_array.get('eap_reauth_period', '')] = []
        if running_array.get('parking_vlan_id', ''):
            summary['dot1x']['parking-vlan-id %s' % \
                             running_array.get('parking_vlan_id', '')] = []
        if running_array.get('dynamic_vlan', ''):
            dvlan = self.config_array['dynamic_vlan']['conf2nclu']
            val = dvlan.get(running_array.get('dynamic_vlan', '0'), None)
            if val:
                summary['dot1x']['dynamic-vlan %s' % val] = []
        summary['dot1x']['radius'] = []
        for k in self.cli_array.keys():
            valkey = self.cli_array[k]['config_list'][0]
            # dot1x interfaces will be added to each interface
            if running_array.get(valkey, '') and \
               k != 'dot1x' and k != 'mab' and k != 'mab-activation-delay' and \
               k != 'eap-reauth-period' and k != 'parking-vlan-id' and \
               k != 'dynamic-vlan':
                val = running_array[valkey]
                if not user_may_edit and k == 'shared-secret':
                    summary['dot1x']['radius'].append('%s PASSWORD_REMOVED' % k)
                elif k == 'server-ip':
                    # radius server-ip is a list
                    for ip in val:
                        summary['dot1x']['radius'].append('%s %s' % (k, ip))
                else:
                    summary['dot1x']['radius'].append('%s %s' % (k, val))
        # interfaces key is special in that dot1x-enabled is shown with interfaces
        # even though they are not in the /etc/network/interfaces file
        return

    def get_managed_files(self):
        files = []
        return files

    def eval_command_line_args(self, cli):
        """
        NetworkDocopt will populate the self.args dictionary based on the command
        line args entered by the user.
        For an add, this method needs to create an interface config file hostapd and stage it
        in /run/nclu/dot1x.
        """
        #print('dot1x: eval_command_line_args')
        self.args = cli.args
        self.argv_expanded = cli.argv_expanded
        rc = True
        if self.args.get('show') and self.args.get('macs'):
            rc = self.do_show_macs()
        elif self.args.get('show') and self.args.get('port-details'):
            rc = self.do_show_port_details()
        elif self.args.get('show') and self.args.get('radius-details'):
            rc = self.do_show_radius_details()
        elif self.args.get('show') and self.args.get('interface'):
            rc = self.do_show_interface()
        elif self.args.get('show'):
            rc = self.do_show_status()
        elif self.args.get('del') and self.args.get('all'):
            rc = self.del_all(cli)
        else:
            rc = self.do_config()
        return rc

# This is for testing only
if __name__ == '__main__':
    c = ConfigWrapper('foo', True)
    print c
