"""
Copyright (C) 2016, 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from ipaddr import IPNetwork
from nclu import ifname_expand_glob
from nclu.plugins.frr.core import (
    frr_reload_exception_to_string,
    get_daemons,
    ETC_FRR_CONF,
    ETC_FRR_CONF_BASELINE,
    ETC_FRR_CONF_SCRATCHPAD,
    ETC_FRR_DAEMONS_SCRATCHPAD,
    SERVICE_NAME,
    USR_LIB_FRR_PIMD,
)
from network_docopt.node import Node, Word
import doctest
import logging
import os
import re
import sys


# use __import__ for files with a hyphen in the name
sys.path.append("/usr/lib/frr/")
frr_reload = __import__("frr-reload")

log = logging.getLogger('netd')


bgp_bgp = (
    "always-compare-med",
    "bestpath",
    "client-to-client reflection",
    "cluster-id",
    "confederation peers",
    "default ipv4-unicast",
    "default local-preference",
    "default show-hostname",
    "default subgroup-pkt-queue-max",
    "deterministic-med",
    "disable-ebgp-connected-route-check",
    "enforce-first-as",
    "fast-external-failover",
    "graceful-restart",
    "graceful-shutdown",
    "listen",
    "log-neighbor-changes",
    "max-med",
    "network import-check",
    "route-map delay-timer",
    "route-reflector allow-outbound-policy",
    "router-id"
)
ospf_ospf = ("router-id",)
ospf6_ospf6 = ("router-id",)


def sanity_check_ip_host_vs_subnet(args, cli):
    """
    Certain commands like "ip route" will convert a host IP to the subnet.
    Look for this so we can give the user a heads up that this is happening.
    """
    ipv4_str = args.get('<ipv4/prefixlen>')
    output = ""

    if ipv4_str:
        ipv4 = IPNetwork(ipv4_str)
        subnet = "%s/%s" % (ipv4.network, ipv4.prefixlen)

        if ipv4_str != subnet:
            args['<ipv4/prefixlen>'] = subnet
            output = "NOTE: This command expects a subnet not a host IP so %s was converted to %s" % (ipv4_str, subnet)

            for (index, node) in enumerate(cli.match):
                if '<ipv4/prefixlen>' in str(node):
                    node.value.value = subnet
                    node.value.value_raw = subnet

    ipv6_str = args.get('<ipv6/prefixlen>')

    if ipv6_str:
        ipv6 = IPNetwork(ipv6_str)
        subnet = "%s/%s" % (ipv6.network, ipv6.prefixlen)

        if ipv6_str != subnet:
            args['<ipv6/prefixlen>'] = subnet
            output = "NOTE: This command expects a subnet not a host IP so %s was converted to %s" % (ipv6_str, subnet)

            for (index, node) in enumerate(cli.match):
                if '<ipv6/prefixlen>' in str(node):
                    node.value.value = subnet
                    node.value.value_raw = subnet

    return output


def look_for_line(target_context, target_subcontext, target_line, exact_match):
    """
    Look for the target_line in ETC_FRR_CONF_BASELINE and ETC_FRR_CONF_SCRATCHPAD.
    If we find the line, return it.  Otherwise, return None.
    """

    lines = []

    for filename in (ETC_FRR_CONF_BASELINE, ETC_FRR_CONF_SCRATCHPAD):
        if os.path.isfile(filename):
            try:
                frr_conf = frr_reload.Config()
                frr_conf.load_from_file(filename)
            except frr_reload.VtyshMarkException as e:
                msg = frr_reload_exception_to_string(filename, e)
                log.error(msg)
                continue

            for context in frr_conf.contexts.itervalues():

                if len(context.keys) == 1:
                    key = context.keys[0]
                    subkey = None

                elif len(context.keys) >= 2:
                    key = context.keys[0]
                    subkey = context.keys[1]

                else:
                    key = None
                    subkey = None

                if key == target_context and subkey == target_subcontext:
                    for line in context.lines:
                        if exact_match:
                            if line == target_line:
                                lines.append(line)
                        else:
                            if line.startswith(target_line):
                                lines.append(line)
                    break
    return lines


def get_bgp_asn(vrf):
    asn = None

    if vrf:
        vrf = "vrf %s" % vrf

    if os.path.exists(ETC_FRR_CONF_SCRATCHPAD):
        with open(ETC_FRR_CONF_SCRATCHPAD, 'r') as fh:
            for line in fh.readlines():
                if line.startswith('router bgp'):
                    line = line.strip()
                    if (vrf and line.endswith(vrf)) or (not vrf and 'vrf' not in line):
                        asn = int(line.split()[2])
                        break

    return asn


def neighbor_interface(context, neighbor):
    """
    Return True if 'neighbor' is already configured as an interface neighbor
    """
    target_line = 'neighbor %s interface' % neighbor

    if look_for_line(context, None, target_line, False):
        return True
    else:
        return False


def neighbor_remote_as(context, neighbor):
    """
    Return True if 'neighbor' already has a remote-as configured
    """

    # First see if the neighbor has remote-as configured directly on the neighbor
    neighbor_remote_as = 'neighbor %s remote-as' % neighbor

    if look_for_line(context, None, neighbor_remote_as, False):
        return True

    # If not, see if the peer is a member of a peer-group where the
    # peer-group has remote-as configured
    neighbor_peer_group = 'neighbor %s peer-group ' % neighbor
    neighbor_peer_group = look_for_line(context, None, neighbor_peer_group, False)

    if neighbor_peer_group:
        neighbor_peer_group = neighbor_peer_group[0]

        if neighbor_peer_group.endswith('peer-group'):
            peer_group = neighbor_peer_group.split()[1]
        else:
            peer_group = neighbor_peer_group.split()[3]
        peer_group_remote_as = 'neighbor %s remote-as' % peer_group

        if look_for_line(context, None, peer_group_remote_as, False):
            return True

    return False


def delete_this_line(line, del_line, del_line_vni, vni, exact_match):
    """
    Return True if this line should be deleted.  Else, return False.
    """

    if del_line_vni:
        if del_line_vni == vni:
            # If the user is deleting the entire vni under "address-family l2vpn evpn",
            # del_line will be None.
            if del_line is None:
                return True

            if exact_match and line.strip() == del_line:
                return True

            if not exact_match and line.strip().startswith(del_line):
                return True

    elif del_line_vni is None and vni:
        return False

    elif del_line is None:
        return False

    else:
        if exact_match and line.strip() == del_line:
            return True

        if not exact_match and line.strip().startswith(del_line):
            return True

        # If you remove "ip igmp" from an interface frr will remove all of
        # the other "ip igmp XYZ" commands under that interface so go ahead
        # and remove those commands from the pending buffer.
        if del_line == 'ip igmp' and line.lstrip().startswith('ip igmp'):
            return True

        # prefix-lists are special
        if ((del_line.startswith('ip prefix-list') and line.startswith('ip prefix-list') or
            (del_line.startswith('ipv6 prefix-list') and line.startswith('ipv6 prefix-list')))):

            re_name_only = re.search(r"""(ip|ipv6) prefix-list \w+$""", del_line)
            re_name_seq_only = re.search(r"""(ip|ipv6) prefix-list \w+ seq \d+$""", del_line)

            # delete the entire prefix-list
            # delete an entry in the prefix-list by seq number
            if re_name_only is not None or re_name_seq_only is not None:
                if line.startswith(del_line + ' '):
                    return True

            # delete an entry in the prefix-list by value
            elif ' seq ' not in del_line:
                re_seq = re.search('^(.*) seq \d+ (.*)$', line)

                if re_seq:
                    line_minus_seq = re_seq.group(1) + ' ' + re_seq.group(2)

                    if del_line == line_minus_seq:
                        return True

    return False


def edit_pending_file(target_context, target_subcontext, add_line, del_line, exact_match, give_feedback=True):
    """
    target_context - A string; the section of the configuration to which the command applies

    target_subcontext - A string or None; the minor subcommand of target_context

    add_line and del_line are None or a string.  Only one should not be None.  The string is the
        user's command.
    """

    assert (add_line is None) != (del_line is None)  # XOR
    output = []

    # Not all contexts have a subcontext.
    subcontext_display = "\n {0}\n".format(target_subcontext) if target_subcontext else ''

    if add_line is not None:
        action = 'Adding'
        add_line = add_line.rstrip()
        line_display = "\n {0}\n".format(add_line)
        found_del_line = True

        if (target_context and
            target_context.startswith('router bgp') and
            target_subcontext == 'address-family l2vpn evpn'):

            # evpn/vni special exception...at the time evpn was coded it was
            # the first frr feature wrappered by nclu to use a
            #
            #   context -> sub-context -> sub-sub-context
            #
            # model where "vni X" is the sub-sub-context within "address-family evpn".
            # As a quick solution for supporting this we always specify the vni line.
            re_vni = re.search(r'(vni \d+) (.*)', add_line)

            if re_vni:
                add_line = "{0}\n    {1}".format(re_vni.group(1), re_vni.group(2))

    del_line_vni = None

    if del_line is not None:
        action = 'Deleting'
        del_line = del_line.strip()
        line_display = "\n {0}\n".format(del_line)
        found_del_line = False

        # Example: "vni 10 rd 1:1"
        if del_line.startswith('vni '):
            del_line_list = del_line.split()
            del_line_vni = del_line_list[1]
            # If the user is deleting the entire vni subsubcontext then make del_line None
            del_line = ' '.join(del_line_list[2:]) if len(del_line_list) > 2 else None

    log.debug("""
action     : {0}
context    : {1}
subcontext : {2}
line       : {3}\n""".format(action, target_context, subcontext_display, line_display))

    #############################################################################################
    # Stage an update to the daemon's file.  Most of the time, we won't need to modify this file.
    #############################################################################################

    rewrite_daemons = False  # Do we need to modify the "daemons" file?
    daemons = get_daemons()  # OrderedDict

    # zebra must always be enabled.
    if daemons.get('zebra', '').lower() != 'yes':
        daemons['zebra'] = 'yes'
        rewrite_daemons = True

    if add_line:

        if ('igmp ' in add_line or ' igmp' in add_line or
            'pim ' in add_line or ' pim' in add_line or
            'multicast' in add_line or 'msdp' in add_line) and os.path.exists(USR_LIB_FRR_PIMD):

            # This is a multicast related command, so pimd must be enabled.
            if daemons.get('pimd', '').lower() != 'yes':
                daemons['pimd'] = 'yes'
                rewrite_daemons = True

        if target_context:

            if target_context.startswith('router bgp'):
                # Enable bgpd.
                if daemons.get('bgpd', '').lower() != 'yes':
                    daemons['bgpd'] = 'yes'
                    rewrite_daemons = True

            elif target_context.startswith('router ospf6'):
                if daemons.get('ospf6d', '').lower() != 'yes':
                    daemons['ospf6d'] = 'yes'
                    rewrite_daemons = True

            elif target_context.startswith('router ospf'):
                # Enable ospfd.
                if daemons.get('ospfd', '').lower() != 'yes':
                    daemons['ospfd'] = 'yes'
                    rewrite_daemons = True

            elif target_context.startswith('interface'):
                if 'ospf6' in add_line:
                    if daemons.get('ospf6d', '').lower() != 'yes':
                        daemons['ospf6d'] = 'yes'
                        rewrite_daemons = True

                elif 'ospf' in add_line:
                    if daemons.get('ospfd', '').lower() != 'yes':
                        daemons['ospfd'] = 'yes'
                        rewrite_daemons = True

                elif ' pim ' in add_line or ' igmp ' in add_line:
                    if daemons.get('pimd', '').lower() != 'yes':
                        daemons['pimd'] = 'yes'
                        rewrite_daemons = True

                elif 'pbr-policy' in add_line:
                    if daemons.get('pbrd', '').lower() != 'yes':
                        daemons['pbrd'] = 'yes'
                        rewrite_daemons = True

            elif target_context.startswith('mpls ldp'):
                if daemons.get('ldpd', '').lower() != 'yes':
                    daemons['ldpd'] = 'yes'
                    rewrite_daemons = True

            elif target_context.startswith('pbr-map'):
                if daemons.get('pbrd', '').lower() != 'yes':
                    daemons['pbrd'] = 'yes'
                    rewrite_daemons = True

            elif target_context.startswith('route-map'):

                if 'as-path' in add_line:
                    # Enable bgpd.
                    if daemons.get('bgpd', '').lower() != 'yes':
                        daemons['bgpd'] = 'yes'
                        rewrite_daemons = True

        else:
            # target_context is None for commands that go in the global
            # context (static routes, debugs, etc.).
            if 'debug bgp ' in add_line:
                if daemons.get('bgpd', '').lower() != 'yes':
                    daemons['bgpd'] = 'yes'
                    rewrite_daemons = True

            elif 'debug ospf ' in add_line:
                if daemons.get('ospfd', '').lower() != 'yes':
                    daemons['ospfd'] = 'yes'
                    rewrite_daemons = True

            elif 'debug ospf6 ' in add_line:
                if daemons.get('ospf6d', '').lower() != 'yes':
                    daemons['ospf6d'] = 'yes'
                    rewrite_daemons = True

            elif 'debug pim ' in add_line or 'debug mroute' in add_line:
                if daemons.get('pimd', '').lower() != 'yes':
                    daemons['pimd'] = 'yes'
                    rewrite_daemons = True

            elif 'debug pbr ' in add_line:
                if daemons.get('pbrd', '').lower() != 'yes':
                    daemons['pbrd'] = 'yes'
                    rewrite_daemons = True

    if rewrite_daemons:
        # Overwrite the old "daemons" file.
        with open(ETC_FRR_DAEMONS_SCRATCHPAD, 'w') as f:
            for (daemon, daemon_value) in daemons.iteritems():
                f.write("{0}={1}\n".format(daemon, daemon_value))

    # If we are working with an ospf/ospf6 vrf, note the name of the vrf
    if target_context is not None and target_context.startswith('router ospf') and ' vrf ' in target_context:
        # The vrf name will be at the end
        # router ospf vrf RED
        ospf_vrf = target_context.split()[-1]
    else:
        ospf_vrf = None

    #############################################################################################
    # Stage configuration changes to ETC_FRR_CONF_SCRATCHPAD.
    #############################################################################################
    use_exit_address_family = bool(target_subcontext) and target_context.startswith('router bgp')

    # Open the scratchpad for reading and writing.  Create it if it does not exist.
    with open(ETC_FRR_CONF_SCRATCHPAD, "r+" if os.path.isfile(ETC_FRR_CONF_SCRATCHPAD) else "w+") as f:

        # Read all lines, and reset the file pointer back to the start of the file.
        config_lines = list(f)
        f.seek(0)

        vni = None
        state = 'LIMBO'
        interface_vrf = None
        subcontext_lines = []

        # Write all of the lines back to the file, but add the add_line
        # (if there is one) at the end of its context/subcontext.
        for line in config_lines:
            line = line.rstrip()

            if line.lstrip().startswith('interface ') and ' vrf ' in line:

                # The vrf name will be at the end.
                #     interface swp1 vrf RED
                interface_vrf = line.lstrip().split()[-1]

            elif line == 'end':
                interface_vrf = None

            if line.lstrip().startswith('vni '):
                vni = line.split()[1]

            if state == 'LIMBO':
                if target_context:
                    if line == target_context:
                        state = 'IN_CONTEXT'
                # If we are adding lines at the global level (static routes, debugs, etc),
                # target_context will be None.  Do nothing for this case.

            elif state == 'IN_CONTEXT':
                if target_subcontext and line.strip() == target_subcontext:
                    state = 'IN_SUBCONTEXT'

                elif line.strip() == 'end':
                    # We just finished writing all of the lines for our context.  If
                    # add_line wasn't already in there, write it too.
                    if add_line:
                        if add_line != 'CONTEXT':
                            if add_line in subcontext_lines:
                                if give_feedback:
                                    output.append("'{0}' configuration already has '{1}'".format(target_context, add_line))
                            else:
                                # Create the subcontext
                                if target_subcontext:
                                    f.write(' ' + target_subcontext + '\n')
                                    f.write('  ' + add_line + '\n')

                                    if use_exit_address_family:
                                        f.write(' exit-address-family\n')
                                else:
                                    f.write(' ' + add_line + '\n')
                        # If our add_line is CONTEXT, there isn't anything
                        # to do because the context already exists.
                        add_line = None

                    elif del_line == 'CONTEXT':
                        # The entire context is being deleted, so delete the 'end'.
                        state = 'LIMBO'
                        continue

                    state = 'LIMBO'
            # End of case IN_CONTEXT

            elif state == 'IN_SUBCONTEXT':
                if line.strip().lower() in ['exit-address-family', 'end']:
                    # We just finished writing all of the lines for our subcontext.  If
                    # add_line wasn't already in there, write it too.
                    if add_line and add_line != 'CONTEXT':
                        if add_line in subcontext_lines:
                            if give_feedback:
                                output.append("'{0} {1}' configuration already has '{2}'".format(target_context, target_subcontext, add_line))
                        else:
                            f.write('  ' + add_line + '\n')
                    add_line = None
                    state = 'IN_CONTEXT'

                elif line.strip() == 'end':
                    state = 'LIMBO'
            # End of case IN_SUBCONTEXT

            log.debug("{0}: {1}".format(state, line))

            if (not target_context or
                (not target_subcontext and state == 'IN_CONTEXT') or
                (target_subcontext and state == 'IN_SUBCONTEXT')):

                if del_line == "CONTEXT":
                    # The entire context is being deleted, so do not write any of the lines.
                    pass

                elif delete_this_line(line, del_line, del_line_vni, vni, exact_match):
                    found_del_line = True

                else:
                    # If the user is adding a line to the global context,
                    # do not add the same line multiple times.
                    if not target_context and line == add_line:
                        if give_feedback:
                            output.append("configuration already has '{0}'".format(add_line))
                        add_line = None
                    f.write(line + '\n')

                subcontext_lines.append(line.strip())
            else:
                # If we are deleting the entire ospf context then we also
                # need to delete the ospf lines under the interfaces
                if (del_line == 'CONTEXT' and
                    target_context.startswith('router ospf6') and
                    line.lstrip().startswith('ipv6 ospf6 ') and
                    ospf_vrf == interface_vrf):
                    pass

                elif (del_line == 'CONTEXT' and
                      target_context.startswith('router ospf') and
                      line.lstrip().startswith('ip ospf ') and
                      ospf_vrf == interface_vrf):
                    pass
                else:
                    f.write(line + '\n')

            if line.lstrip() in ('end', 'exit-vni'):
                vni = None

        # End of "for" loop

        if add_line:
            log.debug("STATE {0}, ADD_LINE: {1}".format(state, add_line))

            # Note that CONTEXT is a special case.  We hit this if
            # the user is trying to add a context, such as "router bgp 100".
            if add_line == 'CONTEXT':
                if state not in ('IN_CONTEXT', 'IN_SUBCONTEXT'):
                    f.write('{0}\n'.format(target_context))

                    if target_subcontext:
                        f.write(' {0}\n'.format(target_subcontext))

                        if use_exit_address_family:
                            f.write(' exit-address-family\n')
                    f.write('end\n')

            # The context (or sub-context) for which we were looking wasn't in the
            # configuration file.
            else:
                # Enter the context.  If it is None, use the global context.
                if target_context:
                    f.write('{0}\n'.format(target_context))

                    # We are in the context.  Enter the sub-context if there is
                    # one. Indent accordingly.
                    if target_subcontext:
                        f.write(' {0}\n'.format(target_subcontext))
                        f.write('  {0}\n'.format(add_line))

                        if use_exit_address_family:
                            f.write(' exit-address-family\n')
                    else:
                        f.write(' {0}\n'.format(add_line))
                    f.write('end\n')
                else:
                    f.write('{0}\n'.format(add_line))
                    f.write('end\n')

        if vni and line.lstrip() == 'exit-vni':
            vni = None

        # If we deleted lines, we need to truncate the rest of the file so that we
        # do not end up with the lines at the end printed twice.
        f.truncate()

    if give_feedback:
        if not found_del_line and del_line != 'CONTEXT':
            if del_line_vni:
                output.append("'{0} {1}' configuration does not have 'vni {2}'".format(target_context, target_subcontext, del_line_vni))
            elif target_subcontext:
                output.append("'{0} {1}' configuration does not have '{2}'".format(target_context, target_subcontext, del_line))
            elif target_context:
                output.append("'{0}' configuration does not have '{1}'".format(target_context, del_line))
            else:
                output.append("configuration does not have '{0}'".format(del_line))

            if del_line in ('no ptm-enable', 'no ipv6 nd suppress-ra', 'no bgp default ipv4-unicast', 'no bgp network import-check'):
                del_line_without_no = del_line.replace('no ', '')
                output.append('\nNote that "{0}" is on by default so when you do a "net add" NCLU\n'.format(del_line_without_no) +
                      'will translate that to a "net del" of the "{0}" lines in {1}'.format(del_line, SERVICE_NAME))

    return '\n'.join(output)


def bgp_neighbor_sanity(context, subcontext, cmd):
    # If we are adding a keyword for a bgp neighbor there are a few sanity
    # checks that we must make
    # - Is the peer defined?
    # - If the peer's name matches an interface is the peer defined as an "interface" peer?
    cmd = cmd.split()
    output = []

    if context and context.startswith('router bgp') and cmd[0].startswith('neighbor'):
        neighbor = cmd[1]
        keyword = cmd[2]
        interfaces = [x for x in os.listdir('/sys/class/net/') if x not in ('bonding_masters', 'swid0_eth')]
        interface_neighbor = False

        # Is this an unnumbered bgp peer on an interface or sub-interface?
        for interface in interfaces:
            if neighbor.startswith(interface):
                interface_neighbor = True
                break

        # interface peer
        if interface_neighbor:
            if keyword != 'interface' and not neighbor_interface(context, neighbor):
                edit_output = edit_pending_file(context, None,
                                                'neighbor {0} interface'.format(neighbor),
                                                 None, True, False)
                if edit_output:
                    output.append(edit_output)

        # ipv4/ipv6 peer
        else:
            for keyword in cmd[2:]:
                if keyword in ('remote-as', 'peer-group'):
                    break
            else:
                if not neighbor_remote_as(context, neighbor):
                    edit_output = edit_pending_file(context, None,
                                                    'neighbor {0} remote-as external'.format(neighbor),
                                                    None, True, False)
                    if edit_output:
                        output.append(edit_output)

    return "\n".join(output)


def igmp_sanity(context, subcontext, cmd):
    """
    If the user is configuring an IGMP command on an interface that interface
    must also have 'ip igmp', add that line automagically
    """
    output = ""

    if context and context.startswith('interface') and cmd.startswith('ip igmp') and cmd != 'ip igmp':
        output = edit_pending_file(context, subcontext, 'ip igmp', None, False, False)

    return output


def add(context, subcontext, cmd, give_feedback=True):
    igmp_output = igmp_sanity(context, subcontext, cmd)
    bgp_output = bgp_neighbor_sanity(context, subcontext, cmd)
    edit_output = edit_pending_file(context, subcontext, cmd, None, True, give_feedback)
    output = []

    for x in (igmp_output, bgp_output, edit_output):
        if x:
            output.append(x)

    return "\n".join(output)


def delete(context, subcontext, command, exact_match, give_feedback=True):
    output = []

    # 'route-target both' in frr is a macro for configuring 'route-target import'
    # and 'route-target export' so intercept this command and do dels for import
    # and export.
    if 'route-target both' in command:
        rt_import = command.replace('route-target both', 'route-target import')
        rt_export = command.replace('route-target both', 'route-target export')
        edit_output = edit_pending_file(context, subcontext, None, rt_import, exact_match, give_feedback)

        if edit_output:
            output.append(edit_output)

        edit_output = edit_pending_file(context, subcontext, None, rt_export, exact_match, give_feedback)

        if edit_output:
            output.append(edit_output)

    else:
        edit_output = edit_pending_file(context, subcontext, None, command, exact_match, give_feedback)

        if edit_output:
            output.append(edit_output)

    # If a deletion occured that erased the last "router bgp ..." configuration info,
    # remove from the pending frr.conf any lines about the route map delay timer.

    # Buffer the pending configuration file.
    if os.path.isfile(ETC_FRR_CONF_SCRATCHPAD):
        with open(ETC_FRR_CONF_SCRATCHPAD) as f:
            config_text = f.read()

        # Find any remaining "router bgp ..." information.
        router_info = re.search(r"""^\s*router\s+bgp\s+\d+\s*$""", config_text, re.I | re.M)

        if router_info is None:
            # Delete delay timer related lines.

            config_text = re.sub(r"""^\s*bgp\s+route-map\s+delay-timer.*$""", '', config_text, flags=re.I | re.M)
            with open(ETC_FRR_CONF_SCRATCHPAD, 'w') as f:
                f.write(config_text)

    return "\n".join(output)


def execute_command_add_del(net_daemon, ifnames, bgppeers):
    """
    Execute an "add" or "del" command, and return the standard 2-tuple.
    """

    cli = net_daemon.nclu_parser
    tokens = cli.args
    assert "add" in tokens or "del" in tokens, "Why are you here?"
    messages = {"output": ''}

    # Subsequent code might modify this initial state, but we need to know the initial state downstream.
    is_add_command = "add" in tokens

    # Sanity check that the log file specified is in a place where FRR has write permissions.
    if "add" in tokens and "log" in tokens and "file" in tokens:
        filename = tokens.get("<text>")

        if not filename.startswith("/var/log/{0}/".format(SERVICE_NAME)):
            messages["error"] = ["FRR log files must be in /var/log/{0}/.".format(SERVICE_NAME)]
            return (False, messages)

    contexts = []
    subcontext = None
    give_feedback = True

    # (add|del) will be the node at #1
    # entry #2 will be the bgp, ospf, interface, etc node
    add_del_node = cli.match[1]
    context_node = cli.match[2]

    # Set node_cmd_start to 3 so we don't look at "(add|del) bgp" when
    # building the actual frr cmd string.
    node_cmd_start = 3

    cmd_is_CONTEXT = False

    if context_node.value.text == "bgp" and cli.match[3].value:
        keyword = cli.match[3].value.text

        if keyword == "autonomous-system":
            # The user entered something like "bgp autonomous-system 100".  Translate that to "router bgp 100".
            cli.match[2].value.value = "router"
            cli.match[2].value.value_raw = "router"
            cli.match[3].value.value = "bgp"
            cli.match[3].value.value_raw = "bgp"
            context_node = cli.match[3]
            cmd_is_CONTEXT = True

        # net add bgp    vrf BLUE autonomous-system 77
        # net add router bgp 77   vrf               BLUE
        # 0   1   2      3   4    5                 6
        elif keyword == "vrf":
            if len(cli.match) >= 7:
                if cli.match[5].value is not None and cli.match[5].value.text == "autonomous-system":
                    vrf = cli.match[4].value.value
                    asn = cli.match[6].value.value
                    cli.match[2].value.value = "router"
                    cli.match[2].value.value_raw = "router"
                    cli.match[3].value.value = "bgp"
                    cli.match[3].value.value_raw = "bgp"
                    cli.match[4].value.value = asn
                    cli.match[4].value.value_raw = asn
                    cli.match[5].value.value = "vrf"
                    cli.match[5].value.value_raw = "vrf"
                    cli.match[6].value.value_raw = vrf
                    context_node = cli.match[3]
                    cmd_is_CONTEXT = True

    elif context_node.value.text in ("ospf", "ospf6"):
        # net del ospf
        # net del ospf6
        # net del ospf vrf BLUE

        if len(cli.match) == 3:
            cmd_is_CONTEXT = True
        elif (cli.match[3].value.text == "vrf" and len(cli.match) == 5 and cli.match[1].value.text in ("add", "del")):
            cmd_is_CONTEXT = True

    elif context_node.value.text == "bond" or context_node.value.text == "loopback":
        cli.match[2].value.value = "interface"
        cli.match[2].value.value_raw = "interface"

    # Find the context and subcontext.
    if "debug" in tokens:
        # debugs are at the top level in frr but in nclu we put them under
        # the protocol...so "net add bgp debug bestpath". We configure this in
        # frr at the top level and as "debug bgp bestpath".

        # convert "routing zebra debug events" to "debug zebra events"
        if tokens.get("routing") and tokens.get("zebra"):
            cli.match[3].value.value = "debug"
            cli.match[3].value.value_raw = "debug"
            cli.match[4].value.value = "zebra"
            cli.match[4].value.value_raw = "zebra"
            node_cmd_start = 3
            contexts.append(None)

        # convert "routing mroute debug detail" to "debug mroute detail"
        elif tokens.get("routing") and tokens.get("mroute"):
            cli.match[3].value.value = "debug"
            cli.match[3].value.value_raw = "debug"
            cli.match[4].value.value = "mroute"
            cli.match[4].value.value_raw = "mroute"
            node_cmd_start = 3
            contexts.append(None)

        else:
            # Flip "bgp debug" to "debug bgp".
            cli.match[3].value.value = cli.match[2].value.value
            cli.match[3].value.value_raw = cli.match[2].value.value_raw
            cli.match[2].value.value = "debug"
            cli.match[2].value.value_raw = "debug"
            node_cmd_start = 2
            contexts.append(None)

    # Convert "routing protocol" to "ip protocol", etc.
    elif (tokens.get("routing") and
          (tokens.get("protocol") or (tokens.get("route") and tokens.get("<ipv4/prefixlen>") or
           (tokens.get("as-path") and tokens.get("access-list")) or
           tokens.get("import-table") or
           tokens.get("multicast-routing") or
           tokens.get("mroute") or
           tokens.get("community-list") or
           tokens.get("extcommunity-list")))):
        cli.match[2].value.value = "ip"
        cli.match[2].value.value_raw = "ip"

        if tokens.get("route") and tokens.get("<ipv4/prefixlen>"):
            messages["output"] = sanity_check_ip_host_vs_subnet(tokens, cli)

        node_cmd_start = 2
        contexts.append(None)

    # Convert "routing route <ipv6/prefixlen>" to "ipv6 route".
    elif tokens.get("routing") and tokens.get("route") and tokens.get("<ipv6/prefixlen>"):
        cli.match[2].value.value = "ipv6"
        cli.match[2].value.value_raw = "ipv6"
        node_cmd_start = 2
        contexts.append(None)
        messages["output"] = sanity_check_ip_host_vs_subnet(tokens, cli)

    # Convert "routing route-map ..." to "route-map ...".
    elif tokens.get("routing") and tokens.get("route-map"):
        cli.match[2].value.value = ''
        cli.match[2].value.value_raw = ''
        context_node = cli.match[3]
        contexts.append(' '.join(map(str, cli.argv_expanded[3:7])))
        node_cmd_start = 7

        # "net add routing route-map FOO permit 10" is 7 words
        if len(cli.argv_expanded) == 7:
            cmd_is_CONTEXT = True

    # net add pbr-map BAR seq 10 match 1.1.1.1/32
    elif tokens.get('pbr-map'):
        context_node = cli.match[2]
        contexts.append(' '.join(map(str, cli.argv_expanded[2:6])))
        node_cmd_start = 6

        # 'net del pbr-map BAR seq 10' is 6 words
        if len(cli.argv_expanded) == 6:
            cmd_is_CONTEXT = True

    # net add nexthop-group BLAH nexthop 1.1.1.1
    elif tokens.get('nexthop-group'):
        context_node = cli.match[2]
        contexts.append(' '.join(map(str, cli.argv_expanded[2:4])))
        node_cmd_start = 4

        # 'net del nexthop-group BLAH' is 4 words
        if len(cli.argv_expanded) == 4:
            cmd_is_CONTEXT = True

    # convert 'routing defaults ...' to 'frr defaults ...'
    elif tokens.get('routing') and tokens.get('defaults'):
        cli.match[2].value.value = 'frr'
        cli.match[2].value.value_raw = 'frr'
        node_cmd_start = 2
        contexts.append(None)

    elif tokens.get("line") and tokens.get("vty"):
        cli.match[2].value.value = ''
        cli.match[2].value.value_raw = ''
        context_node = cli.match[4]
        node_cmd_start = 5
        contexts.append(' '.join(map(str, cli.argv_expanded[3:5])))

        # "net add routing line vty" is 5 words.
        if len(cli.argv_expanded) == 5:
            cmd_is_CONTEXT = True

    # Convert "routing log" to just "log", etc.
    elif (tokens.get("routing") and
          (tokens.get("log") or
           tokens.get("service") or
           tokens.get("agentx") or
           tokens.get("password") or
           tokens.get("ptm-enable"))):
        cli.match[2].value.value = ''
        cli.match[2].value.value_raw = ''
        node_cmd_start = 2
        contexts.append(None)
        context_node = cli.match[3]

    # Convert "routing prefix-list ipv4" to "ip prefix-list".
    elif tokens.get("routing") and tokens.get("prefix-list") and tokens.get("ipv4"):
        cli.match[2].value.value = ''
        cli.match[2].value.value_raw = ''
        cli.match[3].value.value = "ip"
        cli.match[3].value.value_raw = "ip"
        cli.match[4].value.value = "prefix-list"
        cli.match[4].value.value_raw = "prefix-list"
        node_cmd_start = 2
        contexts.append(None)
        messages["output"] = sanity_check_ip_host_vs_subnet(tokens, cli)

    # Convert "routing prefix-list ipv6" to "ipv6 prefix-list".
    elif tokens.get("routing") and tokens.get("prefix-list") and tokens.get("ipv6"):
        cli.match[2].value.value = ''
        cli.match[2].value.value_raw = ''
        cli.match[3].value.value = "ipv6"
        cli.match[3].value.value_raw = "ipv6"
        cli.match[4].value.value = "prefix-list"
        cli.match[4].value.value_raw = "prefix-list"
        node_cmd_start = 2
        contexts.append(None)
        messages["output"] = sanity_check_ip_host_vs_subnet(tokens, cli)

    elif context_node.value.value == "vrf":
        # "net add vrf <text> vni <1-16777215>" must configure
        # vrf <text>
        # vni <1-16777215>
        contexts.append("vrf %s" % tokens.get("<text>"))
        del cli.match[3]
        del cli.match[2]
        node_cmd_start = 2

    # Translate "pim" to "ip pim".
    elif context_node.value.value in ("pim", "msdp"):

        # "net add pim vrf BLUE rp 1.1.1.1" must configure
        #
        # vrf BLUE
        #  ip pim rp 1.1.1.1
        #
        if tokens.get("vrf"):
            contexts.append("vrf %s" % tokens.get("<text>"))
            del cli.match[4]
            del cli.match[3]
        else:
            contexts.append(None)

        ip_word = Word("ip")
        ip_word.value = "ip"
        ip_word.value_raw = "ip"
        ip_node = Node(0, None, "ip")
        ip_node.value = ip_word
        cli.match.insert(2, ip_node)
        node_cmd_start = 2

    elif context_node.value.value == "bgp":
        bgp_vrf = None
        afi_idx = 3
        safi_idx = 4

        if tokens.get("vrf") and tokens.get("<text>"):
            bgp_vrf = tokens.get("<text>")
            node_cmd_start += 2
            afi_idx += 2
            safi_idx += 2

        if tokens.get("autonomous-system"):
            bgp_asn = tokens.get("<1-4294967295>")
        else:
            bgp_asn = get_bgp_asn(bgp_vrf)

        if not bgp_asn:
            if tokens.get("vrf") is not None:
                messages["error"] = ["You must first enable BGP via \"net add bgp vrf VRF_NAME autonomous-system NUMBER\"."]
            else:
                messages["error"] = ["You must first enable BGP via \"net add bgp autonomous-system NUMBER\"."]
            return (False, messages)

        if bgp_vrf is not None:
            contexts.append("router bgp {0} vrf {1}".format(bgp_asn, bgp_vrf))
        else:
            contexts.append("router bgp {0}".format(bgp_asn))

        # Find the subcontext for bgp.
        if str(cli.match[node_cmd_start]) == "[ipv4|ipv6]":
            ipv4_ipv6_node = cli.match[afi_idx]
            uni_multi_node = cli.match[safi_idx]

            if ipv4_ipv6_node.value and ipv4_ipv6_node.value.text:
                afi = ipv4_ipv6_node.value.text
            else:
                afi = "ipv4"

            if uni_multi_node.value and uni_multi_node.value.text:
                safi = uni_multi_node.value.text
            else:
                safi = "unicast"

            subcontext = "address-family {0} {1}".format(afi, safi)
            node_cmd_start += 2

        elif str(cli.match[afi_idx]) == "[ipv4]" and str(cli.match[safi_idx]) == "[unicast]":
            subcontext = "address-family ipv4 unicast"
            node_cmd_start += 2

        elif str(cli.match[afi_idx]) == "[ipv6]" and str(cli.match[safi_idx]) == "[unicast]":
            subcontext = "address-family ipv6 unicast"
            node_cmd_start += 2

        elif str(cli.match[afi_idx]) == "ipv4" and cli.match[safi_idx].value and cli.match[safi_idx].value.text == "unicast":
            subcontext = "address-family ipv4 unicast"
            node_cmd_start += 2

        elif str(cli.match[afi_idx]) == "ipv6" and str(cli.match[safi_idx]) == "unicast":
            subcontext = "address-family ipv6 unicast"
            node_cmd_start += 2

        elif str(cli.match[afi_idx]) == "ipv4" and cli.match[safi_idx].value and cli.match[safi_idx].value.text == "labeled-unicast":
            subcontext = "address-family ipv4 labeled-unicast"
            node_cmd_start += 2

        elif str(cli.match[afi_idx]) == "ipv6" and cli.match[safi_idx].value and cli.match[safi_idx].value.text == "labeled-unicast":
            subcontext = "address-family ipv6 labeled-unicast"
            node_cmd_start += 2

        elif str(cli.match[afi_idx]) == "[l2vpn]" and str(cli.match[safi_idx]) == "evpn":
            subcontext = "address-family l2vpn evpn"
            node_cmd_start += 2

        elif str(cli.match[afi_idx]) == "evpn":
            subcontext = "address-family l2vpn evpn"
            node_cmd_start += 1

        elif tokens.get("network") and tokens.get("<ipv6/prefixlen>"):
            subcontext = "address-family ipv6 unicast"

        # The "ipv4 unicast" is optional (just to make v4 easier to configure)
        # for any AFI/SAFI specific command. If they left off the "ipv4 unicast",
        # add it for them.
        if subcontext is None:
            for x in ("aggregate-address",
                      "as-override",
                      "network",
                      "redistribute",
                      "maximum-paths",
                      "activate",
                      "allowas-in",
                      "default-originate",
                      "filter-list",
                      "next-hop-self",
                      "prefix-list",
                      "remove-private-AS",
                      "route-map",
                      "route-reflector-client",
                      "send-community",
                      "soft-reconfiguration"):
                if x in cli.argv_expanded:
                    if x == "route-map":
                        if "delay-timer" not in cli.argv_expanded:
                            subcontext = "address-family ipv4 unicast"
                            break
                    elif x == "network":
                        if "import-check" not in cli.argv_expanded:
                            subcontext = "address-family ipv4 unicast"
                            break
                    else:
                        subcontext = "address-family ipv4 unicast"
                        break

    elif context_node.value.text == "ospf":
        ospf_vrf = None

        if tokens.get("vrf"):
            ospf_vrf = tokens.get("<text>")
            node_cmd_start += 2

        if ospf_vrf is not None:
            contexts.append("router ospf vrf {0}".format(ospf_vrf))
        else:
            contexts.append("router ospf")

    elif context_node.value.text == "ospf6":
        contexts.append("router ospf6")

    elif context_node.value.text == "mpls" and tokens.get("ldp"):
        contexts.append("mpls ldp")
        node_cmd_start += 1

        if tokens.get("address-family"):
            if tokens.get("ipv4"):
                subcontext = "address-family ipv4"
            elif tokens.get("ipv6"):
                subcontext = "address-family ipv6"
            node_cmd_start += 2

    elif context_node.value.text in ("bond", "interface", "vlan", "loopback"):
        if ifnames:
            for ifname in ifnames:
                contexts.append("interface {0}".format(ifname))
        else:
            contexts.append("interface {0}".format(cli.match[3].value.text))

        node_cmd_start += 1

    # global config level
    else:
        node_cmd_start = 2
        contexts.append(None)

    if cmd_is_CONTEXT:
        cmd = "CONTEXT"
    else:
        cmd = []
        for node in cli.match[node_cmd_start:]:
            if node.value and node.value.text:
                if node.value.text == "<interface>":
                    cmd.append("<interface>")
                elif node.value.text == "<bgppeer>":
                    cmd.append("<bgppeer>")
                else:
                    cmd.append(node.value.value)

        cmd = ' '.join(map(str, cmd)).strip()

    if contexts and contexts[0]:

        # There are about two dozen commands that are in the global bgp
        # context and start with the keyword 'bgp'. 'bgp router-id x.x.x.x'
        # is one example.  We did not want the parser to read:
        #
        #    frr add bgp bgp router-id x.x.x.x
        #
        # Because the double bgp just looks/feels weird. Prepend the needed
        # bgp keyword for any of these two dozen commands.
        if contexts[0].startswith("router bgp"):
            for bgp_bgp_cmd in bgp_bgp:
                if cmd.startswith(bgp_bgp_cmd):
                    cmd = 'bgp ' + cmd
                    break

            if cmd.startswith('timers'):
                cmd = cmd.replace('timers', 'timers bgp')

            if cmd == 'bgp default ipv4-unicast':
                # 'bgp default ipv4-unicast' is on by default.  A "no" command is necessary to turn it off.
                cmd = 'no ' + cmd
                give_feedback = False

                if tokens.get('del'):
                    # "net del bgp default ipv4-unicast" --> "net add no bgp default ipv4-unicast"
                    tokens['del'] = None
                    tokens['add'] = True
                elif tokens.get('add'):
                    # "net add bgp default ipv4-unicast" --> "net del no bgp default ipv4-unicast"
                    tokens['del'] = True
                    tokens['add'] = None

            if cmd == 'bgp network import-check':
                # 'bgp network import-check' is on by default.  A "no" command is necessary to turn it off.
                cmd = 'no ' + cmd
                give_feedback = False

                if tokens.get('del'):
                    # "net del bgp network import-check" --> "net add no bgp network import-check"
                    tokens['del'] = None
                    tokens['add'] = True
                elif tokens.get('add'):
                    # "net add bgp network import-check" --> "net del no bgp network import-check"
                    tokens['del'] = True
                    tokens['add'] = None

            if re.search(r"""neighbor \S+ activate""", cmd) is not None:
                # 'ipv4 unicast' is active by default unless 'no bgp default ipv4-unicast' is configured.
                if subcontext == 'address-family ipv4 unicast':

                    # If 'no bgp default ipv4-unicast' is configured, treat this like any other address-family.
                    # Otherwise, prepend "no " to the command, and flip the add/del.
                    if not look_for_line(contexts[0], None, 'no bgp default ipv4-unicast', True):
                        give_feedback = False

                        if tokens.get('del'):
                            cmd = 'no ' + cmd
                            tokens['del'] = None
                            tokens['add'] = True
                        elif tokens.get('add'):
                            tokens['del'] = True
                            tokens['add'] = None

            # If you configure something like "timers 2 3" frr will
            # silently change this to "1 3" so enforce it here so the
            # user is aware of the restriction.
            #
            #     net add bgp neighbor <bgppeer> timers <0-65535> <3-65535>
            #
            if tokens.get('add') and tokens.get('neighbor') and tokens.get('timers') and tokens.get('<3-65535>'):
                keepalive = tokens.get('<0-65535>')
                holdtime = tokens.get('<3-65535>')

                if keepalive > (holdtime / 3):
                    messages["error"] = ["The BGP keepalive interval must be less than or equal to 1/3 the holdtime."]
                    return (False, messages)

        # Same problem for some ospf commands
        elif contexts[0] == 'router ospf' or contexts[0].startswith('router ospf '):
            for ospf_ospf_cmd in ospf_ospf:
                if cmd.startswith(ospf_ospf_cmd):
                    cmd = 'ospf ' + cmd
                    break

            # If the user is configuring 'passive-interface swpX' the action we take
            # depends on whether or not 'passive-interface default' is configured.
            if tokens.get('passive-interface') and not tokens.get('default'):

                if look_for_line(contexts[0], None, 'passive-interface default', True):
                    cmd = 'no ' + cmd
                    give_feedback = False

                    if tokens.get('del'):
                        tokens['del'] = None
                        tokens['add'] = True

                    elif tokens.get('add'):
                        tokens['del'] = True
                        tokens['add'] = None

        elif contexts[0] == 'router ospf6' or contexts[0].startswith('router ospf6 '):
            for ospf6_ospf6_cmd in ospf6_ospf6:
                if cmd.startswith(ospf6_ospf6_cmd):
                    cmd = 'ospf6 ' + cmd
                    break

        # Like 'bgp default ipv4-unicast', 'ipv6 nd suppress-ra' and 'ptm-enable'
        # are on by default so we have to jump through some hoops to add the "no" line
        elif contexts[0].startswith('interface'):
            if cmd in ('ipv6 nd suppress-ra', 'ptm-enable'):
                cmd = 'no ' + cmd
                give_feedback = False

                if tokens.get('del'):
                    tokens['del'] = None
                    tokens['add'] = True
                elif tokens.get('add'):
                    tokens['del'] = True
                    tokens['add'] = None

            elif cmd.startswith('ospf6'):
                cmd = cmd.replace('ospf6', 'ipv6 ospf6', 1)

            elif cmd.startswith('ospf'):
                cmd = cmd.replace('ospf', 'ip ospf', 1)

            elif cmd.startswith('igmp'):
                cmd = cmd.replace('igmp', 'ip igmp', 1)

            elif cmd.startswith('pim'):
                cmd = cmd.replace('pim', 'ip pim', 1)

            elif cmd.startswith('multicast'):
                cmd = cmd.replace('multicast', 'ip multicast', 1)

            elif cmd.startswith('msdp'):
                cmd = cmd.replace('msdp', 'ip msdp', 1)

    # If the user is doing a del there are several options where we can
    # del based on the keyword and do not require the value.  For example
    # the user can delete the bgp router-id using either of the following:
    #
    #   net del bgp router-id 1.1.1.1
    #   net del bgp router-id
    #
    # exact_match determines if delete() looks for the line 'bgp router-id 1.1.1.1'
    # or just look for a line that begins with 'bgp router-id'
    if str(add_del_node) in ("(add|del)", "add"):
        exact_match = True

    elif str(add_del_node) == 'del':
        last_node = cli.match[-1]

        # If the user specified the optional arg at the end then
        # exact_match must be True
        if last_node.has_optional_branch():
            exact_match = False
        else:
            exact_match = True

    else:
        raise RuntimeError("Invalid add_del_node: {0}".format(add_del_node))

    if ifnames:
        # If the user entered a glob for interfaces those need to be
        # expanded in one of two places. The first scenario is where
        # the interface name is part of the context.  For example:
        #
        #    net add inter swp3-4 ip ospf network point-to-point
        #
        # needs to add this ospf command under contexts 'interface swp3
        # and 'interface swp4'. But if the user did
        #
        #    net add bgp neighbor swp3-4 interface peer-group FOO
        #
        # we need to expand this as separate commands within the 'router bgp' context.
        #
        # So check the len of contexts to figure out which way we
        # should expand the ifnames
        if len(contexts) > 1:
            for context in contexts:
                if "add" in tokens:
                    messages["output"] += add(context, subcontext, cmd, give_feedback)
                elif "del" in tokens:
                    messages["output"] += delete(context, subcontext, cmd, exact_match, give_feedback)
        else:
            context = contexts[0]

            for ifname in ifnames:
                cmd_with_ifname = cmd.replace("<interface>", ifname)

                if "add" in tokens:
                    messages["output"] += add(context, subcontext, cmd_with_ifname, give_feedback)
                elif "del" in tokens:
                    messages["output"] += delete(context, subcontext, cmd_with_ifname, exact_match, give_feedback)
    elif bgppeers:
        context = contexts[0]

        for peer in bgppeers:
            cmd_with_peer = cmd.replace('<bgppeer>', peer)

            if "add" in tokens:
                messages["output"] += add(context, subcontext, cmd_with_peer, give_feedback)
            elif "del" in tokens:
                messages["output"] += delete(context, subcontext, cmd_with_peer, exact_match, give_feedback)
    else:
        context = contexts[0]

        if "add" in tokens:
            messages["output"] += add(context, subcontext, cmd, give_feedback)
        elif "del" in tokens:
            messages["output"] += delete(context, subcontext, cmd, exact_match, give_feedback)

    # Executing the command concluded successfully.  Additional changes in /etc/network/interfaces might be necessary.
    if "<interface>" in tokens:
        if "ifupdown2" in net_daemon.enabled_wrappers:
            assert net_daemon.wrappers[0][0] == "ifupdown2"
            # ifupdown2 is enabled.

            if is_add_command:
                # add_interfaces doesn't return a value, and it is a "do something maybe" function.
                # Interfaces that are already configured will be ignored.
                # TODO - Make add_interfaces return boolean or a standard 2-tuple.
                net_daemon.wrappers[0][1].add_interfaces(tokens["<interface>"])
            # Else, nothing needs to happen for a "del" command.
        else:
            messages["warning"] = ["ifupdown2 is not enabled.  You must manually create or delete interfaces in /etc/network/interfaces before committing."]

    return (True, messages)


def del_interfaces(interfaces):
    """
    Given a non-empty list of interface names, remove all FRR configuration associated with the interface(s).
    This function is called after deleting interfaces from /etc/networks/interfaces.  It is a
    "do something maybe" function by design because an interface configured in /etc/network/interfaces
    might not have FRR configuration.
    """

    assert isinstance(interfaces, list) and interfaces

    try:
        frr_conf = frr_reload.Config()

        if os.path.isfile(ETC_FRR_CONF_SCRATCHPAD):
            frr_conf.load_from_file(ETC_FRR_CONF_SCRATCHPAD)
        elif os.path.isfile(ETC_FRR_CONF):
            frr_conf.load_from_file(ETC_FRR_CONF)
        else:
            # Nothing to do.
            return
    except frr_reload.VtyshMarkException as e:
        log.error(frr_reload_exception_to_string(ETC_FRR_CONF, e))
        return

    for interface in interfaces:
        interface_context = "interface {0}".format(interface)
        interface_context_vrf = interface_context + " vrf "
        sub_interface_base = interface_context + '.'

        for context in frr_conf.contexts.keys():
            if context[0] == interface_context:
                context_to_del = interface_context
            elif context[0].startswith(interface_context_vrf) or context[0].startswith(sub_interface_base):
                context_to_del = context[0]
            else:
                # Do not delete the context.
                continue

#            context_to_del = interface_context
#            subcontext_to_del = None
#            command = "CONTEXT"
#            delete(context_to_del, subcontext_to_del, command, True)
            delete(context_to_del, None, "CONTEXT", True)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)7s: %(message)s")
    doctest.testmod()
