# Copyright (C) 2016-2017 Cumulus Networks, inc.
#
# All Rights reserved.
#
# This software is subject to the Cumulus Networks End User License Agreement available
# at the following locations:.
#
# Internet: https://cumulusnetworks.com/downloads/eula/latest/view/
#
# Cumulus Linux systems: /usr/share/cumulus/EULA.txt

"""
Usage:

    # LNV: Lightweight Network Virtualization
    # LNV configuration
    lnv (add|del) lnv service-node anycast-ip <ipv4>
    lnv (add|del) lnv service-node source <ipv4>
    lnv (add|del) lnv service-node peers <wildcard>

    # LNV show commands
    lnv show lnv

Options:

    anycast-ip   : An anycast IPv4 address
    lnv          : Lightweight Network Virtualization
    peers        : A peer, neighbor, etc
    service-node : LNV service-node
    source       : Source
    vtep         : VXLAN Tunnel End Point

"""

from collections import OrderedDict
from network_docopt import sort_for_humans
from nclu import get_lldp, ConfigWrapperBase, ConfigFileKeyValue, service_is_active, tabulate_remove_unicode as tru
from tabulate import tabulate
from itertools import izip_longest
from subprocess import CalledProcessError, check_output, STDOUT
import json
import logging
import logging.handlers
import os.path
import re
import shutil

log = logging.getLogger('netd')
VXSND_CONF = '/etc/vxsnd.conf'


def ifaces_in_vlan(bridge_vlan_show, target_vlan):
    ifaces = []
    for (ifname, value) in bridge_vlan_show.iteritems():
        # value is a list of dictionaries
        for entry in value:
            vlan = entry.get('vlan')

            if vlan == target_vlan:
                ifaces.append(ifname)

    return sort_for_humans(list(set(ifaces)))


def show_lnv():
    """
    Pull data from various places to print a summary of the LNV state on this node
    """

    # Are we a vtep?
    try:
        check_output(['/bin/systemctl', 'is-active', 'vxsnd.service'])
        is_service_node = True
    except CalledProcessError:
        is_service_node = False

    # Are we a service node?
    try:
        check_output(['/bin/systemctl', 'is-active', 'vxrd.service'])
        is_vtep = True
    except CalledProcessError:
        is_vtep = False

    if is_service_node:
        '''
        {"peers": [], "version": 3, "anycast": "6.0.0.9", "ctrl_port": 10001, "data_port": 4789, "local": "6.0.0.9"}

        Protocol version: 3
        Local address      Anycast address    Peer Addresses
        =============      ===============    ==============
        6.0.0.9            6.0.0.9

        Data (UDP) Port                       Control (UDP) Port
        ==============                        =================
        4789                                  10001

        '''
        try:
            output = check_output(['/usr/bin/vxsndctl', 'show', 'detail', '-j'])
        except CalledProcessError:
            output = "{}"
        vxsnd_show = json.loads(output)


        '''
        {"10": [["6.0.0.12", "76", "89254930658124"], ["6.0.0.11", "86", "87057984938359"]]}

        VNI         Address         Ageout
        ===         =======         ======
        10          6.0.0.11        85
        10          6.0.0.12        75

        '''
        try:
            output = check_output(['/usr/bin/vxsndctl', 'fdb', '-j'])
        except CalledProcessError:
            output = "{}"
        vxsnd_fdb = json.loads(output)

        output = []
        output.append("")
        output.append("  LNV Role           : Service Node")
        output.append("  Version            : %s" % vxsnd_show.get('version'))
        output.append("  Local IP           : %s" % vxsnd_show.get('local'))
        output.append("  Anycast IP         : %s" % vxsnd_show.get('anycast'))
        output.append("  UDP Data Port      : %s" % vxsnd_show.get('data_port'))
        output.append("  UDP Control Port   : %s" % vxsnd_show.get('ctrl_port'))
        output.append("  Service Node Peers : %s" % ', '.join(vxsnd_show.get('peers')))
        output.append("")

        header = ('VNI', 'VTEP', 'Ageout')

        data = []
        for (vni, values) in  vxsnd_fdb.iteritems():
            for (ip, ageout, timeout) in values:
                data.append((vni, ip, ageout))

        final_data = []
        prev_vni = None
        for (vni, ip, ageout) in sorted(data):
            if prev_vni is None or prev_vni != vni:
                final_data.append((vni, ip, ageout))
            else:
                final_data.append(('', ip, ageout))
            prev_vni = vni

        for line in tabulate(tru(final_data), header).splitlines():
            output.append('  ' + line)
        output.append("")
        output.append("")

        print "\n".join(output)

    if is_vtep:
        '''
        {"10": {"dev_name": "vni-10", "svcnodeip": "6.0.0.9", "hrep_addrs": ["6.0.0.12"], "localip": "6.0.0.11"}}

        VNI         Local Addr      Svc Node
        ===         ==========      ========
        10          6.0.0.11        6.0.0.9
        '''
        try:
            # This takes ~350ms but we have to have this data
            output = check_output(['/usr/bin/vxrdctl', 'vxlans', '-j'])
        except CalledProcessError:
            output = "{}"
        vxrd_vxlans = json.loads(output)


        '''
        {"10": ["6.0.0.12", "6.0.0.11"]}

        VNI         Peer Addrs
        ===         ==========
        10          6.0.0.11, 6.0.0.12

        '''
        # No new info here d what we already learned via 'vxrdctl vxlans'
        # output = check_output(['/usr/bin/vxrdctl', 'peers', '-j'])
        # peers = json.loads(output)


        '''
        {"src_ip": "6.0.0.11", "snd_ip": "6.0.0.9", "version": 3, "head_rep": true}

        Protocol version: 3
        Local address      Svcnode address    Head rep.
        =============      ===============    =========
        6.0.0.11           6.0.0.9            Enabled

        '''
        # Here we learn the version # and if headend replication is enabled
        try:
            # This takes ~200ms but we have to have this data
            output = check_output(['/usr/bin/vxrdctl', 'show', '-j'])
        except CalledProcessError:
            output = "{}"
        vxrd_show = json.loads(output)

        try:
            output = check_output(['/sbin/bridge', '-j', 'vlan', 'show'])
        except CalledProcessError:
            output = "{}"
        bridge_show = json.loads(output)

        try:
            output = check_output(['/sbin/brctl', 'show'])
        except CalledProcessError:
            output = ""

        brctl_show = {}
        bridge_name = None
        for line in output.splitlines():
            if line.startswith('bridge name'):
                continue

            columns = line.replace('\t', ' ').split()

            '''
            bridge name bridge id           STP enabled interfaces
            br-10       8000.002590b201b9   yes         swp3
                                                        swp4
                                                        vni-10
            '''
            if len(columns) == 4:
                bridge_name = columns[0]
                # bridge_id = columns[1]
                # step = columns[2]
                iface = columns[3]
                brctl_show[bridge_name] = [iface, ]
            else:
                if bridge_name:
                    brctl_show[bridge_name].append(columns[0])

        output = []
        output.append("")
        output.append("  LNV Role            : VTEP")
        output.append("  Version             : %s" % vxrd_show.get('version'))
        output.append("  Headend Replication : %s" % vxrd_show.get('head_rep'))
        output.append("")

        lldp = get_lldp()

        header = ('VLAN', 'VNI', 'Local IP', 'Service Node IP', 'VLAN Members', 'VTEP Peers')
        data = []

        for (vni, value) in vxrd_vxlans.iteritems():
            ifaces = []
            vni_vlan = None
            vni_iface = value['dev_name']
            vni_local_ip = value['localip']
            vni_svcnode_ip = value['svcnodeip']

            vni_bridge_show = bridge_show.get(vni_iface)

            if vni_bridge_show:
                vni_vlan = vni_bridge_show[0].get('vlan')
                ifaces = ifaces_in_vlan(bridge_show, vni_vlan)

            peers = sort_for_humans(value['hrep_addrs'])

            for (iface, peer) in izip_longest(ifaces, peers):
                if iface:
                    lldp_peer = lldp.get(iface)

                    if lldp_peer:
                        iface = "%s (%s)" % (iface, lldp_peer)

                data.append((vni_vlan, vni, vni_local_ip, vni_svcnode_ip, iface, peer))

        final_data = []
        prev_vni_vlan = None
        for (vni_vlan, vni, vni_local_ip, vni_svcnode_ip, iface, peer) in sorted(data):
            if prev_vni_vlan is None or prev_vni_vlan != vni_vlan:
                final_data.append((vni_vlan, vni, vni_local_ip, vni_svcnode_ip, iface, peer))
            else:
                final_data.append(('', '', '', '', iface, peer))

            prev_vni_vlan = vni_vlan

        for line in tabulate(tru(final_data), header).splitlines():
            output.append('  ' + line)
        output.append("")
        print "\n".join(output)


class ConfigWrapper(ConfigWrapperBase):

    def __init__(self, show_linux_command, color_diffs):
        super(ConfigWrapper, self).__init__('lnv', show_linux_command, color_diffs)
        self.files[VXSND_CONF] =\
            ConfigFileKeyValue(self, VXSND_CONF,
                               [['/bin/systemctl', 'enable', 'vxsnd.service'],
                                ['/bin/systemctl', 'reset-failed', 'vxsnd.service'],
                                ['/bin/systemctl', 'restart', 'vxsnd.service']])
        self.cfg = self.files[VXSND_CONF]

    def del_all(self, cli):
        values = self.cfg.get_value()
        svcnode_ip = values.get('svcnode_ip')
        src_ip = values.get('src_ip')
        svcnode_peers = values.get('svcnode_peers')

        if svcnode_ip is not None and svcnode_ip != '0.0.0.0':
            if not os.path.exists(self.cfg.scratchpad):
                shutil.copyfile(self.cfg.filename, self.cfg.scratchpad)
            self.cfg.edit('svcnode_ip', '0.0.0.0')

        if src_ip is not None and src_ip != '0.0.0.0':
            if not os.path.exists(self.cfg.scratchpad):
                shutil.copyfile(self.cfg.filename, self.cfg.scratchpad)
            self.cfg.edit('src_ip', '0.0.0.0')

        if svcnode_peers:
            if not os.path.exists(self.cfg.scratchpad):
                shutil.copyfile(self.cfg.filename, self.cfg.scratchpad)
            self.cfg.edit('svcnode_peers', '')

    def show_config_commands(self, user_may_edit, ifupdown2_wrapper):
        values = self.cfg.get_value()
        svcnode_ip = values.get('svcnode_ip')
        src_ip = values.get('src_ip')
        svcnode_peers = values.get('svcnode_peers')
        supported = []
        unsupported = []

        if svcnode_ip and svcnode_ip != '0.0.0.0':
            supported.append('net add lnv service-node anycast-ip %s' % svcnode_ip)

        if src_ip and src_ip != '0.0.0.0':
            supported.append('net add lnv service-node source %s' % src_ip)

        if svcnode_peers:
            supported.append('net add lnv service-node peers %s' % svcnode_peers)

        return (supported, unsupported)

    def show_config_summary(self, user_may_edit, summary):
        values = self.cfg.get_value()
        svcnode_ip = values.get('svcnode_ip')
        src_ip = values.get('src_ip')
        svcnode_peers = values.get('svcnode_peers')

        if ((svcnode_ip and svcnode_ip != '0.0.0.0') or
            (src_ip and src_ip != '0.0.0.0') or
            svcnode_peers):
            summary["lnv"] = OrderedDict()
            summary["lnv"]["service-node"] = OrderedDict()

            if svcnode_ip and svcnode_ip != '0.0.0.0':
                summary["lnv"]["service-node"]["anycast-ip"] = svcnode_ip

            if src_ip and src_ip != '0.0.0.0':
                summary["lnv"]["service-node"]["source"] = src_ip

            if svcnode_peers:
                summary["lnv"]["service-node"]["peers"] = svcnode_peers

    def eval_command_line_args(self, cli):
        super(ConfigWrapper, self).eval_command_line_args(cli)  # Creates the scratchpad, if necessary.
        args = cli.args
        command_ok = True

        if cli.args.get('add'):

            if args.get('service-node'):
                if args.get('anycast-ip'):
                    anycast_ip = args.get('<ipv4>')
                    self.cfg.edit('svcnode_ip', anycast_ip)

                elif args.get('source'):
                    source_ip = args.get('<ipv4>')
                    self.cfg.edit('src_ip', source_ip)

                elif args.get('peers'):
                    peers = ' '.join(args.get('<wildcard>').replace(',', ' ').strip().split())
                    self.cfg.edit('svcnode_peers', peers)

        elif cli.args.get('del'):

            # Calling self.cfg.edit with True results in commented-out key-value pairs in the configuration file.
            if args.get('service-node'):
                if args.get('anycast-ip'):
                    self.cfg.edit('svcnode_ip', '0.0.0.0', True)

                elif args.get('source'):
                    self.cfg.edit('src_ip', '0.0.0.0', True)

                elif args.get('peers'):
                    self.cfg.edit('svcnode_peers', '', True)

        elif args.get('show'):
            show_lnv()

        return command_ok

    def commit_pending(self, verbose):
        """
        In addition to copying a scratchpad to a configuration file, committing changes to
        LNV necessitates restarting the vxsnd daemon (when adding) or possibly stopping the
        vxsnd daemon (when removing the last svcnode_ip parameter).

        Return a 3-tuple of (bool, str, [str]).  The boolean indicates if the commit
        succeeded.  The string includes information, including errors, for the user.
        The list contains the names of the files modified.
        """

        # TODO - This overridden method allows the parent class's method to restart vxsnd as usual
        # but adds the optional step of stopping vxsnd for delete actions.  This is an easy
        # implementation, but restarting vxsnd might not be necessary.

        # Write the scratchpad to VXSND_CONF, and delete the scratchpad, using the parent class method.
        success, message, modified_files = super(ConfigWrapper, self).commit_pending(verbose)

        if not success:
            return (success, message, modified_files)

        if os.path.exists(VXSND_CONF):
            with open(VXSND_CONF) as f:
                vxsnd_conf_text = f.read().lower()
        else:
            vxsnd_conf_text = ''

        # Shoud we stop the vxsnd daemon?
        uncommented_svcnode_ip = re.search(r"""^\s*svcnode_ip\s*=""", vxsnd_conf_text, re.MULTILINE) is not None
        if not uncommented_svcnode_ip:
            if service_is_active("vxsnd"):
                try:
                    # Stop the vxsnd daemon, and ensure it does not restart after a reboot.
                    commands = ["systemctl stop vxsnd", "systemctl disable vxsnd"]
                    for command in commands:
                        output = check_output(command.split(), stderr=STDOUT)
                        if verbose:
                            message += '\n' + output

                except Exception as e:
                    message += "\n\"{0}\" failed:\n{1}\n".format(command, e)

        # Return the tuple returned by the parent class method.
        return (success, message, modified_files)
