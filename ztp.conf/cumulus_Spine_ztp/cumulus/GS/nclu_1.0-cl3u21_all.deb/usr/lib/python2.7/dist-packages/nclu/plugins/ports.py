"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

import logging
import os
import re
from nclu import (
    files_match,
    ifname_expand_glob,
    ifnames_to_glob,
    service_is_active,
    service_is_enabled,
    WORKING_DIRECTORY,
)
from nclu.netshow2 import (
    is_bond_member,
    is_bridge_member,
    get_master,
    get_interface_subdivisions
)
from nclu.plugins import (
    get_config_files_helper,
    get_pending_diffs,
    make_scratchpads,
    merge_messages,
    persist_configurations,
    remove_scratch_files_and_backups,
    run_commands,
)
from nclu.wrappers.ifupdown2 import ifname_in_etc_network_interfaces, ifname_prefix_in_etc_network_interfaces
from network_docopt import sort_for_humans
from subprocess import CalledProcessError, check_output, STDOUT

PORTS_CONF = "/etc/cumulus/ports.conf"
PORTS_CONF_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "ports", "ports.conf")

log = logging.getLogger("netd")


def build_doc_string():
    """ Syntax for this plug-in is only available when PORTS_CONF exists. """

    if os.path.isfile(PORTS_CONF):
        return """/
Usage:
    net add interface <interface> breakout (1x|2x|4x|4x10|/4|3/2|disabled|loopback)

Options:
    1x          : Do not split or gang the port
    2x          : Split the port into two interfaces
    4x          : Split the port into four interfaces
    4x10        : Split the port into four 10 Gbps interfaces
    /4          : Gang four ports into a single port
    3/2         : Two ports ganged then split into three
    disabled    : Disabled
    breakout    : Split an interface into multiple interface via a breakout cable
    loopback    : Loopback
"""

    return ''


def commit_pending(verbose):
    """
    Copy scratchpad files over configuration files, call necessary restart commands, etc.

    Return a 2-tuple of (bool, dict).  The boolean indicates if the commit succeeded.
    The dictionary is as described in nclu/plugins/__init__.py:execute_modular.
    """

    assert os.path.isfile(PORTS_CONF), "This plug-in should only provide syntax if {0} exists.".format(PORTS_CONF)

    messages = {"output": ''}

    if not os.path.isfile(PORTS_CONF_SCRATCHPAD) or files_match(PORTS_CONF, PORTS_CONF_SCRATCHPAD):
        # There are no changes to commit.
        return (True, messages)

    # Validate the prospective changes.
    validation_command = ["/usr/cumulus/bin/validate-ports", "-f", PORTS_CONF_SCRATCHPAD]
    try:
        check_output(validation_command, stderr=STDOUT)
    except CalledProcessError as e:
        log.exception(e)
        messages["error"] = ["\"{0}\" failed.  See the log for details.".format(validation_command)]
        messages["error"] += [e.output]
        return (False, messages)

    # The prospective changes seem valid.  Copy the scratchpad files over the running configuration.
    persist_configurations([(PORTS_CONF, PORTS_CONF_SCRATCHPAD)])

    # Run restart commands, if any.
    ports_commands = get_restart_commands()
    outcome, _, command_messages = run_commands(ports_commands, verbose)
    merge_messages(messages, command_messages)

    if outcome:
        # The commit succeeded.
        remove_scratch_files_and_backups([PORTS_CONF_SCRATCHPAD])
    else:
        # The commit failed.  Revert the configuration.
        if os.path.isfile(PORTS_CONF_SCRATCHPAD + ".bak"):
            persist_configurations([(PORTS_CONF, PORTS_CONF_SCRATCHPAD + ".bak")], False)
        revert_outcome, _, revert_messages = run_commands(ports_commands, verbose)
        merge_messages(messages, revert_messages)
        if not revert_outcome:
            messages["error"].append("Reverting {0} changes failed.".format(PORTS_CONF))

    return (outcome, messages)


def show_config_commands(ifupdown2_wrapper):
    """
    net show configuration commands
    """

    assert os.path.isfile(PORTS_CONF), "This plug-in should only provide syntax if {0} exists.".format(PORTS_CONF)

    ports_by_setting = {}

    for port, setting in get_ports_and_settings():
        if setting not in ports_by_setting:
            ports_by_setting[setting] = []
        ports_by_setting[setting].append(port)

    commands = []

    for setting in sort_for_humans(ports_by_setting.keys()):
        port_ifnames = ["swp{0!s}".format(p) for p in ports_by_setting[setting]]
        port_ifnames_glob = ifnames_to_glob(port_ifnames)
        commands.append("net add interface {0} breakout {1}".format(port_ifnames_glob, setting))

    return (commands, [])


def show_config_summary(summary):
    """
    Do nothing for this plug-in.  The framework requires this function.
    """

    assert isinstance(summary, dict)
    return


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """

    assert os.path.isfile(PORTS_CONF), "This plug-in should only provide syntax if {0} exists.".format(PORTS_CONF)

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert "breakout" in tokens, "Why are you here?"

    if not os.path.isfile(PORTS_CONF_SCRATCHPAD):
        make_scratchpads([(PORTS_CONF, PORTS_CONF_SCRATCHPAD, '')])

    messages = {"output": ''}

    # Determine the new port speed.
    for new_speed in ("1x", "2x", "4x", "4x10", "/4", "3/2", "disabled", "loopback"):
        if new_speed in tokens:
            break
    else:
        # This is a programming error.  The user input should not have matched any command in this plug-in.
        messages["error"] = ["The port speed was not specified."]
        return (False, messages)

    ports_to_edit = set()
    for interface in ifname_expand_glob(tokens["<interface>"]):
        # We should not be working on non-physical interfaces or vlan interfaces.
        index_re = re.compile(r"""swp(L?\d+)$""")
        interface_index = index_re.match(interface)
        if interface_index is None:
            messages["error"] = ["The \"breakout\" command can only be used on physical interfaces, such as swp1, swp2, etc.",
                                 "{0} is not a physical interface.".format(interface)]
            return (False, messages)

        if '.' in interface:
            messages["error"] = ["The \"breakout\" command can not be used on a VLAN subinterface.",
                                 "{0} is not a physical interface.".format(interface)]
            return (False, messages)

        # We should not disrupt bridge or bond members.
        if is_bridge_member(interface) or is_bond_member(interface):
            master = get_master(interface) or ''
            messages["error"] = ["The \"breakout\" command can not be used on intefaces that are bond or bridge members.",
                                 "Please remove interface {} from {} membership and commit changes.".format(interface, master)]
            return (False, messages)

        # We should not disrupt an interface in the configuration.
        if ifname_in_etc_network_interfaces(interface):
            messages["error"] = ["The \"breakout\" command can not be used on intefaces that have a configuration.",
                                 "Please remove interface {} from the config and commit changes.".format(interface)]
            return (False, messages)

        # We should not disrupt a subinterface in the configuration.
        if ifname_prefix_in_etc_network_interfaces("{}s".format(interface)):
            messages["error"] = ["The \"breakout\" command can not be used on intefaces that have a subinterface configuration.",
                                 "Please remove subinterface for {} from the config and commit changes.".format(interface)]
            return (False, messages)

        # Ensure running subinterfaces are not running bond or running bridge members.
        for subinterface in get_interface_subdivisions(interface):
            if is_bridge_member(subinterface) or is_bond_member(subinterface):
                master = get_master(subinterface) or ''
                messages["error"] = ["The \"breakout\" command can not be used on subintefaces that are bond or bridge members.",
                                     "Please remove interface {} from {} membership and commit changes.".format(interface, master)]
                return (False, messages)

        # Edit the interface.
        ports_to_edit.add(interface_index.group(1))

    port_and_settings_re = re.compile(r"""\s*(?P<port>L?\d+)\s*=\s*(?P<setting>\w+)""")

    with open(PORTS_CONF_SCRATCHPAD) as f:
        ports_conf_scratchpad_lines = list(f)

    with open(PORTS_CONF_SCRATCHPAD, 'w') as f:
        for line in ports_conf_scratchpad_lines:
            port_and_settings = port_and_settings_re.match(line)

            if port_and_settings is None or port_and_settings.group("port") not in ports_to_edit:
                # Write the line back to the scratchpad as-is.  It is a comment, blank, or port not being modified.
                f.write(line)
            else:
                if port_and_settings.group("setting").upper() == new_speed.upper():
                    if "info" not in messages:
                        messages["info"] = []
                    messages["info"].append("\"{0}\" configuration already has \"{1}\".".format(port_and_settings.group("port"), new_speed))
                f.write("{0}={1}\n".format(port_and_settings.group("port"), new_speed))

    # Making changes to PORTS_CONF concluded successfully.  Additional changes in /etc/network/interfaces are necessary.
    if net_daemon.wrappers[0][0] == "ifupdown2":
        # ifupdown2 is enabled.
        # TODO - breakout_interfaces doesn't return a value.  Remedy this when ifupdown2.py is converted to a plug-in.
        net_daemon.wrappers[0][1].breakout_interfaces(tokens)
    else:
        messages["warning"] = ["ifupdown2 is not enabled.  You must manually create the new interfaces in /etc/network/interfaces before committing."]

    return (True, messages)


def del_all():
    """
    net del all

    For now, do no alter PORTS_CONF as part of "net del all".
    TODO - Why not?
    """

    return


def get_config_files():
    """
    Return a string with the content of all existing, non-empty configuration files managed with this plug-in.
    """

    return get_config_files_helper(get_managed_files())


def get_pending(use_colors):
    """ Return a string of the pending changes in all managed files. """

    the_diff = get_pending_diffs([(PORTS_CONF, PORTS_CONF_SCRATCHPAD)], use_colors)

    if the_diff:
        if use_colors:
            the_diff += "\033[91m"

        the_diff += """

********************************************************************
********************************************************************
NOTE: "net commit" might run "systemctl restart switchd" to apply the
change to {0}. This can take a few seconds.
********************************************************************
********************************************************************
""".format(PORTS_CONF)

        if use_colors:
            the_diff += "\033[0m"

    return the_diff


def abort_pending():
    remove_scratch_files_and_backups([PORTS_CONF_SCRATCHPAD])


def get_managed_files():
    """ Return a list of managed files. """

    return [PORTS_CONF]


def get_restart_commands(filename=None):
    """
    Return a list of commands that should be called for the given file after a rollback.
    Some plug-ins use this in commit_pending as well.

    Do not return start, restart, or reload commands for disabled services that are not
    already running.
    """

    assert filename is None or filename == PORTS_CONF, "This is the only option."

    if service_is_enabled("switchd.service") or service_is_active("switchd.service"):
        return [["/bin/systemctl", "reset-failed", "switchd.service"],
                ["/bin/systemctl", "restart", "switchd.service"],
                ["/sbin/ifreload", "-a"]]

    log.info("ports.py: switchd.service is disabled and will not be started.")
    return []


def get_ports_and_settings():
    """
    Generate (port::str, setting::str) 2-tuples parsed from PORTS_CONF, which looks like:
        1=4x10G
        2=40G
        3=40G
        4=40G
        ...
    """

    with open(PORTS_CONF) as f:
        ports_and_settings = re.findall(r"""^\s*(L?\d+)\s*=\s*(\S+)""", f.read(), re.MULTILINE)

    for port, setting in ports_and_settings:
        if "4x10" in setting:
            setting = "4x10"
        elif "4x" in setting:
            setting = "4x"
        elif "2x" in setting:
            setting = "2x"
        elif "/4" in setting:
            setting = "/4"
        elif "3/2" in setting:
            setting = "3/2"
        elif "disable" in setting:
            # This catches "disable" and "disabled."
            setting = "disabled"
        elif "loopback" in setting:
            setting = "loopback"
        else:
            setting = "1x"

        yield (port, setting)
