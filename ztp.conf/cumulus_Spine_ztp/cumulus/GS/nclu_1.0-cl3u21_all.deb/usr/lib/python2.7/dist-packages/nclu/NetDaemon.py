"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from datetime import datetime
from network_docopt import get_network_docopt_info, NetworkDocopt
from nclu import PENDING_COMMANDS_FILE, WORKING_DIRECTORIES_PERMISSIONS, WORKING_DIRECTORY
from nclu.capturing import Capturing
from nclu.docstring import build_doc_string
from nclu.execute_command import basic_usage, execute_command
from nclu.plugins import is_modular
from nclu.plugins.ptp import tab_wildcard_ptp
from nclu.plugins.transponders import (
    tab_transponder_port,
    tab_transponder_frequency,
    tab_transponder_module
)
from nclu.tab_completion import tab_complete_policer, tab_interface, tab_wildcard_snapshot
from nclu.wrappers.accesslist import (
    match_acl_ipv4,
    match_acl_ipv6,
    match_acl_mac,
    match_policer_name,
    tab_acl_ipv4,
    tab_acl_ipv6,
    tab_acl_mac,
    tab_policer_name
)
from nclu.plugins.frr.matchtab import (
    match_aspath_access_list,
    match_bgppeer,
    match_community,
    match_community_list,
    match_extcommunity,
    match_extcommunity_list,
    match_route_map,
    match_peer_group,
    match_prefix_list_v4,
    match_prefix_list_v6,
    match_rd,
    match_route_target,
    tab_aspath_access_list,
    tab_bgppeer,
    tab_community_list,
    tab_extcommunity_list,
    tab_peergroup,
    tab_prefix_list_v4,
    tab_prefix_list_v6,
    tab_route_map
)
from sys import exit
from threading import Event
import grp
import json
import logging
import nclu.wrappers
import os
import pwd
import re
import signal
import socket
import struct


NETD_CONF = "/etc/netd.conf"
UDS_PATH = os.path.join(WORKING_DIRECTORY, "uds")
IFUPDOWN2_ADDONS_PATH = "/usr/share/ifupdown2/addons"
UDS_PERMISSIONS = 0o666

log = logging.getLogger("netd")

extra_help_text = """
    <interface>         : an interface such as swp1, swp2, etc
    <ipv4>              : an IPv4 address
    <number-range-list> : example: "1-5,8,10-12,15"
    <number-range>      : example: "1024-1200"
    <number>            : any integer
    <text>              : any text
    <wildcard>          : any text
    acl                 : access-list
    bgp                 : Border Gateway Protocol
    bond                : bond, port-channel, etc
    bridge              : a layer2 bridge
    clag                : Multi-Chassis Link Aggregation
    commands            : a list of 'net' commands
    configuration       : settings, configuration state, etc
    confirm             : approve, acknowledge, etc
    delete              : to remove
    description         : description
    files               : configuration files
    history             : history
    hostname            : local hostname
    last                : the most recent 'net commit' snapshot
    lnv                 : Lightweight Network Virtualization
    management-vrf      : Management VRF
    net                 : command line tool for nclu
    pbr                 : Policy Based Routing
    ospf                : Open Shortest Path First (OSPFv2)
    ospf6               : Open Shortest Path First (OSPFv3)
    rollback            : revert to a previous configuration state
    verbose             : show detailed output
"""


class NetDaemon(object):
    """
    Encapsulate a configured daemon used to process NCLU commands.
    The configuration is read from a file passed to the constructor.
    """

    def __init__(self, config_file=NETD_CONF):
        # If set, the user wants to stop the daemon.
        self.shutdown_event = Event()

        self.config_file = config_file
        self.reload()

        # Multiple users can interact with an instance of NetDaemon.  We need to keep track
        # of them so, when a user issues "net rollback ...", we know which prior state to target.
        # The keys shall be a 2-tuple of (uid, gid).  The values . . . TODO.
        self.future_rollbacks = {}

    def signal_handler(self, signum, frame):
        """
        This method is used to break out of the "while True" loop in self.main()
        in response to SIGINT or SIGTERM.  The main thread (netd) should set this
        behavior with calls to signal.signal.

        The signal handling framework requires two parameters.
        """

        assert signum in (signal.SIGINT, signal.SIGTERM)
        log.info("Received SIGINT or SIGTERM ({0}).".format(signum))
        self.shutdown_event.set()

    def reload_handler(self, signum, frame):
        """
        Reload the configuration, and reinitalize the parser, in response to SIGHUP.
        The main thread (netd) should set this behavior with calls to signal.signal.

        The signal handling framework requires two parameters.
        """

        assert signum == signal.SIGHUP
        log.info("Received SIGHUP.")
        self.reload()

    def reload(self):
        """
        Execute common steps for instantiation and the reload handler.
        """

        self.load_configuration()
        self.wrappers = make_wrappers_list(self.enabled_wrappers, self.show_linux_command, self.color_diffs)

        # Initialize a NetworkDocopt instance to parse the user input.  Note that "execute_command" uses NetDaemon.keywords.
        docstring, self.keywords, helptext = build_doc_string(basic_usage + '\n' + extra_help_text, self.enabled_wrappers, self.enabled_plugins, self.blacklist)
        self.nclu_parser = NetworkDocopt(docstring, True)
        self.nclu_parser.helptext["global"] = helptext
        self.nclu_parser.tab_complete_policer = tab_complete_policer

        # Populate command specific helptext.
        assert len(self.enabled_wrappers) > 0, "If the wrapper paradigm has been removed, edit this block."
        for name, _ in self.wrappers:
            m = __import__("nclu.wrappers." + name, fromlist=["per_command_helptext"])
            if hasattr(m, "per_command_helptext"):
                log.debug("Found per_command_helptext for {0}.".format(name))
                for (command, command_helptext) in m.per_command_helptext.items():
                    self.nclu_parser.add_per_command_helptext(command, command_helptext)
        for name in self.enabled_plugins:
            m = __import__("nclu.plugins." + name, fromlist=["per_command_helptext"])
            if hasattr(m, "per_command_helptext"):
                log.debug("Found per_command_helptext for {0}.".format(name))
                for (command, command_helptext) in m.per_command_helptext.items():
                    self.nclu_parser.add_per_command_helptext(command, command_helptext)

        # TODO - The next three blocks should be delegated to the relevant wrappers for enhanced modularity.
        if "frr" in self.enabled_plugins:
            # Match the <...> tags in the parser.
            self.nclu_parser.add_tag_matcher("<as-path-access-list>", match_aspath_access_list, True)
            self.nclu_parser.add_tag_matcher("<bgppeer>", match_bgppeer, False)
            self.nclu_parser.add_tag_matcher("<community>", match_community, False)
            self.nclu_parser.add_tag_matcher("<community-list>", match_community_list, True)
            self.nclu_parser.add_tag_matcher("<extcommunity>", match_extcommunity, False)
            self.nclu_parser.add_tag_matcher("<extcommunity-list>", match_extcommunity_list, True)
            self.nclu_parser.add_tag_matcher("<peergroup>", match_peer_group, True)
            self.nclu_parser.add_tag_matcher("<prefix-list-v4>", match_prefix_list_v4, True)
            self.nclu_parser.add_tag_matcher("<prefix-list-v6>", match_prefix_list_v6, True)
            self.nclu_parser.add_tag_matcher("<route-map>", match_route_map, True)
            self.nclu_parser.add_tag_matcher("<rd>", match_rd, False)
            self.nclu_parser.add_tag_matcher("<route-target>", match_route_target, False)

            # Expand the tab complete options for a <...> tag.
            self.nclu_parser.add_tab_complete_hook("<as-path-access-list>", tab_aspath_access_list)
            self.nclu_parser.add_tab_complete_hook("<bgppeer>", tab_bgppeer)
            self.nclu_parser.add_tab_complete_hook("<community-list>", tab_community_list)
            self.nclu_parser.add_tab_complete_hook("<extcommunity-list>", tab_extcommunity_list)
            self.nclu_parser.add_tab_complete_hook("<interface>", tab_interface)
            self.nclu_parser.add_tab_complete_hook("<interface-list>", tab_interface)
            self.nclu_parser.add_tab_complete_hook("<peergroup>", tab_peergroup)
            self.nclu_parser.add_tab_complete_hook("<prefix-list-v4>", tab_prefix_list_v4)
            self.nclu_parser.add_tab_complete_hook("<prefix-list-v6>", tab_prefix_list_v6)
            self.nclu_parser.add_tab_complete_hook("<route-map>", tab_route_map)
            self.nclu_parser.add_tab_complete_hook("<wildcard-snapshot>", tab_wildcard_snapshot)

        assert "accesslist" not in self.enabled_plugins, "Change the following line."
        if "accesslist" in self.enabled_wrappers:
            # Match the <...> tags in the parser.
            self.nclu_parser.add_tag_matcher("<acl-ipv4>", match_acl_ipv4, False)
            self.nclu_parser.add_tag_matcher("<acl-ipv6>", match_acl_ipv6, False)
            self.nclu_parser.add_tag_matcher("<acl-mac>", match_acl_mac, False)
            self.nclu_parser.add_tag_matcher("<policer-name>", match_policer_name, False)

            # Expand the tab complete options for a <...> tag.
            self.nclu_parser.add_tab_complete_hook("<acl-ipv4>", tab_acl_ipv4)
            self.nclu_parser.add_tab_complete_hook("<acl-ipv6>", tab_acl_ipv6)
            self.nclu_parser.add_tab_complete_hook("<acl-mac>", tab_acl_mac)
            self.nclu_parser.add_tab_complete_hook("<policer-name>", tab_policer_name)

        if "ptp" in self.enabled_plugins:
            self.nclu_parser.add_tab_complete_hook("<wildcard-ptp>", tab_wildcard_ptp)

        if "transponders" in self.enabled_plugins:
            self.nclu_parser.add_tab_complete_hook("<trans-port>", tab_transponder_port)
            self.nclu_parser.add_tab_complete_hook("<trans-frequency>", tab_transponder_frequency)
            self.nclu_parser.add_tab_complete_hook("<trans-module>", tab_transponder_module)

    def load_configuration(self):
        """
        Set class attributes as specified in self.config_file.

        NOTE: The configuration file should not contain multiple lines setting the same parameters.
        This is not explicitly prohibited, but parts of such a file will be ignored.
        """

        try:
            # Read the configuration file.
            with open(self.config_file) as f:
                config_text = f.read()
        except OSError as e:
            exit("Couldn't read the configuration file, {0}.  ({1})".format(self.config_file, e))

        # These boolean attributes pertain to how the output returned to the user should look.
        self.show_linux_command = re.search(r"""^\s*show_linux_command\s*=\s*True""", config_text, re.IGNORECASE | re.MULTILINE) is not None
        self.color_diffs = re.search(r"""^\s*color_diffs\s*=\s*True""", config_text, re.IGNORECASE | re.MULTILINE) is not None

        # Populate the permissions attributes.  These are four frozensets that specify who can do what.  If the permission is
        # not specified in the configuration file, or if it is set to blank, the resulting attribute will be an empty frozenset.
        for permissions_group in ("users_with_edit", "users_with_show", "groups_with_edit", "groups_with_show"):
            users_re = re.search(r"""^\s*{0}\s*=\s*(?P<users>\S[\S\t ,]*)$""".format(permissions_group), config_text, re.IGNORECASE | re.MULTILINE)
            # TODO - Should users be mapped to lowercase?  Are "root" and "ROOT" different to the OS?
            setattr(self, permissions_group, frozenset([] if (users_re is None) else users_re.group("users").replace(',', ' ').split()))

        # Populate the blacklist for ifupdown.  Blacklisted terms serve to filter the available ifupdown2 commands.
        blacklist_re = re.search(r"""^\s*ifupdown_blacklist\s*=\s*(?P<blacklist>\S[\S\t ,]*)$""", config_text, re.IGNORECASE | re.MULTILINE)
        self.blacklist = frozenset([] if (blacklist_re is None) else blacklist_re.group("blacklist").replace(',', ' ').split())

        # Get a lowercase set of all components configured to be enabled.  The netmisc and ports components are always available.
        self.enabled_wrappers = set(["netmisc"])
        self.enabled_plugins = set(["ports"])
        for component in map(str.lower, re.findall(r"""^\s*enable_(\S+)\s*=\s*True""", config_text, re.IGNORECASE | re.MULTILINE)):
            if component in ("time", "nclu_time"):
                # This name was changed in CL 3.6 so as not to collide with the Python standard library.
                component = "ntp"

            try:
                if is_modular(component):
                    __import__("nclu.plugins." + component)
                    self.enabled_plugins.add(component)
                else:
                    __import__("nclu.wrappers." + component)
                    self.enabled_wrappers.add(component)
            except ImportError:
                log.warning("Cannot enable {0}.".format(component))
        for component in (self.enabled_wrappers | self.enabled_plugins):
            if not os.path.isdir(os.path.join(WORKING_DIRECTORY, component)):
                # Create a working directory for the component.  This is to diminish the chance of raising OSError downstream.
                os.makedirs(os.path.join(WORKING_DIRECTORY, component), mode=WORKING_DIRECTORIES_PERMISSIONS)
        assert len(self.enabled_wrappers) > 0, "If the wrapper paradigm has been removed, edit this block.  Also delete ConfigWrapperBase, etc."

        if "ports" not in self.enabled_plugins:
            self.enabled_plugins.add("ports")
            log.warning("\"ports\" is being enabled even though it is not enabled in {0}.".format(self.config_file))

    def main(self, server_address=UDS_PATH):
        """
        Connect to a Unix domain socket (UDS), and exchange information with clients (i.e. net).
        This method contains an infinite loop from which the user can exit with an interrupt signal.

        The client transmits a command as a list of strings (i.e. sys.argv from "net").  This method
        receives the command, tests that the user has adequate permission, calls a function to execute
        the command, and transmits the output of execution to the client.
        """

        caught_exception = False

        # Log the process ID upon start-up.
        try:
            netd_pid = os.getpid()
        except OSError as e:
            # This should not halt execution, but the program should exit non-zero.
            caught_exception = True
            log.exception(e)
            netd_pid = "Error"
        log.info("netd started with process ID (pid) {0}.".format(netd_pid))

        # powerpc is the only non-generic we care about. alpha, mips, sparc, and parisc also have non-generic values.
        if re.match(r"""ppc|powerpc""", os.uname()[4]) is not None:
            so_passcred = 20
            so_peercred = 21
        else:
            so_passcred = 16
            so_peercred = 17

        # Create a Unix domain socket (UDS) that instances of "net" use to communicate with netd.
        uds = open_socket(server_address, so_passcred)

        # This is the main loop for processing client requests.  All exceptions, other than not being able
        # to open a socket, should be caught so that the daemon doesn't crash.
        while True:

            if self.shutdown_event.is_set():
                log.debug("Shutdown signal received.  Breaking out of the loop.")
                try:
                    uds.close()
                except socket.error as e:
                    log.exception(e)
                    caught_exception = True
                break

            try:
                # Accept a connection from a client (i.e. net).
                connection, _ = uds.accept()
            except socket.error as e:
                if isinstance(e.args, tuple) and e[0] == 4:
                    # TODO - Why is the block necessary?  Doesn't signal_handler do the same thing?
                    # 4 is "Interrupted system call", a.k.a. SIGINT.  The user wants to stop netd.
                    log.info("socket.accept() caught signal.  Starting shutdown.")
                    self.shutdown_event.set()
                else:
                    log.info("netd socket {0} hit an error:\n{1}".format(server_address, e))
                    uds.close()

                    # Re-initialize the UDS.
                    uds = open_socket(server_address, so_passcred)

                # Avoid the subsequent reference to "connection", which might not be initialized.
                continue

            try:
                # Receive the request from the "net" instance.
                data = connection.recv(4096)
                data = json.loads(data)
                assert isinstance(data, list), "\"net\" should transmit a JSON string representation of sys.args."
            except (ValueError, socket.error) as e:
                # Received bad input from the client.
                log.exception(e)
                reply_and_close(connection, "ERROR: Netd couldn't parse the input.")
                continue

            if "Press <ENTER> to confirm connectivity." in data:
                # The user ran "net commit confirm" and pressed Enter to accept the changes.
                self.net_commit_confirmed = True

                # Remove the parameter from the data because it does not match any NCLU command.
                data.remove("Press <ENTER> to confirm connectivity.")
            else:
                self.net_commit_confirmed = False

            # Wrap everything else in try/except to avoid crashing.
            try:

                # uid, gid, and "user" are stored as attributes because they are referenced
                # downstream for the rollback functionality.

                # These values independently are integers or None.
                self.uid, self.gid = get_uid_gid(connection, so_peercred)

                command = ' '.join(data)

                non_ascii_chars = [c for c in command if ord(c) > 127]
                if non_ascii_chars:
                    # Don't process commands with non-ascii characters.
                    # TODO - Move to Python3, which supports unicode natively, and remove this restriction.
                    reply_and_close(connection, "ERROR: Non-ASCII characters are not supported: ({0})".format(non_ascii_chars))
                    continue

                # The logs would be pretty chatty if we logged all of the TAB complete
                # calls.  Make those log.debug() and everything else log.info().
                self.user = "Unknown" if (self.uid is None) else pwd.getpwuid(self.uid)[0]
                if "--completions" in data:
                    log.debug("RXed: user {0}, command \"{1}\"".format(self.user, command))
                else:
                    log.info("RXed: user {0}, command \"{1}\"".format(self.user, command))

                # Determine if the user is trying to display options with tab completion.  This is
                # shell-dependent, and it should not require checking user permissions.
                if "--completions" in data:
                    # bash model
                    # "data" is the original "data" but with the "--completions X" at the end removed.
                    print_options, ended_with_space, data = get_network_docopt_info(data)
                    options_style = "bash"
                elif "--fish-completion" in data:
                    # fish model
                    ended_with_space = True if data[-1].endswith(' ') else False
                    # For "foo sh <TAB>", "data" will be ["foo", "--fish-completion", "foo show "].
                    data = data[-1].strip().split()
                    print_options = True
                    options_style = "fish"
                else:
                    print_options = False
                    options_style = None

                if print_options:
                    # Display tab completions.

                    # TODO - Capturing output is a work-around.  See Capturing.__doc__.
                    with Capturing() as reply:
                        self.nclu_parser.print_options(ended_with_space, options_style, data)
                    if not reply:
                        log.debug("NetDaemon.main - If Capturing is no longer in use, edit this code.")

                    # Transmit the reply back to the "net" client.
                    reply_and_close(connection, '\n'.join(reply))
                    self.nclu_parser.re_init()
                    continue

                # The user isn't requesting tab options.

                if len(data) == 3 and ' '.join(data[1:]) in ("help verbose", "verbose help"):
                    # Return all available commands.
                    reply_and_close(connection, self.nclu_parser.docstring)
                    continue

                # Validate, expand, and tokenize the command, if possible.
                outcome, message = self.nclu_parser.run(data)

                if not outcome or (not self.nclu_parser.argv_expanded and len(data) > 2):
                    if not outcome and not message.startswith("ERROR"):
                        # Couldn't parse the command.
                        message = "ERROR: " + message
                    # Else, the user is running a "help" command other than "net" or "net [-h|help|--help]".
                    # For example, "net help interface".

                    reply_and_close(connection, message)
                    self.nclu_parser.re_init()
                    continue

                has_permission = True
                add_to_pending_list = False
                if self.nclu_parser.argv_expanded and self.nclu_parser.argv_expanded[1] != "example":
                    # Verify permissions for commands other than "net [-h|help|--help]" and "net example".
                    # self.nclu_parser.argv_expanded==[] for the help commands.

                    if self.nclu_parser.argv_expanded[1] == "show":
                        # The user wants to run a show command.
                        has_permission = self.user_may_show(self.uid, self.gid)
                    else:
                        # The user wants to run a command the requires "edit" permission.
                        has_permission = self.user_may_edit(self.uid, self.gid)

                        if self.nclu_parser.argv_expanded[1] not in ("abort", "commit", "pending", "rollback"):
                            add_to_pending_list = True
                # Else, self.nclu_parser.argv_expanded==[], or the user is running an "example" command.

                if has_permission:
                    # Execute the command.
                    success, reply = execute_command(self.nclu_parser.argv_expanded, self)
                    assert isinstance(success, bool), "Did the command succeed?"
                    assert isinstance(reply, (str, unicode)), "This is the output to display to the user."
                else:
                    success = False
                    reply = "You do not have permission to execute that command."

                if success and add_to_pending_list:
                    try:
                        store_pending_command(self.user, ' '.join(self.nclu_parser.argv_expanded))
                    except OSError as e:
                        log.warning("Couldn't append the command to the pending commands list: {0}".format(e))
                        reply += "\nWARNING: Couldn't append the command to the pending commands list.  See the log."

                # Transmit the reply back to the "net" client.  If the command was not successful,
                # prepend "ERROR: ".  The "net" instance will respond to "ERROR" by exiting non-zero.
                reply_and_close(connection, ('' if success else "ERROR: ") + reply)
                self.nclu_parser.re_init()

            except Exception as e:
                # TODO - Catch more specific exceptions?
                log.exception(e)
                caught_exception = True
                error_details = "{0}\n".format(e) if str(e) else ''
                reply_and_close(connection, "ERROR: {0}See /var/log/netd.log for more details.".format(error_details))
                self.nclu_parser.re_init()

        log.info("netd is stopping with process ID (pid) {0}.".format(netd_pid))

        if caught_exception:
            exit("Caught an exception in NetDaemon.main().  See the log for details.")
        # Else, let the upstream code (netd) dictate the return value.

    def user_may_edit(self, uid, gid):
        """
        Return True if the given user/group is allowed to make networking changes.
        Otherwise, return False.  Any command that isn't a "show" command falls
        under this category.
        """

        return self.permissions_helper(uid, gid, "users_with_edit", "groups_with_edit")

    def user_may_show(self, uid, gid):
        """
        Return True if this user/group is allowed to run show commands.  Otherwise,
        return False.
        """

        return self.permissions_helper(uid, gid, "users_with_show", "groups_with_show")

    def permissions_helper(self, uid, gid, users_name, groups_name):
        """
        Return True if the given user/group has permission.  Otherwise, return False.
        """

        assert uid is None or isinstance(uid, int)
        assert gid is None or isinstance(gid, int)

        if uid is None:
            user = None
        else:
            # Test if the user has permission.
            try:
                user = pwd.getpwuid(uid)[0]

                if user in getattr(self, users_name):
                    # The user has permission.
                    return True
            except KeyError:
                # There is no password entry for the given user.
                user = None

        if gid is not None:
            # Test if the group has permission.
            try:
                group = grp.getgrgid(gid)[0]

                if group in getattr(self, groups_name):
                    # The group has permission.
                    return True
            except KeyError:
                # There is no database entry for the given group.
                pass

        # Test if the users and groups with permission correspond to the given uid or gid.
        # TODO - This code might fail for the case of multiple accounts with the same uid.

        if uid is not None:
            for tmp_user in getattr(self, users_name):
                try:
                    tmp_uid = pwd.getpwnam(tmp_user)[2]

                    if uid == tmp_uid:
                        return True
                except KeyError:
                    # There is no password entry for this tmp_user.
                    pass

        for tmp_group in getattr(self, groups_name):
            try:
                group_db = grp.getgrnam(tmp_group)

                if (user is not None and user in group_db.gr_mem) or (gid is not None and gid == group_db.gr_gid):
                    return True

            except KeyError:
                # There is no database entry for this tmp_group.
                pass

        return False


def reply_and_close(connection, reply=''):

    assert isinstance(reply, (str, unicode))

    try:
        # Transmit the reply to the "net" instance.
        connection.send(reply)
    except socket.error as e:
        log.info("Sending the reply failed. ({0})".format(e))

    connection.close()


def open_socket(uds_address, so_passcred):
    """
    Open the given Unix domain socket (UDS), and return its descriptor.
    """

    if os.path.exists(uds_address):
        os.remove(uds_address)

    try:
        uds = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        uds.bind(uds_address)
        uds.setsockopt(socket.SOL_SOCKET, so_passcred, 1)
        uds.listen(1)
        os.chmod(uds_address, UDS_PERMISSIONS)
    except socket.error as e:
        # Couldn't open/bind/listen-to the socket.  Halt the daemon.
        exit(str(e))

    return uds


def get_uid_gid(uds, so_peercred):
    """
    Obtain the effective user and group IDs of the process on the other end
    of a socket. SO_PEERCRED is used so the information returned is trustworthy.
    We are OK with root saying they are somebody less privileged.
    """

    try:
        credentials = uds.getsockopt(socket.SOL_SOCKET, so_peercred, struct.calcsize('3i'))
        (_, uid, gid) = struct.unpack('3i', credentials)

        if uid == -1:
            uid = None

        if gid == -1:
            gid = None

    except socket.error as e:
        log.error("socket get credentials failed: {0}".format(e))
        uid = None
        gid = None

    return (uid, gid)


def store_pending_command(user, command):
    """
    Append the given command to a file.  This might raise OSError.
    """

    with open(PENDING_COMMANDS_FILE, 'a') as f:
        f.write("{0}\t{1}\t{2}\n".format(user, datetime.now(), command))
    os.chmod(PENDING_COMMANDS_FILE, 0o600)


def make_wrappers_list(wrappers, show_linux_command, color_diffs):
    """
    Given a set of wrapper names (strings), return a list of 2-tuples of (str, ConfigWrapper)
    where the string is the name of the wrappered component (dns, dhcp, etc.), and
    ConfigWrapper is an object instance as defined in the wrapper code.  Note that not all
    ConfigWrapper objects derive from ConfigBaseWrapper.
    """

    assert isinstance(wrappers, set)
    assert "netmisc" in wrappers, "The netmisc wrapper should always be available."
    assert len(wrappers) > 0, "If the wrapper paradigm has been removed, remove this function."

    wrappers_list = []

    # Order matters!  If ifupdown2 is installed, add the ifupdown2 wrapper first.  This is because
    # some other wrappers depend on ifupdown2 changes.
    if "ifupdown2" in wrappers:
        if os.path.exists(IFUPDOWN2_ADDONS_PATH):
            # ifupdown2 is installed.  Initialize and append the global ifupdown2 wrapper in ifupdown2.py.
            nclu.wrappers.ifupdown2.initialize_global_ifupdown2(show_linux_command, color_diffs)
            wrappers_list.append(("ifupdown2", nclu.wrappers.ifupdown2.ifupdown2_wrapper))
        else:
            log.warning("ifupdown2 is configured to be enabled, but it is not installed.")

    # Append the other component wrappers in no particular order.
    for component in (wrappers - set(["ifupdown2"])):
        m = __import__("nclu.wrappers." + component, fromlist=["ConfigWrapper"])
        assert hasattr(m, "ConfigWrapper"), "The {0} wrapper is missing a ConfigWrapper class.".format(component)
        wrappers_list.append((component, m.ConfigWrapper(show_linux_command, color_diffs)))

    return wrappers_list
