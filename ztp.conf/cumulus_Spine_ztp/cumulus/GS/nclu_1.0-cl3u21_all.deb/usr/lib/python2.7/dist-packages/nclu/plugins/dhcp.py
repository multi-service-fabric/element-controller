"""
Copyright (C) 2016, 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt

----------------------------------------------------------------------------------------

Usage:
    net show configuration dhcp [json]

    # dhcp relay (IPv4)
    net add dhcp relay server <ipv4>
    net del dhcp relay server [<ipv4>]
    net add dhcp relay interface <interface>
    net del dhcp relay interface [<interface>]

    # dhcp relay6 (IPv6)
    net add dhcp relay6 upstream <interface> [<ipv6>]
    net del dhcp relay6 upstream [<interface>]
    net add dhcp relay6 downstream <interface> [<ipv6>]
    net del dhcp relay6 downstream [<interface>]

    # dhcp server (IPv4)
    net add dhcp server <interface>
    net del dhcp server [<interface>]

    # dhcp server6 (IPv6)
    net add dhcp server6 <interface>
    net del dhcp server6 [<interface>]

Options:
    dhcp         : Dynamic Host Configuration Protocol
    relay        : IPv4 relay agent
    relay6       : IPv6 relay agent
    server       : IPv4 server
    server6      : IPv6 server
    downstream   : A downstream interface
    upstream     : An upstream interface
    interface    : Summary info of all interfaces
    <interface>  : Summary info of all interfaces
    json         : Print output in json
    <ipv4>       : An IPv4 address
    <ipv6>       : An IPv6 address
"""

import logging
import os
import re
from collections import OrderedDict
from nclu import ifname_expand_glob, ifnames_to_glob, files_match, WORKING_DIRECTORY
from nclu.NetDaemon import NetDaemon
from nclu.plugins import (
    get_config_files_helper,
    get_pending_diffs,
    make_scratchpads,
    merge_messages,
    persist_configurations,
    remove_scratch_files_and_backups,
    run_commands,
)
from network_docopt import sort_for_humans

# File name constants

# DHCP IPv4 relay
ISC_DHCP_RELAY4 = "/etc/default/isc-dhcp-relay"
ISC_DHCP_RELAY4_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "dhcp", os.path.basename(ISC_DHCP_RELAY4))

# DHCP IPv6 relay
ISC_DHCP_RELAY6 = "/etc/default/isc-dhcp-relay6"
ISC_DHCP_RELAY6_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "dhcp", os.path.basename(ISC_DHCP_RELAY6))

# DHCP IPv4 server
DHCPD_CONFIG4 = "/etc/dhcp/dhcpd.conf"
DHCPD_PID4 = "/run/dhcpd.pid"
ISC_DHCP_SERVER4 = "/etc/default/isc-dhcp-server"
ISC_DHCP_SERVER4_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "dhcp", os.path.basename(ISC_DHCP_SERVER4))

# DHCP IPv6 server
DHCPD_CONFIG6 = "/etc/dhcp/dhcpd6.conf"
DHCPD_PID6 = "/run/dhcpd6.pid"
ISC_DHCP_SERVER6 = "/etc/default/isc-dhcp-server6"
ISC_DHCP_SERVER6_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "dhcp", os.path.basename(ISC_DHCP_SERVER6))

# This is appropriate for ISC_DHCP_RELAY4 and ISC_DHCP_RELAY6.
RELAY_DEFAULT = """\
SERVERS=""
INTF_CMD=""
OPTIONS=""
"""

# This is appropriate for ISC_DHCP_SERVER4 or ISC_DHCP_SERVER6, depending on the contents of the
# "format" string that must be used with this string.
SERVER_DEFAULT = """\
DHCPD_CONF="-cf {0}"
DHCPD_PID="-pf {0}"
OPTIONS=""
INTERFACES=""
"""

log = logging.getLogger("netd")


def commit_pending(verbose):
    """
    Copy scratchpad files over configuration files, call necessary restart commands, etc.

    Return a 2-tuple of (bool, dict).  The boolean indicates if the commit succeeded.
    The dictionary is as described in nclu/plugins/__init__.py:execute_modular.
    """

    success, messages = commit_pending_ipv4_relay(verbose)
    if not success:
        _, revert_messages = revert_ipv4_relay(verbose)
        merge_messages(messages, revert_messages)
        return (False, messages)

    success, more_messages = commit_pending_ipv4_server(verbose)
    merge_messages(messages, more_messages)
    if not success:
        _, revert_messages = revert_ipv4_server(verbose)
        merge_messages(messages, revert_messages)
        _, revert_messages = revert_ipv4_relay(verbose)
        merge_messages(messages, revert_messages)
        return (False, messages)

    success, more_messages = commit_pending_ipv6_relay(verbose)
    merge_messages(messages, more_messages)
    if not success:
        _, revert_messages = revert_ipv6_relay(verbose)
        merge_messages(messages, revert_messages)
        _, revert_messages = revert_ipv4_server(verbose)
        merge_messages(messages, revert_messages)
        _, revert_messages = revert_ipv4_relay(verbose)
        merge_messages(messages, revert_messages)
        return (False, messages)

    success, more_messages = commit_pending_ipv6_server(verbose)
    merge_messages(messages, more_messages)
    if not success:
        _, revert_messages = revert_ipv6_server(verbose)
        merge_messages(messages, revert_messages)
        _, revert_messages = revert_ipv6_relay(verbose)
        merge_messages(messages, revert_messages)
        _, revert_messages = revert_ipv4_server(verbose)
        merge_messages(messages, revert_messages)
        _, revert_messages = revert_ipv4_relay(verbose)
        merge_messages(messages, revert_messages)
        return (False, messages)

    return (True, messages)


def commit_pending_relay_helper(scratchpad, config, verbose):
    """ Commit pending changes in the given relay scratchpad, and return the standard 2-tuple. """

    if not os.path.isfile(scratchpad) or files_match(config, scratchpad):
        # There are no changes to commit.
        return (True, {"output": ''})

    with open(scratchpad) as f:
        scratchpad_contents = f.read()

    # Don't permit configuring a DHCP relay interface without having a configured relay server.
    if re.search(r'''INTF_CMD\s*=\s*"\s*\S.*?"''', scratchpad_contents) is not None and \
            re.search(r'''SERVER\s*=\s*"\s*"''', scratchpad_contents) is not None:
        if '4' in config:
            error_message = "First run \"net add dhcp relay server <ipv4>\"."
        else:
            error_message = "First run \"net add dhcp relay6 downstream <interface> [<ipv6>]\"."
        return (False, {"output": '', "error": [error_message]})

    persist_configurations([(config, scratchpad)])

    outcome, _, messages = run_commands(get_restart_commands(config), verbose)

    if outcome:
        # The commit succeeded.
        remove_scratch_files_and_backups([scratchpad])

    return (outcome, messages)


def commit_pending_ipv4_relay(verbose):
    """
    Commit pending changes in ISC_DHCP_RELAY4_SCRATCHPAD, and return the standard 2-tuple.
    """

    return commit_pending_relay_helper(ISC_DHCP_RELAY4_SCRATCHPAD, ISC_DHCP_RELAY4, verbose)


def commit_pending_ipv6_relay(verbose):
    """
    Commit pending changes in ISC_DHCP_RELAY4_SCRATCHPAD, and return the standard 2-tuple.
    """

    return commit_pending_relay_helper(ISC_DHCP_RELAY6_SCRATCHPAD, ISC_DHCP_RELAY6, verbose)


def revert_helper(scratchpad, config, verbose):
    """ Revert pending changes, and return the standard 2-tuple. """

    assert os.path.isfile(scratchpad + ".bak")

    persist_configurations([(config, scratchpad + ".bak")], False)
    outcome, _, messages = run_commands(get_restart_commands(config), verbose)
    return (outcome, messages)


def revert_ipv4_relay(verbose):
    """
    Revert changes to ISC_DHCP_RELAY4, and return the standard 2-tuple.
    """

    return revert_helper(ISC_DHCP_RELAY4_SCRATCHPAD, ISC_DHCP_RELAY4, verbose)


def revert_ipv6_relay(verbose):
    """
    Revert changes to ISC_DHCP_RELAY6, and return the standard 2-tuple.
    """

    return revert_helper(ISC_DHCP_RELAY6_SCRATCHPAD, ISC_DHCP_RELAY6, verbose)


def commit_pending_server_helper(scratchpad, config, verbose):
    """
    Commit pending changes in the given server scratchpad, and return the standard 2-tuple.
    """

    if not os.path.isfile(scratchpad) or files_match(config, scratchpad):
        # There are no changes to commit.
        return (True, {"output": ''})

    persist_configurations([(config, scratchpad)])

    outcome, _, messages = run_commands(get_restart_commands(config), verbose)

    if outcome:
        # The commit succeeded.
        remove_scratch_files_and_backups([scratchpad])

    return (outcome, messages)


def commit_pending_ipv4_server(verbose):
    """
    Commit pending changes in ISC_DHCP_SERVER4_SCRATCHPAD, and return the standard 2-tuple.
    """

    return commit_pending_server_helper(ISC_DHCP_SERVER4_SCRATCHPAD, ISC_DHCP_SERVER4, verbose)


def commit_pending_ipv6_server(verbose):
    """
    Commit pending changes in ISC_DHCP_SERVER6_SCRATCHPAD, and return the standard 2-tuple.
    """

    return commit_pending_server_helper(ISC_DHCP_SERVER6_SCRATCHPAD, ISC_DHCP_SERVER6, verbose)


def revert_ipv4_server(verbose):
    """ Revert changes to ISC_DHCP_SERVER4, and return the standard 2-tuple. """

    return revert_helper(ISC_DHCP_SERVER4_SCRATCHPAD, ISC_DHCP_SERVER4, verbose)


def revert_ipv6_server(verbose):
    """ Revert changes to ISC_DHCP_SERVER6, and return the standard 2-tuple. """

    return revert_helper(ISC_DHCP_SERVER6_SCRATCHPAD, ISC_DHCP_SERVER6, verbose)


def show_config_commands(ifupdown2_wrapper):
    """
    net show configuration commands
    """

    dhcp_relay_servers, dhcp_relay_interfaces, dhcp_servers, dhcp_relay6_servers, dhcp_relay6_interfaces, dhcp_servers6 = get_dhcp_configuration()
    commands = []

    # DHCP IPv4
    commands.extend(["net add dhcp relay server {0}".format(server) for server in dhcp_relay_servers])
    commands.extend(["net add dhcp relay interface {0}".format(interface) for interface in dhcp_relay_interfaces])
    commands.extend(["net add dhcp server {0}".format(server) for server in dhcp_servers])

    # DHCP IPv6
    commands.extend(["net add dhcp relay6 server {0}".format(server) for server in dhcp_relay6_servers])
    commands.extend(["net add dhcp relay6 interface {0}".format(interface) for interface in dhcp_relay6_interfaces])
    commands.extend(["net add dhcp server6 {0}".format(server) for server in dhcp_servers6])

    return (commands, [])


def show_config_summary(summary):
    """
    net show configuration <YOUR MODULE NAME>

    Populate the "summary" dictionary with information about the <YOUR MODULE NAME> configuration.
    """

    assert isinstance(summary, dict)

    dhcp_relay_servers, dhcp_relay_interfaces, dhcp_servers, dhcp_relay6_servers, dhcp_relay6_interfaces, dhcp_servers6 = get_dhcp_configuration()

    # IPv4 relay
    if dhcp_relay_servers or dhcp_relay_interfaces:
        summary["dhcp relay"] = OrderedDict()

        if dhcp_relay_servers:
            summary["dhcp relay"]["SERVERS"] = dhcp_relay_servers

        if dhcp_relay_interfaces:
            summary["dhcp relay"]["INTF_CMD"] = dhcp_relay_interfaces

    # IPv4 server
    if dhcp_servers:
        summary["dhcp server"] = OrderedDict()
        summary["dhcp server"]["INTERFACES"] = dhcp_servers

    # IPv6 relay
    if dhcp_relay6_servers or dhcp_relay6_interfaces:
        summary["dhcp relay6"] = OrderedDict()

        if dhcp_relay6_servers:
            summary["dhcp relay6"]["SERVERS"] = dhcp_relay6_servers

        if dhcp_relay6_interfaces:
            summary["dhcp relay6"]["INTF_CMD"] = dhcp_relay6_interfaces

    # IPv6 server
    if dhcp_servers6:
        summary["dhcp server6"] = OrderedDict()
        summary["dhcp server6"]["INTERFACES"] = dhcp_servers6


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """

    assert isinstance(net_daemon, NetDaemon)

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert "configuration" not in tokens, "\"net show configuration dhcp\" does not use this code path."
    assert "dhcp" in tokens, "Why are you here?"

    if "relay" in tokens or "relay6" in tokens:
        return execute_relay_command(tokens)
    elif "server" in tokens or "server6" in tokens:
        # Order matters!  This block should follow the check for "relay" because some commands contain "relay server".
        return execute_server_command(tokens)

    return (False, {"output": '', "error": ["NCLU doesn't know how to process this command."]})


def execute_relay_command(tokens):
    """
    Return the standard 2-tuple for "relay" and "relay6" commands.

    "upstream", for IPv6, specifies the interface to which queries from clients, and other relay
    agents, should be forwarded.  The user has the option to specify a unicast/multicast address.

    "downstream", for IPv6, specifies the interface on which queries will be received from clients
    and other relay agents.  The user has the option to specify a link address.

    https://docs.cumulusnetworks.com/display/DOCS/Configuring+DHCP+Relays
    """

    # Does the user want to modify settings for IPv4 (relay) or IPv6 (relay6)?
    relay_file = ISC_DHCP_RELAY4 if ("relay" in tokens) else ISC_DHCP_RELAY6
    scratchpad = ISC_DHCP_RELAY4_SCRATCHPAD if ("relay" in tokens) else ISC_DHCP_RELAY6_SCRATCHPAD

    if not os.path.isfile(scratchpad):
        make_scratchpads([(relay_file, scratchpad, RELAY_DEFAULT)])

    # Read the configuration file.
    with open(scratchpad) as f:
        dhcp_config = f.read()

    messages = {"output": '', "info": []}

    # Using the appropriate helper function, update the text of dhcp_config.  If a command attempts to add something
    # that already exists, or if a command attempts to delete something that does not exist, the helper functions append
    # an info message.  If there is nothing to modify, the helper functions return None.

    # IPv4
    if "add" in tokens and "relay" in tokens:
        if "server" in tokens:
            # net add dhcp relay server <ipv4>
            dhcp_config = add_dhcp_relay_server(tokens["<ipv4>"], dhcp_config, messages)
        elif "interface" in tokens:
            # net add dhcp relay interface <interface>
            dhcp_config = add_dhcp_relay_interface(tokens["<interface>"], dhcp_config, messages)
    elif "del" in tokens and "relay" in tokens:
        if "server" in tokens:
            # net del dhcp relay server [<ipv4>]
            dhcp_config = del_dhcp_relay_server(tokens.get("<ipv4>"), dhcp_config, messages)
        elif "interface" in tokens:
            # net del dhcp relay interface [<interface>]
            dhcp_config = del_dhcp_relay_interface(tokens.get("<interface>"), dhcp_config, messages)
    # IPv6
    elif "add" in tokens and "relay6" in tokens:
        if "upstream" in tokens:      # server
            # net add dhcp relay6 upstream <interface> [<ipv6>]
            dhcp_config = add_dhcp_relay6_server(tokens["<interface>"], tokens.get("<ipv6>"), dhcp_config, messages)
        elif "downstream" in tokens:  # interface
            # net add dhcp relay6 downstream <interface> [<ipv6>]
            dhcp_config = add_dhcp_relay6_interface(tokens["<interface>"], tokens.get("<ipv6>"), dhcp_config, messages)
    elif "del" in tokens and "relay6" in tokens:
        if "upstream" in tokens:      # server
            # net del dhcp relay6 upstream [<interface>]
            dhcp_config = del_dhcp_relay6_server(tokens.get("<interface>"), dhcp_config, messages)
        elif "downstream" in tokens:  # interface
            # net del dhcp relay6 downstream [<interface>]
            dhcp_config = del_dhcp_relay6_interface(tokens.get("<interface>"), dhcp_config, messages)
    else:
        # This is a programming error.
        return (False, {"output": '', "error": ["NCLU does not know how to process this command."]})

    if not messages["info"]:
        del messages["info"]

    if "error" in messages:
        return (False, messages)

    if dhcp_config is None:
        # The command is a no-op.  The "info" list should enumerate the reasons.
        assert "info" in messages
        return (True, messages)

    # Write the modified configuration file to disk.
    with open(scratchpad, 'w') as f:
        f.write(dhcp_config)

    return (True, messages)


def execute_server_command(tokens):
    """
    Return the standard 2-tuple for "server" and "server6" commands.

    https://docs.cumulusnetworks.com/display/DOCS/Configuring+DHCP+Servers
    """

    # Does the user want to modify settings for IPv4 (relay) or IPv6 (relay6)?
    server_file = ISC_DHCP_SERVER4 if ("server" in tokens) else ISC_DHCP_SERVER6
    scratchpad = ISC_DHCP_SERVER4_SCRATCHPAD if ("server" in tokens) else ISC_DHCP_SERVER6_SCRATCHPAD
    dhcpd_config = DHCPD_CONFIG4 if ("server" in tokens) else DHCPD_CONFIG6
    dhcpd_pid = DHCPD_PID4 if ("server" in tokens) else DHCPD_PID6

    if not os.path.isfile(scratchpad):
        make_scratchpads([(server_file, scratchpad, SERVER_DEFAULT.format(dhcpd_config, dhcpd_pid))])

    # Read the configuration file.
    with open(scratchpad) as f:
        dhcp_config = f.read()

    # Create a string containing the existing interface commands in the configuration file.
    interfaces_re = re.compile(r'''^\s*#?\s*INTERFACES\s*=\s*"(?P<interfaces>[ \S]*?)"''', re.IGNORECASE | re.MULTILINE)
    interfaces_line = interfaces_re.search(dhcp_config)

    if interfaces_line is None:
        # The scratchpad does not contain an INTERFACES line.  Add one.
        dhcp_config += '\nINTERFACES=""\n'
        interfaces_str = ''
    else:
        # A string like "swp1 swp2"; might be the empty string.
        interfaces_str = interfaces_line.group("interfaces")

    # Get the interface(s) the user specified, if any.  "del" commands don't require an interface.
    interfaces = ifname_expand_glob(tokens.get("<interface>", ''))
    assert isinstance(interfaces, list)

    messages = {"output": ''}

    if "add" in tokens:
        # net add dhcp server <interface>

        assert interfaces, "This list should not be empty for an \"add\" command."
        interfaces_to_add = []

        # Test for no-op conditions.
        for interface in interfaces:
            if re.search(r"""\b{0}\b""".format(re.escape(interface)), interfaces_str) is None:
                interfaces_to_add.append(interface)
            else:
                if "info" not in messages:
                    messages["info"] = []
                messages["info"].append("{0} is already configured.".format(interface))

        if not interfaces_to_add:
            # The command is a no-op.
            return (True, messages)

        # Add the interface(s) to the configuration file text.  Don't include a lead blank if
        # interfaces_str is empty.
        if interfaces_str:
            dhcp_config = interfaces_re.sub('INTERFACES="{0} {1}"'.format(interfaces_str, ' '.join(interfaces_to_add)), dhcp_config)
        else:
            dhcp_config = interfaces_re.sub('INTERFACES="{0}"'.format(' '.join(interfaces_to_add)), dhcp_config)
    elif "del" in tokens:
        # net del dhcp server ...

        if interfaces:
            # net del dhcp server <interface>

            interfaces_to_del = []

            # Remove the given interface from the configuration file text.
            for interface in interfaces:
                if re.search(r"""\b{0}\b""".format(re.escape(interface)), interfaces_str) is None:
                    if "info" not in messages:
                        messages["info"] = []
                    messages["info"].append("{0} is not configured.".format(interface))
                else:
                    interfaces_to_del.append(interface)

            if not interfaces_to_del:
                # The command is a no-op.
                return (True, messages)

            for interface in interfaces_to_del:
                interfaces_str = re.sub(re.escape(interface), '', interfaces_str, re.IGNORECASE)

            # Replace multi-spaces in the interfaces string with single spaces.
            interfaces_str = re.sub(r"""\s{2,}""", ' ', interfaces_str).strip()

            # Update the INTERFACES line in the configuration file text.
            dhcp_config = interfaces_re.sub('INTERFACES="{0}"'.format(interfaces_str), dhcp_config)
        else:
            # net del dhcp server
            # The user did not specifiy an interface to remove.  Remove all interfaces.
            dhcp_config = interfaces_re.sub('INTERFACES=""', dhcp_config)
    else:
        # This is a programming error.
        return (False, {"output": '', "error": ["NCLU does not know how to process this command."]})

    # Write the modified configuration file to disk.
    with open(scratchpad, 'w') as f:
        f.write(dhcp_config)

    return (True, {"output": ''})


def add_dhcp_relay_server(ip, dhcp_config, messages):
    """
    net add dhcp relay server <ipv4>

    Add the IP to the SERVER string in dhcp_config, and return the modified dhcp_config.
    If the given IP is already in the SERVERS string, return None to indicate an error.

    ip - A string; an IPv4 address
    dhcp_config - A string; configuration file contents
    messages - The dictionary portion of the standard 2-tuple
    """

    assert "info" in messages

    # Create a string, server_line, containing the existing server IPs in the configuration file.
    server_line_re = re.compile(r'''^\s*#?\s*SERVERS\s*=\s*"(?P<ips>[.\d ]*)"''', re.IGNORECASE | re.MULTILINE)
    server_line = server_line_re.search(dhcp_config)

    if server_line is None:
        # The configuration does not contain SERVERS.  Add the parameter as a new line.
        dhcp_config += '\nSERVERS=""\n'
        server_ips = ''
    else:
        # A string like "1.1.1.1 2.2.2.2"; might be the empty string.
        server_ips = server_line.group("ips")

    if re.search(r"""\b{0}\b""".format(re.escape(ip)), server_ips) is not None:
        # The command is a no-op.
        messages["info"].append("{0} is already configured.".format(ip))
        return None

    # Add the new IP to the configuration file text.  Don't include a lead blank if the SERVER
    # string does not already have values.  Note that this substitution drops end of line comments.
    padding = "{0} ".format(server_ips) if server_ips else ''
    return server_line_re.sub('SERVERS="{0}{1}"'.format(padding, ip), dhcp_config)


def add_dhcp_relay_interface(interface, dhcp_config, messages):
    """
    net add dhcp relay interface <interface>

    Add the interface(s) to the INTF_CMD string in dhcp_config, and return the modified dhcp_config.
    If all given interfaces are already in the INTF_CMD string, return None to indicate a no-op
    command, which is not an error.

    interface - A non-empty string; an interface name or glob
    dhcp_config - A string; configuration file contents
    messages - The dictionary portion of the standard 2-tuple
    """

    assert isinstance(interface, str) and interface, "type(interface) = {0}".format(type(interface))
    assert "info" in messages

    # Create a string containing the existing interface commands in the configuration file.
    intf_cmd_line_re = re.compile(r'''^\s*#?\s*INTF_CMD\s*=\s*"(?P<interfaces>[ \S]*?)"''', re.IGNORECASE | re.MULTILINE)
    intf_cmd_line = intf_cmd_line_re.search(dhcp_config)

    if intf_cmd_line is None:
        # The configuration does not contain INTF_CMD.  Add the parameter as a new line.
        dhcp_config += '\nINTF_CMD=""\n'
        intf_cmd = ''
    else:
        # A string like "-i swp1 -i swp2"; might be the empty string.
        intf_cmd = intf_cmd_line.group("interfaces")

    # Create a list of strings from the interface(s) the user specified.
    interface = ifname_expand_glob(interface)
    assert isinstance(interface, list) and interface and isinstance(interface[0], str), "interface = {0}".format(interface)
    interfaces_to_add = []

    # Check for no-op conditions.
    for ifname in interface:
        if re.search(r"""\b{0}\b""".format(re.escape(ifname)), intf_cmd) is None:
            interfaces_to_add.append(ifname)
        else:
            messages["info"].append("{0} is already configured.".format(ifname))

    if not interfaces_to_add:
        # The command is a no-op.
        return None

    # Add the new interface(s) to the configuration file text.  Don't include a lead blank if the INTF_CMD
    # string does not already have values.  Note that this substitution drops end of line comments.
    padding = "{0} ".format(intf_cmd) if intf_cmd else ''
    return intf_cmd_line_re.sub('INTF_CMD="{0}-i {1}"'.format(padding, " -i ".join(interfaces_to_add)), dhcp_config)


def del_dhcp_relay_server(ip, dhcp_config, messages):
    """
    net del dhcp relay server [<ipv4>]

    Delete the IP from the SERVER string in dhcp_config, and return the modified dhcp_config.
    If the given IP is not already in the SERVERS string, return None to indicate an error.

    If no IP is given, delete all IPs.

    ip - A string, or None; an IPv4 address
    dhcp_config - A string; configuration file contents
    messages - The dictionary portion of the standard 2-tuple
    """

    assert (isinstance(ip, str) and ip) or ip is None
    assert "info" in messages

    server_line_re = re.compile(r'''^\s*SERVERS\s*=\s*"(?P<ips>[.\d ]*)"''', re.IGNORECASE | re.MULTILINE)
    server_line = server_line_re.search(dhcp_config)

    if server_line is None:
        messages["info"].append("No servers are configured.")
        return None

    # The existing configuration has a SERVERS line.

    if ip is None:
        # The user did not specifiy an IP to remove.  Remove all IPs.
        return server_line_re.sub('SERVERS=""', dhcp_config)

    # A string like "1.1.1.1 2.2.2.2"; might be the empty string.
    server_ips = server_line.group("ips")

    if re.search(r"""\b{0}\b""".format(re.escape(ip)), server_ips) is None:
        messages["info"].append("{0} is not configured.".format(ip))
        return None

    # Remove the given IPv4 address from the configuration.
    server_ips = re.sub(r"""\b{0}\b""".format(re.escape(ip)), '', server_ips)

    # Replace runs of spaces with a single space.
    server_ips = re.sub(r"""\s{2,}""", ' ', server_ips).strip()

    # Replace the contents of SERVERS in the configuration file.
    return server_line_re.sub('SERVERS="{0}"'.format(server_ips), dhcp_config)


def del_dhcp_relay_interface(interface, dhcp_config, messages):
    """
    net del dhcp relay interface [<interface>]

    Delete the interface from the INTF_CMD string in dhcp_config, and return the modified dhcp_config.
    If the given interface is not in the INTF_CMD string, return None to indicate an error.

    If no interface is given, delete all interfaces.

    interface - A non-empty string, or None; an interface name or glob
    dhcp_config - A string; configuration file contents
    messages - The dictionary portion of the standard 2-tuple
    """

    assert (isinstance(interface, str) and interface) or interface is None
    assert "info" in messages

    # Create a string containing the existing interface commands in the configuration file.
    intf_cmd_line_re = re.compile(r'''^\s*INTF_CMD\s*=\s*"(?P<interfaces>[ \S]*?)"''', re.IGNORECASE | re.MULTILINE)
    intf_cmd_line = intf_cmd_line_re.search(dhcp_config)

    if intf_cmd_line is None:
        messages["info"].append("No interfaces are configured.")
        return None

    # The existing configuration has a INTF_CMD line.

    if interface is None:
        # The user did not specifiy an interface to remove.  Remove all interfaces.
        return intf_cmd_line_re.sub('INTF_CMD=""', dhcp_config)

    # Create a list of strings from the interface(s) the user specified.
    interface = ifname_expand_glob(interface)
    assert isinstance(interface, list) and interface and isinstance(interface[0], str), "interface = {0}".format(interface)

    # A string like "-i swp1 -i swp2"; might be the empty string.
    intf_cmd = intf_cmd_line.group("interfaces")

    interfaces_to_del = []

    for ifname in interface:
        if re.search(r"""\b{0}\b""".format(re.escape(ifname)), intf_cmd) is None:
            messages["info"].append("{0} is not configured.".format(ifname))
        else:
            interfaces_to_del.append(ifname)

    if not interfaces_to_del:
        # The command is a no-op.
        return None

    for ifname in interfaces_to_del:
        # Remove the interface from the configuration.
        intf_cmd = re.sub(r"""-i \b{0}\b""".format(re.escape(ifname)), '', intf_cmd, re.IGNORECASE)

    # Replace runs of spaces with a single space.
    intf_cmd = re.sub(r"""\s{2,}""", ' ', intf_cmd).strip()

    # Replace the contents of INTF_CMD in the configuration file.
    return intf_cmd_line_re.sub('INTF_CMD="{0}"'.format(intf_cmd), dhcp_config)


def add_dhcp_relay6_server(interface, ip, dhcp_config, messages):
    """
    net add dhcp relay6 upstream <interface> [<ipv6>]

    Given a string containing the contents of the configuration file, return the
    modified string that results from adding a new server (upstream) interface name.
    The user optionally can specify an IPv6 address.

    If the given <IPv6>%<interface> combination is already in the SERVERS string,
    return None to indicate that the command is a no-op, which is not an error.

    interface - A non-empty string; an interface name or glob
    ip - A non-empty string, or None; an IPv6 address
    dhcp_config - A string; configuration file contents
    messages - The dictionary portion of the standard 2-tuple
    """

    assert isinstance(interface, str) and interface, "type(interface) = {0}".format(type(interface))
    assert (isinstance(ip, str) and ip) or ip is None
    assert "info" in messages

    # Create a string containing the existing server interfaces and IPs in the configuration file.
    server_line_re = re.compile(r'''^\s*#?\s*SERVERS\s*=\s*"(?P<interfaces>[-u :\da-z%]*)"''', re.IGNORECASE | re.MULTILINE)
    server_line = server_line_re.search(dhcp_config)

    # If our baseline DHCP config file does not contain a SERVER="" line, add one.
    if server_line is None:
        dhcp_config += '\nSERVERS=""\n'
        server_interfaces = ''
    else:
        # A string like "-u 2001:db8:100::2%swp51 -u 2001:db8:100::2%swp52"; might be the empty string.
        server_interfaces = server_line.group("interfaces")

    interface = ifname_expand_glob(interface)
    assert isinstance(interface, list) and interface and isinstance(interface[0], str), "interface = {0}".format(interface)
    interfaces_to_add = []

    # Test for no-op and error conditions.
    for ifname in interface:
        configuration_re = re.search(r"""(?:(?P<ip>[0-9a-fA-F:]+)%)?\b{0}\b""".format(ifname), server_interfaces)

        if configuration_re is None:
            # This interface is not configured.
            interfaces_to_add.append(ifname)
        else:
            # This interface is already configured.

            if (ip is None and configuration_re.group("ip") is None) or (ip is not None and configuration_re.group("ip") == ip):
                messages["info"].append("{0} is already configured.".format(ifname))
            else:
                messages["error"] = ["{0} cannot be configured.  Delete it first.".format(ifname)]
                return None

    if not interfaces_to_add:
        # The command is a no-op.
        return None

    # Add the new interface(s), and mabye IPv6, to the configuration file text.
    # Don't include a lead blank if the SERVER string does not already have values.
    if server_interfaces:
        if ip:
            return server_line_re.sub('SERVERS="{0} -u {1}%{2}"'.format(server_interfaces, ip, " -u {0}%".join(interfaces_to_add).format(ip)), dhcp_config)
        else:
            return server_line_re.sub('SERVERS="{0} -u {1}"'.format(server_interfaces, " -u ".join(interfaces_to_add)), dhcp_config)
    else:
        # There aren't any existing interface configurations.
        if ip:
            return server_line_re.sub('SERVERS="-u {0}%{1}"'.format(ip, " -u {0}%".join(interfaces_to_add).format(ip)), dhcp_config)
        else:
            return server_line_re.sub('SERVERS="-u {0}"'.format(" -u ".join(interfaces_to_add)), dhcp_config)


def add_dhcp_relay6_interface(interface, ip, dhcp_config, messages):
    """
    net add dhcp relay6 downstream <interface> [<ipv6>]

    Given a string containing the contents of the configuration file, return the
    modified string that results from adding a new relay interface (downstream).
    The user optionally can specify an IPv6 address, so this function will accept
    ip=None.

    If all of the given interfaces are already in INTF_CMD string, return None
    to indicate that the command is a no-op, which is not an error.

    interface - A non-empty string; an interface name or glob
    ip - A non-empty string, or None; an IPv6 address
    dhcp_config - A string; configuration file contents
    messages - The dictionary portion of the standard 2-tuple
    """

    assert isinstance(interface, str) and interface, "type(interface) = {0}".format(type(interface))
    assert (isinstance(ip, str) and ip) or ip is None
    assert "info" in messages

    # Create a string containing the existing server interfaces and IPs in the configuration file.
    intf_cmd_line_re = re.compile(r'''^\s*#?\s*INTF_CMD\s*=\s*"(?P<interfaces>[-l :\da-z%]*)"''', re.IGNORECASE | re.MULTILINE)
    intf_cmd_line = intf_cmd_line_re.search(dhcp_config)

    # If our baseline DHCP config file does not contain a INTF_CMDS="" line, add one.
    if intf_cmd_line is None:
        dhcp_config += '\nINTF_CMD=""\n'
        intf_cmd = ''
    else:
        # A string like "-l 1::%vlan100 -l vlan101"; might be the empty string.
        intf_cmd = intf_cmd_line.group("interfaces")

    interface = ifname_expand_glob(interface)
    assert isinstance(interface, list) and interface and isinstance(interface[0], str), "interface = {0}".format(interface)
    interfaces_to_add = []

    # Test for no-op and error conditions.
    for ifname in interface:
        configuration_re = re.search(r"""(?:(?P<ip>[0-9a-fA-F:]+)%)?\b{0}\b""".format(ifname), intf_cmd)

        if configuration_re is None:
            # This interface is not configured.
            interfaces_to_add.append(ifname)
        else:
            # This interface is already configured.

            if (ip is None and configuration_re.group("ip") is None) or (ip is not None and configuration_re.group("ip") == ip):
                messages["info"].append("{0} is already configured.".format(ifname))
            else:
                messages["error"] = ["{0} cannot be configured.  Delete it first.".format(ifname)]
                return None

    if not interfaces_to_add:
        # The command is a no-op.
        return None

    # Add the new interface(s), and mabye IPv6, to the configuration file text.
    # Don't include a lead blank if the INTF_CMD string does not already have values.
    if intf_cmd:
        if ip:
            return intf_cmd_line_re.sub('INTF_CMD="{0} -l {1}%{2}"'.format(intf_cmd, ip, " -l {0}%".join(interfaces_to_add).format(ip)), dhcp_config)
        else:
            return intf_cmd_line_re.sub('INTF_CMD="{0} -l {1}"'.format(intf_cmd, " -l ".join(interfaces_to_add)), dhcp_config)
    else:
        # There aren't any existing interface configurations.
        if ip:
            return intf_cmd_line_re.sub('INTF_CMD="-l {0}%{1}"'.format(ip, " -l {0}%".join(interfaces_to_add).format(ip)), dhcp_config)
        else:
            return intf_cmd_line_re.sub('INTF_CMD="-l {0}"'.format(" -l ".join(interfaces_to_add)), dhcp_config)


def del_dhcp_relay6_server(interface, dhcp_config, messages):
    """
    net del dhcp relay6 upstream [<interface>]

    Given a string containing the contents of the configuration file, return
    the modified string that results from removing a given server interface.
    If no interface is given, remove all server interfaces.

    Attempting to delete an interface that is not configured is a no-op; it is
    not an error.

    interface - A non-empty string, or None; an interface name or glob
    dhcp_config - A string; configuration file contents
    messages - The dictionary portion of the standard 2-tuple
    """

    assert (isinstance(interface, str) and interface) or interface is None, "type(interface) = {0}".format(type(interface))
    assert "info" in messages

    server_line_re = re.compile(r'''SERVERS\s*=\s*"(?P<interfaces>[-u :\da-z%]*)"''', re.IGNORECASE)
    server_line = server_line_re.search(dhcp_config)

    if server_line is None:
        messages["info"].append("No servers are configured.")
        return None

    if interface is None:
        # The user did not specifiy an IP to remove.  Remove all IPs.
        return server_line_re.sub('SERVERS=""', dhcp_config)

    # Create a list of strings from the interface(s) the user specified.
    interface = ifname_expand_glob(interface)

    # A string like "-u 2001:db8:100::2%swp51 -u 2001:db8:100::2%swp52"; might be the empty string.
    server_interfaces = server_line.group("interfaces")

    interfaces_to_del = []

    # Test for no-op conditions.
    for ifname in interface:
        if re.search(r"""\b{0}\b""".format(re.escape(ifname)), server_interfaces) is None:
            messages["info"].append("{0} is not configured.".format(ifname))
        else:
            interfaces_to_del.append(ifname)

    if not interfaces_to_del:
        # The command is a no-op.
        return None

    for ifname in interfaces_to_del:
        # Remove the given IPv6 interface from the configuration.
        server_interfaces = re.sub(r"""-u (?:[:\da-f]+%)?{0}""".format(re.escape(ifname)), '', server_interfaces)

    # Replace runs of spaces with a single space.
    server_interfaces = re.sub(r"""\s{2,}""", ' ', server_interfaces).strip()

    # Replace the contents of SERVERS in the configuration file.
    return server_line_re.sub('SERVERS="{0}"'.format(server_interfaces), dhcp_config)


def del_dhcp_relay6_interface(interface, dhcp_config, messages):
    """
    net del dhcp relay6 downstream [<interface>]

    Given a string containing the contents of the configuration file, return the
    modified string that results from removing one or more IPv6 relay interfaces.

    Attempting to delete an interface that is not configured is a no-op; it is
    not an error.

    interface - A non-empty string, or None; an interface name or glob
    dhcp_config - A string; configuration file contents
    messages - The dictionary portion of the standard 2-tuple
    """

    assert (isinstance(interface, str) and interface) or interface is None, "type(interface) = {0}".format(type(interface))
    assert "info" in messages

    intf_cmd_line_re = re.compile(r'''INTF_CMD\s*=\s*"(?P<interfaces>[-l :\da-z%]*)"''', re.IGNORECASE)
    intf_cmd_line = intf_cmd_line_re.search(dhcp_config)

    if intf_cmd_line is None:
        messages["info"].append("No interfaces are configured.")
        return None

    if interface is None:
        # The user did not specifiy an interface to remove.  Remove all interfaces.
        return intf_cmd_line_re.sub('INTF_CMD=""', dhcp_config)

    # Create a list of the interface(s) the user specified.  The input might be a glob.
    interface = ifname_expand_glob(interface)  # A list of strings

    # A string like "-l 1::%vlan100"; might be the empty string.
    intf_cmd = intf_cmd_line.group("interfaces")

    interfaces_to_del = []

    # Test for no-op conditions.
    for ifname in interface:
        if re.search(r"""\b{0}\b""".format(re.escape(ifname)), intf_cmd) is None:
            messages["info"].append("{0} is not configured.".format(ifname))
        else:
            interfaces_to_del.append(ifname)

    if not interfaces_to_del:
        # The command is a no-op.
        return None

    for ifname in interfaces_to_del:
        # Remove the interface from the configuration.
        intf_cmd = re.sub(r"""-l \b(?:[:\da-f]+%)?{0}\b""".format(re.escape(ifname)), '', intf_cmd, re.IGNORECASE)

    # Replace runs of spaces with a single space.
    intf_cmd = re.sub(r"""\s{2,}""", ' ', intf_cmd)

    # Replace the contents of INTF_CMD in the configuration file.
    return intf_cmd_line_re.sub('INTF_CMD="{0}"'.format(intf_cmd.strip()), dhcp_config)


def del_all():
    """
    net del all

    Revert all configuration files associated with this plug-in to their defaults
    if there is an existing configuration.
    """

    if not os.path.isdir(os.path.join(WORKING_DIRECTORY, "dhcp")):
        os.makedirs(os.path.join(WORKING_DIRECTORY, "dhcp"))

    if os.path.isfile(ISC_DHCP_RELAY4):
        with open(ISC_DHCP_RELAY4_SCRATCHPAD, 'w') as f:
            f.write(RELAY_DEFAULT)

    if os.path.isfile(ISC_DHCP_RELAY6):
        with open(ISC_DHCP_RELAY6_SCRATCHPAD, 'w') as f:
            f.write(RELAY_DEFAULT)

    if os.path.isfile(ISC_DHCP_SERVER4):
        with open(ISC_DHCP_SERVER4_SCRATCHPAD, 'w') as f:
            f.write(SERVER_DEFAULT.format(DHCPD_CONFIG4, DHCPD_PID4))

    if os.path.isfile(ISC_DHCP_SERVER6):
        with open(ISC_DHCP_SERVER6_SCRATCHPAD, 'w') as f:
            f.write(SERVER_DEFAULT.format(DHCPD_CONFIG6, DHCPD_PID6))


def get_config_files():
    """
    Return a string with the content of all existing, non-empty configuration files managed with this plug-in.
    """

    return get_config_files_helper(get_managed_files())


def get_pending(use_colors):
    """ Return a string of the pending changes in all managed files. """

    return get_pending_diffs(zip(get_managed_files(), get_scratchpad_files()), use_colors)


def abort_pending():
    remove_scratch_files_and_backups(get_scratchpad_files())


def get_managed_files():
    """
    Return a list of managed files.

    DHCPD_CONFIG4, DHCPD_PID4, DHCPD_CONFIG6, and DHCPD_PID6 are not actively managed.  They
    exist as file name constants because the those values appear in the text of files that
    are managed.
    """

    return [ISC_DHCP_RELAY4, ISC_DHCP_RELAY6, ISC_DHCP_SERVER4, ISC_DHCP_SERVER6]


def get_scratchpad_files():
    """ Order matters!  These files should mirror the output of get_managed_files. """

    return [ISC_DHCP_RELAY4_SCRATCHPAD, ISC_DHCP_RELAY6_SCRATCHPAD, ISC_DHCP_SERVER4_SCRATCHPAD, ISC_DHCP_SERVER6_SCRATCHPAD]


def get_restart_commands(filename):
    """
    Return a list of commands that should be called for the given file after a rollback.
    Some plug-ins use this in commit_pending as well.
    """

    assert filename in get_managed_files(), "filename = {0}".format(filename)

    if filename == ISC_DHCP_RELAY4:
        return [["/bin/systemctl", "enable", "dhcrelay.service"],
                ["/bin/systemctl", "reset-failed", "dhcrelay.service"],
                ["/bin/systemctl", "restart", "dhcrelay.service"]]

    elif filename == ISC_DHCP_RELAY6:
        return [["/bin/systemctl", "enable", "dhcrelay6.service"],
                ["/bin/systemctl", "reset-failed", "dhcrelay6.service"],
                ["/bin/systemctl", "restart", "dhcrelay6.service"]]

    elif filename == ISC_DHCP_SERVER4:
        return [["/bin/systemctl", "enable", "dhcpd.service"],
                ["/bin/systemctl", "reset-failed", "dhcpd.service"],
                ["/bin/systemctl", "restart", "dhcpd.service"]]

    elif filename == ISC_DHCP_SERVER6:
        return [["/bin/systemctl", "enable", "dhcpd6.service"],
                ["/bin/systemctl", "reset-failed", "dhcpd6.service"],
                ["/bin/systemctl", "restart", "dhcpd6.service"]]

    # This is a programming error.
    raise RuntimeError("Invalid file name ({0}).".format(filename))


def get_dhcp_configuration():
    """
    Return a 6-tuple of lists of information parsed from the various DHCP configuration files.
    """

    dhcp_relay_servers = []
    dhcp_relay_interfaces = []
    dhcp_servers = []

    dhcp_relay6_servers = []
    dhcp_relay6_interfaces = []
    dhcp_servers6 = []

    relay_key_value_pair_re = re.compile(r'''^\s*(SERVERS|INTF_CMD)\s*=\s*"([^"]*)"''', re.IGNORECASE | re.MULTILINE)
    server_key_value_pair_re = re.compile(r'''^\s*INTERFACES\s*=\s*"([^"]*)"''', re.IGNORECASE | re.MULTILINE)

    # IPv4 and IPv6 relay
    for dhcp_file in (ISC_DHCP_RELAY4, ISC_DHCP_RELAY6):
        if not os.path.isfile(dhcp_file):
            continue

        with open(dhcp_file) as f:
            config_text = f.read()

        key_value_pairs = relay_key_value_pair_re.findall(config_text)

        for key, value in key_value_pairs:
            if key.upper() == "SERVERS":
                if dhcp_file.endswith('6'):
                    # relay6 server
                    interfaces = value.replace("-u", '').split()

                    try:
                        interfaces_as_glob = ifnames_to_glob(interfaces)
                    except (RuntimeError, ValueError) as e:
                        # Could not globify the interfaces.
                        log.warning("(get_dhcp_configuration) \"{0}\" raised an exception in ifnames_to_glob: {1}.".format(str(interfaces), e))
                        interfaces_as_glob = None

                    if interfaces_as_glob:
                        dhcp_relay6_servers.append(interfaces_as_glob)
                    else:
                        dhcp_relay6_servers.extend(interfaces)
                else:
                    # relay server
                    dhcp_relay_servers.extend(value.split())

            elif key.upper() == "INTF_CMD":
                if dhcp_file.endswith('6'):
                    # relay6 interface
                    interfaces = value.replace("-l", '').strip().split()
                else:
                    # relay interface
                    interfaces = value.replace("-i", '').strip().split()

                try:
                    interfaces_as_glob = ifnames_to_glob(interfaces)
                except (RuntimeError, ValueError) as e:
                    # Could not globify the interfaces.
                    log.warning("(get_dhcp_configuration) \"{0}\" raised an exception in ifnames_to_glob: {1}.".format(str(interfaces), e))
                    interfaces_as_glob = None

                if dhcp_file.endswith('6'):
                    if interfaces_as_glob:
                        dhcp_relay6_interfaces.append(interfaces_as_glob)
                    else:
                        dhcp_relay6_interfaces.extend(interfaces)
                else:
                    if interfaces_as_glob:
                        dhcp_relay_interfaces.append(interfaces_as_glob)
                    else:
                        dhcp_relay_interfaces.extend(interfaces)

    # IPv4 and IPv6 server
    for dhcp_file in (ISC_DHCP_SERVER4, ISC_DHCP_SERVER6):
        if not os.path.isfile(dhcp_file):
            continue

        with open(dhcp_file) as f:
            config_text = f.read()

        servers = server_key_value_pair_re.findall(config_text)

        for value in servers:
            if dhcp_file.endswith('6'):
                # server6
                dhcp_servers6.extend(value.split())
            else:
                # server
                dhcp_servers.extend(value.split())

    if dhcp_relay_servers:
        dhcp_relay_servers = sort_for_humans(dhcp_relay_servers)

    if dhcp_relay_interfaces:
        dhcp_relay_interfaces = sort_for_humans(dhcp_relay_interfaces)

    if dhcp_servers:
        dhcp_servers = sort_for_humans(dhcp_servers)

    if dhcp_relay6_servers:
        dhcp_relay6_servers = sort_for_humans(dhcp_relay6_servers)

    if dhcp_relay6_interfaces:
        dhcp_relay6_interfaces = sort_for_humans(dhcp_relay6_interfaces)

    if dhcp_servers6:
        dhcp_servers6 = sort_for_humans(dhcp_servers6)

    return (dhcp_relay_servers, dhcp_relay_interfaces, dhcp_servers, dhcp_relay6_servers, dhcp_relay6_interfaces, dhcp_servers6)
