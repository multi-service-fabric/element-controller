"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

import os
import re
from collections import Counter
from nclu import EXAMPLES_DIRECTORIES
from sys import exit


def build_doc_string(front_matter, enabled_wrappers, enabled_plugins, blacklist):
    """
    Return a 3-tuple.  The first value is an aggregated docstring derived from the
    "front_matter", wrappers, and plug-ins.

    The second value, "keywords", is a dictionary with wrappered component names
    (i.e. dns) as keys and sets of strings as values.  The sets should include all syntax
    tokens unique to that wrapper.

    The third value is a dictionary of help text.
    TODO - Why?  It doesn't seem to be used anywhere.

    front_matter - A string; any syntax not derived from wrappers/plug-ins
    """

    assert isinstance(front_matter, str)
    assert isinstance(enabled_wrappers, set)
    assert isinstance(enabled_plugins, set)
    assert len(enabled_wrappers) > 0, "If the wrapper paradigm has been removed, edit this function, and edit get_syntax."

    docstring = ['', "Usage:"]
    keywords = {}

    # Parse the front matter.
    front_usage, options, front_usage_keywords, helptext = parse_doc_string(front_matter.splitlines())
    docstring.extend(front_usage)

    # Add the example commands.
    docstring.extend(sorted(get_example_commands(), key=str.lower))

    # Add Usage and Options for component modules.
    get_syntax(enabled_plugins, docstring, options, keywords, helptext)
    get_syntax(enabled_wrappers, docstring, options, keywords, helptext, blacklist, False)

    docstring.extend(['', "Options:"])
    options = sorted(options, key=lambda (o, d): (o.lower(), d.lower()))  # A deduplicated, sorted list

    # Determine the length of the longest options variable name.
    max_variable_length = max([len(vn) for vn, _ in options])

    # Append the options syntax.
    for variable, help_text in options:
        docstring.append("    {0} : {1}".format(variable.ljust(max_variable_length), help_text))

    # Count the occurance of syntax tokens in the basic usage text and plugins.
    count = Counter(front_usage_keywords)
    for keyword in keywords.itervalues():
        count.update(keyword)

    # Remove non-unique tokens from the wrappers keywords dictionary.  Non-unique tokens should not
    # be used downstream to select a wrapper or plug-in to use for command execution.
    for keyword in count:
        if count[keyword] > 1:
            for wrapper in keywords:
                keywords[wrapper].discard(keyword)

    return ('\n'.join(docstring) + '\n', keywords, helptext)


def parse_doc_string(lines):
    """
    Given the lines of a syntax doc string, return a 4-tuple of (usage, options, keywords, helptext).
    """

    assert isinstance(lines, list)

    usage = []
    options = set()      # (variable, variable help text)
    keywords = set()
    helptext = {}        # variable : variable help text
    state = "LIMBO"

    for line in lines:
        line = line.strip()

        if line == "Usage:":
            state = "USAGE"
            continue

        elif line == "Options:":
            state = "OPTIONS"
            continue

        if state == "USAGE":
            if line.startswith('#'):
                usage.append("    " + line)
            elif line:
                # Chop the first word.  This will be "ifupdown2", "frr", etc.
                line_re = re.match(r"""^\S+\s(.*)""", line)
                assert line_re is not None, "line={0}".format(line)
                usage.append("    net {0}".format(line_re.group(1)))
                found_keyword = False

                for word in line.split()[1:]:
                    tmp_word = word.replace('(', '').replace(')', '').replace('[', '').replace(']', '')

                    for subword in tmp_word.split('|'):
                        if not subword.startswith('<'):
                            keywords.add(subword)
                            found_keyword = True

                if not found_keyword:
                    raise ValueError("Could not extract the keyword from \"{0}\".".format(line))
            else:
                usage.append('')

        elif state == "OPTIONS":
            if line:
                line_re = re.match(r"""^(?P<variable>.*?):(?P<help_text>.*)$""", line)

                if line_re is not None:
                    variable = line_re.group("variable").strip()
                    variable_help_text = line_re.group("help_text").strip()

                    if variable not in helptext:
                        helptext[variable] = variable_help_text

                    options.add((variable, variable_help_text))

        elif state == "LIMBO":
            pass

        else:
            # This is a programming error.
            raise RuntimeError("\"{0}\" is an invalid state.".format(state))

    return (usage, options, keywords, helptext)


def get_example_commands():
    """
    Return a set of example commands (i.e. "net example dns").  The set deduplicates
    in case multiple directories have an example for the same component.
    """

    examples = set()
    for example_dir in EXAMPLES_DIRECTORIES:
        if not os.path.isdir(example_dir):
            continue
        for root_dir, _, filenames in os.walk(example_dir):
            subdir_re = re.search(r"""{0}(.+)""".format(example_dir), root_dir)
            command_preface = '' if (subdir_re is None) else (subdir_re.group(1).replace('/', ' ').strip() + ' ')
            examples.update(["    net example {0}{1}".format(command_preface, fn) for fn in filenames])
    return examples


def get_syntax(components, docstring, options, keywords, helptext, blacklist=None, is_plugin=True):
    """
    Given a set of component names, all of which are assumed to have associated modules, update
    the "docstring", "options", "keywords", and "helptext" parameters.

    components - A set of strings
    is_plugin - A boolean; Are the compoents plug-ins (True) or wrappers (False)?
    """

    assert isinstance(docstring, list)
    assert isinstance(options, set)
    assert isinstance(keywords, dict)
    assert isinstance(helptext, dict)

    for component in components:
        # Import the component's module.
        try:
            import_string = "nclu.{0}.{1}".format("plugins" if is_plugin else "wrappers", component)
            m = __import__(import_string, fromlist=["build_doc_string", "__doc__"])
        except ImportError as e:
            exit("{0} is configured to be available, imported via '{1}', but failed due to '{2}'".format(component, import_string, e))

        # Get the component's syntax.
        if hasattr(m, "build_doc_string"):
            # The module's doc string is dynamically constructed.

            if component == "ifupdown2":
                assert blacklist is not None, "Pass the blacklist as a parameter."
                component_docstring = m.build_doc_string(blacklist)
            else:
                component_docstring = m.build_doc_string()
        else:
            # The module's doc string is static.

            if not hasattr(m, "__doc__"):
                exit("The {0} module needs to define its associated syntax.".format(component))

            # The wrapper has a static doc string.
            component_docstring = m.__doc__

        # Add the component syntax to the aggregate.
        component_usage, component_options, component_keywords, component_helptext = parse_doc_string(component_docstring.splitlines())
        docstring.extend(component_usage)
        options |= component_options
        keywords[component] = component_keywords

        for (keyword, help_str) in component_helptext.items():
            if keyword not in helptext:
                helptext[keyword] = help_str
