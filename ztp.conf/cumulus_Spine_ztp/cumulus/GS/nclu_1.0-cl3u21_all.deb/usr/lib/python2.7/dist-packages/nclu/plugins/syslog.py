"""
Copyright (C) 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt

----------------------------------------------------------------------------------------

Usage:
    net (add|del) syslog host (ipv4 <ipv4>|ipv6 <ipv6>) port [udp|tcp] <number>
    net show configuration syslog

Options:
    host    : A remote host running a log server
"""

import logging
import os
import re
from collections import OrderedDict
from nclu import files_match, service_is_enabled, WORKING_DIRECTORY
from nclu.NetDaemon import NetDaemon
from nclu.plugins import (
    get_config_files_helper,
    get_pending_diffs,
    make_scratchpads,
    merge_messages,
    persist_configurations,
    remove_scratch_files_and_backups,
    run_commands,
)

REMOTE_LOG = "/etc/rsyslog.d/11-remotesyslog.conf"
REMOTE_LOG_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "syslog", os.path.basename(REMOTE_LOG))

log = logging.getLogger("netd")


# NetDaemon.reload looks for this.
per_command_helptext = {"net (add|del) syslog": {"host": "A remote host running a log server"}}


def commit_pending(verbose):
    """
    Copy scratchpad files over configuration files, call necessary restart commands, etc.

    Return a 2-tuple of (bool, dict).  The boolean indicates if the commit succeeded.
    The dictionary is as described in nclu/plugins/__init__.py:execute_modular.
    """

    if not os.path.isfile(REMOTE_LOG_SCRATCHPAD) or files_match(REMOTE_LOG, REMOTE_LOG_SCRATCHPAD):
        # There are no changes to commit.
        return (True, {"output": ''})

    persist_configurations([(REMOTE_LOG, REMOTE_LOG_SCRATCHPAD)])
    syslog_commands = get_restart_commands()

    outcome, _, messages = run_commands(syslog_commands, verbose)

    if outcome:
        # The commit succeeded.
        remove_scratch_files_and_backups([REMOTE_LOG_SCRATCHPAD])
    else:
        # The commit failed.  Revert configurations.
        if os.path.isfile(REMOTE_LOG_SCRATCHPAD + ".bak"):
            persist_configurations([(REMOTE_LOG, REMOTE_LOG_SCRATCHPAD + ".bak")], False)
            revert_outcome, _, revert_messages = run_commands(syslog_commands, verbose)
            merge_messages(messages, revert_messages)
            if not revert_outcome:
                messages["error"].append("Reverting {0} changes failed.".format(REMOTE_LOG))

    return (outcome, messages)


def show_config_commands(ifupdown2_wrapper):
    """
    net show configuration commands
    """

    if not os.path.isfile(REMOTE_LOG):
        return ([], [])

    # Read relevant data from the configuration file.
    with open(REMOTE_LOG) as f:
        configs = re.findall(r"""^\s*\*\.\*\s+(?P<protocol>@@?)(?P<ip>[.:a-f\d]+):(?P<port>\d+)""", f.read(), re.IGNORECASE | re.MULTILINE)

    commands = []

    for protocol, ip, port in configs:
        protocol = "udp" if protocol == '@' else "tcp"
        commands.append("net add syslog host {0} port {1} {2}".format(ip, protocol, port))

    return (commands, [])


def show_config_summary(summary):
    """
    net show configuration syslog

    Populate the "summary" dictionary with information about the syslog configuration.
    """

    assert isinstance(summary, dict)

    if not os.path.exists(REMOTE_LOG):
        # Nothing to do.
        return

    with open(REMOTE_LOG) as f:
        config_file = f.read()

    ipv4 = re.findall(r"""^\s*\*\.\*\s+(@@?)([.\d]+:\d+)""", config_file, re.IGNORECASE | re.MULTILINE)
    ipv6 = re.findall(r"""^\s*\*\.\*\s+(@@?)(\[[:\da-f]+\]:\d+)""", config_file, re.IGNORECASE | re.MULTILINE)

    if not (ipv4 or ipv6):
        # Nothing to do.
        return

    summary["syslog"] = OrderedDict()

    if ipv4:
        summary["syslog"]["ipv4"] = OrderedDict()
        for protocol, ip_port in ipv4:
            if protocol == '@':
                # UDP
                if summary["syslog"]["ipv4"].get("udp") is None:
                    summary["syslog"]["ipv4"]["udp"] = []
                summary["syslog"]["ipv4"]["udp"].append(ip_port)
            else:
                # TCP
                if summary["syslog"]["ipv4"].get("tcp") is None:
                    summary["syslog"]["ipv4"]["tcp"] = []
                summary["syslog"]["ipv4"]["tcp"].append(ip_port)

    if ipv6:
        summary["syslog"]["ipv6"] = OrderedDict()
        for protocol, ip_port in ipv6:
            if protocol == '@':
                # UDP
                if summary["syslog"]["ipv6"].get("udp") is None:
                    summary["syslog"]["ipv6"]["udp"] = []
                summary["syslog"]["ipv6"]["udp"].append(ip_port)
            else:
                # TCP
                if summary["syslog"]["ipv6"].get("tcp") is None:
                    summary["syslog"]["ipv6"]["tcp"] = []
                summary["syslog"]["ipv6"]["tcp"].append(ip_port)


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """

    assert isinstance(net_daemon, NetDaemon)

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert "configuration" not in tokens, "\"net show configuration syslog\" does not use this code path."
    assert "syslog" in tokens, "Why are you here?"

    if not os.path.isfile(REMOTE_LOG_SCRATCHPAD):
        make_scratchpads([(REMOTE_LOG, REMOTE_LOG_SCRATCHPAD, '')])

    ip = tokens["<ipv4>"] if ("ipv4" in tokens) else tokens["<ipv6>"]
    port = tokens["<number>"]

    if "add" in tokens:
        return add_remote_log_server(tokens, ip, port)
    if "del" in tokens:
        return del_remote_log_server(tokens, ip, port)

    # This is a programming error.
    return (False, {"output": '', "error": ["NCLU doesn't know how to process this command."]})


def add_remote_log_server(tokens, ip, port):
    """
    Start logging for UDP (default) or TCP on a given host.  If the user specifies
    a different port or protocol for an IP already in the configuration, the existing
    line should be replaced with the new information.

    http://stackoverflow.com/questions/186829/how-do-ports-work-with-ipv6#186848
    """

    if "tcp" in tokens:
        # TCP
        if "ipv4" in tokens:
            output = "*.*   @@{0}:{1}  # TCP\n".format(ip, port)    # TCP and IPv4
        else:
            assert "ipv6" in tokens
            output = "*.*   @@[{0}]:{1}  # TCP\n".format(ip, port)  # TCP and IPv6
    else:
        # UDP (default; "udp" might or might not be in tokens)
        if "ipv4" in tokens:
            output = "*.*   @{0}:{1}   # UDP\n".format(ip, port)    # UDP and IPv4
        else:
            assert "ipv6" in tokens
            output = "*.*   @[{0}]:{1}   # UDP\n".format(ip, port)  # UDP and IPv6

    # Check for existing configurations for the given IP.
    with open(REMOTE_LOG_SCRATCHPAD) as f:
        config_file = f.read()
    existing_re = re.compile(r"""^\s*\*\.\*\s+@@?\[?{0}\]?:\d+.*?$""".format(ip), re.IGNORECASE | re.MULTILINE)
    rewrite_needed = existing_re.search(config_file) is not None

    if rewrite_needed:
        config_file = existing_re.sub('', config_file)  # Remove existing configurations for the given IP.
        with open(REMOTE_LOG_SCRATCHPAD, 'w') as f:
            f.write(config_file)
            f.write(output)
    else:
        with open(REMOTE_LOG_SCRATCHPAD, 'a') as f:
            f.write(output)

    return (True, {"output": ''})


def del_remote_log_server(tokens, ip, port):
    """ Stop logging for UDP or TCP on a given host. """

    if "tcp" in tokens:
        # TCP
        if "ipv4" in tokens:
            substitution = r"""^\s*\*\.\*\s+@@{0}:{1}(?:\s+#\s*TCP)?\s*$"""      # TCP and IPv4
        else:
            substitution = r"""^\s*\*\.\*\s+@@\[{0}\]:{1}(?:\s+#\s*TCP)?\s*$"""  # TCP and IPv6
    else:
        # UDP (default; "udp" might or might not be in tokens)
        if "ipv4" in tokens:
            substitution = r"""^\s*\*\.\*\s+@{0}:{1}(?:\s+#\s*UDP)?\s*$"""       # UDP and IPv4
        else:
            substitution = r"""^\s*\*\.\*\s+@\[{0}\]:{1}(?:\s+#\s*UDP)?\s*$"""   # UDP and IPv6

    # Input the configuration scratchpad file.
    with open(REMOTE_LOG_SCRATCHPAD) as f:
        config_file = f.read()

    config_file = re.sub(substitution.format(ip, port), '', config_file, 0, re.IGNORECASE | re.MULTILINE)

    # Output the modified configuration file.
    with open(REMOTE_LOG_SCRATCHPAD, 'w') as f:
        f.write(config_file)

    return (True, {"output": ''})


def del_all():
    """
    net del all

    Revert all configuration files associated with this plug-in to their defaults.
    """

    open(REMOTE_LOG, 'w').close()


def get_config_files():
    """
    Return a string with the content of all existing, non-empty configuration files managed with this plug-in.
    """

    return get_config_files_helper(get_managed_files())


def get_pending(use_colors):
    """ Return a string of the pending changes in all managed files. """

    return get_pending_diffs([(REMOTE_LOG, REMOTE_LOG_SCRATCHPAD)], use_colors)


def abort_pending():
    remove_scratch_files_and_backups([REMOTE_LOG_SCRATCHPAD])


def get_managed_files():
    """ Return a list of managed files. """

    return [REMOTE_LOG]


def get_restart_commands(filename=None):
    """
    Return a list of commands that should be called for the given file after a rollback.
    Some plug-ins use this in commit_pending as well.
    """

    assert filename is None or filename in get_managed_files(), "filename = {0}".format(filename)

    syslog_commands = []

    if not service_is_enabled("rsyslog.service"):
        syslog_commands.append(["/bin/systemctl", "enable", "rsyslog.service"])

    syslog_commands.extend([["/usr/sbin/rsyslogd", "-N1"],
                            ["/bin/systemctl", "reset-failed", "rsyslog.service"],
                            ["/bin/systemctl", "restart", "rsyslog.service"]])

    return syslog_commands
