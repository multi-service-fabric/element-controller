from nclu import ifname_expand_glob
from network_docopt import sort_for_humans
from network_docopt.match import ifname_is_glob
from nclu.plugins.frr.core import ETC_FRR_CONF_SCRATCHPAD, ETC_FRR_CONF
import doctest
import logging
import os
import re

assert ETC_FRR_CONF is not None

log = logging.getLogger('netd')


def get_config_lines(target):

    final = []

    for filename in (ETC_FRR_CONF_SCRATCHPAD, ETC_FRR_CONF):
        if os.path.exists(filename):
            with open(filename) as f:
                for line in f:
                    line = line.strip()

                    if line.startswith(target):
                        final.append(line)

    return final


def get_aspath_access_list():
    final = []

    for line in get_config_lines('ip as-path access-list'):
        # ip as-path access-list LARRY permit 1234
        final.append(line.split()[3])

    final = sort_for_humans(list(set(final)))
    return final


def get_bgp_peergroups(args={}):
    final = []
    vrf = None

    if args.get('vrf'):
        vrf = "vrf %s" % args.get('<text>')

    for filename in (ETC_FRR_CONF_SCRATCHPAD, ETC_FRR_CONF):
        if os.path.exists(filename):
            with open(filename, 'r') as fh:
                state = None

                for line in fh.readlines():
                    line = line.strip()

                    if line.startswith('router bgp'):
                        if vrf:
                            if line.endswith(vrf):
                                state = 'ROUTER_BGP'
                            else:
                                state = None
                        else:
                            state = 'ROUTER_BGP'

                    if line.startswith('neighbor ') and line.endswith('peer-group'):
                        if state == 'ROUTER_BGP':
                            final.append(line.split()[1])

    final = sort_for_humans(list(set(final)))
    return final


def get_bgppeers(args={}):
    final = []
    vrf = None

    if args.get('vrf'):
        vrf = "vrf %s" % args.get('<text>')

        # If the user specified 'vrf all' treat this as if they didn't
        # specify any vrf at all so that we find all peers across all vrfs
        if vrf == 'vrf all':
            vrf = None

    for filename in (ETC_FRR_CONF_SCRATCHPAD, ETC_FRR_CONF):
        if os.path.exists(filename):
            with open(filename, 'r') as fh:
                state = None

                for line in fh.readlines():
                    line = line.strip()

                    if line.startswith('router bgp'):
                        if vrf:
                            if line.endswith(vrf):
                                state = 'ROUTER_BGP'
                            else:
                                state = None
                        else:
                            state = 'ROUTER_BGP'

                    if line.startswith('neighbor '):
                        if state == 'ROUTER_BGP':
                            final.append(line.split()[1])

    final = sort_for_humans(list(set(final)))
    return final


def get_community_list():
    final = []

    for line in get_config_lines('ip community-list'):
        # ip community-list standard MARGE permit 100:100
        final.append(line.split()[3])

    final = sort_for_humans(list(set(final)))
    return final


def get_extcommunity_list():
    final = []

    for line in get_config_lines('ip extcommunity-list'):
        # ip community-list standard MARGE permit 100:100
        final.append(line.split()[3])

    final = sort_for_humans(list(set(final)))
    return final


def get_prefix_list_v4():
    final = []

    for line in get_config_lines('ip prefix-list'):
        # ip prefix-list BOB seq 5 permit any
        final.append(line.split()[2])

    final = sort_for_humans(list(set(final)))
    return final


def get_prefix_list_v6():
    final = []

    for line in get_config_lines('ipv6 prefix-list'):
        # ipv6 prefix-list JASON seq 5 permit any
        final.append(line.split()[2])

    final = sort_for_humans(list(set(final)))
    return final


def get_route_map():
    final = set([])

    for line in get_config_lines('route-map'):
        # route-map FOO permit 10
        final.add(line.split()[1])

    return sorted(final)


def match_aspath_access_list(argv_word, use_fuzzy, tab_completing):
    """
    <as-path-access-list>
    """
    if use_fuzzy:
        if ' ' not in argv_word:
            return True
    else:
        if argv_word in get_aspath_access_list():
            return True

        if tab_completing:
            for acl in get_aspath_access_list():
                if acl.startswith(argv_word):
                    return True
    return False


def match_bgppeer(argv_word, use_fuzzy, tab_completing):
    """
    <bgppeer>

    argv_word could be an IPv4 address, IPv6 address, ifname or glob of ifnames
    """
    if use_fuzzy:
        if ' ' not in argv_word:
            return True
    else:
        potential_peers = []

        if ifname_is_glob(str(argv_word)):
            for x in ifname_expand_glob(str(argv_word)):
                potential_peers.append(x)
        else:
            potential_peers.append(argv_word)

        all_are_peers = True
        bgp_peers = get_bgppeers()

        for peer in potential_peers:
            if peer not in bgp_peers:
                all_are_peers = False

        if all_are_peers:
            return True

        if tab_completing and len(potential_peers) == 1:
            for peer in bgp_peers:
                if peer.startswith(argv_word):
                    return True
    return False


def match_community(argv_word, use_fuzzy, tab_completing):
    """
    <community>
    There is no fuzzy matching for communities
    """
    if re.search('^\d+:\d+$', argv_word):
        return True
    return False


def match_community_list(argv_word, use_fuzzy, tab_completing):
    """
    <community-list>
    """
    if use_fuzzy:
        if ' ' not in argv_word:
            return True
    else:
        if argv_word in get_community_list():
            return True

        if tab_completing:
            for commlist in get_community_list():
                if commlist.startswith(argv_word):
                    return True
    return False


def match_extcommunity(argv_word, use_fuzzy, tab_completing):
    """
    There is no fuzzy matching for extended communities
    ASN:nn_or_IP-address:nn
    """
    if re.search('^\d+:\d+$', argv_word):
        return True

    if re.search('^\d+\.\d+\.\d+\.\d+:\d+$', argv_word):
        return True

    return False


def match_extcommunity_list(argv_word, use_fuzzy, tab_completing):
    """
    <extcommunity-list>
    """
    if use_fuzzy:
        if ' ' not in argv_word:
            return True
    else:
        if argv_word in get_extcommunity_list():
            return True

        if tab_completing:
            for extcommlist in get_extcommunity_list():
                if extcommlist.startswith(argv_word):
                    return True
    return False


def match_route_map(argv_word, use_fuzzy, tab_completing):
    """
    There is no fuzzy matching for route-maps
    """
    if use_fuzzy:
        if ' ' not in argv_word:
            return True
    else:
        if argv_word in get_route_map():
            return True

        if tab_completing:
            for routemap in get_route_map():
                if routemap.startswith(argv_word):
                    return True

    return False


def match_peer_group(argv_word, use_fuzzy, tab_completing):
    if ' ' not in argv_word:
        return True
    return False


def match_prefix_list_v4(argv_word, use_fuzzy, tab_completing):
    if use_fuzzy:
        if ' ' not in argv_word:
            return True
    else:
        if argv_word in get_prefix_list_v4():
            return True

        if tab_completing:
            for prefix_list in get_prefix_list_v4():
                if prefix_list.startswith(argv_word):
                    return True
    return False


def match_prefix_list_v6(argv_word, use_fuzzy, tab_completing):
    if use_fuzzy:
        if ' ' not in argv_word:
            return True
    else:
        if argv_word in get_prefix_list_v6():
            return True

        if tab_completing:
            for prefix_list in get_prefix_list_v6():
                if prefix_list.startswith(argv_word):
                    return True
    return False


def match_rd(argv_word, use_fuzzy, tab_completing):
    """
    <rd>
    """
    if ":" in argv_word:
        (part1, part2) = argv_word.split(':')

        if part1.isdigit() and part2.isdigit():
            part1 = int(part1)
            part2 = int(part2)

            # 4-byte:2-byte
            if part1 >= 0 and part1 <= 4294967295 and part2 >= 0 and part2 <= 65535:
                return True

            # 2-byte:4-byte
            if part1 >= 0 and part1 <= 65535 and part2 >= 0 and part2 <= 4294967295:
                return True

        # Hideous regex for matching an IPv4 address
        elif re.search('(([01]?[0-9]?[0-9]|2[0-4][0-9]|2[5][0-5])\.){3}([01]?[0-9]?[0-9]|2[0-4][0-9]|2[5][0-5])', part1):
            if part2.isdigit():
                part2 = int(part2)

                if part2 >= 0 and part2 <= 65535:
                    return True

                if use_fuzzy:
                    return True

    return False


def match_route_target(argv_word, use_fuzzy, tab_completing):
    """
    <route-target>
    """
    if ":" in argv_word:
        (part1, part2) = argv_word.split(':')

        if part1.isdigit() and part2.isdigit():
            part1 = int(part1)
            part2 = int(part2)

            # 4-byte:2-byte
            if part1 >= 0 and part1 <= 4294967295 and part2 >= 0 and part2 <= 65535:
                return True

            # 2-byte:4-byte
            if part1 >= 0 and part1 <= 65535 and part2 >= 0 and part2 <= 4294967295:
                return True

    return False


def tab_aspath_access_list(args, ended_with_space, last_argv):
    final = []
    for x in get_aspath_access_list():
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'as-path access-list'))

    if not final:
        final.append(('<as-path-access-list>', 'as-path access-list'))

    return final


def tab_bgppeer(args, ended_with_space, last_argv):
    final = []
    for x in get_bgppeers(args):
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'BGP neighbor or peer-group'))

    if not final:
        final.append(('<bgppeer>', 'BGP neighbor or peer-group'))

    return final


def tab_community_list(args, ended_with_space, last_argv):
    final = []
    for x in get_community_list():
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'BGP community-list'))

    if not final:
        final.append(('<community-list>', 'BGP community-list'))

    return final


def tab_extcommunity_list(args, ended_with_space, last_argv):
    final = []
    for x in get_extcommunity_list():
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'BGP extcommunity-list'))

    if not final:
        final.append(('<extcommunity-list>', 'BGP extcommunity-list'))

    return final


def tab_peergroup(args, ended_with_space, last_argv):
    final = []
    for x in get_bgp_peergroups(args):
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'BGP peer-group'))

    if not final:
        final.append(('<peergroup>', 'BGP peer-group'))

    return final


def tab_prefix_list_v4(args, ended_with_space, last_argv):
    final = []
    for x in get_prefix_list_v4():
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'prefix-list'))

    if not final:
        final.append(('<prefix-list>', 'prefix-list'))

    return final


def tab_prefix_list_v6(args, ended_with_space, last_argv):
    final = []
    for x in get_prefix_list_v6():
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'prefix-list'))

    if not final:
        final.append(('<prefix-list>', 'prefix-list'))

    return final


def tab_route_map(args, ended_with_space, last_argv):
    final = []

    # If ended_with_space is True, the user did something like "net show route-map <TAB>", and
    # we need to list all route-maps (in that example).  If ended_with_space is False, they did
    # "net show route-map B<TAB>", and we need to list only the route-maps that begin with 'B'.
    for x in get_route_map():
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'route-map'))

    if not final:
        final.append(('<route-map>', 'route-map'))

    return final


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)7s: %(message)s")
    doctest.testmod()
