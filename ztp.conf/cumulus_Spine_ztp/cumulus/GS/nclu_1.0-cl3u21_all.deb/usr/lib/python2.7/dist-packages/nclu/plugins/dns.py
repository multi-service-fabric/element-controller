"""
Copyright (C) 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt

----------------------------------------------------------------------------------------
Use this module to specify DNS parameters.

http://man7.org/linux/man-pages/man5/resolv.conf.5.html


Usage:
    net add dns nameserver (ipv4 <ipv4>|ipv6 <ipv6>) [vrf <interface>]
    net del dns nameserver (ipv4 <ipv4>|ipv6 <ipv6>)
    net show configuration dns

Options:
    nameserver    : An IP address of a remote DNS server
    vrf           : Virtual routing and forwarding
"""


import logging
import re
import os
from collections import OrderedDict
from difflib import Differ
from nclu.NetDaemon import NetDaemon
from nclu.plugins import (
    get_config_files_helper,
    get_pending_diffs,
    make_scratchpads,
    merge_messages,
    persist_configurations,
    remove_scratch_files_and_backups,
    run_commands)
from stat import S_IXUSR, S_IXGRP, S_IXOTH  # Flags used to set file permissions for executibility

RESOLV = "/etc/resolv.conf"
RESOLV_SCRATCHPAD = "/run/nclu/dns/{0}".format(os.path.basename(RESOLV))
NO_DNS_UPDATE = "/etc/dhcp/dhclient-enter-hooks.d/nodnsupdate"

log = logging.getLogger("netd")


def commit_pending(verbose):
    """
    In addition to copying a scratchpad to a configuration file, committing changes to
    DNS might necessitate running an executable that ensures VRF rules (FIBs) are updated.
    This is the case when the scratchpad adds or removes nameserver lines with vrf information.

    Return a 2-tuple of (bool, dict).  The boolean indicates if the commit succeeded.
    The dictionary is as described in execute_modular.
    """

    if not os.path.isfile(RESOLV_SCRATCHPAD):
        # There are no changes to commit.
        return (True, {"output": ''})

    with open(RESOLV_SCRATCHPAD) as f:
        scratchpad_text = f.read()

    if os.path.isfile(RESOLV):
        with open(RESOLV) as f:
            resolv_conf_text = f.read()
    else:
        resolv_conf_text = ''

    diff_lines = Differ().compare(resolv_conf_text.splitlines(True), scratchpad_text.splitlines(True))
    commands, stuff_to_add, stuff_to_del = get_restart_commands(RESOLV, diff_lines)

    # Write the scratchpad to RESOLV_CONF, and delete the scratchpad, using the parent class method.
    persist_configurations([(RESOLV, RESOLV_SCRATCHPAD)])

    # Call executables to update VRF rules (FIBs).
    outcome, commands_count, messages = run_commands(commands, verbose)

    if outcome:
        # The commit succeeded.
        remove_scratch_files_and_backups([RESOLV_SCRATCHPAD])

        if stuff_to_add:
            # The user added a nameserver.  Make sure this change isn't overwritten by DHCP upon rebooting.
            if not os.path.isfile(NO_DNS_UPDATE):
                create_no_dns_update_file()
        elif stuff_to_del and (resolv_conf_text.count("nameserver") - stuff_to_del) == 0:
            assert not ((resolv_conf_text.count("nameserver") - stuff_to_del) < 0)

            # The user deleted the last nameserver entry.  Remove the NO_DNS_UPDATE file.
            if os.path.isfile(NO_DNS_UPDATE):
                os.remove(NO_DNS_UPDATE)
    else:
        # The commit failed.  Revert configurations.
        assert os.path.isfile(RESOLV_SCRATCHPAD + ".bak"), "This should have been created by the previous call to persist_configurations."
        persist_configurations([(RESOLV, RESOLV_SCRATCHPAD + ".bak")], False)

        # Rerun commands which previously executed successfully.
        revert_outcome, revert_commands_count, revert_messages = run_commands(commands[:commands_count], verbose)
        merge_messages(messages, revert_messages)
        if revert_commands_count < commands_count:
            if "error" not in messages:
                messages["error"] = []
            messages["error"].append("Successfully executed {0} commands while trying to commit, but reverting the commit only "
                                     "successfully executed {1} commands.".format(commands_count, revert_commands_count))

    return (outcome, messages)


def get_restart_commands(filename, diff_lines):
    """
    DNS is exceptional in that the commands that should be run after changing the configuration depend
    on the specifics of the changes.  (Most protocols just require restarting a daemon.)

    Return a 3-tuple where the first element is a list of commands.  The remaining elements are
    used by commit_pending.  This function is also used during a rollback.

    filename - A string; only RESOLV has associated changes
    diff - A list of strings; the difference between the old configuration and the new configuration
    """

    assert filename in get_managed_files(), "filename = {0}".format(filename)

    if filename != RESOLV:
        return ([], False, 0)

    assert diff_lines is not None

    vrfs_to_add = []
    vrfs_to_del = []
    stuff_to_add = False
    stuff_to_del = 0
    nameserver_diff_re = re.compile(r"""(?P<action>-|\+)\s*nameserver\s+(?P<ip>[.:\da-f]+)(?:\s+#\s+vrf\s+(?P<vrf>\w+))?""", re.IGNORECASE)

    # Get affected VRFs, if any.
    for line in diff_lines:
        nameserver_diff = nameserver_diff_re.match(line)
        if nameserver_diff is not None:
            if nameserver_diff.group("action") == '+':
                stuff_to_add = True
                if nameserver_diff.group("vrf"):  # Neither None nor the empty string
                    vrfs_to_add.append((nameserver_diff.group("ip"), nameserver_diff.group("vrf")))
            else:
                assert nameserver_diff.group("action") == '-'
                stuff_to_del += 1
                if nameserver_diff.group("vrf"):  # Neither None nor the empty string
                    vrfs_to_del.append((nameserver_diff.group("ip"), nameserver_diff.group("vrf")))

    # Derive executables to update VRF rules (FIBs).
    commands = [["/usr/lib/vrf/vrf-dns-helper", "dns_add", ip, vrf] for ip, vrf in vrfs_to_add]
    commands.extend([["/usr/lib/vrf/vrf-dns-helper", "dns_del", ip, vrf] for ip, vrf in vrfs_to_del])

    return (commands, stuff_to_add, stuff_to_del)


def create_no_dns_update_file():
    """
    Create a file that prevents DHCP from overwriting users' changes when the device is rebooted.
        https://www.vultr.com/docs/stop-dhcp-from-changing-resolve-conf
    """

    assert not os.path.isfile(NO_DNS_UPDATE), "Don't call this function if the file already exists."

    with open(NO_DNS_UPDATE, 'w') as f:
        f.write("#!/bin/sh\n"
                "make_resolv_conf(){\n"
                "    :\n"
                "}\n")

    # Make the file executable.
    existing_permissions = os.stat(NO_DNS_UPDATE).st_mode
    os.chmod(NO_DNS_UPDATE, existing_permissions | S_IXUSR | S_IXGRP | S_IXOTH)


def show_config_commands(ifupdown2_wrapper):
    """
    net show configuration commands
    """

    if not os.path.isfile(RESOLV):
        # Nothing to do.
        return ([], [])

    # Read the "nameserver" parameter lines from the configuration file.
    with open(RESOLV) as f:
        servers = re.findall(r"""^\s*nameserver\s+([.:\da-f]+)(?:\s+#\s+vrf\s+(\w+))?""", f.read(), re.IGNORECASE | re.MULTILINE)

    commands = []

    for ip, vrf in servers:
        if '.' in ip:
            # IPv4
            if vrf:
                commands.append("net add dns nameserver ipv4 {0} vrf {1}".format(ip, vrf))
            else:
                commands.append("net add dns nameserver ipv4 {0}".format(ip))
        else:
            # IPv6
            if vrf:
                commands.append("net add dns nameserver ipv6 {0} vrf {1}".format(ip, vrf))
            else:
                commands.append("net add dns nameserver ipv6 {0}".format(ip))

    return (commands, [])


def show_config_summary(summary):
    """
    net show configuration dns

    Populate the "summary" dictionary with information about the DNS configuration.
    """

    assert isinstance(summary, dict)

    if not os.path.isfile(RESOLV):
        # Nothing to do.
        return

    with open(RESOLV) as f:
        servers = re.findall(r"""^\s*nameserver\s+([.:\da-f]+(?:\s+#\s+vrf\s+\w+)?)""", f.read(), re.IGNORECASE | re.MULTILINE)

    if servers:
        summary["dns"] = OrderedDict()
        summary["dns"]["nameserver"] = servers


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """

    assert isinstance(net_daemon, NetDaemon)

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert "configuration" not in tokens, "\"net show configuration dns\" does not use this code path."
    assert "dns" in tokens and "nameserver" in tokens, "Why are you here?"

    if not os.path.isfile(RESOLV_SCRATCHPAD):
        make_scratchpads([(RESOLV, RESOLV_SCRATCHPAD, '')])

    if tokens.get("add") is not None:
        return add_dns_nameserver(tokens)
    elif tokens.get("del") is not None:
        return del_dns_nameserver(tokens)

    return (False, {"output": '', "error": "Unrecognized DNS command."})


def add_dns_nameserver(tokens):
    """
    dns add dns nameserver (ipv4 <ipv4>|ipv6 <ipv6>) [vrf <interface>]

    Add a nameserver IP address to the configuration file if it is not already present.
    """

    assert tokens.get("<ipv4>") is not None or tokens.get("<ipv6>") is not None
    ip = tokens.get("<ipv4>") if (tokens.get("ipv4") is not None) else tokens.get("<ipv6>")

    # Make sure the IP isn't already in the scratchpad file.
    with open(RESOLV_SCRATCHPAD) as f:
        if re.search(r"""^\s*nameserver\s+{0}""".format(ip), f.read(), re.IGNORECASE | re.MULTILINE) is not None:
            return (True, {"output": '', "info": ["The IP is already present."]})

    # Append a new nameserver line to the scratchpad file.
    with open(RESOLV_SCRATCHPAD, 'a') as f:
        if tokens.get("vrf") is not None:
            vrf = tokens.get("<interface>")
            f.write("nameserver {0} # vrf {1}\n".format(ip, vrf))
        else:
            f.write("nameserver {0}\n".format(ip))

    return (True, {"output": ''})


def del_dns_nameserver(tokens):
    """
    dns del dns nameserver (ipv4 <ipv4>|ipv6 <ipv6>)

    Remove a "nameserver" line containing the given IP address.
    """

    with open(RESOLV_SCRATCHPAD) as f:
        scratchpad = f.read()

    # Remove the given IP from the configuration file text.
    ip = tokens.get("<ipv4>") if (tokens.get("ipv4") is not None) else tokens.get("<ipv6>")
    scratchpad_modified = re.sub(r"""^\s*nameserver\s+{0}.*?$""".format(ip), '', scratchpad, 0, re.IGNORECASE | re.MULTILINE)

    if len(scratchpad_modified) < len(scratchpad):
        # Output the modified configuration text.
        with open(RESOLV_SCRATCHPAD, 'w') as f:
            f.write(scratchpad_modified)
        return (True, {"output": ''})

    return (True, {"output": '', "info": ["The IP was not present."]})


def del_all():
    """
    net del all

    Remove all "nameserver" entries from the DNS configuration file other than the first entry,
    and remove the NO_DNS_UPDATE file.
    """

    if not os.path.isfile(RESOLV_SCRATCHPAD):
        # Create the scratchpad.
        make_scratchpads([(RESOLV, RESOLV_SCRATCHPAD, '')])

    with open(RESOLV_SCRATCHPAD) as f:
        scratchpad = f.read()

    nameservers = re.findall(r"""^\s*nameserver\s+[\d.:a-f]+.*?$""", scratchpad, re.IGNORECASE | re.MULTILINE)
    if len(nameservers) > 1:
        # Delete every nameserver entry after the first.
        for nameserver in nameservers[1:]:
            scratchpad = re.sub(nameserver, '', scratchpad, 0, re.MULTILINE)

        # Output the modified file.
        with open(RESOLV_SCRATCHPAD, 'w') as f:
            f.write(scratchpad)

    if os.path.isfile(NO_DNS_UPDATE):
        os.remove(NO_DNS_UPDATE)


def get_config_files():
    """
    Return a string with the content of all existing, non-empty configuration files managed with this plug-in.
    """

    return get_config_files_helper([RESOLV])


def get_pending(use_colors):
    """ Return a string of the pending changes in all managed files. """

    return get_pending_diffs([(RESOLV, RESOLV_SCRATCHPAD)], use_colors)


def abort_pending():
    remove_scratch_files_and_backups([RESOLV_SCRATCHPAD])


def get_managed_files():
    """ Return a list of managed files. """

    return [RESOLV, NO_DNS_UPDATE]
