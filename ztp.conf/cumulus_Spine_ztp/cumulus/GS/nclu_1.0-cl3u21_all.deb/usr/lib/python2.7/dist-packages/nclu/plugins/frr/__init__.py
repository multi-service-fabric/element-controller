"""
Copyright (C) 2016, 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt


This module is permissions sensitive.  Its configuration files contain passwords that
should not be shown to users without edit permission.
"""

import doctest
import logging
import os
import re
import shutil
from nclu import (
    chown_chgroup,
    files_match,
    get_pending_add_del_commands,
    glob_to_numbers,
    ifname_expand_glob,
    service_is_active,
    service_is_enabled,
    WORKING_DIRECTORIES_PERMISSIONS,
)
from nclu.plugins import (
    get_config_files_helper,
    get_pending_diffs,
    persist_configurations,
    remove_scratch_files_and_backups
)
from nclu.plugins.frr.adddel import execute_command_add_del
from nclu.plugins.frr.frr_docstring import __doc__
from nclu.plugins.frr.showclear import (
    execute_command_show_clear,
    sanitize_passwords,
    show_config_commands as showclear_show_config_commands,
    show_config_summary as showclear_show_config_summary
)
from nclu.plugins.frr.core import (
    get_daemons,
    FRR_RELOAD_PY,
    SERVICE_NAME,
    SCRATCHPAD_DIRECTORY,
    ETC_FRR,
    ETC_FRR_DAEMONS,
    ETC_FRR_DAEMONS_SCRATCHPAD,
    ETC_FRR_DAEMONS_BACKUP,
    ETC_FRR_DAEMONS_BASELINE,
    ETC_FRR_CONF,
    ETC_FRR_CONF_SCRATCHPAD,
    ETC_FRR_CONF_BACKUP,
    ETC_FRR_CONF_BASELINE,
)
from subprocess import CalledProcessError, check_output, STDOUT

# NetDaemon.reload looks for this.
per_command_helptext = {
    "net (add|del) bgp timers": {"<0-65535>": "Keepalive interval"},
    "net (add|del) bgp timers <0-65535>": {"<0-65535>": "Holdtime"},
    "net (add|del) bgp neighbor <bgppeer> bfd": {"<2-255>": "Detect Multiplier"},
    "net (add|del) bgp neighbor <bgppeer> bfd <2-255>": {"<50-60000>": "Required min receive interval"},
    "net (add|del) bgp neighbor <bgppeer> bfd <2-255> <50-60000>": {"<50-60000>": "Desired min transmit interval"},
}

logging.getLogger("frr-reload").setLevel(logging.WARNING)
log = logging.getLogger("netd")


def frr_restart_needed():
    """
    Returne True if any of the following are True, else return False
    - The daemons was modified
    - frr is not running
    - The ospf/ospf6 router-id was modified
    """
    if os.path.isfile(ETC_FRR_DAEMONS_SCRATCHPAD) and not files_match(ETC_FRR_DAEMONS, ETC_FRR_DAEMONS_SCRATCHPAD):
        return True

    if not service_is_active(SERVICE_NAME):
        return True

    # If the OSPF(6) router-id is changing we must restart frr
    if os.path.isfile(ETC_FRR_CONF) and os.path.isfile(ETC_FRR_CONF_SCRATCHPAD):

        try:
            check_output(["/usr/bin/diff", "-U", '3', ETC_FRR_CONF, ETC_FRR_CONF_SCRATCHPAD])
        except CalledProcessError as e:
            # There is a delta.
            if re.search(r"""^\+\s+ospf6? router-id""", e.output, re.MULTILINE) is not None:
                return True

    return False


def frr_wr_mem():
    """
    Issue a "wr mem", this is primarily to get ETC_FRR_CONF in a nice clean format
    """
    messages = {"output": ''}

    try:
        check_output(["/usr/bin/vtysh", "-c", "wr mem"], stderr=STDOUT)
        return (True, messages)

    except CalledProcessError as e:
        log.exception(e)
        messages["error"] = ["'wr mem' failed due to '{0}'".format(e.output)]
        log.error(messages["error"][0])
        return (False, messages)


def frr_restart(verbose):
    """
    Restart the FRR service.  Return a 2-tuple of (bool, str) indicating if the restart
    succeeded and any messages for the user.
    """

    assert isinstance(verbose, bool)
    messages = {"output": ''}

    try:
        output = check_output(["/bin/systemctl", "enable", SERVICE_NAME])
        if verbose:
            messages["output"] += ('\n' if messages["output"] else '') + output

        output = check_output(["/bin/systemctl", "reset-failed", SERVICE_NAME])
        if verbose:
            messages["output"] += ('\n' if messages["output"] else '') + output

        output = check_output(["/bin/systemctl", "restart", SERVICE_NAME])
        if verbose:
            messages["output"] += ('\n' if messages["output"] else '') + output

    except CalledProcessError as e:
        log.exception(e)
        messages["error"] = ["Failed to restart {0} due to \"{1}\".".format(SERVICE_NAME, e.output)]
        log.error(messages["error"][0])
        return (False, messages)

    return (True, messages)


def frr_reload(verbose):
    messages = {"output": ''}

    try:
        output = check_output([FRR_RELOAD_PY, "--overwrite", "--stdout", "--reload", ETC_FRR_CONF], stderr=STDOUT)
        if verbose:
            messages["output"] = output

        result, wr_mem_messages = frr_wr_mem()

    except CalledProcessError as e:
        log.exception(e)
        log.error(e.output)
        messages["error"] = ["{0} failed.\n{1}\n{2}\n{3}\n".format(FRR_RELOAD_PY, '=' * 80, e.output, '=' * 80)]
        return (False, messages)

    return (result, messages if result else wr_mem_messages)


def file_baselines_match():
    messages = {"output": ''}

    # Verify that FRR's daemon and configuration files have not been modified.
    if not files_match(ETC_FRR_DAEMONS, ETC_FRR_DAEMONS_BASELINE):
        messages["error"] = ["{0} was modified by another user.\n{1}".format(ETC_FRR_DAEMONS, get_pending_add_del_commands())]
        return (False, messages)

    if (os.path.exists(ETC_FRR_CONF) and os.path.exists(ETC_FRR_CONF_BASELINE) and
        os.path.getmtime(ETC_FRR_CONF) > os.path.getmtime(ETC_FRR_CONF_BASELINE)):
        messages["error"] = ["{0} was modified by another user.\n{1}".format(ETC_FRR_CONF, get_pending_add_del_commands())]
        return (False, messages)

    return (True, messages)


def init_guts_add_del():
    """
    - create BASELINE files if needed
    - create SCRATCHPAD files if needed
    """
    messages = {"output": ''}

    # We use BASELINE files to later determine if the original config file was
    # modified by another user.
    if not os.path.isfile(ETC_FRR_CONF_BASELINE):
        (result, wr_mem_message) = frr_wr_mem()

        if result:

            # To create ETC_FRR_CONF_BASELINE we need to "mark" the config file with "end"
            # strings to ID the various contexts and sub-contexts.  This is done via "vtysh -m".
            try:
                output = check_output(["/usr/bin/vtysh", "-m", "-f", ETC_FRR_CONF], stderr=STDOUT).splitlines()
            except CalledProcessError as e:
                # vtysh will fail to mark the file if it contains an invalid
                # configuration. Since we just issued a "wr mem", if ETC_FRR_CONF
                # contains an invalid config it is due to a bug in FRR.
                msg = "'vtysh -m -f {0}' failed due to '{1}'.\nThe contents of {2} are:\n".format(ETC_FRR_CONF, e.output, ETC_FRR_CONF)
                with open(ETC_FRR_CONF) as f:
                    msg += f.read()
                log.error(msg)

                messages["error"] = ["Could not mark {0} due to '{1}'.\nSee /var/log/netd.log for more details".format(ETC_FRR_CONF, e.output)]
                return (False, messages)

            with open(ETC_FRR_CONF_BASELINE, 'w') as f:
                for line in output:
                    if line != '!':
                        f.write(line + '\n')

            shutil.copyfile(ETC_FRR_CONF_BASELINE, ETC_FRR_CONF_SCRATCHPAD)
        else:
            return (False, wr_mem_message)

    if not os.path.isfile(ETC_FRR_DAEMONS_BASELINE):
        shutil.copyfile(ETC_FRR_DAEMONS, ETC_FRR_DAEMONS_BASELINE)
        shutil.copyfile(ETC_FRR_DAEMONS, ETC_FRR_DAEMONS_SCRATCHPAD)

    (result, files_modified_messages) = file_baselines_match()

    if not result:
        messages = files_modified_messages
        return (False, messages)

    return (True, messages)


def init_guts():
    """
    - handle the transition from quagga to frr and vice versa
    - create the scratchpad directory
    - start frr if needed
    """

    messages = {"output": ''}

    if os.path.exists("/run/frr/.qcompat"):
        if SERVICE_NAME == "frr":
            messages["error"] = ["frr was migrated to quagga, please run 'sudo systemctl restart netd'"]
            return (False, messages)
    else:
        if SERVICE_NAME == "quagga":
            messages["error"] = ["quagga was migrated to frr, please run 'sudo systemctl restart netd'"]
            return (False, messages)

    # Create the scratchpad directory
    if not os.path.isdir(SCRATCHPAD_DIRECTORY):
        os.makedirs(SCRATCHPAD_DIRECTORY, mode=WORKING_DIRECTORIES_PERMISSIONS)

    if not os.path.isdir(ETC_FRR):
        messages["error"] = ["The FRR wrapper could not initialize. {0} is missing.".format(ETC_FRR)]
        log.error(messages["error"][0])
        return (False, messages)

    # /etc/frr/daemons does not exist or is empty.  Create a default file.
    if not os.path.exists(ETC_FRR_DAEMONS) or os.path.getsize(ETC_FRR_DAEMONS) == 0:
        with open(ETC_FRR_DAEMONS, 'w') as f:
            f.write("zebra=yes\n")

    # /etc/frr/frr.conf does not exist or is empty.  Create a default file.
    if not os.path.isfile(ETC_FRR_CONF) or os.path.getsize(ETC_FRR_CONF) == 0:
        with open(ETC_FRR_CONF, 'w') as f:
            f.write("service integrated-vtysh-config\n")

    if not service_is_active(SERVICE_NAME):
        daemons = get_daemons()

        # If zebra is not enabled, update the daemons file to enable zebra
        if daemons.get("zebra", "").lower() != "yes":
            daemons["zebra"] = "yes"

            with open(ETC_FRR_DAEMONS, 'w') as f:
                for (daemon, daemon_value) in daemons.iteritems():
                    f.write("{0}={1}\n".format(daemon, daemon_value))

        (result, systemctl_message) = frr_restart(False)

        if result:
            (result, systemctl_message) = frr_wr_mem()

        if not result:
            messages = systemctl_message
            return (False, messages)

    return (True, messages)


def copy_scratchpad_to_frr_conf():
    # FRR is picky about frr.conf being "marked" so remove all of the "end"
    # lines that are there as a result of marking the contexts
    # and sub-contexts.
    with open(ETC_FRR_CONF, 'w') as fh_new:
        with open(ETC_FRR_CONF_SCRATCHPAD) as fh_scratch:
            for line in fh_scratch:
                if line.strip() != 'end':
                    fh_new.write(line)

    chown_chgroup(ETC_FRR_CONF, SERVICE_NAME, SERVICE_NAME)


def commit_pending(verbose):
    """
    Copy scratchpad files over configuration files, call necessary restart commands, etc.

    Return a 2-tuple of (bool, dict).  The boolean indicates if the commit succeeded.
    The dictionary is as described in nclu/plugins/__init__.py:execute_modular.
    """

    messages = {"output": ''}

    if not os.path.isfile(ETC_FRR_DAEMONS_SCRATCHPAD) and not os.path.isfile(ETC_FRR_CONF_SCRATCHPAD):
        # There are no changes to commit.
        return (True, messages)

    if (files_match(ETC_FRR_DAEMONS_BASELINE, ETC_FRR_DAEMONS_SCRATCHPAD) and
        files_match(ETC_FRR_CONF_BASELINE, ETC_FRR_CONF_SCRATCHPAD)):

        # There are no changes to commit.
        remove_scratch_files_and_backups((ETC_FRR_DAEMONS_SCRATCHPAD, ETC_FRR_CONF_SCRATCHPAD))
        return (True, messages)

    # Did user-A edit the config file after user-B started staging changes via nclu?
    (result, files_modified_messages) = file_baselines_match()

    if not result:
        messages = files_modified_messages
        return (False, messages)

    # A service must be enabled to start automatically following a reboot
    if not service_is_enabled(SERVICE_NAME):
        try:
            check_output(["/bin/systemctl", "enable", SERVICE_NAME])
        except CalledProcessError as e:
            log.exception(e)
            log.error(e.output)
            messages["error"] = ["Failed to enable {0}, see /var/log/netd.log for more details".format(SERVICE_NAME)]
            return (False, messages)

    result = False
    do_frr_restart = frr_restart_needed()

    # copy the daemons scratchpad file over the real daemons file
    if os.path.isfile(ETC_FRR_DAEMONS_SCRATCHPAD):
        persist_configurations([(ETC_FRR_DAEMONS, ETC_FRR_DAEMONS_SCRATCHPAD)])
        chown_chgroup(ETC_FRR_DAEMONS, SERVICE_NAME, SERVICE_NAME)

    # copy the frr.conf scratchpad file over the real frr.conf file
    if os.path.isfile(ETC_FRR_CONF_SCRATCHPAD):
        shutil.copyfile(ETC_FRR_CONF, ETC_FRR_CONF_BACKUP)
        copy_scratchpad_to_frr_conf()

    # TODO - we need the diff
    if do_frr_restart:
        result, systemctl_message = frr_restart(verbose)

        if result:
            result, systemctl_message = frr_wr_mem()

            if result:
                copy_scratchpad_to_frr_conf()
                result, systemctl_message = frr_reload(verbose)
    else:
        result, systemctl_message = frr_reload(verbose)

    # reload/restart worked, delete our backup and scratchpad files
    if result:
        remove_scratch_files_and_backups((ETC_FRR_DAEMONS_SCRATCHPAD, ETC_FRR_CONF_SCRATCHPAD))

    # reload/restart failed, restore the config files from our backups but do
    # not delete the scratchpad files
    else:
        messages = systemctl_message

        if os.path.isfile(ETC_FRR_DAEMONS_BACKUP):
            persist_configurations([(ETC_FRR_DAEMONS, ETC_FRR_DAEMONS_BACKUP)], False)
            os.remove(ETC_FRR_DAEMONS_BACKUP)

        if os.path.isfile(ETC_FRR_CONF_BACKUP):
            persist_configurations([(ETC_FRR_CONF, ETC_FRR_CONF_BACKUP)], False)
            os.remove(ETC_FRR_CONF_BACKUP)

        # restart/reload frr to apply the original configuration
        if do_frr_restart:
            (result, systemctl_message) = frr_restart(verbose)
        else:
            (result, systemctl_message) = frr_reload(verbose)

    return (result, messages)


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert tokens.get("configuration") is None, "\"net show configuration\" does not use this code path."

    result, messages = init_guts()

    if not result:
        return (False, messages)

    ifnames = []
    bgppeers = []
    result = True

    if tokens.get("<interface>"):
        ifname = str(tokens.get("<interface>"))

        try:
            ifnames = ifname_expand_glob(ifname)  # A list
        except ValueError as e:
            messages["error"] = ["\"{0}\" is not a valid interface name nor glob.  {1}".format(ifname, e)]
            log.error(messages["error"][0])
            return (False, messages)

    elif tokens.get("vlan") and tokens.get("<number-range-list>"):
        vlan_numbers = glob_to_numbers(str(tokens.get("<number-range-list>")))

        for number in vlan_numbers:
            ifnames.append("vlan{0}".format(number))

    elif tokens.get("<bgppeer>"):
        bgppeer = str(tokens.get("<bgppeer>"))

        try:
            bgppeers.extend(ifname_expand_glob(bgppeer))
        except ValueError as e:
            messages["error"] = ["\"{0}\" is not a valid interface name nor glob.  {1}".format(bgppeer, e)]
            log.error(messages["error"][0])
            return (False, messages)

    if tokens.get('add') or tokens.get('del'):
        (result, messages) = init_guts_add_del()

        if result:
            (result, messages) = execute_command_add_del(net_daemon, ifnames, bgppeers)

    elif tokens.get("show") or tokens.get("clear"):
        (result, messages) = execute_command_show_clear(net_daemon, ifnames, bgppeers)

        if "is not running" in messages["output"]:
            # A service managed by frr.service, such as pimd or ospfd, is not running.
            result = False
            handle_service_notifications(messages)

    else:
        messages["error"] = ["No commands matched."]
        result = False

    return (result, messages)


def handle_service_notifications(messages):
    """
    Modify a messages dictionary containing notice of services not running by removing
    the notifications from "output", deduplicating, and moving them to "errors".
    """

    assert "is not running" in messages["output"]

    if "error" not in messages:
        messages["error"] = []

    services_not_running = frozenset(re.findall(r"""^\s*\S+ is not running$""", messages["output"], re.MULTILINE))

    for notification in services_not_running:
        messages["output"] = messages["output"].replace(notification, '')
        messages["error"].append(notification)

    messages["output"] = messages["output"].strip()


def del_all():
    """
    net del all
    """

    result, messages = init_guts()
    if not result:
        return

    result, messages = init_guts_add_del()
    if not result:
        return

    with open(ETC_FRR_DAEMONS_SCRATCHPAD, 'w') as f:
        f.write("zebra=yes\n")

    with open(ETC_FRR_CONF_SCRATCHPAD, 'w') as f:
        f.write("service integrated-vtysh-config\n")


def get_config_files(user_may_edit):
    """
    Return a string with the content of all existing, non-empty configuration files managed with this plug-in.
    """

    managed_files_text = get_config_files_helper(get_managed_files())

    if user_may_edit:
        return managed_files_text

    # The user doesn't have edit permission.  Redact sensitive information.
    return sanitize_passwords(managed_files_text)


def get_pending(use_colors):
    return get_pending_diffs([(ETC_FRR_DAEMONS, ETC_FRR_DAEMONS_SCRATCHPAD),
                              (ETC_FRR_CONF_BASELINE, ETC_FRR_CONF_SCRATCHPAD)],
                             use_colors)


def abort_pending():
    remove_scratch_files_and_backups((ETC_FRR_DAEMONS_SCRATCHPAD, ETC_FRR_CONF_SCRATCHPAD))


def get_managed_files():
    return [ETC_FRR_DAEMONS, ETC_FRR_CONF]


def show_config_commands(user_may_edit, ifupdown2_wrapper):
    return showclear_show_config_commands(user_may_edit, ifupdown2_wrapper)


def show_config_summary(user_may_edit, summary):
    showclear_show_config_summary(user_may_edit, summary)


def get_restart_commands(filename, diff_lines):
    """
    If ETC_FRR_DAEMONS is being modified, restarting FRR is required.
    Otherwise, only a reload is required.  The goal is not to perform
    a restart and a reload.
    """

    assert filename in get_managed_files(), "filename = {0}".format(filename)

    if filename == ETC_FRR_DAEMONS:
        # A restart is always required when modifying this file.
        return [("/bin/systemctl", "enable", SERVICE_NAME),
                ("/bin/systemctl", "reset-failed", SERVICE_NAME),
                ("/bin/systemctl", "restart", SERVICE_NAME)]

    assert filename == ETC_FRR_CONF, "This is the only other option right now."

    # Determine from the diff if a restart is required.
    for line in diff_lines:
        line = line.strip()

        # Example:
        # --- /run/nclu/frr//frr.conf.scratchpad.baseline   2018-03-28 05:17:15.512668667 -0700
        # +++ /run/nclu/frr//frr.conf.scratchpad    2018-03-28 05:17:15.514668576 -0700
        if line.startswith('--- ') and "daemons" in line.lower():
            # A restart will occur due to changes to ETC_FRR_DAEMONS.
            # No additional commands need to be run for ETC_FRR_CONF.
            return []

    # A reload is required.
    return [("/bin/systemctl", "enable", SERVICE_NAME),
            ("/bin/systemctl", "reload", SERVICE_NAME)]


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)7s: %(message)s")
    doctest.testmod()
