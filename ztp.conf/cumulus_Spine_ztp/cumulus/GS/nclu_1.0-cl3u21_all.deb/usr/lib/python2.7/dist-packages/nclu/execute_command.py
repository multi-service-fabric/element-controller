"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from nclu import EXAMPLES_DIRECTORIES, get_vrf_name, ifname_expand_glob, ifname_is_glob, ifnames_to_glob, PENDING_COMMANDS_FILE
from nclu.capturing import Capturing
from nclu.execute_command_commit import execute_commit
from nclu.execute_command_rollback import execute_rollback
from nclu.execute_command_show import execute_show, show_config_commands, show_config_files, show_config_summary
from nclu.pending import get_pending, get_pending_json
from nclu.plugins import execute_modular, format_messages, is_modular, merge_messages
from nclu.plugins.frr.adddel import del_interfaces as frr_del_interfaces
from nclu.wrappers.ifupdown2 import EtcNetworkInterface, get_ifnames, keywords_configured
import logging
import os

log = logging.getLogger("netd")

# Return this text when the user runs "net" or "net (-h|help|--help)".
# It is not a complete list of commands.
basic_usage = """
Usage:
    # net <COMMAND> [<ARGS>] [help]
    #
    # net is a command line utility for networking on Cumulus Linux switches.
    #
    # COMMANDS are listed below and have context specific arguments which can
    # be explored by typing "<TAB>" or "help" anytime while using net.
    #
    # Use "man net" for a more comprehensive overview.

    net abort
    net commit [verbose] [confirm [<number-seconds>]] [description <wildcard>]
    net commit delete (<number>|<number-range>)
    net commit permanent <wildcard>
    net del all
    net help [verbose]
    net pending [json]
    net rollback (<number>|last)
    net rollback description <wildcard-snapshot>
    net show commit (history|<number>|<number-range>|last)
    net show rollback (<number>|last)
    net show rollback description <wildcard-snapshot>
    net show configuration [commands|files|acl|bgp|multicast|ospf|ospf6]
    net show configuration interface [<interface>]

Options:

    # Help commands
    help     : context sensitive information; see section below
    example  : detailed examples of common workflows

    # Configuration commands
    add      : add/modify configuration
    del      : remove configuration

    # Commit buffer commands
    abort    : abandon changes in the commit buffer
    commit   : apply the commit buffer to the system
    pending  : show changes staged in the commit buffer
    rollback : revert to a previous configuration state

    # Status commands
    show     : show command output
    clear    : clear counters, BGP neighbors, etc

    <number-seconds> : Number of seconds
"""


def execute_command(command_list, net_daemon):
    """
    Run the given command, and return a 2-tuple of (bool, str).  The boolean
    indicates if execution succeeded, and the string is the output of the command.

    TODO - When the wrapper paradigm is gone, have this function directly return
    the dictionary associated with plug-ins.
    """

    assert isinstance(command_list, list)
    assert isinstance(net_daemon.wrappers, list) and len(net_daemon.wrappers) > 0, "If the wrappers paradigm has been removed, edit this function."

    # "keywords" might be used to select a module to execute a command.
    assert isinstance(net_daemon.keywords, dict)

    if not command_list:
        # net [-h|help|--help]
        return (True, basic_usage)

    preprocess_command(net_daemon.nclu_parser)

    # Convenience variable
    command = ' '.join(net_daemon.nclu_parser.argv_expanded)

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert isinstance(tokens, dict)

    if "abort" in tokens:
        # net abort
        abort_pending(net_daemon.wrappers, net_daemon.enabled_plugins)
        return (True, '')

    if "example" in tokens:
        # net example <?>

        # Instead of a bunch of if-else statements checking for a specific
        # parameter after "example", just get the parameter from its position.
        assert len(net_daemon.nclu_parser.argv_expanded) > 2, str(net_daemon.nclu_parser.argv_expanded)
        example_path = get_example_path(net_daemon.nclu_parser.argv_expanded[2:])

        if example_path is None:
            return (False, "There is no example for \"{0}\".".format(' '.join(net_daemon.nclu_parser.argv_expanded[2:])))

        try:
            # Return all uncommented lines from the file.
            reply = ''
            with open(example_path) as f:
                for line in f:
                    if not line.startswith('#'):
                        reply += line.rstrip() + '\n'
        except OSError as e:
            return (False, "Couldn't open the example file: {0}".format(e))

        return (True, reply)

    if "pending" in tokens:
        # net pending [json]

        if "json" in tokens:
            return (True, get_pending_json(net_daemon.wrappers, net_daemon.enabled_plugins))
        return (True, get_pending(net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.color_diffs))

    if command == "net del all":
        abort_pending(net_daemon.wrappers, net_daemon.enabled_plugins)

        for plugin in net_daemon.enabled_plugins:
            m = __import__("nclu.plugins." + plugin, fromlist=["del_all"])
            m.del_all()

        for name, wrapper in net_daemon.wrappers:
            assert hasattr(wrapper, "del_all"), "{0} needs to implement \"del_all\".".format(name)
            wrapper.del_all(net_daemon.nclu_parser)

        reply = """\033[91m
***************************************************************************
***************************************************************************\033[0m
NOTE: "net del all" will stage a default configuration file for each of the
packages that are supported by NCLU.  This default configuration may be
different from the configuration that you would get should you remove and
re-install each of these packages.  Please review the staged changes via
"net pending".\033[91m
***************************************************************************
***************************************************************************\033[0m

"""
        return (True, reply)

    # Order matters!  This check must occur before the plug-ins and wrappers checks below.
    if "configuration" in tokens:
        # net show configuration . . .

        if "commands" in tokens:
            return (True, show_config_commands(net_daemon))
        if "files" in tokens:
            return (True, '\n' + show_config_files(net_daemon))

        # TODO - This doesn't work well with modular design because new plug-ins are likely to have to edit this block.
        if "acl" in tokens:
            component = "accesslist"
        elif ("bgp" in tokens or
              "ospf" in tokens or
              "ospf6" in tokens or
              "multicast" in tokens or
              "pim" in tokens or
              "pbrd" in tokens):
            component = "frr"
        elif "dot1x" in tokens:
            component = "dot1x"
        elif "dhcp" in tokens:
            component = "dhcp"
        elif "syslog" in tokens:
            component = "syslog"
        elif "dns" in tokens:
            component = "dns"
        elif "snmp-server" in tokens:
            component = "snmp"
        elif "ptp" in tokens:
            component = "ptp"
        elif "transponders" in tokens:
            component = "transponders"
        elif "interface" in tokens:
            # <interface> might be None, which is okay.
            component = "interface {0}".format(tokens.get("<interface>"))
        else:
            component = None

        # The call to show_config_summary could raise RuntimeError.
        try:
            return (True, show_config_summary(net_daemon, component))
        except RuntimeError as e:
            return (False, str(e))

    assert "ifupdown2" not in net_daemon.enabled_plugins, "Edit this block if ifupdown2 has been converted to a plug-in."
    if net_daemon.wrappers[0][0] == "ifupdown2":
        # ifupdown2 is enabled.  Attempt to validate any interface names specified in the command.
        outcome, message = net_daemon.wrappers[0][1].validate_net_cmd_vs_ifnames(net_daemon.nclu_parser)
        if not outcome:
            return (False, message)

    # Try to execute the command using a component module, which should be used if the component's syntax
    # uniquely includes a non-variable token in the expanded command.
    target_component = None
    for token_key, token_value in tokens.iteritems():
        # Skip syntax variables, which could have values that match fixed keywords.  ex. <interface> = "ipv4"
        if token_key.startswith('<'):
            log.debug("Skipping syntax variable \"{0}\".".format(token_key))
            continue

        for component in net_daemon.keywords:
            if token_value in net_daemon.keywords[component]:
                log.debug("\"{0}\" is unique.".format(token_value))
                target_component = component
                break

        if target_component is not None:
            break
    else:
        # No command token is dispositive.  Try a different approach.
        target_component = select_component(net_daemon.nclu_parser)

    if target_component is not None:
        log.debug("Executing the command using the {0} component module.".format(target_component))

        if is_modular(target_component):
            # Execute the command with a plug-in.
            outcome, messages = execute_modular(target_component, net_daemon)

            if outcome:
                with Capturing() as reply:
                    post_messages = post_plugin(net_daemon, target_component)
                assert isinstance(reply, list)
                if reply:
                    log.debug("Calling post_plugin suppressed the following output:\n{0}".format(reply))
                assert "error" not in post_messages, "Post-execution should never fail the command."
                merge_messages(messages, post_messages)

            return (outcome, format_messages(messages, net_daemon.color_diffs))

        # Else, execute the command with a wrapper.
        for name, wrapper in net_daemon.wrappers:
            if name == target_component:
                assert hasattr(wrapper, "eval_command_line_args"), "Wrappers must have this method."
                with Capturing() as reply:
                    # The call to eval_command_line_args is likely to print output.
                    outcome = wrapper.eval_command_line_args(net_daemon.nclu_parser)
                assert isinstance(reply, list)
                assert isinstance(outcome, bool), "eval_command_line_args should return a boolean indicating if the command succeeded."
                if outcome:
                    # Some wrappered commands have actions that must occur after the main action succeeds.
                    outcome, message = post_wrapper(net_daemon, name)
                    return (outcome, '\n'.join(reply) + message)
        return (False, "Execution of the command failed." + ("\n{0}".format('\n'.join(reply)) if reply else ''))

    # Order matters!  This check must happen before checking for "commit" or "rollback"
    # because of the existence of the commands "net show commit" and "net show rollback".
    # It must also happen after attempts to execute using wrappers, which define
    # additional "show" commands, and it must happen after the test for "configuration",
    # which involves commands with "net show configuration . . .".
    if "show" in tokens:
        return execute_show(net_daemon)

    if "commit" in tokens:
        return execute_commit(net_daemon)

    if "rollback" in tokens:
        return execute_rollback(net_daemon)

    return (False, "Unrecognized command.")


def abort_pending(wrappers, plugins):
    assert len(wrappers) > 0, "If the wrappers paradigm has been removed, edit this function."

    for plugin in plugins:
        m = __import__("nclu.plugins." + plugin, fromlist=["abort_pending"])
        m.abort_pending()

    for _, wrapper in wrappers:
        wrapper.abort_pending()

    if os.path.isfile(PENDING_COMMANDS_FILE):
        os.remove(PENDING_COMMANDS_FILE)


def get_example_path(example):
    """
    Return the full path to the example file with the same name as the parameter.
    If such a file cannot be found, return None.

    >>> get_example_path(["bond"])
    '/usr/share/nclu/example/bond'

    >>> get_example_path(["ospf", "unnumbered"])
    '/usr/share/nclu/example/ospf/unnumbered'
    """

    assert isinstance(example, list)

    for example_dir in EXAMPLES_DIRECTORIES:
        assert example_dir.endswith('/')
        filename = example_dir + '/'.join(example)
        if os.path.isfile(filename):
            return filename
    return None


def select_component(nclu_parser):
    """
    Try to deduce the appropriate component using combinations of tokens.  If this fails,
    return None.  Otherwise, return the appropriate component as a string.
    """

    # Convenience variable
    tokens = nclu_parser.args
    assert isinstance(tokens, dict)

    if "acl" in tokens and ("vlan" in tokens or "ipv4" in tokens or "ipv6" in tokens or "mac" in tokens):
        return "accesslist"

    if "acl" in tokens and ("bgp" in tokens or "ospf" in tokens or "ospf6" in tokens or "pim" in tokens or "igmp" in tokens or "inbound" in tokens):
        return "accesslist"

    if "access-list" in tokens and "as-path" not in tokens:
        return "accesslist"

    if ("show" in tokens or "clear" in tokens) and ("bgp" in tokens or "ospf" in tokens or "ospf6" in tokens or "pim" in tokens or "igmp" in tokens):
        return "frr"

    if "acl" not in tokens and ("bgp" in tokens or "ospf" in tokens or "ospf6" in tokens or "pim" in tokens or "igmp" in tokens or "inbound" in tokens):
        return "frr"

    if len(nclu_parser.argv_expanded) == 3 and "ospf" in tokens:
        # net del ospf
        return "frr"

    if "show" in tokens and ("interface" in tokens or "system" in tokens or "lldp" in tokens or "version" in tokens or "bfd" in tokens):
        # net show . . .
        return "netmisc"

    if "dhcp" in tokens and ("server" in tokens or "server6" in tokens):
        # net add|del dhcp server|server6 . . .
        return "dhcp"

    if ("interface" in tokens or "bond" in tokens) and ("add" in tokens or "del" in tokens):
        # net add|del interface|bond . . .
        return "ifupdown2"

    if len(nclu_parser.argv_expanded) >= 3 and nclu_parser.argv_expanded[2] == "vrf":
        if "show" in tokens:
            return "netmisc"
        else:
            return "ifupdown2"

    if ("show" in tokens or "clear" in tokens):
        if "dot1x" in tokens:
            return "dot1x"
        if "snmp-server" in tokens:
            return "snmp"

    if "vlan" in tokens:
        return "ifupdown2"

    if "time" in tokens:
        return "ntp"

    if "address" in tokens and (tokens.get("<ipv4/prefixlen>") is not None or tokens.get("<ipv6/prefixlen>") is not None):
        return "ifupdown2"

    if "traffic" in tokens:
        return "traffic"

    if "loopback" in tokens:
        return "ifupdown2"

    if "vxlan" in tokens:
        if "routing" in tokens:
            return "frr"
        else:
            return "ifupdown2"

    if "syslog" in tokens and "host" in tokens and "port" in tokens:
        return "syslog"

    return None


def preprocess_command(nclu_parser):
    """
    Perform any necessary data preprocessing here.
    """

    interface = nclu_parser.args.get("<interface>")

    # If "interface" is neither None, nor an empty list, nor an empty string . . .
    if interface:
        # Translate "null0" to "Null0" since this is what frr uses.

        if isinstance(interface, list):
            nclu_parser.args["<interface>"] = ["Null0" if x == "null0" else x for x in interface]
        else:
            assert isinstance(interface, str)
            if interface == "null0":
                nclu_parser.args["<interface>"] = "Null0"


def post_plugin(net_daemon, component):
    """
    If the execution of a command implemented with a plug-in should have any side effects
    outside the plug-in that are broadly applicable, implement them here.  This currently includes:
        1. /etc/network/interfaces changes in response to "add" commands in plug-ins other
            than FRR and ifupdown (currently a wrapper)

    Return the dictionary component of the standard 2-tuple.

    component - A string; the name of the plug-in used to execute the command
    """

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert isinstance(tokens, dict)

    # Create new interfaces, if necessary.
    if component in ("frr", "ifupdown2", "ports") or \
            ("dns" in tokens and "vrf" in tokens) or \
            "add" not in tokens:
        # No interfaces need to be created.
        #   The specified plug-ins directly handle interface creation.
        #   Don't create anything for "net add|del dns ... vrf <interface>".
        #   No addition; no need for new interfaces.
        return {"output": ''}

    assert len(net_daemon.enabled_wrappers) > 0, "If the wrappers paradigm has been removed, edit this function."
    if "ifupdown2" not in net_daemon.enabled_wrappers:
        return {"output": '', "warning": ["ifupdown2 is not enabled.  You must manually configure any new interfaces."]}

    assert net_daemon.wrappers[0][0] == "ifupdown2" and net_daemon.wrappers[0][1] is not None, "ifupdown2 should be first by construction."
    ifupdown2_wrapper = net_daemon.wrappers[0][1]

    messages = {"output": ''}

    if "<interface>" in tokens:
        # If the command has multiple <interface> variables, <interface> will be a list.  Otherwise, it will be unicode.
        log.debug("execute_commands.py:post_plugin: type(tokens[\"<interface>\"]) = {0}".format(type(tokens["<interface>"])))
        interfaces = [tokens["<interface>"]] if isinstance(tokens["<interface>"], basestring) else tokens["<interface>"]
        interfaces_not_created = ifupdown2_wrapper.add_interfaces(ifnames_to_glob(interfaces))
        if interfaces_not_created:
            messages["warning"] = ["{0} could not be created.".format(interface) for interface in interfaces_not_created]

    elif "vlan" in tokens and tokens.get("<number-range-list>") is not None:
        ifnames_valid, interfaces = get_ifnames(net_daemon.nclu_parser, False)
        if ifnames_valid:
            svi_ifnames = filter(lambda i: i.startswith("vlan"), interfaces)
            interfaces_not_created = ifupdown2_wrapper.add_svi_interfaces(svi_ifnames)
            if interfaces_not_created:
                messages["warning"] = ["{0} could not be created.".format(interface) for interface in interfaces_not_created]

    vrf_names = get_vrf_name(net_daemon.nclu_parser.argv_expanded)  # A string, or None
    if vrf_names is not None and "vrf-table" not in tokens:
        # The user is configuring a VRF that does not exist.  Create it.

        vrf_names = ifname_expand_glob(vrf_names) if ifname_is_glob(vrf_names) else [vrf_names]

        for vrf_name in vrf_names:
            vrf_iface = EtcNetworkInterface(vrf_name, ifupdown2_wrapper.ifquery_all)
            if not ifupdown2_wrapper.vrf_add(vrf_iface):
                if "warning" not in messages:
                    messages["warning"] = []
                messages["warning"].append("{0} could not be created.".format(vrf_name))

    return messages


def post_wrapper(net_daemon, component):
    """
    Perform command-specific actions that should follow a call to eval_command_line_args.
    This is only for wrappers!  Plug-ins should not add code here.

    Return (boolean, str) indicating success status and a message, if any.

    component - A string; the name of the wrapper used in execute_command
    """

    assert len(net_daemon.wrappers) > 0, "If the wrappers paradigm has been removed, delete this function."
    assert isinstance(component, str)

    # Convenience variables
    nclu_parser = net_daemon.nclu_parser
    tokens = nclu_parser.args
    assert isinstance(tokens, dict)
    wrappers = net_daemon.wrappers

    ifupdown2_wrapper = wrappers[0][1] if (wrappers[0][0] == "ifupdown2") else None

    if "add" in tokens:
        # If we are configuring an interface in a wrapper, create that interface in /etc/network/interfaces, if necessary.

        if component == "dot1x" and tokens.get("<interface>"):
            if ifupdown2_wrapper is not None:
                ifnames_valid, interfaces = get_ifnames(nclu_parser, False)
                if ifnames_valid:
                    for interface in interfaces:
                        eni = EtcNetworkInterface(interface, ifupdown2_wrapper.ifquery_all)
                        if not eni.exists():
                            eni.add_interface()
                        eni.conf_key_value_solo(True, "bridge-learning", "off", False)

        if component == "dot1x" and "parking-vlan-id" in tokens and tokens.get("<1-4094>") is not None:
            # Add the vlan id to the vlan-aware bridge if it exists.
            if ifupdown2_wrapper is not None:
                ifnames_valid, interfaces = get_ifnames(nclu_parser, False)
                eni = EtcNetworkInterface("bridge", ifupdown2_wrapper.ifquery_all)
                if eni.exists() and ifnames_valid:
                    eni.conf_key_value_multiple_values(True, "bridge-vids", str(tokens["<1-4094>"]))

        # Create new interfaces, if necessary.
        if component == "netmisc" and "breakout" in tokens:
            pass
        elif "dns" in tokens and "vrf" in tokens:
            # Do not create new interfaces for commands of the format:
            #     net add|del dns ... vrf <interface>
            pass
        else:
            if ifupdown2_wrapper is not None:
                interface = tokens.get("<interface>")

                if interface is not None:
                    # The function ifnames_to_glob takes a list of interface names and globs.
                    # If the command has multiple <interface> variables, our 'interface'
                    # variable will be a list.  Otherwise, it will be unicode.
                    if isinstance(interface, basestring):
                        interface = [str(interface)]

                    ifupdown2_wrapper.add_interfaces(ifnames_to_glob(interface))

                elif "vlan" in tokens and tokens.get("<number-range-list>") is not None:
                    ifnames_valid, interfaces = get_ifnames(nclu_parser, False)
                    if ifnames_valid:
                        svi_ifnames = filter(lambda i: i.startswith("vlan"), interfaces)
                        ifupdown2_wrapper.add_svi_interfaces(svi_ifnames)

                # If the user is configuring a VRF that does not exist, we must create that VRF.
                vrf_names = get_vrf_name(nclu_parser.argv_expanded)
                if vrf_names is not None and "vrf-table" in tokens is None:
                    if ifname_is_glob(vrf_names):
                        vrf_names = ifname_expand_glob(vrf_names)
                    else:
                        vrf_names = [vrf_names]

                    for vrf_name in vrf_names:
                        vrf_iface = EtcNetworkInterface(vrf_name, ifupdown2_wrapper.ifquery_all)
                        ifupdown2_wrapper.vrf_add(vrf_iface)

    elif "del" in tokens:
        # The user deleted interface(s) via the ifupdown2 wrapper.  Delete affected configuration
        # information in other wrappers and plug-ins.

        if component == "dot1x" and tokens.get("<interface>") and \
               ("dot1x" in tokens and "mab" not in tokens and "parking-vlan" not in tokens):
            # dot1x was removed without attributes.  Remove bridge-learning.
            if ifupdown2_wrapper is not None:
                ifnames_valid, interfaces = get_ifnames(nclu_parser, False)
                if ifnames_valid:
                    for interface in interfaces:
                        eni = EtcNetworkInterface(interface, ifupdown2_wrapper.ifquery_all)
                        if not eni.exists():
                            ifupdown2_wrapper.add_interface()
                        eni.conf_key_value_solo(False, "bridge-learning", "off", False)

        if component == "dot1x" and "parking-vlan-id" in tokens and tokens.get("<1-4094>") is not None:
            # Remove the vlan id in the one and only bridge.

            if ifupdown2_wrapper is not None:
                ifnames_valid, interfaces = get_ifnames(nclu_parser, False)
                eni = EtcNetworkInterface("bridge", ifupdown2_wrapper.ifquery_all)
                if not eni.exists():
                    return (False, "You cannot remove parking-vlan-id without a bridge interface.")
                else:
                    if ifnames_valid:
                        eni.conf_key_value_multiple_values(False, "bridge-vids", str(tokens["<1-4094>"]))

        if component == "ifupdown2" and not keywords_configured(tokens):
            ifnames_valid, interfaces = get_ifnames(nclu_parser, True)
            if ifnames_valid and interfaces:
                # After deleting interfaces from /etc/network/interfaces, remove associated configuration
                # from other components.

                if "frr" in net_daemon.enabled_plugins:
                    # Remove associated FRR configuration.
                    frr_del_interfaces(interfaces)

                if "accesslist" in net_daemon.enabled_wrappers:
                    for name, wrapper in wrappers:
                        if name == "accesslist":
                            # Remove associated accesslist configuration.
                            wrapper.del_interfaces(ifnames_to_glob(interfaces))
                            break
                    else:
                        raise RuntimeError("\"accesslist\" is enabled, but the wrapper was not found.")

    return (True, '')
