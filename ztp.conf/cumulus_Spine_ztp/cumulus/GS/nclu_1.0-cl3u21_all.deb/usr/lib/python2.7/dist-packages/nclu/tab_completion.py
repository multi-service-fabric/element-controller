"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from nclu import get_interfaces, get_lldp, ifname_is_glob
from nclu.rollback import snapper_entries
from nclu.wrappers.ifupdown2 import keywords_configured

# Don't import nclu.wrappers.ifupdown2.ifupdown2_wrapper here.  The import will happen before
# that global variable is initialized, and it will be None here.


def tab_complete_policer(tokens, final_words, ended_with_space, last_argv):
    """
    If an interface is not configured for L2, do not show a bunch of mstpctl options...that sort of thing.
    This is called by NetworkDocopt.
    """

    m = __import__("nclu.wrappers.ifupdown2", fromlist=["ifupdown2_wrapper"])

    if m.ifupdown2_wrapper is None:
        # ifupdown2 is not enabled.
        return final_words

    ifname = tokens.get("<interface>")

    if ifname:
        # "ifname" can be a list because NetworkDocopt supports multiple <interface> variables per line.
        if isinstance(ifname, list):
            # In the tab complete context, all elements will be the same.  Just take the first one.
            ifname = ifname[0]

        iface = None if ifname_is_glob(ifname) else m.ifupdown2_wrapper.get_iface(ifname)
    else:
        iface = None

    if iface is not None:
        if tokens.get("bond") and not iface.has_cmd("bond-slaves") and not tokens.get("clag") and not tokens.get("slaves"):
            # Show the "bond-slaves" option until the user has configured the bond-slaves.

            if last_argv == "bond" and ended_with_space:
                final_words = ["slaves"]
            elif ended_with_space:
                final_words = ["bond"]

        if tokens.get("vxlan") and not iface.has_cmd("vxlan-id"):
            # "net add vxlan vni100 <TAB>": Restrict to "vxlan id" until the user configures that keyword.

            if "alias" in final_words:
                final_words = ["vxlan"]
            elif "local-tunnelip" in final_words:
                final_words = ["id"]

        if tokens.get("bond") or tokens.get("interface"):

            # Hide bridge options if this isn't a L2 interface.
            # We used to also hide all of the mstpctl- options too.  However, when we moved
            # those under the "stp" context, it looked weird because stp would be in
            # the parse tree, but then when you did a TAB you did not see any options.
            l2_commands = ("allow-untagged", "portmcfl", "portmcrouter", "pvid")
            found_l2_command = False

            for c in l2_commands:
                if c in final_words:
                    found_l2_command = True
                    break

            if found_l2_command:
                rm_l2_commands = False

                if iface.is_layer2():
                    # bridge-access or bridge-vids is configured.
                    pass
                else:
                    bridge = m.ifupdown2_wrapper.get_iface("bridge")

                    if bridge:
                        bridge_ports = bridge.get_keyword_value("bridge-ports")

                        if bridge_ports:
                            bridge_ports = bridge_ports.split()

                            if ifname not in bridge_ports:
                                rm_l2_commands = True
                        else:
                            rm_l2_commands = True
                    else:
                        rm_l2_commands = True

                if rm_l2_commands:
                    for x in l2_commands:
                        if x in final_words:
                            final_words.remove(x)

            if tokens.get("clag") is not None and not iface.has_cmd("clagd-peer-ip") and not iface.has_cmd("clagd-sys-mac"):
                # Hide clag options.
                # clagd-
                clag_commands = ("args", "enable", "priority")

                for c in clag_commands:
                    if c in final_words:
                        final_words.remove(c)

    # These are keywords that we have to be willing to accept so that we can
    # show the "net add" commands for them in the "net show config commands"
    # output, but we do not want to list them in the TAB options as the user
    # should never really configure these directly.
    #
    # Note that inbound-interface/outbound-interface are okay for the user to
    # configure, but listing them in the TAB output is really confusing because
    # the user thinks this applies the ACL to the interface when it does not.  It
    # is just a match rule.  This is a corner case scenario, so keep these
    # hidden for now.
    #
    # run keyword needs to be hidden from the user completely because today,
    # cl-chassis is the only client for that code.
    keywords_to_hide = ("vlan-id", "vlan-aware", "inbound-interface", "outbound-interface", "run")
    for c in keywords_to_hide:
        if c in final_words:
            final_words.remove(c)

    return final_words


def tab_wildcard_snapshot(args, ended_with_space, last_argv):
    final = []
    entry, _ = snapper_entries()

    for (snapshot_id, value) in entry.iteritems():
        desc = value.get("desc")

        if value.get("type") == "post" and desc.startswith("nclu"):
            help_text = "ID {0}, created by {1} on {2}".format(value["id"], value["user"], value["date"])
            final.append((desc, help_text))

    return final


def tab_interface(tokens, ended_with_space, last_argv):
    """
    Return a list of 2-tuples of (<interface>, <help text>) to display for
    prospective <interface> values in TAB completion.
    """

    assert isinstance(tokens, dict)

    ifnames = []  # Return value
    lldp = get_lldp()
    bgp_only = False
    bond_only = False
    bond_pairs = bool(tokens.get("bond")) and bool(tokens.get("slaves"))
    loopback_only = False
    vlan_interface_only = False
    vrf_only = False
    vxlan_only = False
    interface_help = "An interface name \"swp1\" or glob \"swp1-4,6,10-12\""

    if (tokens.get("clag") is not None) and (tokens.get("port") is not None) and (tokens.get("bond") is not None):
        # Special case with the word "bond" and two "<interface>":
        #   net add clag port bond <interface> interface <interface> clag-id <0-65535>

        if tokens.get("<interface>") is None:
            # The user has yet to specify the bond name.  Limit <interface> TAB choices to bond_only.
            bond_only = True
            ifnames.append(("<interface>", 'A bond name, example "bond-leaf-11"'))

        else:
            # The user entered the bond name and is at the 2nd <interface>.  List everthing.
            ifnames.append(("<interface>", interface_help))
    elif tokens.get("bond"):
        if keywords_configured(tokens):
            ifnames.append(("<interface>", interface_help))
        else:
            bond_only = True
            ifnames.append(("<interface>", 'A bond name, example "bond-leaf-11"'))
    elif tokens.get("loopback"):
        if keywords_configured(tokens):
            ifnames.append(("<interface>", interface_help))
        else:
            loopback_only = True
            ifnames.append(("<interface>", 'A loopback name, example "lo"'))
    elif tokens.get("vlan"):
        if keywords_configured(tokens):
            ifnames.append(("<interface>", interface_help))
        else:
            vlan_interface_only = True
            ifnames.append(("<interface>", 'A vlan interface name, example "vlan10"'))
    elif tokens.get("vxlan"):
        if keywords_configured(tokens):
            ifnames.append(("<interface>", interface_help))
        else:
            vxlan_only = True
            ifnames.append(("<interface>", 'A vxlan name, example "vxlan10"'))
    elif tokens.get("vrf"):
        vrf_only = True
        ifnames.append(("<interface>", 'A VRF name, example "BLUE"'))

    elif tokens.get("bgp") and tokens.get("neighbor"):
        bgp_only = True
        ifnames.append(("<interface>", interface_help))
    else:
        ifnames.append(("<interface>", interface_help))

    m = __import__("nclu.wrappers.ifupdown2", fromlist=["ifupdown2_wrapper"])

    if not m.ifupdown2_wrapper.etc_network_interfaces_changed():
        ifaces_to_check = get_interfaces()

        for ifname in ifaces_to_check:
            add_ifname = False
            iface = m.ifupdown2_wrapper.get_iface(ifname)

            if bgp_only:
                if iface.is_bond() or iface.is_physical() or iface.is_vlan_interface():
                    add_ifname = True

            elif bond_only:
                if iface.is_bond():
                    add_ifname = True

            elif loopback_only:
                if iface.is_loopback():
                    add_ifname = True

            elif vxlan_only:
                if iface.is_vxlan():
                    add_ifname = True

            elif vlan_interface_only:
                if iface.is_vlan_interface():
                    add_ifname = True

            elif vrf_only:
                if iface.is_vrf():
                    add_ifname = True

            # if bond_pairs is true then we are configuring bond-slaves
            # so do not lists loopbacks, other bonds, etc
            elif bond_pairs:
                if iface.is_physical():
                    add_ifname = True

            else:
                add_ifname = True

            # if the user did "swp1<TAB>" then only list the interfaces that begin with swp1
            if add_ifname:
                if not ended_with_space and not ifname.startswith(last_argv):
                    add_ifname = False

            if add_ifname:
                if ifname in lldp:
                    ifnames.append((ifname, "LLDP peer {0}".format(lldp.get(ifname))))
                else:
                    ifnames.append((ifname, "interface"))

    # log.info("ifnames: %s" % pformat(ifnames))
    return ifnames
