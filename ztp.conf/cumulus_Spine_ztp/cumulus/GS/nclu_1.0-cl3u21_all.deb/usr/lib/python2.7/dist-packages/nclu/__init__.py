#!/usr/bin/env python
"""
Copyright (C) 2016-2017 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from collections import OrderedDict
from grp import getgrnam
from network_docopt import sort_for_humans
from network_docopt.match import ifname_is_glob
from pprint import pformat
from pwd import getpwnam
from socket import gethostbyaddr
from subprocess import check_output, STDOUT, CalledProcessError
from tabulate import tabulate  # This is an add-on from Pip.
import codecs
import errno
import filecmp                 # Using filecmp.cmp.  Note that cmp() is a built-in function.
import json
import logging
import logging.handlers
import os
import re
import shutil

log = logging.getLogger("netd")

WORKING_DIRECTORY = "/run/nclu/"

# This applies to the working directory, which must be world executable so
# clients can communicate with netd via the UDS created in NetDaemon.py.
WORKING_DIRECTORY_PERMISSIONS = 0o711

# This applies to subdirectories in the working directory.
WORKING_DIRECTORIES_PERMISSIONS = 0o711

EXAMPLES_DIRECTORIES = ("/usr/share/nclu/example/", "/usr/local/share/nclu/example/")
HISTORY_LOG = "/var/log/netd-history.log"
NCLU_VERSION = 1.0
PENDING_COMMANDS_FILE = WORKING_DIRECTORY + "pending_commands.txt"

glob_msg = """
"INTERFACE" looks sort of like a glob but does not use valid glob syntax.
Globs use commas and hyphens to specify a range of interfaces.

Examples:
    swp1-4
    swp1-4,swp8,swp9
    swp1-4,8,9
    swp1-4,swp8-9
    swp1,swp8,swp9
    swp1,8,9
    swp1,swp8-9
    swp1s0-4
    lo,bridge,swp1s0-4

"""


def files_match(fileA, fileB):
    """
    Given two file paths, return a boolean indicating if the contents of the files
    are identical.
    """

    if not os.path.isfile(fileA) and not os.path.isfile(fileB):
        # Neither file exists.  Regard this as equality.
        return True

    if not os.path.isfile(fileA) or not os.path.isfile(fileB):
        # Only one file exists, so they cannot be equal.
        return False

    return filecmp.cmp(fileA, fileB)


def get_file_contents(filename):
    with open(filename) as f:
        return f.read()


def make_pending_diff(config, scratch, color_diffs):
    """
    Return the diff between a configuration file and a scratch pad file.  This is used when the
    user runs "net pending" or "net commit".  If the files' contents are identical, or if the
    scratch pad doesn't exist, return the empty string.
    """

    if not os.path.isfile(scratch):
        return ''

    try:
        check_output(["/usr/bin/diff",
                      "-U", "10",
                      # Treat absent files (i.e. "config") as empty.
                      "-N",
                      config,
                      scratch])

        # "diff" exits 0 when the files are identical.
        return ''

    except CalledProcessError as e:
        if not color_diffs:
            return e.output

        # Output the deletes in red and the adds in green.

        the_diff = ''
        for line in e.output.splitlines():
            if line.startswith("---") or line.startswith("+++"):
                the_diff += "\033[94m{0}\033[0m\n".format(line)
            elif line.startswith('-'):
                the_diff += "\033[91m{0}\033[0m\n".format(line)
            elif line.startswith('+'):
                the_diff += "\033[92m{0}\033[0m\n".format(line)
            else:
                the_diff += line + '\n'

    return the_diff


def chown_chgroup(filename, user, group):
    uid = getpwnam(user).pw_uid
    gid = getgrnam(group).gr_gid
    os.chown(filename, uid, gid)


def file_contains(filename, target_line):
    """
    Return True if the given file contains the given line.  Otherwise, return False.
    """
    if os.path.isfile(filename):
        with open(filename) as f:
            line = f.readline()
            while line:
                if line.strip() == target_line.strip():
                    return True
                line = f.readline()
    return False


def ifname_expand_glob(ifname):
    """
    Given a glob of interface names, return a list of strings containing each interface.
    If the input is a single interface name, return it as a list.  This function does
    not do any sorting.

    >>> ifname_expand_glob('')
    []

    >>> ifname_expand_glob('swp7')
    ['swp7']

    >>> ifname_expand_glob('lo')
    ['lo']

    >>> ifname_expand_glob('bridge')
    ['bridge']

    >>> ifname_expand_glob('peer-group')
    ['peer-group']

    >>> ifname_expand_glob('Bond-T')
    ['Bond-T']

    >>> ifname_expand_glob('swp7.1')
    ['swp7.1']

    >>> ifname_expand_glob('swp7,eth0')
    ['swp7', 'eth0']

    >>> ifname_expand_glob('swp7,swp8')
    ['swp7', 'swp8']

    >>> ifname_expand_glob('swp7,8')
    ['swp7', 'swp8']

    >>> ifname_expand_glob('swp7-8')
    ['swp7', 'swp8']

    >>> ifname_expand_glob('swp7.1,3')
    ['swp7.1', 'swp7.3']

    >>> ifname_expand_glob('swp7.1-3')
    ['swp7.1', 'swp7.2', 'swp7.3']

    >>> ifname_expand_glob('swp7.1,3-4')
    ['swp7.1', 'swp7.3', 'swp7.4']

    >>> ifname_expand_glob('swp1,8,9')
    ['swp1', 'swp8', 'swp9']

    >>> ifname_expand_glob('swp1-3,8,9')
    ['swp1', 'swp2', 'swp3', 'swp8', 'swp9']

    >>> ifname_expand_glob('swp1,swp8-9')
    ['swp1', 'swp8', 'swp9']

    >>> ifname_expand_glob('swp1,swp2.1,4,swp8-9')
    ['swp1', 'swp2.1', 'swp2.4', 'swp8', 'swp9']

    >>> ifname_expand_glob('swp7s1')
    ['swp7s1']

    >>> ifname_expand_glob('swp7s1-3')
    ['swp7s1', 'swp7s2', 'swp7s3']

    >>> ifname_expand_glob('swp7s1.1-3')
    ['swp7s1.1', 'swp7s1.2', 'swp7s1.3']

    >>> ifname_expand_glob('lo,eth0,swp1')
    ['lo', 'eth0', 'swp1']

    >>> ifname_expand_glob('bridge,vxlan10010')
    ['bridge', 'vxlan10010']

    >>> ifname_expand_glob('bridge,vxlan10010,10012')
    ['bridge', 'vxlan10010', 'vxlan10012']

    >>> ifname_expand_glob('bridge,vxlan10010-10013')
    ['bridge', 'vxlan10010', 'vxlan10011', 'vxlan10012', 'vxlan10013']

    >>> ifname_expand_glob('peer-group,Bond-T,swp4-6,8,Bond-S')
    ['peer-group', 'Bond-T', 'swp4', 'swp5', 'swp6', 'swp8', 'Bond-S']

    >>> ifname_expand_glob('peer-group,Bond-T,swp4-6,8')
    ['peer-group', 'Bond-T', 'swp4', 'swp5', 'swp6', 'swp8']

    >>> ifname_expand_glob('server02,swp10')
    ['server02', 'swp10']

    >>> ifname_expand_glob('swp31s0-1')
    ['swp31s0', 'swp31s1']

    >>> ifname_expand_glob('swp53s0,swp53s3')
    ['swp53s0', 'swp53s3']

    >>> ifname_expand_glob('swp53s0,3')
    ['swp53s0', 'swp53s3']

    >>> ifname_expand_glob('vni-1010,1020,1030,1040,1050')
    ['vni-1010', 'vni-1020', 'vni-1030', 'vni-1040', 'vni-1050']

    >>> ifname_expand_glob('server09,server11,13')
    ['server09', 'server11', 'server13']

    >>> ifname_expand_glob('po1ntnxprodnd09,po1ntnxprodnd11,13')
    ['po1ntnxprodnd09', 'po1ntnxprodnd11', 'po1ntnxprodnd13']

    >>> ifname_expand_glob('cs1-osl3')
    ['cs1-osl3']

    >>> ifname_expand_glob('cs1-osl3,swp1')
    ['cs1-osl3', 'swp1']

    >>> ifname_expand_glob('bond-to-cpu10-14')
    ['bond-to-cpu10', 'bond-to-cpu11', 'bond-to-cpu12', 'bond-to-cpu13', 'bond-to-cpu14']
    """

    if not isinstance(ifname, (str, unicode)):
        raise TypeError("This function takes a string and returns a list of strings.  type(ifname)={0}".format(type(ifname)))

    return ifname_expand_glob_helper(ifname, [])


def ifname_expand_glob_helper(ifname, result):
    """ This function is recursive. """

    if ifname == '':
        # Base case 1
        return result

    if not ifname_is_glob(ifname):
        # Base case 2: non-globish input
        result.append(ifname)
        return result

    # Get the first glob component.  This could be a single name, like "bridge", or
    # it could be a range with commas and hyphens.  For example, given "swp1-7,9",
    # get the entire string.  Given "swp1-7,9,eth0", get "swp1-7,9,".

    glob = ''

    # Subinterface base and range?
    m = re.match(r"""(?P<base>[a-zA-Z0-9-]+?\-?(?:\d+s)?\d+\.)(?P<glob>(?:0(?!\d)|[1-9]\d*)((,|-)\d+)+,?)""", ifname)
    if m is None:

        # Non-subinterface base and range?
        m = re.match(r"""(?P<base>[a-zA-Z0-9-]+?\-?(?:\d+s)?)(?P<glob>(?:0(?!\d)|[1-9]\d*)((,|-)\d+)+,?)""", ifname)

        if m is None:
            m = re.match(r"""(?P<base>\S+?),""", ifname)

            if m is not None:
                # The input begins with a component that doesn't have a range.
                # Ex: lo, bridge, peer-group, Bond-T, server02, etc.
                glob = None
            else:
                raise ValueError("Couldn't parse '{0}'.".format(ifname))

    # Append the expanded substring of interfaces to the result.

    base = m.group('base')
    assert not ifname_is_glob(base), "base = {0}".format(base)

    if glob is None:
        # Append a single interface name to the result.
        result.append(base)
    else:
        # Append a multiple interface names to the result.
        glob = m.group('glob').rstrip(',')

        for number in glob_to_numbers(glob):
            result.append('{0}{1}'.format(base, number))

    # Recurse with the remaining input string.
    return ifname_expand_glob_helper(ifname[len(m.group()):], result)


def ifnames_to_glob(interfaces):
    """
    Given an iterable of strings containing interface names and globs, return
    a single glob.  Interface names with lead zeros (ex. swp01) will not be
    converted to ranges.

    >>> ifnames_to_glob([])
    ''

    >>> ifnames_to_glob(['swp1', 'swp2', 'swp3'])
    'swp1-3'

    >>> ifnames_to_glob(['swp1-3,5'])
    'swp1-3,5'

    >>> ifnames_to_glob(['swp1-3,5', 'swp6'])
    'swp1-3,5-6'

    TODO - The next test fails because the sorting of interface names is inadequate.
    The current output is 'swp1,swp1s0-1,swp2-3'.

    # >>> ifnames_to_glob(['swp1', 'swp1s1', 'swp2,3', 'swp1s0'])
    # 'swp1-3,swp1s0-1'

    >>> ifnames_to_glob(['vlan100', 'vlan1'])
    'vlan1,100'

    >>> ifnames_to_glob(['vlan99', 'vlan9'])
    'vlan9,99'

    >>> ifnames_to_glob(['vlan'])
    'vlan'

    >>> ifnames_to_glob(['vlan99', 'vlan'])
    'vlan,vlan99'

    >>> ifnames_to_glob(['vlan', 'vlan99'])
    'vlan,vlan99'

    >>> ifnames_to_glob(['vlan2000', 'vlan20'])
    'vlan20,2000'

    >>> ifnames_to_glob(['vlan2000,vlan20',])
    'vlan20,2000'

    >>> ifnames_to_glob(['vlan100', 'swp1', 'swp2', 'vlan1', 'swp3', 'eth0'])
    'eth0,swp1-3,vlan1,100'

    >>> ifnames_to_glob(['vlan100', 'swp1-3', 'vlan1', 'eth0'])
    'eth0,swp1-3,vlan1,100'

    >>> ifnames_to_glob(['swp1.1'])
    'swp1.1'

    >>> ifnames_to_glob(['VlanA-1.100'])
    'VlanA-1.100'

    >>> ifnames_to_glob(['swp1.5', 'swp1.1', 'swp1.3', 'swp1.2'])
    'swp1.1-3,5'

    >>> ifnames_to_glob(['swp4', 'VlanA-1.100', 'swp2', 'swp1'])
    'swp1-2,4,VlanA-1.100'

    >>> ifnames_to_glob(['swp1a'])
    'swp1a'

    >>> ifnames_to_glob(['vlan100', 'swp1', 'vlan', 'swp2', 'vlan1', 'swp3', 'eth0'])
    'eth0,swp1-3,vlan,vlan1,100'

    >>> ifnames_to_glob(['lo'])
    'lo'

    >>> ifnames_to_glob(['eth1', 'lo', 'eth0'])
    'eth0-1,lo'

    >>> ifnames_to_glob(['bridge', 'vxlan10010'])
    'bridge,vxlan10010'

    >>> ifnames_to_glob(['bridge', 'vxlan10015', 'vxlan10011', 'vxlan10010'])
    'bridge,vxlan10010-10011,10015'

    >>> ifnames_to_glob(['host4_bond'])
    'host4_bond'

    >>> ifnames_to_glob(['swp4-5', 'host4_bond', 'bridge', 'host5_bond1', 'host5_bond2'])
    'bridge,host4_bond,host5_bond1-2,swp4-5'

    >>> ifnames_to_glob(['server2', 'server3', 'server1'])
    'server1-3'

    >>> ifnames_to_glob(['server2,server3,server1'])
    'server1-3'

    >>> ifnames_to_glob(['server02', 'server03', 'server01'])
    'server01,server02,server03'

    >>> ifnames_to_glob(['server09,server11'])
    'server09,server11'

    >>> ifnames_to_glob(['server09', 'server11'])
    'server09,server11'

    >>> ifnames_to_glob(['server09,server11,server13'])
    'server09,server11,13'

    >>> ifnames_to_glob(['server09', 'server11', 'server13'])
    'server09,server11,13'
    """

    if not isinstance(interfaces, list):
        raise TypeError("This function takes a list of strings and returns a string.  type(ifname)={0}".format(type(interfaces)))

    # Convert all unicode to str
    interfaces = map(str, interfaces)

    # Expand glob inputs so the helper function doesn't have to deal with them.
    # Ex. ['swp3-5,7', 'eth0'] --> ['swp3', 'swp4', 'swp5', 'swp7', 'eth0']
    interfaces_expanded = []
    for interface in interfaces:
        interfaces_expanded.extend(ifname_expand_glob(interface))

    # Sort and deduplicate the interfaces.  This groups interface names with the same prefix,
    # and prefixes without suffixes come before the same prefix with a suffix.
    # TODO - Note the failing doc test related to sorting.
    interfaces_expanded = sorted(set(interfaces_expanded), key=str.lower)  # A list

    return ifnames_to_glob_helper(interfaces_expanded, '')


def ifnames_to_glob_helper(interfaces, result):
    """ This function is recursive. """

    if not interfaces:
        # Base case 1: empty list
        return result

    assert not ifname_is_glob(interfaces[0]), "This function should not receive glob input.  interfaces[0]={0}".format(interfaces[0])

    # Define a regex to parse interface names into a prefix and optional suffix (trailing digits).
    interface_re = re.compile(r"""(?P<prefix>\S+?)(?P<suffix>\d+)?$""")

    # Get the prefix and suffix, if any, of the first interface.
    m = interface_re.match(interfaces[0])
    assert m is not None, "interfaces[0]={0}".format(interfaces[0])
    prefix = m.group('prefix')
    suffix = m.group('suffix')  # Might be None

    if suffix is None or (len(suffix) > 1 and suffix.startswith('0')):
        # The first interface has no suffix, or it has a suffix with lead zeros, which should
        # not be part of a glob range.  Append the interface to the result, and recurse.
        if result:
            result += ','
        result += interfaces[0]
        return ifnames_to_glob_helper(interfaces[1:], result)

    suffixes = [int(suffix)]

    # Determine the index of the last interface with the same prefix as the first interface.
    for index in range(1, len(interfaces)):
        m = interface_re.match(interfaces[index])
        assert m is not None, "interfaces[{0}]={1}".format(index, interfaces[index])
        if m.group('prefix') == prefix:
            # All interfaces with the same prefix should have a suffix due to the presorting.
            assert m.group('suffix') is not None, "interfaces[{0}]={1}".format(index, interfaces[index])
            suffixes.append(int(m.group('suffix')))
        else:
            # Encountered a different base.  Append the globified interfaces to the result, and recurse.
            if result:
                result += ','
            result += "{0}{1}".format(prefix, numbers_to_glob(suffixes))
            return ifnames_to_glob_helper(interfaces[index:], result)
    else:
        # Base case 2: All interfaces have the same prefix.
        # Append the globified interfaces to the result, and return.
        if result:
            result += ','
        return result + "{0}{1}".format(prefix, numbers_to_glob(suffixes))


def numbers_to_glob(ids):
    """
    For example, given an iterable:
     (3,4,7,10,11,12,17,22,4001,4002,4003,7777,8000,8001,8002,8003,8004)

    Return a string:
     3-4,7,10-12,17,22,4001-4003,7777,8000-8004

    The parameter, ids, is an iterable that might contain integers, integers as strings, or
    integer ranges as strings.  This method handles all these types.

    >>> numbers_to_glob((100, 1))
    '1,100'

    >>> numbers_to_glob((99, 9))
    '9,99'

    >>> numbers_to_glob((2000, 20))
    '20,2000'

    >>> numbers_to_glob((3,4,7,10,11,12,17,22,4001,4002,4003,7777,8000,8001,8002,8003,8004))
    '3-4,7,10-12,17,22,4001-4003,7777,8000-8004'
    """
    ids_final = []

    # Convert the input, which can contain integers and strings, to a sorted list of integers.
    for _id in ids:  # Note that "id" is a Python built-in function.
        if isinstance(_id, int):
            ids_final.append(_id)
        elif _id.isdigit():
            ids_final.append(int(_id))
        else:
            re_number_range = re.match(r"""(\d+)-(\d+)""", _id)
            if re_number_range is not None:
                start = int(re_number_range.group(1))
                end = int(re_number_range.group(2)) + 1
                if end < start:
                    print "Invalid numeric range."
                    return []
                ids_final.extend(range(start, end))

    if not ids_final:
        print "numbers_to_glob() could not extract any IDs from %s" % pformat(ids)
        return ''

    ids = sorted(set(ids_final))  # A list
    min_id = ids[0]
    max_id = ids[-1]
    limiters = []

    # If the range of integers is continuous (i.e. 1,2,3) . . .
    if len(ids) == (max_id - min_id + 1):
        if min_id == max_id:
            limiters.append(str(min_id))
        else:
            limiters.append("{0}-{1}".format(min_id, max_id))
    # Otherwise, some integers get skipped (i.e. 1,2,5).
    else:
        streak_start_x = 0
        streak_end_x = 0
        len_ids = len(ids)

        for x in range(len_ids):

            # The first number in the list
            if x == 0:
                current = ids[x]
                next_ids = ids[x + 1]

                if current + 1 == next_ids:
                    streak_start_x = current
                else:
                    limiters.append(str(current))

            # The last number in the list
            elif x == len_ids - 1:
                prev_ids = ids[x - 1]
                current = ids[x]

                if prev_ids + 1 == current:
                    streak_end_x = current
                    limiters.append("{0}-{1}".format(streak_start_x, streak_end_x))
                else:
                    limiters.append(str(current))

            # Any number in the middle of the list
            else:
                prev_ids = ids[x - 1]
                current = ids[x]
                next_ids = ids[x + 1]

                # In the middle of a streak...do nothing
                if prev_ids + 1 == current and current + 1 == next_ids:
                    pass

                # The end of a streak
                elif prev_ids + 1 == current:
                    streak_end_x = current
                    limiters.append("{0}-{1}".format(streak_start_x, streak_end_x))
                    streak_start_x = 0
                    streak_end_x = 0

                # The beginning of a streak
                elif current + 1 == next_ids:
                    streak_start_x = current

                # A loner
                else:
                    limiters.append(str(current))

    return ','.join(limiters)


def glob_to_numbers(glob):
    """
    Given a string containing single numbers and ranges, return a sorted
    list of deduplicated integers.

    glob - A string of digits and ranges

    >>> glob_to_numbers('3-4,7,10-12,17,22,4001-4003,7777,8000-8004')
    [3, 4, 7, 10, 11, 12, 17, 22, 4001, 4002, 4003, 7777, 8000, 8001, 8002, 8003, 8004]
    """

    assert isinstance(glob, (str, unicode)), "glob={0}".format(glob)

    # Using split(',') instead of the replacement could yield empty strings in the result.
    glob_list = glob.replace(',', ' ').split()

    numbers = set()
    range_re = re.compile(r"""^(\d+)-(\d+)$""")  # ex. 4-6

    for x in glob_list:
        if x.isdigit():
            numbers.add(int(x))
        else:
            range_match = range_re.match(x)

            if range_match is None:
                # The substring is neither a digit nor a range.
                print "Globs must consist of numbers or ranges, but {0} is neither. We were given glob '{1}'.".format(x, glob)
                return []
            else:
                min_range = int(range_match.group(1))
                max_range = int(range_match.group(2))

                if max_range >= min_range:
                    numbers.update(range(min_range, max_range + 1))
                else:
                    print "Glob \"{0}\" contains the invalid range \"{1}\".".format(glob, x)  # ex. 6-4
                    return []

    return sorted(numbers)  # A sorted list


def is_number_glob(glob):
    """
    Return True if the input is a numeric glob.  The input must be a string, such as '1-5,10,13-15,20'.
    """

    assert isinstance(glob, str), "glob={0}".format(glob)

    # Using split(',') instead of the replacement could yield empty strings in the result.
    glob = glob.replace(',', ' ').split()  # A list of strings

    # All elements must be string digits or ranges.
    glob_re = re.compile(r"""^\d+(?:-\d+)?$""")
    for x in glob:
        if glob_re.match(x) is None:
            return False

    return True


def get_lldp():
    """
    Return the Link Layer Discovery Protocol information as determined by /usr/sbin/lldpctl
    and by inspecting the files in /sys/class/net.

    The output of /usr/sbin/lldpctl looks like this:

    {
      "lldp": [
        {
          "interface": [
            {
              "name": "eth0",
              "via": "LLDP",
              "rid": "1",
              "age": "7 days, 01:35:40",
              ...
            }
          ]
        }
      ]
    }
    """

    lldp = {}

    if os.path.isfile("/usr/sbin/lldpctl"):
        try:
            output = check_output(["/usr/sbin/lldpctl", "-f", "json"])

            try:
                output_dict = json.loads(output)

                if not isinstance(output_dict, dict):
                    log.warning("get_lldp: /usr/sbin/lldpctl returned a {0}.  Expected a dictionary.  LLDP output might be incomplete.".format(type(output_dict)))
                elif "lldp" not in output_dict or not isinstance(output_dict["lldp"], list) or not output_dict["lldp"] \
                        or not isinstance(output_dict["lldp"][0], dict) or "interface" not in output_dict["lldp"][0] \
                        or not isinstance(output_dict["lldp"][0]["interface"], list):
                    log.warning("get_lldp: The output of /usr/sbin/lldpctl is not in the expected format.  LLDP output might be incomplete.")
                else:
                    # /usr/sbin/lldpctl seems to have produced valid output.  Extract relevant information to populate "lldp".

                    for interface_dict in output_dict["lldp"][0]["interface"]:
                        if not isinstance(interface_dict, dict):
                            log.warning("get_lldp: Ignored a {0} in the output of /usr/sbin/lldpctl.".format(type(interface_dict)))
                            continue

                        if "name" not in interface_dict:
                            log.warning("get_lldp: Ignored an unnamed interface in the output of /usr/sbin/lldpctl.")
                            continue

                        if "chassis" in interface_dict and isinstance(interface_dict["chassis"], list) \
                                and interface_dict["chassis"] and isinstance(interface_dict["chassis"][0], dict) \
                                and "name" in interface_dict["chassis"][0] and isinstance(interface_dict["chassis"][0]["name"], list) \
                                and interface_dict["chassis"][0]["name"] and "value" in interface_dict["chassis"][0]["name"][0] \
                                and isinstance(interface_dict["chassis"][0]["name"][0]["value"], basestring):

                            lldp[interface_dict["name"]] = interface_dict["chassis"][0]["name"][0]["value"]
                        else:
                            lldp[interface_dict["name"]] = "unknown"

            except ValueError as e:
                log.warning("get_lldp: Could not parse the JSON output of /usr/sbin/lldpctl.  LLDP output might be incomplete.")
                log.exception(e)

        except CalledProcessError as e:
            log.warning("get_lldp: The call to /usr/sbin/lldpctl failed.  LLDP output might be incomplete.")
            log.exception(e)
    else:
        log.warning("get_lldp: /usr/sbin/lldpctl is not available.  LLDP output might be incomplete.")

    for ifname in os.listdir("/sys/class/net/"):
        bonding_slaves_filename = os.path.join("/sys/class/net/", ifname, "/bonding/slaves")

        if os.path.isfile(bonding_slaves_filename):
            with open(bonding_slaves_filename) as f:
                lines = list(f)

            lldp_peers = set()

            if lines:
                firstline = lines[0]

                if firstline:
                    for bond_slave in firstline.split():
                        if bond_slave in lldp:
                            lldp_peers.add(lldp[bond_slave])

            if lldp_peers:
                lldp[ifname] = ', '.join(sorted(lldp_peers))

    return lldp


def tabulate_pending_add_del_commands():
    header = ["User", "Timestamp", "Command"]
    data = []

    if os.path.isfile(PENDING_COMMANDS_FILE):
        with codecs.open(PENDING_COMMANDS_FILE, encoding="utf-8") as f:
            for line in f:
                user, timestamp, command = line.strip().split('\t')
                data.append((user, timestamp, command))
        return tabulate(tabulate_remove_unicode(data), header)
    return None


def get_pending_add_del_commands():
    if not os.path.isfile(PENDING_COMMANDS_FILE):
        return ''

    commands = "The following is a list of all add/del\n" \
               "commands since the last 'net commit'.\n" \
               "======================================\n"

    try:
        with open(PENDING_COMMANDS_FILE) as f:
            for line in f:
                _, _, command = line.strip().split('\t')
                commands += command + '\n'
    except OSError as e:
        log.exception(e)
        return "Couldn't retrieve the pending commands.  See the log."

    return commands


def globify_interface_commands(init_commands):
    """
    >>> globify_interface_commands(['net add int swp1 mtu 1500', 'net add int swp2 mtu 1500', 'net add int swp3 mtu 1500'])
    ['net add int swp1-3 mtu 1500']

    >>> globify_interface_commands(['net add int swp3 mtu 1500', 'net add int Vlan100 mtu 1500', 'net add int swp1 mtu 1500'])
    ['net add int swp1,3,Vlan100 mtu 1500']

    >>> globify_interface_commands(['net add int vlan2', 'net add int vlan1'])
    ['net add int vlan1-2']

    >>> globify_interface_commands(['net add vlan 1 vlan-raw-device VlanA-1'])
    ['net add vlan 1 vlan-raw-device VlanA-1']

    >>> globify_interface_commands(['net add vlan 2 vlan-raw-device VlanA-1', 'net add vlan 1 vlan-raw-device VlanA-1'])
    ['net add vlan 2 vlan-raw-device VlanA-1', 'net add vlan 1 vlan-raw-device VlanA-1']
    """

    final_commands = []              # Return value
    globbed_commands = []
    non_globbed_commands = []
    commands_by_id = OrderedDict()

    for command in init_commands:
        # Ex. 'net add int swp1 mtu 1500' --> ['net', 'add', 'int', 'swp1', 'mtu', '1500']
        command_list = command.split()

        if len(command_list) <= 3:
            # The command does not specify interfaces.  Add it as-is.
            # Ex: net add bridge
            final_commands.append(command)
            continue

        iface_type = command_list[2]  # bond, interface, loopback, vlan, vxlan, etc.

        if iface_type == 'vlan':
            # Add a vlan command as-is.
            # Ex: net add vlan 10-20
            # Ex: net add vlan 1 vlan-raw-device VlanA-1
            final_commands.append(command)
            continue

        add_del = command_list[1]
        ifname = command_list[3]
        command_id_part3 = ' '.join(command_list[4:]) if (len(command_list) > 4) else ''
        command_id = (add_del, iface_type, command_id_part3)

        if command_id not in commands_by_id:
            commands_by_id[command_id] = []
        commands_by_id[command_id].append(ifname)

    # We must first configure the bond-slaves, vlan-interface, and other statements.
    for bond_slaves_etc_first in (True, False):
        for (command_id, ifnames) in commands_by_id.iteritems():
            assert isinstance(ifnames, list)
            (add_del, iface_type, keyword_value) = command_id

            if (keyword_value.startswith('bond-slaves') or
                keyword_value.startswith('vxlan')):
                if not bond_slaves_etc_first:
                    continue
            elif bond_slaves_etc_first:
                continue

            if len(ifnames) > 1:
                try:
                    ifnames_glob = ifnames_to_glob(ifnames)
                except (RuntimeError, ValueError) as e:
                    # Could not globify the interfaces.
                    log.warning("(globify_interface_commands) '{0}' raised an exception in ifnames_to_glob: {1}.".format(str(ifnames), e))
                    ifnames_glob = None
            else:
                ifnames_glob = None

            if ifnames_glob:
                globbed_commands.append("net {0} {1} {2} {3}".format(add_del, iface_type, ifnames_glob, keyword_value).strip())
            else:
                for ifname in ifnames:
                    non_globbed_commands.append("net {0} {1} {2} {3}".format(add_del, iface_type, ifname, keyword_value).strip())

    final_commands.extend(globbed_commands)
    final_commands.extend(non_globbed_commands)
    return final_commands


def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc:
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else:
            raise


def seconds_to_hhmmss(secs):
    # TODO - Delete code by using the Python standard library "time" package?
    if not secs:
        return 'never'

    mins, secs = divmod(secs, 60)
    hours, mins = divmod(mins, 60)
    days, hours = divmod(hours, 24)

    if days:
        return '{0} day{1}, {2:0>2}:{3:0>2}:{4:0>2}'.format(days, 's' if days > 1 else '', hours, mins, secs)
    else:
        return '{0:0>2}:{1:0>2}:{2:0>2}'.format(hours, mins, secs)


def get_hostname(ip):
    try:
        hostname = gethostbyaddr(ip)
        return " ({0})".format(hostname[0])
    except Exception:
        return ""


def platform_vendor():
    """
    Return the vendor string from /usr/lib/cumulus/cl-platform.
    """
    try:
        output = check_output("/usr/lib/cumulus/cl-platform")
        output = output.strip()
    except CalledProcessError:
        output = ''

    if ',' in output:
        (vendor, model) = output.split(',')
        return vendor

    return None


def file_set_key_value(filename, keyword, new_value, comment_out=False):
    """
    For config files that follow a key=value notation (i.e. ip = 10.1.1.1), this function
    provides a way to alter the value for a key.
    """

    if not os.path.isfile(filename):
        log.info("Could not set {0} to {1} in {2}.  The file does not exist.".format(keyword, new_value, filename))
        return

    new_content = []
    found_keyword = False

    with open(filename) as f:
        for line in f:
            # This regex matches the case when a key is present but not assigned a value (i.e. key=<blank> # Comment).
            re_key_no_value = re.search(r"""^(?:\s*#)?\s*({0}\s*)=[\t ]*(#[\S\t ]*)?$""".format(keyword), line, re.IGNORECASE)

            if re_key_no_value is not None:
                before_equals = re_key_no_value.group(1)
                comment = re_key_no_value.group(2)
                line = ('#' if comment_out else '') + "{0} = {1}".format(before_equals, new_value)
                if comment:
                    line += ' ' + comment
                line += '\n'
                found_keyword = True
            else:
                # This regex matches the case when a key is present and assigned a value (i.e. key=value # Comment).
                re_key_value = re.search(r"""^(?:\s*#)?\s*({0}\s*=\s*)(?:".*"|\S[^#\s]*)([\t ]*#[\S\t ]*)?$""".format(keyword), line, re.IGNORECASE)

                if re_key_value is not None:
                    before_value = re_key_value.group(1)
                    comment = re_key_value.group(2)
                    line = ('#' if comment_out else '') + "{0}{1}".format(before_value, new_value)
                    if comment:
                        line += comment
                    line += '\n'
                    found_keyword = True

            new_content.append(line)

    if not found_keyword:
        # The keyword is not already in the file.  Append it to the end.
        line = ('#' if comment_out else '') + "{0} = {1}\n".format(keyword, new_value)
        new_content.append(line)

    with open(filename, 'w') as f:
        f.write(''.join(new_content))


def file_del_key(filename, key_to_del):
    """
    For config files that follow a key=value notation (i.e. ip = 10.1.1.1), this function
    provides a way to delete line(s) with 'key_to_del'.
    """

    if not os.path.isfile(filename):
        log.info("Could not delete {0} in {1}.  The file does not exist.".format(key_to_del, filename))
        return False

    new_content = []
    deleted_key_to_del = False

    with open(filename) as f:
        for line in f:
            re_key = re.search(r'''^\s*(.*?)\s*=''', line)

            if re_key is not None:
                key = re_key.group(1)

                if key == key_to_del:
                    deleted_key_to_del = True
                else:
                    new_content.append(line)

            else:
                new_content.append(line)

    with open(filename, 'w') as f:
        f.write(''.join(new_content))

    return deleted_key_to_del


def is_mac_address(word):
    return (re.match('(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}', word) or
            re.match('[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}\.[0-9A-Fa-f]{4}', word))


class ConfigFile(object):

    def __init__(self, parent, filename, commands):
        """
        'parent' is the ConfigWrapper class that owns us.

        TODO - Passing the parent class is not necessary.
        http://stackoverflow.com/questions/10091957/get-parent-class-name#10092179

        'commands' is a list of commands to run if the configuration file is modified.
        """

        self.parent = parent
        self.filename = filename.strip()

        filename_underscore = self.filename.replace('/', '_').replace('.', '_').strip('_')
        self.scratchpad = os.path.join(self.parent.run_nclu, "%s_scratchpad" % filename_underscore)
        self.backup = os.path.join(self.parent.run_nclu, "%s_backup" % filename_underscore)
        self.commands = commands

    def __str__(self):
        return self.filename

    def remove_backup(self):
        if os.path.exists(self.backup):
            os.remove(self.backup)

    def remove_scratchpad(self):
        if os.path.exists(self.scratchpad):
            os.remove(self.scratchpad)


class ConfigFileSingleLine(ConfigFile):
    """
    For config files with a single line
    """

    def edit(self, value):
        """
        Return True if the file was modified
        """
        current_value = self.get_value(True)
        if current_value == value:
            print "{0} already has {1}".format(self.scratchpad, value)
            return True
        else:
            with open(self.scratchpad, 'w') as f:
                f.write(value + '\n')
            return True

    def get_value(self, read_scratchpad=False):
        """
        This file should only contain one line. If it happens to contain more
        than one return the first valid (not blank and not a comment) and log
        a warning.
        """
        result = None
        filename = self.scratchpad if read_scratchpad else self.filename

        if os.path.isfile(filename):
            with open(filename) as f:
                for line in f:
                    line = line.strip()

                    # Ignore blank lines and comments
                    if not line or line.startswith('#'):
                        continue

                    if result is None:
                        result = line
                    else:
                        log.warning("{0} contains multiple values.  It should only contain one value.".format(filename))

        return result


class ConfigFileKeyValue(ConfigFile):

    def edit(self, key, value, comment_out=False, give_feedback=True):
        """
        Return True if the file was modified.
        """

        current_value = self.get_value(True)  # A dictionary

        if current_value.get(key) == value:
            if give_feedback:
                print "{0} already has '{1} = {2}'".format(self.scratchpad, key, value)
            return True
        else:
            file_set_key_value(self.scratchpad, key, value, comment_out)
            return True

    def delete(self, key_to_del):
        return file_del_key(self.scratchpad, key_to_del)

    def get_value(self, read_scratchpad=False):
        filename = self.scratchpad if read_scratchpad else self.filename
        results = {}

        if os.path.isfile(filename):
            with open(filename) as f:
                for line in f:
                    line = line.strip()

                    # Ignore blank lines and comments
                    if not line or line.startswith('#'):
                        continue

                    re_key_value = re.search(r"""^\s*(.*?)\s*=\s*"?\s*(.*?)\s*"?\s*$""", line, re.IGNORECASE)

                    if re_key_value is not None:
                        key = re_key_value.group(1)
                        value = re_key_value.group(2)
                        results[key] = value
        return results


class ConfigWrapperBase(object):

    def __init__(self, name, show_linux_command, color_diffs):
        self.show_linux_command = show_linux_command
        self.color_diffs = color_diffs
        self.name = name
        self.run_nclu = WORKING_DIRECTORY + self.name

        if not os.path.exists(self.run_nclu):
            mkdir_p(self.run_nclu)

        self.files = {}  # The keys are file names; the values are ConfigFile instances (including subclasses).

    def __str__(self):
        return self.name

    def add_config_file(self, filename, command):
        self.files[filename.strip()] = ConfigFile(self, filename, command)

    def get_managed_files(self):
        return self.files.keys()

    def get_service_cmd_for_file(self, filename):
        cfg = self.files.get(filename)
        return cfg.commands if (cfg is not None) else []

    def abort_pending(self):
        if os.path.exists(self.run_nclu):
            for filename in os.listdir(self.run_nclu):
                full_filename = os.path.join(self.run_nclu, filename)

                if os.path.isdir(full_filename):
                    shutil.rmtree(full_filename)
                else:
                    os.remove(full_filename)

    def del_all(self, cli):
        raise NotImplementedError("Subclasses should override the del_all method.")

    def commit_pending(self, verbose):
        """
        Return a 3-tuple of (bool, str, [str]).  The boolean indicates if the commit succeeded.
        The string includes information, including errors, for the user.  The list contains the
        names of the files modified.
        """

        commit_ok = True
        message = ''
        files_modified = []
        commands = []

        # Copy scratchpad files over the real configuration files.
        for cfg in self.files.itervalues():
            if os.path.exists(cfg.scratchpad) and not files_match(cfg.filename, cfg.scratchpad):
                shutil.copy(cfg.filename, cfg.backup)
                shutil.copy(cfg.scratchpad, cfg.filename)
                files_modified.append(cfg)

                # If we have modified multiple files that require the same command to be
                # run, only run that command one time.  An example of this sceanrio is if
                # traffic.conf and datapath.conf are modified, both require a switchd
                # restart but there is no need to restart switchd twice.
                for command in cfg.commands:
                    if command not in commands:
                        commands.append(command)

        # Run all commands that are needed to apply the changes in the new config files
        for cmd_index, command in enumerate(commands):
            try:
                output = check_output(command, stderr=STDOUT)

                if verbose:
                    message += output
            except CalledProcessError as e:
                message += "\n\"{0}\" failed:\n{1}\n".format(' '.join(command), e)
                if verbose:
                    message += e.output + '\n'
                commit_ok = False
                break

        if commit_ok:
            # Remove scratchpad and backup files.
            for cfg in files_modified:
                cfg.remove_scratchpad()
                cfg.remove_backup()

            return (True, message, [cfg.filename for cfg in files_modified])

        else:
            # Restore the config file from our backup
            for cfg in files_modified:
                shutil.move(cfg.backup, cfg.filename)

            # Rerun the commands we ran to apply config changes
            for command in commands[:cmd_index]:
                try:
                    output = check_output(command, stderr=STDOUT)

                    if verbose:
                        message += output

                except CalledProcessError as e:
                    message += "\n\"{0}\" failed:\n{1}\n".format(' '.join(command), e)

            return (False, message, [])

    def eval_command_line_args(self, cli):
        """
        The child class will need to do additional work in its eval_command_line_args().
        The overrided function should return True to inform the calling block that the
        command was successfully executed.  Among other consequences of not returning True,
        the command will not show up among the pending commands in the output of "net pending".
        """

        # If we are doing an add or del, we must create the scratchpad file if it doesn't already exist.
        if cli.args.get('add') or cli.args.get('del'):
            for cfg in self.files.itervalues():
                if not os.path.exists(cfg.scratchpad):
                    if os.path.exists(cfg.filename):
                        shutil.copyfile(cfg.filename, cfg.scratchpad)
                    else:
                        # Create an empty scratchpad file to deter downstream errors.  This
                        # is an inelegant solution to the problem of users manually deleting
                        # configuration files after netd starts.  See CM-16233.
                        with open(cfg.scratchpad, 'w'):
                            pass

        return True

    def get_pending(self):
        """
        Return diff text for the configuration files managed by the wrapper.  This might be an
        empty string.
        """

        the_diff = ''

        for cfg in self.files.itervalues():
            if os.path.isfile(cfg.scratchpad):
                the_diff += make_pending_diff(cfg.filename, cfg.scratchpad, self.color_diffs)

        return the_diff

    def show_config_files(self, user_may_edit):
        # TODO - This method doesn't need user_may_edit.

        reply = ''

        for cfg in self.files.itervalues():
            if os.path.isfile(cfg.filename) and os.path.getsize(cfg.filename) > 0:
                reply += "{0}\n{1}\n{2}\n".format(cfg.filename, '=' * len(cfg.filename), get_file_contents(cfg.filename))

        return reply

    def show_config_commands(self, user_may_edit, ifupdown2_wrapper):
        raise NotImplementedError("Subclasses should override the show_config_commands method.")

    def show_config_summary(self, user_may_edit, summary):
        raise NotImplementedError("Subclasses should override the show_config_summary method.")


def get_interfaces():
    """
    Get a full list by combining the interfaces in /etc/network/interfaces
    along with any that are pending.
    """

    ifnames = set()

    if os.path.exists('/run/nclu/iface/'):
        for filename in os.listdir('/run/nclu/iface/'):
            if not filename.endswith('.original') and not filename.endswith('.del'):
                ifnames.add(filename)

    if os.path.exists('/etc/network/interfaces'):
        with open('/etc/network/interfaces') as f:
            for line in f.readlines():
                line = line.strip()
                if line.startswith('iface '):
                    line_tokens = line.split()
                    if len(line_tokens) > 1 and "${" not in line_tokens[1]:
                        ifnames.add(line_tokens[1])

    if os.path.exists('/sys/class/net/'):
        for ifname in os.listdir('/sys/class/net/'):
            if ifname not in ('swid0_eth', 'bonding_masters') and not ifname.endswith('-v0'):
                ifnames.add(ifname)

    return sort_for_humans(list(ifnames))


def get_vrf_name(argv):
    """
    Return the name of the vrf specified in argv, or return None.

    >>> get_vrf_name(['net', 'show', 'hello', 'world']) is None
    True

    >>> get_vrf_name(['net', 'add', 'vrf', 'RED'])
    'RED'

    >>> get_vrf_name(('net', 'add', 'vrf', 'BLUE'))
    'BLUE'

    >>> get_vrf_name(['net', 'add', 'vrf']) is None
    True
    """

    assert isinstance(argv, (list, tuple)), "argv must be a list or tuple.  It is a {0}.".format(type(argv))

    if "vrf" not in argv:
        return None

    vrf_keyword_index = argv.index("vrf")
    if vrf_keyword_index == len(argv) - 1:
        log.debug("A command should not end with \"vrf\": {0}".format(argv))
        return None

    return argv[vrf_keyword_index + 1]


def _decode_list(data):
    rv = []
    for item in data:
        if isinstance(item, unicode):
            item = item.encode('utf-8')
        elif isinstance(item, list):
            item = _decode_list(item)
        elif isinstance(item, dict):
            item = decode_dict(item)
        rv.append(item)
    return rv


def decode_dict(data):
    rv = {}
    for key, value in data.iteritems():
        if isinstance(key, unicode):
            key = key.encode('utf-8')
        if isinstance(value, unicode):
            value = value.encode('utf-8')
        elif isinstance(value, list):
            value = _decode_list(value)
        elif isinstance(value, dict):
            value = decode_dict(value)
        rv[key] = value
    return rv


def nclu_check_output(command, service_name):
    """
    Execute the given command for a systemctl-started service.  Return a 2-tuple of (bool, str).
    The first value indicates if the command succeeded (0 exit); the second is the output for
    the user.

    command         - A list that specifies the command to be executed.
                      A space separated command can be split on space to obtain a list that can passed as command.
    service_name    - A string that specifies the systemctl-started service.
                      For example: netd, lldpd, ptmd.
    """

    assert isinstance(command, list) and command, "\"command\" should be a non-empty list."
    assert isinstance(service_name, str) and service_name

    try:
        output = check_output(command)
    except CalledProcessError as e1:
        # Determine if the command failed because the service is not running or because of some other problem.

        # This command returns "active" or "inactive".
        service_state_cmd = "systemctl is-active {0}.service".format(service_name)
        try:
            service_state = check_output(service_state_cmd.split(), stderr=STDOUT)
        except CalledProcessError as e2:
            return (False, "{0} returned a non-zero exit code. The exception is \"{1}\".".format(service_state_cmd, e2))

        if "inactive" in service_state:
            return (False, "The {0} service is not running (inactive).".format(service_name))
        else:
            return (False, "The {0} service is running, but \"{1}\" failed.\n{2}".format(service_name, ' '.join(command), e1))

    return (True, output)


def service_is_active(name):
    try:
        output = check_output(['/bin/systemctl', 'is-active', name]).splitlines()
        if output and output[0] == 'active':
            return True
        return False
    except CalledProcessError:
        return False


def service_is_enabled(name):
    try:
        check_output(["/bin/systemctl", "is-enabled", name])
        return True
    except CalledProcessError:
        return False


def tabulate_remove_unicode_helper(datum):
    """
    >>> tabulate_remove_unicode_helper('Go Torros!')
    'Go Torros!'

    >>> tabulate_remove_unicode_helper(u'Jos\xe9')
    'Jos?'

    This test case works manually in the interpreter but not here.  ???
#    >>> tabulate_remove_unicode_helper('Jos\xe9')
#    'Jos\xe9'
    """

    # "tabulate" can take input that is not an iterable-of-iterables, but we're not
    # using the other options, such as iterables of dictionaries.  Don't permit them.
    #     https://pypi.python.org/pypi/tabulate
    assert not isinstance(datum, dict)

    return datum.encode('ascii', 'replace') if isinstance(datum, unicode) else datum


def tabulate_remove_unicode(data):
    """
    CM-16979 demonstrated that unicode input in the first parameter to the
    third party "tabulate" function raises UnicodeEncodeError.  This
    function takes an iterable of iterables, congruent with the first
    "tabulate" parameter, and returns the input with any unicode removed.

    >>> tabulate_remove_unicode([('yo', 'hey', u'Jos\xe9')])
    [['yo', 'hey', 'Jos?']]
    """

    # Return a list of lists.
    return [map(tabulate_remove_unicode_helper, datum) for datum in data]


def parse_doc_string(doc_string):
    """
    Parse a doc string, extract the Usage and Options lines
    """
    state = 'LIMBO'
    usage = []
    options = []

    for line in doc_string.splitlines():
        if line == 'Usage:':
            state = 'USAGE'
        elif line == 'Options:':
            state = 'OPTIONS'
        else:
            if state == 'LIMBO':
                pass
            elif state == 'USAGE':
                usage.append(line)
            elif state == 'OPTIONS':
                options.append(line)
            else:
                raise Exception("Invalid state %s, line is %s" % (state, line))

    return (usage, options)


def construct_doc_string(usage, options):
    return '\nUsage:\n' + '\n'.join(usage) + '\n\nOptions:\n' + '\n'.join(options)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(filename)16s %(levelname)8s: %(message)s")
    log = logging.getLogger(__name__)

    import doctest
    doctest.testmod()
