"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

from nclu.rollback import get_rollback_id_from_description, rollback, snapper_last_nclu_pre_commit


def execute_rollback(net_daemon):
    """
    Execute "net rollback ..." commands, and return a 2-tuple of (bool, str).  The
    boolean indicates if execution succeeded, and the string is the output.

    Relevant basic usage commands:
        net rollback (<number>|last)
        net rollback description <wildcard-snapshot>
    """

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert isinstance(tokens, dict)

    assert "show" not in tokens, "\"net show rollback\" should not take this execution path."
    assert "rollback" in tokens, "Why are you here?"

    rollback_target = None

    if tokens.get("<number>") is not None:
        rollback_target = tokens["<number>"]
    elif "last" in tokens:
        rollback_target = snapper_last_nclu_pre_commit()
    elif "description" in tokens:
        assert tokens.get("<wildcard-snapshot>") is not None

        # This value can have different types, depending on the input.  The subsequent function call takes a string.
        description = tokens["<wildcard-snapshot>"]
        outcome, rollback_target = get_rollback_id_from_description(str(description))

        if not outcome:
            # "rollback_target" is an error message in this case.
            return (False, rollback_target)

    if rollback_target is None:
        return (False, "Couldn't get the rollback target.")

    return rollback(rollback_target, net_daemon.wrappers, net_daemon.enabled_plugins, net_daemon.user)
