"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt

----------------------------------------------------------------------------------------

Use this plug-in to configure Precision Time Protocol.  The package "linuxptp" must
be installed.

https://www.mankier.com/8/ptp4l

Usage:
    net add ptp (global|interface <interface>) (gm-capable|path-trace-enabled|slave-only|use-syslog|verbose) (yes|no)
    net add ptp (global|interface <interface>) (priority1|priority2) <0-255>
    net add ptp (global|interface <interface>) domain-number <0-16>
    net add ptp (global|interface <interface>) logging-level <0-7>
    net add ptp (global|interface <interface>) summary-interval <number>
    net add ptp (global|interface <interface>) time-stamping

    net del ptp (global|interface <interface>) (domain-number|gm-capable|logging-level|path-trace-enabled|priority1|priority2|slave-only|summary-interval|time-stamping|use_syslog|verbose)

    net (add|del) ptp interface <interface>
    net show ptp <wildcard-ptp>
    net show configuration ptp

Options:
    domain-number     : 0-16; PTP domain number
    global            : Global configuration used as a default for all interfaces
    gm-capable        : Set to "no" for a slave or boundary clock; "yes" otherwise
    path-tree-enabled : Enable the mechanism used to trace the route of the Announce messages
    priority1         : 0-255; should be above 128 for a slave or boundary clock
    priority2         : 0-255; should be above 128 for a slave or boundary clock
    ptp               : Precision Time Protocol
    slave-only        : Set to "yes" to be a PTP slave; "no" otherwise
    summary-interval  : The number of seconds, as a power of 2, between summary prints (ex. 2 --> 4s)
    time-stamping     : Enable time stamping, based on platform would be hardware/software
    use-syslog        : Enable printing messages to the system log
    verbose           : Enable printing messages to the standard output
"""

# TODO - SYNTAX CHECKS DURING ADD THAT ENFORCE PERMISSIBLE VALUES DESCRIBED ABOVE

import logging
import os
import re
from collections import OrderedDict
from nclu import files_match, ifname_expand_glob, service_is_enabled, WORKING_DIRECTORIES_PERMISSIONS, WORKING_DIRECTORY
from nclu.plugins import (
    get_config_files_helper,
    get_pending_diffs,
    make_scratchpads,
    merge_messages,
    format_messages,
    persist_configurations,
    remove_scratch_files_and_backups,
    run_commands)
from subprocess import CalledProcessError, check_output

log = logging.getLogger("netd")

# The configuration file is case-sensitive.
PTP_CONF = "/etc/ptp4l.conf"
PTP_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "ptp", os.path.basename(PTP_CONF))

# These files are members of the linuxptp package.  They must be available for this plug-in to work correctly.
PTP_AVAILABLE = os.path.isfile("/usr/sbin/pmc") and os.path.isfile("/lib/systemd/system/ptp4l.service") and \
    os.path.isfile("/lib/systemd/system/phc2sys.service") and os.path.isfile("/usr/sbin/hwstamp_ctl")

# This is the state of PTP_CONF immediately after installing the "linuxptp" package.
PTP_DEFAULT_CONFIGURATION = """\
[global]
#
# Default Data Set
#
slaveOnly        0
priority1        255
priority2        255
domainNumber     0

#
# Run time options
#
logging_level        5
path_trace_enabled   0
use_syslog           1
verbose              0
summary_interval     0

#
# Default interface options
#
time_stamping    hardware

# Clock description
# Interfaces in which ptp should be enabled
# these interfaces should be routed ports
# if an interface does not have an ip address
# the ptp4l will not work as expected.
# [swp1]
#
#productDescription     ;;
#revisionData           ;;
#manufacturerIdentity   00:00:00
#userDescription                ;
#timeSource             0xA0
#

#
# Interfaces in which ptp should be enabled
# these interfaces should be routed ports
# if an interface does not have an ip address
# the ptp4l will not work as expected.
# [swp1]
#
"""

# This dictionary maps the syntax used in PTP_CONF to supported command syntax.
# Some commands to don't require mapping.  In that case, the value should be None.
SUPPORTED_COMMANDS = {
    "domainNumber": "domain-number",
    "gmCapable": "gm-capable",
    "logging_level": "logging-level",
    "path_trace_enabled": "path-trace-enabled",
    "priority1": None,
    "priority2": None,
    "slaveOnly": "slave-only",
    "summary_interval": "summary-interval",
    "time_stamping": "time-stamping",
    "use_syslog": "use-syslog",
    "verbose": None,
}

# These values are acceptable (case insensitive) for <wildcard-ptp>.
PMC_SUPPORTED_PARAMETERS = {
    "parent_data_set": "",
    "time_status_np": "",
    "current_data_set": "",
    "grandmaster_settings_np": "",
    "slave_only": "",
    "version_number": "",
    "announce_receipt_timeout": "",
    "clock_accuracy": "",
    "clock_description": "",
    "current_data_set": "",
    "default_data_set": "",
    "delay_mechanism": "",
    "domain": "",
    "log_announce_interval": "",
    "log_min_pdelay_req_interval": "",
    "log_sync_interval": "",
    "null_management": "",
    "port_data_set": "",
    "port_data_set_np": "",
    "priority1": "",
    "priority2": "",
    "timescale_properties": "",
    "time_properties_data_set": "",
    "traceability_properties": "",
    "user_description": "",
}

log = logging.getLogger("netd")


def check_ptp_platform():
    """
    Determine if the platform is hardware (mlx/bcm) or software (vx), and
    return a string.

    If the determination cannot be made, return None.
    """

    try:
        platform_detect = check_output("/usr/bin/platform-detect").strip()
    except CalledProcessError as e:
        log.exception(e)
        return None

    if platform_detect:
        # platform_detect looks like "dell,s6000_s1220".
        log.debug("platform detected: {0}".format(platform_detect))
        _, second = platform_detect.split(',')
        if second == "vx":
            return "software"
        else:
            return "hardware"
    # Else, return None by default.


def commit_pending(verbose):
    """
    Copy scratchpad files over configuration files, call necessary restart commands, etc.

    Return a 2-tuple of (bool, dict).  The boolean indicates if the commit succeeded.
    The dictionary is as described in nclu/plugins/__init__.py:execute_modular.
    """

    if not PTP_AVAILABLE:
        return (True, {"output": ''})

    if not os.path.isfile(PTP_SCRATCHPAD) or files_match(PTP_CONF, PTP_SCRATCHPAD):
        # There are no changes to commit.
        return (True, {"output": ''})

    persist_configurations([(PTP_CONF, PTP_SCRATCHPAD)])
    ptp_commands = get_restart_commands()

    outcome, _, messages = run_commands(ptp_commands, verbose)

    if outcome:
        # The commit succeeded.
        remove_scratch_files_and_backups([PTP_SCRATCHPAD])

    else:
        # The commit failed.  Revert the configuration.
        if os.path.isfile(PTP_SCRATCHPAD + ".bak"):
            persist_configurations([(PTP_CONF, PTP_SCRATCHPAD + ".bak")], False)
            revert_outcome, _, revert_messages = run_commands(ptp_commands, verbose)
            merge_messages(messages, revert_messages)

    return (outcome, messages)


def show_config_commands(ifupdown2_wrapper):
    """
    net show configuration commands
    """

    if not os.path.isfile(PTP_CONF) or not PTP_AVAILABLE:
        # Nothing to do.
        return ([], [])

    supported = []
    unsupported = []
    summary = OrderedDict()
    show_config_summary(summary)

    for block in summary["ptp"].iterkeys():
        if block.lower() != "global":
            supported.append("net add ptp interface {0}".format(block))
        # Else, the configuration file stage after "net del all" already has a global block.

        for parameter in summary["ptp"][block].iterkeys():
            value = summary["ptp"][block][parameter]

            if parameter in ("gmCapable", "path_trace_enabled", "slaveOnly", "use_syslog", "verbose"):
                # The command syntax associated expects "yes" or "no", but the configuration file needs 1 or 0.
                if value == '1':
                    value = "yes"
                elif value == '0':
                    value = "no"
                else:
                    log.warning("\"{0}\" is not a valid value for \"{1}\".".format(value, parameter))
                    continue
            elif parameter == "time_stamping":
                value = ''

            command_value = " {0}".format(value) if value else ''

            if parameter in SUPPORTED_COMMANDS:
                if SUPPORTED_COMMANDS[parameter] is not None:
                    # Convert the PTP_CONF syntax to the command syntax.
                    parameter = SUPPORTED_COMMANDS[parameter]

                parameter_add_syntax = "global" if block.lower() == "global" else "interface {0}".format(block.lower())
                command = "net add ptp {0} {1}{2}".format(parameter_add_syntax, parameter, command_value)
                supported.append(command)
            else:
                command = "echo \"[{0}]\\n{1}{2}\" >> {3}".format(block, parameter, command_value, PTP_CONF)
                unsupported.append(command)

    return (supported, unsupported)


def show_config_summary(summary):
    """
    "net show configuration ptp" is not available, but the framework requires this function.

    Populate the "summary" dictionary with information about the PTP configuration.
    """

    assert isinstance(summary, dict)

    if not os.path.isfile(PTP_CONF) or not PTP_AVAILABLE:
        # Nothing to do.
        return

    with open(PTP_CONF) as f:
        configuration_lines = list(f)

    ptp_summary = OrderedDict()

    # Use these regexes to find uncommented configuration lines.  According to
    # the ptp4l manual, all valid options begin with an alphabetic character.
    block_re = re.compile(r"""\s*\[\s*(?P<block>\S+)\s*\]""")
    key_value_re = re.compile(r"""\s*(?P<key>[a-zA-Z]\S*)\s+(?P<value>\S+)\s*""")

    current_block = None

    for line in configuration_lines:
        block = block_re.match(line)
        if block is not None:
            # The line begins a block.
            current_block = block.group("block")
            if current_block not in ptp_summary:
                ptp_summary[current_block] = OrderedDict()
            continue

        if current_block is None:
            continue

        parameter = key_value_re.match(line)
        if parameter is not None:
            ptp_summary[current_block][parameter.group("key")] = parameter.group("value").lower()

    summary["ptp"] = ptp_summary


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """

    if not PTP_AVAILABLE:
        return (False, {"output": '', "error": ["PTP is not available.  Do you need to install the linuxptp package?"]})

    # Don't import NetDaemon at the top because doing so would create a circular dependency.
    # NetDaemon.py imports this module's tab completer.
    from nclu.NetDaemon import NetDaemon
    assert isinstance(net_daemon, NetDaemon)

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert "configuration" not in tokens, "\"net show configuration ptp\" does not use this code path."
    assert "ptp" in tokens, "Why are you here?"

    if "add" in tokens or "del" in tokens:
        # "net (add|del) ptp ..."

        contexts = set(["global"] if ("global" in tokens) else ifname_expand_glob(tokens["<interface>"]))
        assert len(contexts) > 0, "contexts = {0}".format(contexts)

        key = None
        value = None

        # Get the command key and value, if any.
        # ex. "net add ptp slave-only yes" --> key = saveonly ; value = '1'
        for config_syntax, command_syntax in SUPPORTED_COMMANDS.iteritems():
            if (config_syntax in tokens and command_syntax is None) or command_syntax in tokens:
                key = config_syntax

                if "add" in tokens:
                    if key == "time_stamping":
                        platform = check_ptp_platform()
                        if platform is not None and platform.lower() == "hardware":
                            value = "hardware"
                        elif platform is not None and platform.lower() == "software":
                            value = "software"
                        else:
                            log.error("platform-detect returned \"{0}\"".format(platform))
                            return (False, {"output": '', "error": ["NCLU doesn't know how to process this command.  Please see the log."]})
                    else:
                        if "yes" in tokens:
                            value = '1'
                        elif "no" in tokens:
                            value = '0'
                        elif "<0-255>" in tokens:
                            value = str(tokens["<0-255>"])
                        elif "<0-16>" in tokens:
                            value = str(tokens["<0-16>"])
                        elif "<0-7>" in tokens:
                            value = str(tokens["<0-7>"])
                        elif "<number>" in tokens:
                            value = str(tokens["<number>"])

                    if value is None:
                        # This is a programming error.
                        raise RuntimeError("For an \"add\" command, a key must have a value.")

                break

        if not os.path.isfile(PTP_SCRATCHPAD):
            make_scratchpads([(PTP_CONF, PTP_SCRATCHPAD, PTP_DEFAULT_CONFIGURATION)])

        if "add" in tokens:
            assert not ((key is not None and value is None) or (key is None and value is not None)), "Keys and values are a pair."
            return execute_command_add(contexts, key, value)

        assert value is None, "Deletes are not associated with a value."
        return execute_command_del(contexts, key)

    elif "show" in tokens:
        # "net show ptp ..."
        return execute_pmc_commands(tokens["<wildcard-ptp>"].lower().split())

    return (False, {"output": '', "error": ["NCLU doesn't know how to process this command."]})


def del_all():
    """
    net del all

    Write the default configuration to PTP_SCRATCHPAD.
    """

    if not PTP_AVAILABLE:
        return

    if not os.path.isdir(os.path.dirname(PTP_SCRATCHPAD)):
        # Create the scratchpad directory.
        os.makedirs(os.path.dirname(PTP_SCRATCHPAD), mode=WORKING_DIRECTORIES_PERMISSIONS)

    with open(PTP_SCRATCHPAD, 'w') as f:
        f.write(PTP_DEFAULT_CONFIGURATION)

    ptp_commands = get_disable_commands()

    if ptp_commands:
        outcome, _, messages = run_commands(ptp_commands, False)

    if not outcome:
            log.warning("ptp.py:del_all: Disabling services failed.  {0}".format(format_messages(messages, False)))


def get_config_files():
    """
    Return a string with the content of all existing, non-empty configuration files managed with this plug-in.
    """

    return get_config_files_helper(get_managed_files())


def get_pending(use_colors):
    """ Return a string of the pending changes in all managed files. """

    if not PTP_AVAILABLE:
        return ''

    return get_pending_diffs([(PTP_CONF, PTP_SCRATCHPAD)], use_colors)


def abort_pending():
    if PTP_AVAILABLE:
        remove_scratch_files_and_backups([PTP_SCRATCHPAD])


def get_managed_files():
    """ Return a list of managed files. """

    if not PTP_AVAILABLE:
        return []

    return [PTP_CONF]


def tab_wildcard_ptp(tokens, ended_with_space, last_argv):
    """
    Return a list of 2-tuples of (<PMC supported parameters not already present in the command>, <help text>).
    This is tab completion for <wildcard-ptp>.
    """

    assert tokens.get("ptp") is not None, "Why are you here?"

    if last_argv == "ptp":
        # The user entered "net show ptp <TAB>".  Return all supported PMC parameters.
        remaining_parameters = sorted(PMC_SUPPORTED_PARAMETERS.iterkeys())
    else:
        # The user has entered one or more parameters for <wildcard-ptp>.  For example, "net show ptp priority1 <TAB>".
        # Return all supported PMC parameters not already entered.
        assert last_argv == "<wildcard-ptp>"
        assert tokens.get("<wildcard-ptp>") is not None
        parameters_entered = tokens["<wildcard-ptp>"].lower().split()
        remaining_parameters = sorted(frozenset(PMC_SUPPORTED_PARAMETERS.iterkeys()) - frozenset(parameters_entered))

    return [(p, PMC_SUPPORTED_PARAMETERS[p]) for p in remaining_parameters]


def execute_pmc_commands(parameters):
    """
    Given a list of strings in PMC_SUPPORTED_PARAMETERS, return the standard 2-tuple.
    Output from "pmc" looks like:
        cumulus@mlx-2410-51:~$ sudo pmc -u -b 0 'GET PRIORITY2'
        sending: GET PRIORITY2
                248a07.fffe.0976bc-0 seq 0 RESPONSE MANAGEMENT PRIORITY2
                priority2 255
    """

    # TODO - This will run pmc multiple times for duplicate parameters.

    messages = {"output": ''}

    pmc_base_command = ["/usr/sbin/pmc", "-u", "-b", '0']

    for parameter in parameters:
        if parameter not in PMC_SUPPORTED_PARAMETERS:
            return (False, {"output": '', "error": ["\"{0}\" is not a supported parameter.".format(parameter)]})

        pmc_command = pmc_base_command + ["GET {0}".format(parameter)]

        try:
            pmc_output = check_output(pmc_command)
            messages["output"] += "{0}\n{1}\n".format(parameter, ('=' * len(parameter)))
            messages["output"] += '\n'.join(map(str.strip, pmc_output.splitlines()[2:])) + "\n\n"
        except CalledProcessError as e:
            if "error" not in messages:
                messages["error"] = []
            messages["error"].append("Execution failed for \"{0}\".  ({1})".format(' '.join(pmc_command), e))

    return (True, messages)


def execute_command_add(affected_blocks, key, value):
    """
    Execute an add command, and return the standard 2-tuple.

    To simplify manipulation of the configuration file, which can have multiple sections that configure the same
    interface or global, this code completely ignores commented lines.  For example, if the configuration includes
    the line "# [swp1]", and if the user runs "net add ptp interface swp1", the existing line will not be
    uncommented.  Instead, an uncommented block for swp1 will be modified, or new lines will be appended.

    affected_blocks - A set of strings; the affected global or interface blocks to modify
    """

    assert isinstance(affected_blocks, set)

    messages = {"output": ''}

    with open(PTP_SCRATCHPAD) as f:
        configuration = f.read()

    # Use this regex to find the key-value pair, if present.
    k_v_pair_re = re.compile(r"""^\s*{0}\s+(?P<value>\S+)(?=\s)""".format(key), re.IGNORECASE | re.MULTILINE)

    for block in affected_blocks:
        # TODO - THIS IS INADEQUATE BECAUSE IT WORKS ON THE FIRST MATCHING BLOCK FOUND.  IF A PARAMETER IS ALREADY
        # CONFIGURED IN A SUBSEQUENT BLOCK, THE CONFIGURATION STILL GETS SET IN THE FIRST BLOCK.  THIS IS PROBABLY
        # ONLY AN ISSUE FOR MANUALLY EDITED CONFIGURATIONS.
        block_re = re.search(r"""^\s*\[\s*{0}\s*\].*?(?=\Z|^[\s#]*\[\s*\S+\s*\])""".format(block), configuration, re.MULTILINE | re.DOTALL)

        if block_re is None:
            # The block is not already configured.  Append a new block to the configuration.
            configuration += "\n[{0}]\n".format(block)
            if key is not None and value is not None:
                configuration += "{0}    {1}\n".format(key, value)
            continue

        # The block is configured.
        log.debug("{0} block\n-----\n{1}".format(block, block_re.group()))

        if key is None and value is None:
            # net add ptp interface <interface>
            # The interface is already present.  There is nothing to configure.
            if "info" not in messages:
                messages["info"] = []
            messages["info"].append("{0} is already configured.".format(block))
            continue

        maybe_space = '' if block_re.group().endswith('\n') else '\n'
        parameter = k_v_pair_re.search(block_re.group())

        if parameter is None:
            # The parameter is not configured for this block.
            new_block = block_re.group() + maybe_space + "{0}    {1}\n".format(key, value)
            log.debug("{0} modified\n-----\n{1}".format(block, new_block))
            configuration = re.sub(re.escape(block_re.group()), new_block, configuration, 1)
        else:
            # The parameter is present and uncommented for this block.
            log.debug("parameter {0} = {1}".format(key, parameter.group("value")))

            if parameter.group("value").lower() != value.lower():
                # The parameter's value needs to be changed.
                new_block = re.sub(parameter.group(), "{0}    {1}".format(key, value), block_re.group())
                log.debug("{0} modified\n-----\n{1}".format(block, new_block))
                configuration = re.sub(re.escape(block_re.group()), new_block, configuration)
            else:
                if "info" not in messages:
                    messages["info"] = []
                messages["info"].append("{0} is already configured with \"{1}={2}\".".format(block, key, value))

    with open(PTP_SCRATCHPAD, 'w') as f:
        f.write(configuration)

    return (True, messages)


def execute_command_del(affected_blocks, key):
    """
    Execute a delete command, and return the standard 2-tuple.

    To simplify manipulation of the configuration file, which can have multiple sections that configure the same
    interface or global, this code completely ignores commented lines.  For example, if the configuration includes
    the line "# [swp1]", and if the user runs "net del ptp interface swp1", the existing line will not be
    remove.

    affected_blocks - A set of strings; the affected global or interface blocks to modify
    key - A string; the parameter (key-value) to delete
        If None, delete all configuration associated with the affected block.
    """

    assert isinstance(affected_blocks, set)

    messages = {"output": ''}

    with open(PTP_SCRATCHPAD) as f:
        configuration_lines = list(f)

    # Use these regexes to find lines to delete.
    block_re = re.compile(r"""\s*\[\s*(?P<block>\S+)\s*\]""")
    key_re = re.compile(r"""\s*{0}(\s|$)""".format(key), re.IGNORECASE)
    uncommented_re = re.compile(r"""\s*[^#]""")

    modified_lines = []
    current_block = None
    found_key = False

    for line in configuration_lines:
        new_block = block_re.match(line)
        if new_block is not None:
            # The line begins a new block.
            current_block = new_block.group("block").lower()

        if current_block is None or current_block not in affected_blocks:
            # Keep all lines in unaffected blocks.
            modified_lines.append(line)
            continue

        # The line is a candidate for deletion.

        if key is None:
            # net del ptp interface <interface>

            if uncommented_re.match(line) is None:
                # Retain uncommented lines in the affected block.
                modified_lines.append(line)
            # Else, discard the uncommented line.

            continue

        # The user is deleting a specific configuration parameter from an affected block.

        if key_re.match(line) is None:
            # Retain the line, which does not configure the given key.
            modified_lines.append(line)
        else:
            found_key = True

    with open(PTP_SCRATCHPAD, 'w') as f:
        f.write(''.join(modified_lines))

    if key is not None and not found_key:
        if "info" not in messages:
            messages["info"] = []
        messages["info"].append("\"{0}\" is not configured.".format(key))

    return (True, messages)


def get_restart_commands(filename=None):
    """
    Return a list of commands that should be called after a commit or rollback.  Parameter
    "filename" is not important for this plug-in because there is only one managed file.
    """

    if not PTP_AVAILABLE:
        return []

    assert filename is None or filename in get_managed_files(), "filename = {0}".format(filename)

    ptp_commands = []

    if not service_is_enabled("ptp4l"):
        ptp_commands.append(("/bin/systemctl", "enable", "ptp4l.service"))

    if not service_is_enabled("phc2sys"):
        ptp_commands.append(("/bin/systemctl", "enable", "phc2sys.service"))

    ptp_commands.extend([("/bin/systemctl", "reset-failed", "ptp4l.service"),
                         ("/bin/systemctl", "reset-failed", "phc2sys.service"),
                         ("/bin/systemctl", "restart", "ptp4l.service"),
                         ("/bin/systemctl", "restart", "phc2sys.service")])

    return ptp_commands


def get_disable_commands(filename=None):
    """
    Return a list of commands that should be called after a net del all.
    Parameter "filename" is not important for this plug-in because there is
    only one managed file.
    """

    if not PTP_AVAILABLE:
        return []

    assert filename is None or filename in get_managed_files(), "filename = {0}".format(filename)

    return([("/bin/systemctl", "disable", "ptp4l.service"),
                        ("/bin/systemctl", "disable", "phc2sys.service"),
                        ("/bin/systemctl", "stop", "ptp4l.service"),
                        ("/bin/systemctl", "stop", "phc2sys.service")])
