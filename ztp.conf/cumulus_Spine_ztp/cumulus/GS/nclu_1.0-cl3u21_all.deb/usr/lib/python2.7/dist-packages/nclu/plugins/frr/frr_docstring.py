
"""
Usage:
    # L3 clear commands
    frr clear bgp [vrf <text>] (<bgppeer>|all) [soft in|soft out]
    frr clear bgp [vrf <text>] prefix <ipv4/prefixlen>
    frr clear ospf interface [<interface>]
    frr clear ospf6 interface [<interface>]

    # L3 show commands
    frr show debugs
    frr show vrf vni [json]
    frr show bgp vrf
    frr show bgp [vrf <text>] vni [json]
    frr show bgp [vrf <text>] [summary] [json]
    frr show bgp [vrf <text>] (<ipv4>|<ipv4/prefixlen>|<ipv6>|<ipv6/prefixlen>) [bestpath|multipath] [json]
    frr show bgp vrf <text> ipv4 unicast [<ipv4>|<ipv4/prefixlen>|summary] [json]
    frr show bgp vrf <text> ipv6 unicast [<ipv6>|<ipv6/prefixlen>|summary] [json]
    frr show bgp ipv4 (unicast|labeled-unicast) [<ipv4>|<ipv4/prefixlen>|summary] [json]
    frr show bgp ipv6 (unicast|labeled-unicast) [<ipv6>|<ipv6/prefixlen>|summary] [json]
    frr show bgp [vrf <text>] [ipv4 unicast|ipv6 unicast] route-leak [json]
    frr show bgp [vrf <text>] neighbor [<bgppeer>] [json]
    frr show bgp [vrf <text>] neighbor <bgppeer> (advertised-routes|received-routes|routes) [json]
    frr show bgp [vrf <text>] (ipv4|ipv6) (unicast|labeled-unicast) neighbor <bgppeer> (advertised-routes|received-routes|routes) [json]
    frr show bgp [vrf <text>] update-groups
    frr show bgp [l2vpn] evpn vrf-import-rt [json]
    frr show bgp [l2vpn] evpn import-rt [json]
    frr show bgp [l2vpn] evpn route [json]
    frr show bgp [l2vpn] evpn route rd <rd> [json]
    frr show bgp [l2vpn] evpn route rd <rd> mac <mac> [ip <ip>] [json]
    frr show bgp [l2vpn] evpn route rd <rd> type (macip|multicast|prefix) [json]
    frr show bgp [l2vpn] evpn route type (macip|multicast|prefix) [json]
    frr show bgp [l2vpn] evpn route vni all [json]
    frr show bgp [l2vpn] evpn route vni <1-16777215> [json]
    frr show bgp [l2vpn] evpn route vni <1-16777215> vtep <ipv4> [json]
    frr show bgp [l2vpn] evpn route vni all vtep <ipv4> [json]
    frr show bgp [l2vpn] evpn route vni <1-16777215> mac <mac> [ip <ip>] [json]
    frr show bgp [l2vpn] evpn route vni <1-16777215> multicast <ipv4> [json]
    frr show bgp [l2vpn] evpn route vni <1-16777215> type (macip|multicast) [json]
    frr show bgp [l2vpn] evpn summary [json]
    frr show bgp [l2vpn] evpn vni [<1-16777215>] [json]
    frr show evpn arp-cache vni all [json]
    frr show evpn arp-cache vni <1-16777215> [json]
    frr show evpn arp-cache vni <1-16777215> ip <ip> [json]
    frr show evpn arp-cache vni <1-16777215> vtep <ipv4> [json]
    frr show evpn mac vni all [json]
    frr show evpn mac vni <1-16777215> [json]
    frr show evpn mac vni <1-16777215> mac <mac>
    frr show evpn mac vni <1-16777215> vtep <ipv4> [json]
    frr show evpn mac vni all vtep <ipv4> [json]
    frr show evpn vni [<1-16777215>]  [json]
    frr show evpn rmac vni [<1-16777215>] mac <mac> [json]
    frr show evpn rmac vni [<1-16777215>] [json]
    frr show evpn rmac vni all [json]
    frr show evpn next-hops vni (all | <1-16777215>) [json]
    frr show evpn next-hops vni <1-16777215> ip <ip> [json]
    frr show ospf vrf
    frr show ospf [vrf <text>] [json]
    frr show ospf [vrf <text>] database (asbr-summary|external|network|nssa-external|opaque-area|opaque-as|opaque-link|router|summary) [<ipv4>|adv-router <ipv4-adv-router>|self-originate]
    frr show ospf [vrf <text>] database [max-age|self-originate]
    frr show ospf [vrf <text>] interface [<interface>] [json]
    frr show ospf [vrf <text>] neighbor [all|<interface>|<ipv4>|detail] [json]
    frr show ospf [vrf <text>] route [json]
    frr show ospf [vrf <text>] border-routers
    frr show ospf [vrf <text>] interface traffic [<interface>] [json]
    frr show ospf6
    frr show ospf6 database [adv-router <ipv4>|linkstate-id <ipv4-id>|self-originated] [detail|dump|internal]
    frr show ospf6 interface [<interface>]
    frr show ospf6 linkstate [detail|router <ipv4>]
    frr show ospf6 neighbor [detail|drchoice]
    frr show ospf6 redistribute
    frr show ospf6 route [<ipv6>|<ipv6/prefixlen>|detail|summary]
    frr show ospf6 route (intra-area|inter-area|external-1|external-2) [detail]
    frr show ospf6 route <ipv6/prefixlen> longer [detail]
    frr show ospf6 route <ipv6/prefixlen> match [detail]
    frr show ospf6 spf tree
    frr show route [vrf <text> [json]]
    frr show route [vrf <text>] (<ipv4>|<ipv6>)
    frr show route [vrf <text>] (<ipv4/prefixlen>|<ipv6/prefixlen>) [longer-prefixes [json]]
    frr show route [vrf <text>] (bgp|connected|kernel|ospf|ospf6|pim|rip|static|summary|supernets-only|table) [json]
    frr show ip nht [vrf <text>|route-map]

    # L3 global configuration
    frr add vrf <text> vni <1-16777215> [prefix-routes-only]
    frr del vrf <text> vni <1-16777215>
    frr add routing defaults datacenter
    frr (add|del) routing protocol (bgp|ospf|static|table) route-map <route-map>
    #frr (add|del) routing import-table <1-252>
    #frr (add|del) routing import-table <1-252> distance <1-255>
    frr (add|del) routing import-table <1-252> [distance <1-255>] [route-map <route-map>]
    frr add routing route <ipv4/prefixlen> (<ipv4>|<interface>|Null0|blackhole|reject) [<1-255>] [vrf <text>] [nexthop-vrf <text>]
    frr add routing route <ipv6/prefixlen> (<ipv6>|<interface>|Null0|blackhole|reject) [<1-255>] [vrf <text>] [nexthop-vrf <text>]
    frr del routing route <ipv4/prefixlen> (<ipv4>|<interface>|Null0) [<1-255>] [vrf <text>] [nexthop-vrf <text>]
    frr del routing route <ipv6/prefixlen> (<ipv6>|<interface>|Null0) [<1-255>] [vrf <text>] [nexthop-vrf <text>]
    frr add routing route <ipv4/prefixlen> (<ipv4>|<interface>|Null0|blackhole|reject) [<1-255>] label <text>
    frr add routing route <ipv6/prefixlen> (<ipv6>|<interface>|Null0|blackhole|reject) [<1-255>] label <text>
    frr del routing route <ipv4/prefixlen> (<ipv4>|<interface>|Null0) [<1-255>] label <text>
    frr del routing route <ipv6/prefixlen> (<ipv6>|<interface>|Null0) [<1-255>] label <text>
    frr (add|del) routing log file <text> [alerts|critical|debugging|emergencies|errors|informational|notifications|warnings]
    frr (add|del) routing log syslog [alerts|critical|debugging|emergencies|errors|informational|notifications|warnings]
    frr (add|del) routing log timestamp precision <0-6>
    frr (add|del) routing zebra debug (events|fpm|kernel|mpls|nht|vxlan)
    frr (add|del) routing zebra debug packet [recv|send] [detail]
    frr (add|del) routing zebra debug rib [detailed]
    frr (add|del) routing mroute debug [detail]
    frr (add|del) routing ptm-enable
    frr add       routing password <text>
    frr (add|del) routing enable password <text>
    frr add       routing line vty
    frr (add|del) routing line vty exec-timeout <0-35791> <0-2147483>
    frr add       routing service integrated-vtysh-config

    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) ptm-enable
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ipv6 nd ra-interval (<1-1800>|msec <70-1800000>)
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ipv6 nd ra-interval [<1-1800>]
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ipv6 nd ra-interval msec [<70-1800000>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ipv6 nd ra-lifetime <0-9000>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ipv6 nd ra-lifetime [<0-9000>]
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) ipv6 nd suppress-ra
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) ipv6 nd prefix <ipv6/prefixlen> [router-address|off-link|off-link no-autoconfig]
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) ipv6 nd prefix <ipv6/prefixlen> (<0-4294967295>|infinite) (<0-4294967295>|infinite) [router-address|off-link|off-link no-autoconfig]

    # L3 BGP 'global' configuration
    frr (add|del) bgp [vrf <text>] autonomous-system <1-4294967295>
    frr (add|del) bgp [vrf <text>] always-compare-med
    frr (add|del) bgp [vrf <text>] bestpath as-path multipath-relax [as-set|no-as-set]
    frr (add|del) bgp [vrf <text>] bestpath compare-routerid
    frr (add|del) bgp [vrf <text>] bestpath med missing-as-worst
    frr (add|del) bgp [vrf <text>] cluster-id (<ipv4>|<1-4294967295>)
    frr (add|del) bgp [vrf <text>] max-med administrative [<0-4294967295>]
    frr (add|del) bgp [vrf <text>] max-med on-startup <5-86400> [<0-4294967295>]
    frr add       bgp debug bestpath <ip/prefixlen>
    frr del       bgp debug bestpath [<ip/prefixlen>]
    frr add       bgp debug keepalives (<ip>|<interface>)
    frr del       bgp debug keepalives [<ip>|<interface>]
    frr add       bgp debug neighbor-events [<ip>|<interface>]
    frr del       bgp debug neighbor-events [<ip>|<interface>]
    frr (add|del) bgp debug updates [in|out]
    frr add       bgp debug updates prefix <ip/prefixlen>
    frr del       bgp debug updates prefix [<ip/prefixlen>]
    frr (add|del) bgp debug zebra
    frr add       bgp debug zebra prefix <ip/prefixlen>
    frr del       bgp debug zebra prefix [<ip/prefixlen>]
    frr (add|del) bgp [vrf <text>] default ipv4-unicast
    frr (add|del) bgp [vrf <text>] network import-check
    frr (add|del) bgp [vrf <text>] graceful-shutdown
    frr (add|del) bgp [vrf <text>] listen limit <1-5000>
    frr (add|del) bgp [vrf <text>] listen range (<ipv4/prefixlen>|<ipv6/prefixlen>) peer-group <peergroup>
    frr add       bgp [vrf <text>] neighbor <bgppeer> advertisement-interval <0-600>
    frr del       bgp [vrf <text>] neighbor <bgppeer> advertisement-interval [<0-600>]
    frr (add|del) bgp [vrf <text>] neighbor <bgppeer> bfd [<2-255> <50-60000> <50-60000>]
    frr (add|del) bgp [vrf <text>] neighbor <bgppeer> bfd [multihop]
    frr (add|del) bgp [vrf <text>] neighbor <bgppeer> capability extended-nexthop
    frr add       bgp [vrf <text>] neighbor <bgppeer> description <wildcard>
    frr del       bgp [vrf <text>] neighbor <bgppeer> description [<wildcard>]
    frr (add|del) bgp [vrf <text>] neighbor <bgppeer> disable-connected-check
    frr (add|del) bgp [vrf <text>] neighbor <bgppeer> ebgp-multihop [<1-255>]
    frr add       bgp [vrf <text>] neighbor <bgppeer> password <text-password>
    frr del       bgp [vrf <text>] neighbor <bgppeer> password [<text-password>]
    frr (add|del) bgp [vrf <text>] neighbor (<ip>|<bgppeer>|<interface>) peer-group <peergroup>
    frr (add|del) bgp [vrf <text>] neighbor (<ip>|<bgppeer>) remote-as (<1-4294967295>|external|internal)
    frr (add|del) bgp [vrf <text>] neighbor <interface> interface remote-as (<1-4294967295>|external|internal)
    frr (add|del) bgp [vrf <text>] neighbor <bgppeer> shutdown
    frr add       bgp [vrf <text>] neighbor <bgppeer> timers <0-65535> <0-65535>
    frr del       bgp [vrf <text>] neighbor <bgppeer> timers [<0-65535>] [<0-65535>]
    frr add       bgp [vrf <text>] neighbor <bgppeer> timers connect <1-65535>
    frr del       bgp [vrf <text>] neighbor <bgppeer> timers connect [<1-65535>]
    frr (add|del) bgp [vrf <text>] neighbor <bgppeer> ttl-security hops <1-254>
    frr add       bgp [vrf <text>] neighbor <bgppeer> update-source (<ipv4>|<ipv6>|<interface-source>)
    frr del       bgp [vrf <text>] neighbor <bgppeer> update-source [<ipv4>|<ipv6>|<interface-source>]
    frr (add|del) bgp [vrf <text>] neighbor <interface> interface [v6only]
    frr (add|del) bgp [vrf <text>] neighbor <interface> interface v6only peer-group <peergroup>
    frr (add|del) bgp [vrf <text>] neighbor <interface> interface peer-group <peergroup>
    frr (add|del) bgp [vrf <text>] neighbor <text-peer-group> peer-group
    frr (add|del) bgp [vrf <text>] route-map delay-timer <0-600>
    frr add       bgp [vrf <text>] router-id <ipv4>
    frr del       bgp [vrf <text>] router-id [<ipv4>]
    frr (add|del) bgp [vrf <text>] timers <0-65535> <0-65535>
    frr add       bgp [vrf <text>] update-delay <0-3600> [<1-3600>]
    frr del       bgp [vrf <text>] update-delay <0-3600> <1-3600>
    frr del       bgp [vrf <text>] update-delay [<0-3600>]

    # L3 BGP per address-family configuration
    frr (add|del) bgp [vrf <text>] [ipv4 unicast] aggregate-address <ipv4/prefixlen> [as-set] [summary-only]
    frr (add|del) bgp [vrf <text>] ipv6 unicast aggregate-address <ipv6/prefixlen> [summary-only]
    frr (add|del) bgp [vrf <text>] network (<ipv4/prefixlen>|<ipv6/prefixlen>) [label-index <0-1048560>] [route-map <text-route-map>]
    frr (add|del) bgp [vrf <text>] ipv4 unicast network <ipv4/prefixlen> [label-index <0-1048560>] [route-map <text-route-map>]
    frr (add|del) bgp [vrf <text>] ipv6 unicast network <ipv6/prefixlen> [label-index <0-1048560>] [route-map <text-route-map>]
    frr (add|del) bgp [vrf <text>] [ipv4 unicast] redistribute (connected|kernel|ospf|pim|static|table|table <1-65535>)
    frr (add|del) bgp [vrf <text>] [ipv4 unicast] redistribute (connected|kernel|ospf|pim|static|table|table <1-65535>) metric <0-4294967295>
    frr (add|del) bgp [vrf <text>] [ipv4 unicast] redistribute (connected|kernel|ospf|pim|static|table|table <1-65535>) route-map <route-map>
    frr (add|del) bgp [vrf <text>] [ipv4 unicast] redistribute (connected|kernel|ospf|pim|static|table|table <1-65535>) metric <0-4294967295> route-map <route-map>
    frr (add|del) bgp [vrf <text>] ipv6 unicast redistribute (connected|kernel|ospf6|static|table)
    frr (add|del) bgp [vrf <text>] ipv6 unicast redistribute (connected|kernel|ospf6|static|table) metric <0-4294967295>
    frr (add|del) bgp [vrf <text>] ipv6 unicast redistribute (connected|kernel|ospf6|static|table) route-map <route-map>
    frr (add|del) bgp [vrf <text>] ipv6 unicast redistribute (connected|kernel|ospf6|static|table) metric <0-4294967295> route-map <route-map>
    frr add       bgp [vrf <text>] [ipv4 unicast|ipv6 unicast] maximum-paths [ibgp] <1-256>
    frr del       bgp [vrf <text>] [ipv4 unicast|ipv6 unicast] maximum-paths [ibgp] [<1-256>]
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> activate
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> addpath-tx-all-paths
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> addpath-tx-bestpath-per-AS
    frr add       bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> allowas-in (<1-10>|origin)
    frr del       bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> allowas-in [<1-10>|origin]
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> as-override
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> default-originate
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> default-originate route-map <route-map>
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> filter-list <as-path-access-list> (in|out)
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> next-hop-self [force]
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast] neighbor <bgppeer> prefix-list <prefix-list-v4> (in|out)
    frr (add|del) bgp [vrf <text>] ipv6 unicast neighbor <bgppeer> prefix-list <prefix-list-v6> (in|out)
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> remove-private-AS [all] [replace-AS]
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> route-map <route-map> (in|out)
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> route-reflector-client
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> send-community [both|extended|standard]
    frr (add|del) bgp [vrf <text>] [ipv4 unicast|ipv4 labeled-unicast|ipv6 unicast|ipv6 labeled-unicast] neighbor <bgppeer> soft-reconfiguration inbound
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn route-target (both|export|import) <route-target>
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn rd <rd>
    frr add       bgp [vrf <text>] [ipv4 unicast|ipv6 unicast] table-map <route-map>
    frr del       bgp [vrf <text>] [ipv4 unicast|ipv6 unicast] table-map [<route-map>]
    frr (add|del) bgp [vrf <text>] (ipv4 unicast|ipv6 unicast) import vrf <text-import-vrf>
    frr (add|del) bgp [vrf <text>] (ipv4 unicast|ipv6 unicast) import vrf route-map <route-map>

    # EVPN
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn advertise-all-vni
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn advertise-default-gw
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn advertise ipv4 unicast [route-map <route-map>]
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn advertise ipv6 unicast [route-map <route-map>]
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn neighbor <bgppeer> activate
    frr add       bgp [vrf <text>] [l2vpn] evpn neighbor <bgppeer> allowas-in <1-10>
    frr del       bgp [vrf <text>] [l2vpn] evpn neighbor <bgppeer> allowas-in [<1-10>]
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn neighbor <bgppeer> route-reflector-client
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn neighbor <bgppeer> route-map <route-map> (in|out)
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn vni <1-16777215>
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn vni <1-16777215> advertise-default-gw
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn vni <1-16777215> advertise-subnet
    frr (add|del) bgp [vrf <text>] [l2vpn] evpn default-originate (ipv4|ipv6)
    frr (add|del) bgp [l2vpn] evpn vni <1-16777215> rd <rd>
    frr (add|del) bgp [l2vpn] evpn vni <1-16777215> route-target (both|export|import) <route-target>

    # L3 OSPF configuration
    frr (add|del) ospf [vrf <text>]
    frr (add|del) ospf [vrf <text>] area (<ipv4>|<0-4294967295>) stub [no-summary]
    frr (add|del) ospf [vrf <text>] area (<ipv4>|<0-4294967295>) filter-list prefix <prefix-list-v4> (in|out)
    frr (add|del) ospf [vrf <text>] auto-cost reference-bandwidth <1-4294967>
    frr (add|del) ospf debug ism [status|events|timers]
    frr (add|del) ospf debug lsa [generate|flooding|install|refresh]
    frr (add|del) ospf debug nsm [status|events|timers]
    frr (add|del) ospf debug packet (hello|dd|ls-request|ls-update|ls-ack|all) [send|recv|detail]
    frr (add|del) ospf debug zebra
    frr (add|del) ospf [vrf <text>] default-information originate [always]
    frr (add|del) ospf [vrf <text>] log-adjacency-changes [detail]
    frr (add|del) ospf [vrf <text>] network <ipv4/prefixlen> area (<ipv4>|<0-4294967295>)
    frr del       ospf [vrf <text>] network <ipv4/prefixlen>
    frr (add|del) ospf [vrf <text>] passive-interface (default|<interface>)
    frr (add|del) ospf [vrf <text>] redistribute (bgp|connected|kernel|static|table|table <1-65535>)
    frr (add|del) ospf [vrf <text>] redistribute (bgp|connected|kernel|static|table|table <1-65535>) metric <0-16777214>
    frr (add|del) ospf [vrf <text>] redistribute (bgp|connected|kernel|static|table|table <1-65535>) metric-type (1|2)
    frr (add|del) ospf [vrf <text>] redistribute (bgp|connected|kernel|static|table|table <1-65535>) route-map <route-map>
    frr add       ospf [vrf <text>] router-id <ipv4>
    frr del       ospf [vrf <text>] router-id [<ipv4>]
    frr add       ospf [vrf <text>] timers lsa min-arrival <0-600000>
    frr del       ospf [vrf <text>] timers lsa min-arrival [<0-600000>]
    frr (add|del) ospf [vrf <text>] timers throttle spf <0-600000> <0-600000> <0-600000>
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>|loopback lo) ospf area (<ipv4>|<0-4294967295>)
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>|loopback lo) ospf area [<ipv4>|<0-4294967295>]
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) ospf authentication message-digest
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) ospf cost <1-65535>
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) ospf message-digest-key <1-255> md5 <text>
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) ospf bfd [<2-255> <50-60000> <50-60000>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf dead-interval <1-65535>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf dead-interval [<1-65535>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf hello-interval <1-65535>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf hello-interval [<1-65535>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf network (broadcast|non-broadcast|point-to-multipoint|point-to-point)
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf network [broadcast|non-broadcast|point-to-multipoint|point-to-point]

    # L3 OSPFv3 configuration
    frr del ospf6
    frr (add|del) ospf6 area <ipv4> stub [no-summary]
    frr (add|del) ospf6 area <ipv4> range <ipv6/prefixlen> [advertise|not-advertise]
    frr (add|del) ospf6 area <ipv4> range <ipv6/prefixlen> cost <0-16777215>
    frr (add|del) ospf6 distance <1-255>
    frr (add|del) ospf6 distance ospf6 intra-area <1-255> inter-area <1-255> external <1-255>
    frr (add|del) ospf6 distance ospf6 intra-area <1-255> inter-area <1-255>
    frr (add|del) ospf6 distance ospf6 intra-area <1-255> external <1-255>
    frr (add|del) ospf6 distance ospf6 inter-area <1-255> external <1-255>
    frr (add|del) ospf6 distance ospf6 inter-area <1-255>
    frr (add|del) ospf6 distance ospf6 intra-area <1-255>
    frr (add|del) ospf6 distance ospf6 external <1-255>
    frr (add|del) ospf6 auto-cost reference-bandwidth <1-4294967>
    frr (add|del) ospf6 debug (abr|asbr|flooding|interface)
    frr (add|del) ospf6 debug border-routers [area-id <ipv4>|router-id <ipv4>]
    frr (add|del) ospf6 debug lsa (router|network|inter-prefix|inter-router|as-external|link|intra-prefix|unknown) [originate|examine|flooding]
    frr (add|del) ospf6 debug message (unknown|hello|dbdesc|lsreq|lsupdate|lsack|all) [send|recv]
    frr (add|del) ospf6 debug neighbor [state|event]
    frr (add|del) ospf6 debug route (table|intra-area|inter-area|memory)
    frr (add|del) ospf6 debug spf (database|process|time)
    frr (add|del) ospf6 debug zebra [send|recv]
    frr (add|del) ospf6 interface <interface> area <ipv4>
    frr (add|del) ospf6 log-adjacency-changes [detail]
    frr (add|del) ospf6 redistribute (bgp|connected|kernel|static|table) [route-map <route-map>]
    frr add       ospf6 router-id <ipv4>
    frr del       ospf6 router-id [<ipv4>]
    frr (add|del) ospf6 stub-router administrative
    frr add       ospf6 timers lsa min-arrival <0-600000>
    frr del       ospf6 timers lsa min-arrival [<0-600000>]
    frr (add|del) ospf6 timers throttle spf <0-600000> <0-600000> <0-600000>
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 bfd [<2-255> <50-60000> <50-60000>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>|loopback lo) ospf6 cost <1-65535>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>|loopback lo) ospf6 cost [<1-65535>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 advertise prefix-list <prefix-list-v6>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 advertise prefix-list [<prefix-list-v6>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 cost <1-65535>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 cost [<1-65535>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 dead-interval <1-65535>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 dead-interval [<1-65535>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 hello-interval <1-65535>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 hello-interval [<1-65535>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 ifmtu <1-65535>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 ifmtu [<1-65535>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>|loopback lo) ospf6 instance-id <0-255>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>|loopback lo) ospf6 instance-id [<0-255>]
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 mtu-ignore
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 network (broadcast|point-to-point)
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 network [broadcast|point-to-point]
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>|loopback lo) ospf6 passive
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 priority <0-255>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 priority [<0-255>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 retransmit-interval <1-65535>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 retransmit-interval [<1-65535>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 transmit-delay <1-3600>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) ospf6 transmit-delay [<1-3600>]

    # L3 multicast debugs
    frr (add|del) msdp debug (events|packets)
    frr (add|del) igmp debug (events|packets|trace)
    frr (add|del) pim debug packets [hello|joins|register]
    frr add pim debug [events|trace|zebra]
    frr del pim debug (events|trace|zebra)

    # L3 multicast show commands
    frr show igmp [vrf <text>] (join|sources)
    frr show igmp [vrf <text>] groups [json]
    frr show igmp [vrf <text>] interface [detail|<interface>] [json]
    frr show mroute [vrf <text>] [count|json]
    frr show msdp [vrf <text>] mesh-group [json]
    frr show msdp [vrf <text>] peer [detail|<ipv4>] [json]
    frr show msdp [vrf <text>] sa [detail] [json]
    frr show msdp [vrf <text>] sa <ipv4> [json]
    frr show msdp [vrf <text>] sa <ipv4> <ipv4-mcast-group> [json]
    frr show pim [vrf <text>] (assert|assert-internal|assert-metric|assert-winner-metric|secondary)
    frr show pim [vrf <text>] (join|local-membership|rpf|rp-info|upstream|upstream-join-desired|upstream-rpf) [json]
    frr show pim [vrf <text>] group-type [json]
    frr show pim [vrf <text>] group-type <ipv4-mcast-group> [json]
    frr show pim [vrf <text>] interface [detail|<interface>] [json]
    frr show pim [vrf <text>] interface traffic [<interface>] [json]
    frr show pim [vrf <text>] neighbor [detail|<interface>|<ipv4>] [json]
    frr show pim [vrf <text>] nexthop-lookup <ipv4-source> <ipv4-mcast-group>
    frr show pim [vrf <text>] state [json]
    frr show pim [vrf <text>] state <ipv4-source> [json]
    frr show pim [vrf <text>] state <ipv4-source> <ipv4-mcast-group> [json]

    # L3 multicast configuration
    frr (add|del) pim [vrf <text>] rp <ipv4> [<ipv4/prefixlen>]
    frr add       pim [vrf <text>] join-prune-interval <60-600>
    frr del       pim [vrf <text>] join-prune-interval [<60-600>]
    frr add       pim [vrf <text>] keep-alive-timer <31-60000>
    frr del       pim [vrf <text>] keep-alive-timer [<31-60000>]
    frr add       pim [vrf <text>] packets <1-100>
    frr del       pim [vrf <text>] packets [<1-100>]
    frr add       pim [vrf <text>] register-suppress-time <5-60000>
    frr del       pim [vrf <text>] register-suppress-time [<5-60000>]
    frr add       pim [vrf <text>] ssm prefix-list <prefix-list-v4>
    frr del       pim [vrf <text>] ssm prefix-list [<prefix-list-v4>]
    frr (add|del) pim [vrf <text>] spt-switchover infinity-and-beyond [prefix-list <prefix-list-v4>]
    frr (add|del) pim [vrf <text>] ecmp [rebalance]
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) igmp
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) igmp version (2|3)
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) igmp version [2]
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) igmp join <ipv4-mcast-group> <ipv4-source>
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) igmp query-interval <1-1800>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) igmp query-interval [<1-1800>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) igmp query-max-response-time <10-250>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) igmp query-max-response-time [<10-250>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) pim drpriority <1-4294967295>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) pim drpriority [<1-4294967295>]
    frr add       (bond <interface>|interface <interface>|vlan <number-range-list>) pim hello <1-180> <3-180>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) pim hello <1-180> <3-180>
    frr del       (bond <interface>|interface <interface>|vlan <number-range-list>) pim hello [<1-180>]
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) pim bfd [<2-255> <50-60000> <50-60000>]
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>|loopback lo) pim sm
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>|loopback lo) pim use-source <ipv4>
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>|loopback lo) multicast boundary oil <prefix-list-v4>
    frr (add|del) msdp mesh-group <text> (member|source) <ipv4>
    frr (add|del) routing mroute <ipv4/prefixlen> (<ipv4>|<interface>) [<1-255>]

    # SNMP Configuration
    frr add routing agentx

    # SNMP Configuration
    frr add routing agentx

    # as-path lists
    frr (add|del) routing as-path access-list <text> (deny|permit) <wildcard>
    frr show ip as-path-access-list [<as-path-access-list>]

    # community-list
    frr (add|del) routing community-list standard <text> (deny|permit) (local-AS|no-advertise|no-export|internet|<community>)
    frr (add|del) routing community-list expanded <text> (deny|permit) <regex>
    frr (add|del) routing extcommunity-list standard <text> (deny|permit) (rt|soo) <extcommunity>
    frr (add|del) routing extcommunity-list expanded <text> (deny|permit) <regex>

    frr show ip community-list <community-list>
    frr show ip extcommunity-list <extcommunity-list>

    # prefix-list
    frr (add|del) routing prefix-list ipv4 <text> description <wildcard>
    frr (add|del) routing prefix-list ipv4 <text> [seq <1-4294967295>] (deny|permit) (<ipv4/prefixlen>|any)
    frr (add|del) routing prefix-list ipv4 <text> [seq <1-4294967295>] (deny|permit) <ipv4/prefixlen> ge <0-32>
    frr (add|del) routing prefix-list ipv4 <text> [seq <1-4294967295>] (deny|permit) <ipv4/prefixlen> ge <0-32> le <1-32>
    frr (add|del) routing prefix-list ipv4 <text> [seq <1-4294967295>] (deny|permit) <ipv4/prefixlen> le <0-32>
    frr (add|del) routing prefix-list ipv4 <text> [seq <1-4294967295>] (deny|permit) <ipv4/prefixlen> le <0-32> ge <1-32>
    frr (add|del) routing prefix-list ipv6 <text> description <wildcard>
    frr (add|del) routing prefix-list ipv6 <text> [seq <1-4294967295>] (deny|permit) (<ipv6/prefixlen>|any)
    frr (add|del) routing prefix-list ipv6 <text> [seq <1-4294967295>] (deny|permit) <ipv6/prefixlen> ge <0-128>
    frr (add|del) routing prefix-list ipv6 <text> [seq <1-4294967295>] (deny|permit) <ipv6/prefixlen> ge <0-128> le <1-128>
    frr (add|del) routing prefix-list ipv6 <text> [seq <1-4294967295>] (deny|permit) <ipv6/prefixlen> le <0-128>
    frr (add|del) routing prefix-list ipv6 <text> [seq <1-4294967295>] (deny|permit) <ipv6/prefixlen> le <0-128> ge <1-128>
    frr del routing prefix-list ipv4 <text> [seq <1-4294967295>]
    frr del routing prefix-list ipv6 <text> [seq <1-4294967295>]
    frr clear ip prefix-list [<prefix-list-v4>|<prefix-list-v4> <ipv4/prefixlen>]
    frr clear ipv6 prefix-list [<prefix-list-v6>|<prefix-list-v6> <ipv6/prefixlen>]
    frr show ip prefix-list [<prefix-list-v4>]
    frr show ip prefix-list <prefix-list-v4> seq <1-4294967295>
    frr show ip prefix-list <prefix-list-v4> <ipv4/prefixlen> [longer|first-match]
    frr show ip prefix-list summary [<prefix-list-v4>]
    frr show ip prefix-list detail [<prefix-list-v4>]
    frr show ipv6 prefix-list [<prefix-list-v6>]
    frr show ipv6 prefix-list <prefix-list-v6> seq <1-4294967295>
    frr show ipv6 prefix-list <prefix-list-v6> <ipv6/prefixlen> [longer|first-match]
    frr show ipv6 prefix-list summary [<prefix-list-v6>]
    frr show ipv6 prefix-list detail [<prefix-list-v6>]

    # route-map
    frr (add|del) routing route-map <text> (deny|permit) <1-65535>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> call <route-map>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> continue <0-65535>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> description <wildcard>
    frr del routing route-map <text> permit <1-65535> on-match (goto <0-65535>|next)
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match as-path <as-path-access-list>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match community <community-list> [exact-match]
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match extcommunity <extcommunity-list>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match interface <interface>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match ip (address|next-hop) prefix-len <0-32>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match ip (address|next-hop|route-source) prefix-list <prefix-list-v4>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match ipv6 address prefix-list <prefix-list-v6>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match ipv6 next-hop <ipv6>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match local-preference <0-4294967295>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match metric <0-4294967295>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match origin (egp|igp|incomplete)
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match peer (<ipv4>|<ipv6>|local)
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match probability <0-100>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match source-protocol (bgp|connected|kernel|ospf|ospf6|static|system)
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match tag <0-65535>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match evpn default-route
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match evpn route-type (macip|prefix|multicast)
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> match evpn vni <1-16777215>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set aggregator as <1-4294967295> <ipv4>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set as-path exclude <1-4294967295>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set as-path prepend <1-4294967295>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set as-path prepend <1-4294967295> <1-4294967295>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set as-path prepend <1-4294967295> <1-4294967295> <1-4294967295>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set as-path prepend <1-4294967295> <1-4294967295> <1-4294967295> <1-4294967295>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set as-path prepend <1-4294967295> <1-4294967295> <1-4294967295> <1-4294967295> <1-4294967295>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set as-path prepend last-as <1-10>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set atomic-aggregate
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set comm-list <community-list> delete
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set community <community> [additive]
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set community none
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set extcommunity (rt|soo) <extcommunity> [<extcommunity>] [<extcommunity>] [<extcommunity>] [<extcommunity>] [<extcommunity>] [<extcommunity>]
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set forwarding-address <ipv6>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set label-index <0-1048560>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set ip next-hop (<ipv4>|peer-address|unchanged)
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set ipv6 next-hop (global|local) <ipv6>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set ipv6 next-hop peer-address
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set local-preference <0-4294967295>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set metric <0-4294967295>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set metric-type (type-1|type-2)
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set origin (egp|igp|incomplete)
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set originator-id <ipv4>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set src (<ipv4>|<ipv6>)
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set tag <0-65535>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set ipv4 vpn next-hop <ipv4>
    frr (add|del) routing route-map <text> (deny|permit) <1-65535> set weight <0-4294967295>
    frr show route-map [<route-map>]

    # MPLS 'global' configuration
    frr (add|del) mpls lsp <16-1048575> <ip> (<16-1048575>|explicit-null|implicit-null)
    frr (add|del) mpls label bind <ipv4/prefixlen> (<16-1048575>|explicit-null|implicit-null)
    frr (add|del) mpls label global-block <16-1048575> <16-1048575>

    frr show mpls ldp (binding|discovery|interface|neighbor)
    frr show mpls ldp (ipv4|ipv6) (binding|discovery|interface)
    frr show mpls status
    frr show mpls table [<16-1048575>] [json]

    frr (add|del) mpls ldp router-id <ipv4>
    frr (add|del) mpls ldp address-family (ipv4|ipv6) interface <interface>
    frr (add|del) mpls ldp address-family ipv4 discovery transport-address <ipv4>
    frr (add|del) mpls ldp address-family ipv6 discovery transport-address <ipv6>

    # PBR
    frr (add|del) nexthop-group <text> nexthop <ip> [<interface>] [nexthop-vrf <text>]
    frr del nexthop-group <text>
    frr (add|del) pbr-map <text> seq <1-700> match src-ip <ip/prefixlen>
    frr (add|del) pbr-map <text> seq <1-700> match dst-ip <ip/prefixlen>
    frr (add|del) pbr-map <text> seq <1-700> set nexthop <ip> [<interface>] [nexthop-vrf <text>]
    frr (add|del) pbr-map <text> seq <1-700> set nexthop-group <text>
    frr del pbr-map <text> seq <1-700>
    frr (add|del) (bond <interface>|interface <interface>|vlan <number-range-list>) pbr-policy <text>
    frr (add|del) pbr debug (events|map|nht|zebra)
    frr show pbr
    frr show pbr map [<text>]
    frr show pbr nexthop-group [<text>]
    frr show pbr interface [<interface>]

Options:

    <as-path-access-list>              : An AS_PATH access-list
    <bgppeer>                          : A BGP peer or neighbor
    <community-list>                   : A BGP community-list
    <community>                        : XX:YY where XX and YY are numbers in the range 0-65535
    <extcommunity-list>                : A BGP extended community-list
    <extcommunity>                     : ASN:nn_or_IP-address:nn VPN extended community
    <interface-source>                 : Source interface
    <ipv4-adv-router>                  : OSPF advertising router
    <ipv4-id>                          : OSPFv3 advertising router
    <ipv4-mcast-group>                 : IPv4 multicast group
    <ipv4-source>                      : IPv4 source address
    <peergroup>                        : A BGP peer-group name
    <prefix-list-v4>                   : An IPv4 prefix-list name
    <prefix-list-v6>                   : An IPv6 prefix-list name
    <regex>                            : A regular expression
    <route-map>                        : A route-map name
    <text-password>                    : A password
    <text-peer-group>                  : A BGP peer-group name
    <text-route-map>                   : A route-map name
    <text-import-vrf>                  : A vrf name for import
    Null0                              : Null interface
    abr                                : Area Border Router
    activate                           : Enable the Address Family for this Neighbor
    additive                           : Add to the existing list of communities
    addpath-tx-all-paths               : Use addpath to advertise all paths to a neighbor
    addpath-tx-bestpath-per-AS         : Use addpath to advertise the bestpath per each neighboring AS
    administrative                     : Administratively applied
    adv-router                         : Advertising Router link states
    advertise                          : Proclaim information to peers
    advertisement-interval             : Minimum interval between sending BGP routing updates
    aggregate-address                  : Configure BGP aggregate entries
    agentx                             : Enable SNMP support for OSPF, OSPFV3, and BGP4 MIBS
    aggregator                         : BGP aggregator attribute
    alerts                             : Immediate action needed
    allowas-in                         : Accept as-path with my AS present in it
    always                             : Always
    always-compare-med                 : Allow comparing MED from different neighbors
    any                                : Any IP prefix
    area                               : An OSPF area
    area-id                            : An OSPF area ID
    arp-cache                  : ARP and ND cache
    as                                 : Autonomous system
    as-external                        : AS-External LSA's
    as-override                        : Override ASNs in outbound updates if aspath equals remote-as
    as-path                            : AS_PATH attribute
    as-path-access-list                : An AS_PATH access-list
    as-set                             : Generate an AS_SET
    asbr                               : Autonomous system border router
    asbr-summary                       : ASBR summary link states
    assert                             : PIM interface assert
    assert-internal                    : PIM interface internal assert state
    assert-metric                      : PIM interface assert metric
    assert-winner-metric               : PIM interface assert winner metric
    atomic-aggregate                   : BGP atomic aggregate attribute
    attribute-unchanged                : BGP attribute is propagated unchanged to this neighbor
    auto-cost                          : Calculate OSPF interface cost according to bandwidth
    autonomous-system                  : AS number
    bestpath                           : BGP bestpath
    bfd                                : Bidirectional forwarding detection
    bgp                                : Border Gateway Protocol
    blackhole                          : Silently discard pkts when matched
    border-routers                     : OSPF ABR's and ASBR's
    both                               : Both
    boundary                           : Limit multicast traffic
    broadcast                          : An OSPF broadcast multi-access network
    call                               : Jump to another Route-Map after match+set
    capability                         : Advertise capability to the peer
    client-to-client                   : Configure client to client route reflection
    cluster-id                         : Configure Route-Reflector Cluster-id
    comm-list                          : A BGP community list
    community                          : BGP community attribute
    community-list                     : Add a community list entry
    compare-routerid                   : Compare router-id for identical EBGP paths
    confed                             : Compare path lengths including confederation sets & sequences in selecting a route
    confederation                      : Confederation parameters
    connect                            : BGP connect timer
    connected                          : Connected routes (directly attached subnet or host)
    continue                           : Exit policy on matches
    cost                               : Interface cost
    count                              : Route and packet count data
    critical                           : Critical conditions
    dampening                          : Enable route-flap dampening
    database                           : OSPF database
    datacenter                         : Datacenter
    dbdesc                             : Database description message
    dd                                 : OSPF Database Description
    dead-interval                      : Interval after which a neighbor is declared dead
    debug                              : Enable debugs
    debugging                          : Debugging messages
    default                            : Configure defaults
    defaults                           : Set of configuration defaults used
    default-originate                  : Originate default route to this neighbor
    deny                               : Deny in routing policy
    description                        : Description
    designated-router                  : PIM interface designated router
    deterministic-med                  : Pick the best-MED path among paths advertised from the neighboring AS
    disable-connected-check            : One-hop away EBGP peer using loopback address
    disable-ebgp-connected-route-check : Disable checking if nexthop is connected on ebgp sessions
    distribute-list                    : Filter updates to/from this neighbor
    dont-capability-negotiate          : Do not perform capability negotiation
    drchoice                           : Designated Router choices
    drpriority                         : PIM Designated Router Election Priority
    dump                               : Dump LSAs
    ebgp-multihop                      : Allow EBGP neighbors not on directly connected networks
    egp                                : Exterior Gateway Protocol
    emergencies                        : System is unusable
    enforce-first-as                   : Enforce the first AS for EBGP routes
    enforce-multihop                   : Enforce EBGP neighbors perform multihop
    errors                             : Error conditions
    event                              : Event information
    events                             : Event information
    exact-match                        : Do exact matching of communities
    examine                            : Examine
    exclude                            : Exclude from the as-path
    expanded                           : An expanded community-list
    extcommunity                       : An extended community
    extcommunity-list                  : An extended community list
    extended                           : Send Extended Community attributes
    extended-nexthop                   : Advertise extended next-hop capability to the peer
    external                           : An external BGP peer, external OSPF LSA, etc
    external-1                         : OSPF Type-1 External routes
    external-2                         : OSPF Type-2 External routes
    fast-external-failover             : Immediately reset session if a link to a directly connected external peer goes down
    file                               : Logging to file
    filter-list                        : Apply an as-path access-list
    first-match                        : First matched prefix
    flooding                           : LSA Flooding
    force                              : Set the next hop to self for reflected routes
    forwarding-address                 : Forwarding Address
    ge                                 : Greater than or equal to
    generate                           : LSA Generation
    global                             : IPv6 global address
    goto                               : Goto Clause number
    graceful-restart                   : Graceful restart capability parameters
    graceful-shutdown                  : Graceful shutdown parameters
    group-type                         : PIM group type
    groups                             : IGMP groups information
    hello                              : PIM interface hello information
    hello-interval                     : Time between HELLO packets
    hops                               : TTL hop count
    ibgp                               : An internal BGP peer
    ifmtu                              : Interface MTU
    igmp                               : Internet Group Management Protocol
    ignore                             : Ignore as-path length in selecting a route
    igp                                : Interior Gateway Protocol
    import vrf                         : Import routes from vrf
    import-table                       : Import routes from non-main kernel table
    in                                 : Apply inbound
    inbound                            : Apply inbound
    incomplete                         : Unknown origin
    info                               : Information
    informational                      : Informational messages
    install                            : LSA Install/Delete
    instance-id                        : Instance identifier
    inter-area                         : OSPF Inter-Area routes
    inter-prefix                       : Inter-Prefix LSA's
    inter-router                       : Inter-Router LSA's
    interface                          : An interface, such as swp1, swp2, etc.
    internal                           : An internal BGP peer
    internet                           : BGP community, matches all routes
    intra-area                         : OSPF Intra-Area routes
    distance                           : Administrative distance
    intra-prefix                       : Intra-Prefix LSA's
    ip                                 : Internet Protocol version 4
    ipv4                               : Internet Protocol version 4
    ipv4-unicast                       : IPv4 Unicast address family
    labeled-unicast                    : Address Family modifier
    label-index                        : Label index value
    ipv6                               : Internet Protocol version 6
    ism                                : Interface State Machine
    join                               : PIM interface join information
    jp-override-interval               : PIM interface J/P override interval
    keepalives                         : BGP keepalives
    kernel                             : Kernel routes (not installed via the zebra RIB)
    lan-prune-delay                    : PIM neighbors LAN prune delay parameters
    last-as                            : Use the peer's AS-number
    le                                 : Less than or equal to
    limit                              : Maximum number of BGP Dynamic Neighbors that can be created
    linkstate                          : Display linkstate routing table
    linkstate-id                       : Search by Link state ID
    listen                             : Configure BGP Dynamic Neighbors
    local                              : IPv6 local address
    local-AS                           : BGP community, restrict routes to our confederations sub-AS
    local-as                           : Specify a local-as number
    local-membership                   : PIM interface local-membership
    local-preference                   : BGP local-preference attribute
    log                                : Logging control
    log-adjacency-changes              : Log neighbor up/down and reset reason
    log-neighbor-changes               : Log neighbor up/down and reset reason
    longer                             : Show route matching the specified Network/Mask pair only
    longer-prefixes                    : Show route matching the specified Network/Mask pair only
    ls-ack                             : Link State Acknowledgement
    ls-request                         : Link State Request
    ls-update                          : Link State Update
    lsa                                : Link State Advertisement
    lsack                              : Link State Acknowledgement
    lsreq                              : Link State Request
    lsupdate                           : Link State Update
    match                              : Match values from routing table
    max-age                            : LSAs in MaxAge list
    max-med                            : Advertise routes with max-med
    maximum-paths                      : Forward packets over multiple paths
    maximum-prefix                     : Maximum number of prefix accept from this peer
    med                                : MED attribute
    memory                             : Memory statistics
    message                            : OSPFv3 message
    metric                             : Metric value for destination routing protocol
    metric-type                        : Type of metric
    min-arrival                        : Minimum delay in receiving new version of a LSA
    missing-as-worst                   : Treat missing MED as the least preferred one
    mroute                             : Static unicast routes in MRIB for multicast RPF lookup
    msdp                               : Multicast Source Discovery Protocol
    msec                               : Millisecond
    mtu-ignore                         : Ignore MTU
    multicast                          : Multicast
    traffic                            : Protocol Packet counters
    multihop                           : Neighbor is not directly connected
    multipath                          : BGP paths flagged as multipath
    multipath-relax                    : Allow load sharing across routes that have different AS paths (but same length)
    nd                                 : Neighbor Discovery
    neighbor                           : A BGP, OSPF, PIM, etc neighbor
    neighbor-events                    : Neighbor state transition events
    network                            : An ipv4 or ipv6 network
    next                               : Next route-map clause
    next-hop                           : Next-hop address of route
    next-hops                          : Next-hops
    next-hop-self                      : Disable the next hop calculation for this neighbor
    nht                                : Next Hop Tracking
    no-advertise                       : BGP community, do not advertise to anyone
    no-as-set                          : Do not generate an AS_SET
    no-export                          : BGP community, do not advertise to eBGP peer
    no-summary                         : Do not inject inter-area routes into stub
    non-broadcast                      : An OSPF NBMA network
    none                               : No community attribute
    notifications                      : Normal but significant conditions
    nsm                                : Neighbor State Machine
    nssa                               : OSPF nssa information
    nssa-external                      : NSSA external link state
    oil                                : Outgoing interface list
    on-match                           : Exit policy on matches
    on-startup                         : Effective on a startup
    opaque-area                        : Link area Opaque-LSA
    opaque-as                          : Link AS Opaque-LSA
    opaque-link                        : Link local Opaque-LSA
    origin                             : BGP origin attribute or the originating AS in the AS_PATH
    originate                          : Originate
    originator-id                      : BGP ORIGINATOR_ID attribute
    ospf                               : Open Shortest Path First (OSPFv2)
    ospf6                              : Open Shortest Path First (OSPFv3)
    out                                : Apply outbound
    override-capability                : Override capability negotiation result
    packet                             : Packet
    packets                            : Packets
    parameters                         : IGMP parameters information
    passive                            : Do not send open messages to this neighbor
    passive-interface                  : Suppress routing updates on an interface
    password                           : Set a password
    peer                               : peer address
    peer-address                       : Use peer address (for BGP only)
    peer-group                         : Member of the peer-group
    permit                             : Permit in routing policy
    pim                                : Protocol Independent Multicast
    point-to-multipoint                : An OSPF point-to-multipoint network
    point-to-point                     : An OSPF point-to-point network
    port                               : Port
    precision                          : Set the timestamp precision
    prefix                             : An IPv4 or IPv6 prefix
    prefix-len                         : Match prefix length of ip address
    prefix-list                        : Filter updates to/from this neighbor
    prepend                            : Prepend to the as-path
    priority                           : priority
    probability                        : Match portion of routes defined by percentage value
    process                            : Debug Detailed SPF Process
    protocol                           : Filter routing info exchanged between zebra and protocol
    ptm-enable                         : Enable neighbor check with specified topology
    query-interval                     : IGMP host query interval
    query-max-response-time            : IGMP max query response value (seconds)
    ra-interval                        : Router Advertisement interval
    ra-lifetime                        : Router lifetime
    range                              : Add a listening range for Dynamic Neighbors
    recv                               : Packet received
    redistribute                       : Redistribute information from another routing protocol
    reference-bandwidth                : Use reference bandwidth method to assign OSPF cost
    refresh                            : LSA Refresh
    reject                             : Emit an ICMP unreachable when matched
    remote-as                          : Specify a BGP neighbor
    remove-private-AS                  : Remove private ASNs in outbound updates
    replace-AS                         : Replace private ASNs with our ASN in outbound updates
    retransmit-interval                : Time between retransmitting lost link state advertisements
    rip                                : Routing Information Protocol (RIP)
    ripng                              : Routing Information Protocol Next Generation
    rmac                               : Router Mac
    route                              : Static routes
    route-map                          : Route-map
    route-reflector                    : Allow modifications made by out route-map
    route-reflector-client             : Configure a neighbor as Route Reflector client
    route-server-client                : Configure a neighbor as Route Server client
    route-source                       : Match advertising source address of route
    router                             : L3 routing protocols or OSPF LSA type
    router-id                          : Router identifier
    rp                                 : Rendevous Point
    rp-info                            : PIM RP information
    rpf                                : PIM cached source rpf information
    rt                                 : Route Target extended community
    secondary                          : The second or next highest in rank or importance
    self-originate                     : Self-originated link states
    self-originated                    : Self-originated link states
    send                               : Packet sent
    send-community                     : Send Community attribute to this neighbor
    seq                                : Sequence number
    set                                : Set values in destination routing protocol
    shutdown                           : Administratively shut down this neighbor
    soft                               : Soft reconfig inbound and outbound updates
    soft-reconfiguration               : Per neighbor soft reconfiguration
    solo                               : Solo peer - part of its own update group
    soo                                : Site-of-Origin extended community
    source-protocol                    : Match protocol via which the route was learnt
    sources                            : IGMP sources information
    spf                                : OSPF SPF timers
    src                                : Source
    ssm                                : Source Specific Multicast
    standard                           : Standard BGP communities
    state                              : State information
    static                             : Statically configured routes
    strict-capability-match            : Strict capability negotiation match
    stub                               : Configure OSPF area as stub
    stub-router                        : Make router a stub router
    summary                            : Summary
    summary-only                       : Filter more specific routes from updates
    supernets-only                     : Show only supernets
    suppress-ra                        : Suppress IPv6 Router Advertisement
    table                              : Non-main Kernel Routing Table
    table-map                          : BGP table to RIB route download filter
    tag                                : Set tag for this route
    throttle                           : Throttling adaptive timer
    time                               : Time
    timers                             : Routing protocol timers
    timestamp                          : Timestamp configuration
    trace                              : IGMP/PIM internal daemon activity
    transmit-delay                     : Transmit delay of this interface
    tree                               : Show SPF tree
    ttl-security                       : Specify the maximum number of hops to the BGP peer
    type-1                             : OSPF6 external type 1 metric
    type-2                             : OSPF6 external type 2 metric
    unchanged                          : Don't modify existing Next hop address
    unicast                            : Unicast Address Family Modifier
    unknown                            : Unknown LSA's
    unsuppress-map                     : Route-map to selectively unsuppress suppressed routes
    update-delay                       : Force initial delay for best-path and updates
    update-groups                      : BGP update groups
    update-source                      : Source of routing updates
    updates                            : BGP updates
    upstream                           : An upstream interface
    upstream-join-desired              : PIM upstream join-desired
    upstream-rpf                       : PIM upstream source rpf
    v6only                             : Enable BGP with v6 link-local only
    vpnv4                              : Vpnv4 address family
    vrf                                : Virtual Routing and Forwarding
    warnings                           : Warning conditions
    weight                             : Set default weight for routes from this neighbor
    zebra                              : Zebra information
    access-list                        : An access list
    Null0                              : Null interface
    routing                            : Routing protocols
    sa                                 : Source address
    sm                                 : Pim sparse mode
    2                                  : IGMP version 2, OSPF metric-type 2, etc
    3                                  : IGMP version 3
    join-prune-interval                : Join Prune Send Interval
    keep-alive-timer                   : Keep alive Timer
    register-suppress-time             : Register Suppress Timer
    ecmp                               : Equal Cost Multi-Path
    rebalance                          : Equal Cost Multi-Path Rebalance
    mesh-group                         : MSDP mesh-group
    member                             : mesh group member
    rd                                 : Route Distinguisher
    route-target                       : Route Target
    <rd>                               : A.B.C.D:2-byte-number, 4-byte-number:2-byte-number or 2-byte-number:4-byte-number
    <route-target>                     : 4-byte-number:2-byte-number or 2-byte-number:4-byte-number
    evpn                               : Ethernet VPN
    l2vpn                              : Layer-2 VPN
    import-rt                          : Import Route Target
    vrf-import-rt                      : VRF Import Route Target
    export-rt                          : Export Route Target
    vni                                : VXLAN Network Identifier
    type                               : Type
    macip                              : MAC-IP (Type-2) route
    mac                                : Media Access Control
    vtep                               : VXLAN Tunnel End Point
    advertise-all-vni                  : Advertise All local VNIs
    advertise-default-gw               : Advertise All default g/w mac-ip routes in EVPN
    import                             : Import
    export                             : Export
    use-source                         : Specify source
    authentication                     : Enable authentication
    message-digest                     : Use message-digest authentication
    message-digest-key                 : Message digest authentication password (key)
    md5                                : MD5 algorithm
    joins                              : PIM Join/Prune protocol packets
    register                           : PIM Register/Reg-Stop protocol packets
    mroute                             : A static unicast route into MRIB for multicast RPF lookup
    debugs                             : Debugs
    syslog                             : Set syslog logging
    line                               : A terminal line
    vty                                : Virtual terminal
    exec-timeout                       : Set the EXEC timeout
    service                            : Service
    integrated-vtysh-config            : Write configuration into integrated file
    import-table                       : Import routes from non-main kernel table
    fpm                                : Debug zebra FPM events
    mpls                               : Multiprotocol Label Switching
    rib                                : Routing Information Base
    detailed                           : Detailed
    table                              : Table
    explicit-null                      : Use Explicit-Null label
    implicit-null                      : Use Implicit-Null label
    label                              : MPLS label
    ldp                                : Label Distribution Protocol
    binding                            : Binding
    discovery                          : Discovery
    address-family                     : address-family
    transport-address                  : Specify transport address for TCP connection
    bind                               : Establish FEC to label binding
    global-block                       : Configure global label block
    lsp                                : Label Switched Path
    nexthop-lookup                     : PIM cached nexthop rpf lookup
    infinite                           : Infinite valid lifetime
    no-autoconfig                      : Do not use prefix for autoconfiguration
    off-link                           : Do not use prefix for onlink determination
    router-address                     : Set Router Address flag
    advertised-routes                  : Display routes advertised to a BGP neighbor
    received-routes                    : Display routes learned from neighbor, including denied routes
    routes                             : Display routes learned from neighbor
    nexthop                            : IP Nexthop
    pbr-map                            : Policy Based Routing map
    default-information                : Control distribution of default information
    map                                : Route-map
    prefix-routes-only                 : EVPN prefix routes only
    import-check                       : Check BGP network route exists in IGP
"""

