#!/usr/bin/env python

"""
Copyright (C) 2016-2017 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt


Usage:

    acl (add|del) control-plane acl ipv4 <acl-ipv4> (inbound|outbound)
    acl (add|del) control-plane acl ipv6 <acl-ipv6> (inbound|outbound)
    acl (add|del) control-plane acl mac <acl-mac> (inbound|outbound)

    acl (add|del) (bond|interface) <interface> acl ipv4 <acl-ipv4> (inbound|outbound)
    acl (add|del) (bond|interface) <interface> acl ipv6 <acl-ipv6> (inbound|outbound)
    acl (add|del) (bond|interface) <interface> acl mac <acl-mac> (inbound|outbound)
    acl (add|del) vlan <number-range-list> acl ipv4 <acl-ipv4> (inbound|outbound)
    acl (add|del) vlan <number-range-list> acl ipv6 <acl-ipv6> (inbound|outbound)
    acl (add|del) vlan <number-range-list> acl mac <acl-mac> (inbound|outbound)

    acl add acl ipv4 (<acl-ipv4>|<text>) [priority <number>] [table mangle] ACTION_IPV4 tcp source-ip (any|<ipv4>|<ipv4/prefixlen>) source-port (any|<tcp-port>|<number-range>) dest-ip (any|<ipv4>|<ipv4/prefixlen>) dest-port (any|<tcp-port>|<number-range>) [tcp-flags <tcp-flags-examine> <tcp-flags-set>] [dscp <dscp>] [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl ipv4 (<acl-ipv4>|<text>) [priority <number>] [table mangle] ACTION_IPV4 udp source-ip (any|<ipv4>|<ipv4/prefixlen>) source-port (any|<udp-port>|<number-range>) dest-ip (any|<ipv4>|<ipv4/prefixlen>) dest-port (any|<udp-port>|<number-range>) [dscp <dscp>] [inbound-interface <interface>|outbound-interface <interface>]


    acl add acl ipv4 (<acl-ipv4>|<text>) [priority <number>] [table mangle] ACTION_IPV4 source-ip (any|<ipv4>|<ipv4/prefixlen>) dest-ip (any|<ipv4>|<ipv4/prefixlen>|local|iprouter) [dscp <dscp>] [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl ipv4 (<acl-ipv4>|<text>) [priority <number>] [table mangle] ACTION_IPV4 (ospf|pim|icmp|igmp|tcp|udp) [dscp <dscp>] [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl ipv4 (<acl-ipv4>|<text>) [priority <number>] [table mangle] ACTION_SPAN tcp source-ip (any|<ipv4>|<ipv4/prefixlen>) source-port (any|<tcp-port>|<number-range>) dest-ip (any|<ipv4>|<ipv4/prefixlen>) dest-port (any|<tcp-port>|<number-range>) [tcp-flags <tcp-flags-examine> <tcp-flags-set>]
    acl add acl ipv4 (<acl-ipv4>|<text>) [priority <number>] [table mangle] ACTION_SPAN udp source-ip (any|<ipv4>|<ipv4/prefixlen>) source-port (any|<udp-port>|<number-range>) dest-ip (any|<ipv4>|<ipv4/prefixlen>) dest-port (any|<udp-port>|<number-range>)
    acl add acl ipv4 (<acl-ipv4>|<text>) [priority <number>] [table mangle] ACTION_SPAN source-ip (any|<ipv4>|<ipv4/prefixlen>) dest-ip (any|<ipv4>|<ipv4/prefixlen>|local|iprouter)
    acl add acl ipv4 (<acl-ipv4>|<text>) [priority <number>] [table mangle] ACTION_SPAN (ospf|pim|icmp|igmp|tcp|udp)
    acl add acl ipv4 <acl-ipv4> renumber
    acl del acl ipv4 <acl-ipv4> [priority <number-range-list>]

    acl add acl ipv6 (<acl-ipv6>|<text>) [priority <number>] ACTION tcp source-ip (any|<ipv6>|<ipv6/prefixlen>) source-port (any|<tcp-port>|<number-range>) dest-ip (any|<ipv6>|<ipv6/prefixlen>) dest-port (any|<tcp-port>|<number-range>) [tcp-flags <tcp-flags-examine> <tcp-flags-set>] [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl ipv6 (<acl-ipv6>|<text>) [priority <number>] ACTION udp source-ip (any|<ipv6>|<ipv6/prefixlen>) source-port (any|<udp-port>|<number-range>) dest-ip (any|<ipv6>|<ipv6/prefixlen>) dest-port (any|<udp-port>|<number-range>) [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl ipv6 (<acl-ipv6>|<text>) [priority <number>] ACTION source-ip (any|<ipv6>|<ipv6/prefixlen>) dest-ip (any|<ipv6>|<ipv6/prefixlen>|local|iprouter) [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl ipv6 (<acl-ipv6>|<text>) [priority <number>] ACTION (ospf|pim|igmp|tcp|udp) [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl ipv6 (<acl-ipv6>|<text>) [priority <number>] ACTION icmp [router-solicitation|router-advertisement|neighbour-solicitation|neighbour-advertisement|<0-255>] [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl ipv6 <acl-ipv6> renumber
    acl del acl ipv6 <acl-ipv6> [priority <number-range-list>]

    acl add acl mac (<acl-mac>|<text>) [priority <number>] ACTION protocol [ETHERTYPE] [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl mac (<acl-mac>|<text>) [priority <number>] ACTION source-mac (MAC_MAPPING) dest-mac (MAC_MAPPING) [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl mac (<acl-mac>|<text>) [priority <number>] ACTION source-mac (MAC_MAPPING) dest-mac (MAC_MAPPING) protocol (ETHERTYPE) [inbound-interface <interface>|outbound-interface <interface>]
    acl add acl mac <acl-mac> renumber
    acl del acl mac <acl-mac> [priority <number-range-list>]

    acl add policer-template (<policer-name>|<text>) mode packet rate <1-2147483647> burst <1-2147483647> [class <0-7>]
    acl del policer-template <policer-name> mode packet rate <1-2147483647> burst <1-2147483647> [class <0-7>]
    acl del policer-template <policer-name>

Options:

    <0x600-0xFFFF>          : Ethertype values
    <acl-ipv4>              : An IPv4 access-list
    <acl-ipv6>              : An IPv6 access-list
    <acl-mac>               : A MAC access-list
    <dscp>                  : Differentiated services
    <ipv4/prefixlen>        : An IPv4 address and prefix length
    <ipv4>                  : An IPv4 address
    <ipv6/prefixlen>        : An IPv6 address and prefix length
    <ipv6>                  : An IPv6 address
    <mac>                   : A MAC address
    <number-range>          : Example: "1024-1200"
    <policer-name>          : A policer-template name
    <tcp-flags-examine>     : TCP flags to examine when matching
    <tcp-flags-set>         : TCP flags to set
    <tcp-port>              : TCP port number
    <udp-port>              : UDP port number
    accept                  : Allow, permit, etc
    any                     : Any IP prefix
    arp                     : Address Resolution Protocol
    bgp                     : Border Gateway Protocol
    bpdu                    : Bridge Protocol Data Unit
    burst                   : Packet burst
    cdp                     : Cisco Discovery Protocol
    cisco-pvst              : Cisco per-VLAN spanning tree
    class                   : Packet class
    control-plane           : A virtual interface for traffic to/from the CPU
    destination             : SPAN destination interface
    dest-ip                 : Destination IP address
    dest-mac                : Destination MAC address
    dest-port               : Destination port number
    dhcp                    : Dynamic Host Configuration Protocol
    dns                     : Domain Name Service
    drop                    : Deny, drop, etc
    dscp                    : Differentiated services
    erspan                  : Extended Switched Port Analyzer
    ftp                     : File Transfer Protocol
    ftps                    : FTP over TLS/SSL
    http                    : Hypertext Transfer Protocol
    https                   : Hypertext Transfer Protocol over SSL/TLS
    icmp                    : Internet Control Message Protocol
    igmp                    : Internet Group Management Protocol
    imap                    : Internet Message Access Protocol
    inbound                 : Apply inbound
    inbound-interface       : An inbound interface
    iprouter                : Destination IP is not a local address but comes to CPU to be routed
    lacp                    : Link Aggregation Control Protocol
    ldap                    : Lightweight Directory Access Protocol
    ldaps                   : Lightweight Directory Access Protocol over TLS/SSL
    local                   : Destination IP is a local address
    mac                     : Media Access Control
    mangle                  : Table for modifying packets
    mode                    : Mode
    neighbour-advertisement : IPv6 neighbour advertisement
    neighbour-solicitation  : IPv6 neighbour solicitation
    ntp                     : Network Time Protocol
    outbound                : Apply outbound
    outbound-interface      : An outbound interface
    police                  : Restrict traffic rates
    policer-template        : Template for configured police settings
    pop                     : Post Office Protocol
    priority                : Priority number
    rate                    : Packet rate
    renumber                : Renumber access-list priority numbers in increments of 10
    router-advertisement    : IPv6 router advertisement
    router-solicitation     : IPv6 router solicitation
    set-class               : Set class values
    set-dscp                : Set DSCP values
    set-qos                 : Set QOS values
    smtp                    : Simple Mail Transfer Protocol
    snmp                    : Simple Network Management Protocol
    source-ip               : Source IP address
    source-mac              : Source MAC address
    source-port             : Source port number
    span                    : Switched Port Analyzer
    ssh                     : Secure Shell
    tcp                     : Transmission Control Protocol
    tcp-flags               : TCP flags
    telnet                  : Telnet
    tftp                    : Trivial File Transfer Protocol
    ttl                     : Time To Live
    udp                     : User Datagram Protocol
    ipv4                    : Internet Protocol version 4
    ipv6                    : Internet Protocol version 6
    table                   : Table
    packet                  : Packet
    pim                     : Protocol Independent Multicast
    protocol                : BGP, OSPF, etc

"""

# http//www.networksorcery.com/enp/protocol/ip/ports00000.htm
tcp_ports = {
    'ftp'         :   21,
    'ssh'         :   22,
    'telnet'      :   23,
    'smtp'        :   25,
    'domain'      :   53,
    'bootps'      :   67,
    'bootpc'      :   68,
    'dhcp-server' :   67,
    'dhcp-client' :   68,
    'http'        :   80,
    'pop3'        :  110,
    'imap2'       :  143,
    'snmp'        :  161,
    'snmp-trap'   :  162,
    'bgp'         :  179,
    'ldap'        :  389,
    'https'       :  443,
    'ldaps'       :  636,
    'msdp'        :  639,
    'clag'        : 5342,
}

udp_ports = {
    'domain'       :    53,
    'bootps'       :    67,
    'bootpc'       :    68,
    'dhcp-server'  :    67,
    'dhcp-client'  :    68,
    'tftp'         :    69,
    'ntp'          :   123,
    'snmp'         :   161,
    'snmp-trap'    :   162,
    'ldap'         :   389,
    'ldaps'        :   636,
    'bfd'          :  3784,
    'bfd-echo'     :  3785,
    'bfd-multihop' :  4784,
    'lnv'          : 10001,
}

dscp_mapping = {
    'best-effort' : 0,
    'af11' : 10,
    'af12' : 12,
    'af13' : 14,
    'af21' : 18,
    'af22' : 20,
    'af23' : 22,
    'af31' : 26,
    'af32' : 28,
    'af33' : 30,
    'af41' : 34,
    'af42' : 36,
    'af43' : 38,
    'cs1'  : 8,
    'cs2'  : 16,
    'cs3'  : 24,
    'cs4'  : 32,
    'cs5'  : 40,
    'cs6'  : 48,
    'cs7'  : 56,
    'ef'   : 46,
}


mac_mapping = {
    'bpdu'       : '01:80:c2:00:00:00',
    'cdp'        : '01:00:0c:cc:cc:cc',
    'cisco-pvst' : '01:00:0c:cc:cc:cd',
    'lacp'       : '01:80:c2:00:00:02',
    'lldp'       : '01:80:c2:00:00:0e',
}

__doc__ = __doc__.replace('ACTION_SPAN', '(span destination <interface>|erspan source-ip <ipv4> dest-ip <ipv4> ttl <1-255>)')
__doc__ = __doc__.replace('ACTION_IPV4', '(accept|drop|set-class <0-7>|police <policer-name>|set-qos set-dscp <dscp>|dscp set-dscp <dscp>)')
__doc__ = __doc__.replace('ACTION', '(accept|drop|set-class <0-7>|police <policer-name>)')

__doc__ = __doc__.replace('MAC_MAPPING', '|'.join(['any', '<mac>',] + sorted(mac_mapping.keys())))
__doc__ = __doc__.replace('ETHERTYPE', 'ipv4|ipv6|arp|any|<0x600-0xFFFF>')


from collections import OrderedDict
from ipaddr import IPv4Network, IPv6Network, AddressValueError
from nclu import (
    make_pending_diff,
    glob_to_numbers,
    ifname_expand_glob,
    files_match,
    mkdir_p,
    WORKING_DIRECTORY,
)
from nclu.wrappers.ifupdown2 import EtcNetworkInterface
from network_docopt import sort_ifaces, sort_for_humans
from network_docopt.match import ifname_is_glob
from pprint import pformat
from subprocess import check_output, CalledProcessError, STDOUT
import logging
import os
import re
import shutil


log = logging.getLogger("netd")

PROTOCOLS = ("tcp", "udp", "ospf", "pim", "igmp")
VAR_LIB_NCLU = "/var/lib/cumulus/nclu/"
VAR_LIB_ACL_CONF = os.path.join(VAR_LIB_NCLU, "nclu_acl.conf")
VAR_LIB_ACL_CONF_BACKUP = VAR_LIB_ACL_CONF + ".backup"
RUN_ACL_CONF = os.path.join(WORKING_DIRECTORY, "accesslist", "nclu_acl.conf")
RUN_NCLU = os.path.join(WORKING_DIRECTORY, "accesslist")
CL_ACLTOOL = "/usr/cumulus/bin/cl-acltool"
RULES_50_NCLU = "/etc/cumulus/acl/policy.d/50_nclu_acl.rules"


class AccessListRule(object):

    def __init__(self, parent_acltype, parent_aclname, parent_aclpriority, words):
        self.table = None

        if words[0] == "table":
            self.table = words[1]
            words = words[2:]

        self.action = words[0]
        self.parent_acltype = parent_acltype
        self.parent_aclname = parent_aclname
        self.parent_aclpriority = parent_aclpriority
        self.guts = []

        if self.action == "set-class":
            self.action = 'set-class %s' % words[1]
            words_start = 2

        elif self.action == 'set-qos':
            self.action = 'set-qos set-dscp %s' % words[2]
            words_start = 3

        elif self.action == 'dscp':
            self.action = 'dscp set-dscp %s' % words[2]
            words_start = 3

        elif self.action == 'police':
            self.action = 'police %s' % words[1]
            words_start = 2

        # span destination swp1
        elif self.action == 'span':
            self.action = 'span destination %s' % words[2]
            words_start = 3

        # erspan source-ip <ipv4> dest-ip <ipv4> ttl <number>
        elif self.action == 'erspan':
            self.action = 'erspan source-ip %s dest-ip %s ttl %s' % (words[2], words[4], words[6])
            words_start = 7

        else:
            words_start = 1

        for word in words[words_start:]:
            ipv4 = None
            ipv6 = None

            if not isinstance(word, int):
                if '.' in word:
                    try:
                        init_ipv4 = IPv4Network(word)
                        ipv4 = IPv4Network("%s/%d" % (init_ipv4.network, init_ipv4.prefixlen))

                        if str(ipv4) != str(init_ipv4):
                            print "NOTE: %s was converted to %s" % (init_ipv4, ipv4)
                        elif '/' not in word:
                            print "NOTE: %s was converted to %s" % (word, ipv4)

                    except AddressValueError:
                        pass

                elif ':' in word:
                    try:
                        init_ipv6 = IPv6Network(word)
                        ipv6 = IPv6Network("%s/%d" % (init_ipv6.network, init_ipv6.prefixlen))

                        if str(ipv6) != str(init_ipv6):
                            print "NOTE: %s was converted to %s" % (init_ipv6, ipv6)
                        elif '/' not in word:
                            print "NOTE: %s was converted to %s" % (word, ipv6)

                    except AddressValueError:
                        pass

            if ipv4:
                self.guts.append(ipv4)
            elif ipv6:
                self.guts.append(ipv6)
            else:
                self.guts.append(word)

        if self.table:
            self.config_line = "acl %s %s priority %s table %s %s %s" % (parent_acltype, parent_aclname, parent_aclpriority, self.table, self.action, ' '.join(map(str, self.guts)))
        else:
            self.config_line = "acl %s %s priority %s %s %s" % (parent_acltype, parent_aclname, parent_aclpriority, self.action, ' '.join(map(str, self.guts)))

    def __str__(self):
        return "%s %s" % (self.action, ' '.join(map(str, self.guts)))

    def is_any_any(self):
        """
        Return True if this is a catch all "any any" rule
        """
        if len(self.guts) >= 2:
            if self.guts[-2] == 'any' and self.guts[-1] == 'any':
                return True
        return False

    def get_inbound_interface(self):
        for (index, word) in enumerate(self.guts):
            if word == 'inbound-interface':
                return self.guts[index + 1]
        return None

    def get_outbound_interface(self):
        for (index, word) in enumerate(self.guts):
            if word == 'outbound-interface':
                return self.guts[index + 1]
        return None

    def get_rule_string(self, ifname, direction, policers):
        rule_string = []
        inbound_interface = self.get_inbound_interface()
        outbound_interface = self.get_outbound_interface()

        if self.table:
            rule_string.append('-t')
            rule_string.append(self.table)

        if ifname == 'control-plane':
            if direction == 'inbound':
                rule_string.append('-A')
                rule_string.append('INPUT')

                if inbound_interface:
                    rule_string.append('--in-interface')
                    rule_string.append(inbound_interface)
                else:
                    rule_string.append('--in-interface')
                    rule_string.append('swp+')

            elif direction == 'outbound':
                rule_string.append('-A')
                rule_string.append('OUTPUT')

                if outbound_interface:
                    rule_string.append('--out-interface')
                    rule_string.append(outbound_interface)
                else:
                    rule_string.append('--out-interface')
                    rule_string.append('swp+')

            else:
                raise Exception("Invalid direction %s" % direction)

        else:
            rule_string.append('-A')
            rule_string.append('FORWARD')

            if direction == 'inbound':
                rule_string.append('--in-interface')
                rule_string.append(ifname)

                if outbound_interface:
                    rule_string.append('--out-interface')
                    rule_string.append(outbound_interface)

            elif direction == 'outbound':
                if inbound_interface:
                    rule_string.append('--in-interface')
                    rule_string.append(inbound_interface)

                rule_string.append('--out-interface')
                rule_string.append(ifname)
            else:
                raise Exception("Invalid direction %s" % direction)

        if self.action == 'accept':
            rule_string.append('-j')
            rule_string.append('ACCEPT')

        elif self.action == 'drop':
            rule_string.append('-j')
            rule_string.append('DROP')

        # span destination swp1
        elif self.action.startswith('span'):
            value = self.action.split()[2]
            rule_string.append('-j')
            rule_string.append('SPAN')
            rule_string.append('--dport')
            rule_string.append(value)

        # erspan source-ip <ipv4> dest-ip <ipv4> ttl <number>
        elif self.action.startswith('erspan '):
            (_, _, src_ip, _, dst_ip, _, ttl) = self.action.split()
            rule_string.append('-j')
            rule_string.append('ERSPAN')
            rule_string.append('--src-ip')
            rule_string.append(src_ip)
            rule_string.append('--dst-ip')
            rule_string.append(dst_ip)
            rule_string.append('--ttl')
            rule_string.append(ttl)

        elif self.action.startswith('set-class'):
            value = self.action.split()[1]
            rule_string.append('-j')

            # ebtables is case senstive for setclass
            if self.parent_acltype == 'mac':
                rule_string.append('setclass')
            else:
                rule_string.append('SETCLASS')

            rule_string.append('--class')
            rule_string.append(value)

        # set-qos set-dscp ef
        elif self.action.startswith('set-qos'):
            dscp = self.action.split()[2]
            rule_string.append('-j')

            if self.parent_acltype == 'mac':
                rule_string.append('setqos')
            else:
                rule_string.append('SETQOS')

            rule_string.append('--set-dscp')
            rule_string.append(str(dscp_mapping.get(dscp)))

        # dscp set-dscp ef
        elif self.action.startswith('dscp'):
            dscp = self.action.split()[2]
            rule_string.append('-j')

            if self.parent_acltype == 'mac':
                rule_string.append('dscp')
            else:
                rule_string.append('DSCP')

            rule_string.append('--set-dscp')
            rule_string.append(str(dscp_mapping.get(dscp)))

        elif self.action.startswith('police'):
            name = self.action.split()[1]
            policer = policers.get(name)

            if policer:
                police_rule_string = []
                police_rule_string.append('-j')

                # ebtables is case senstive for police
                if self.parent_acltype == 'mac':
                    police_rule_string.append('police')
                else:
                    police_rule_string.append('POLICE')

                for x in policer.split():
                    if x == 'mode':
                        police_rule_string.append('--set-mode')

                    elif x == 'packet':
                        police_rule_string.append('pkt')

                    elif x == 'rate':
                        police_rule_string.append('--set-rate')

                    elif x == 'burst':
                        police_rule_string.append('--set-burst')

                    elif x == 'class':
                        police_rule_string.append('--set-class')

                    elif x.isdigit():
                        police_rule_string.append(str(x))

                    else:
                        print "Not sure how to convert ACL \"{0}\" policer \"{1}\" word {2}.".format(self.parent_aclname, self, x)
                        return None

                rule_string.extend(police_rule_string)
            else:
                print "Policer {0} does not exist.  Skipping this rule.".format(name)
                return None

        else:
            raise Exception("Invalid action %s" % self.action)

        num_words = len(self.guts)
        index = 0
        protocol = None

        while index < num_words:
            word = self.guts[index]

            # inbound-interface and outbound-interface keywords were honored
            # near the top of get_rule_string()
            if word in ('inbound-interface', 'outbound-interface'):
                index += 1

            elif self.parent_acltype == 'ipv4' or self.parent_acltype == 'ipv6':
                try:
                    re_range = re.match('^(\d+)-(\d+)$', word)
                except TypeError:
                    re_range = None

                if word in PROTOCOLS:
                    protocol = word
                    rule_string.append('-p')
                    rule_string.append(protocol)

                elif word.isdigit() or re_range:
                    if protocol == 'icmp' and self.parent_acltype == 'ipv6':
                        rule_string.append('-m')
                        rule_string.append('icmp6')
                        rule_string.append('--icmpv6-type')

                        if re_range:
                            start = int(re_range.group(1))
                            stop = int(re_range.group(2))
                            rule_string.append("%d:%d" % (start, stop))
                        else:
                            rule_string.append(word)

                    else:
                        raise Exception("Invalid AccessListRule keyword %s, parent acltype %s" % (word, self.parent_acltype))

                elif word == 'source-ip':
                    index += 1
                    ip = self.guts[index]

                    if ip != 'any':
                        rule_string.append('-s')
                        rule_string.append(str(ip))

                elif word == 'source-port':
                    index += 1
                    port = self.guts[index]

                    if port != 'any':
                        rule_string.append('--sport')
                        try:
                            re_range = re.match('^(\d+)-(\d+)$', port)
                        except TypeError:
                            re_range = None

                        if re_range:
                            start = int(re_range.group(1))
                            stop = int(re_range.group(2))
                            port = "%d:%d" % (start, stop)

                        if protocol == 'udp':
                            if port in udp_ports:
                                port = udp_ports[port]
                        elif protocol == 'tcp':
                            if port in tcp_ports:
                                port = tcp_ports[port]
                        else:
                            log.warning("Invalid AccessListRule protocol %s" % word)
                            continue

                        port = str(port)
                        rule_string.append(port)

                elif word == 'dest-ip':
                    index += 1
                    ip = self.guts[index]

                    if ip == 'any':
                        pass
                    elif ip == 'local':
                        rule_string.append('-m')
                        rule_string.append('addrtype')
                        rule_string.append('--dst-type')
                        rule_string.append('LOCAL')
                    elif ip == 'iprouter':
                        rule_string.append('-m')
                        rule_string.append('addrtype')
                        rule_string.append('--dst-type')
                        rule_string.append('IPROUTER')
                    else:
                        rule_string.append('-d')
                        rule_string.append(str(ip))

                elif word == 'dest-port':
                    index += 1
                    port = self.guts[index]

                    if port != 'any':
                        rule_string.append('--dport')

                        try:
                            re_range = re.match('^(\d+)-(\d+)$', port)
                        except TypeError:
                            re_range = None

                        if re_range:
                            start = int(re_range.group(1))
                            stop = int(re_range.group(2))
                            port = "%d:%d" % (start, stop)

                        if protocol == 'udp':
                            if port in udp_ports:
                                port = udp_ports[port]
                        elif protocol == 'tcp':
                            if port in tcp_ports:
                                port = tcp_ports[port]
                        else:
                            log.warning("Invalid AccessListRule protocol %s" % word)
                            continue

                        port = str(port)
                        rule_string.append(port)

                # 'tcp-flags <tcp-flags-examine> <tcp-flags-set>' tranlates to '--tcp-flags SYN,RST,ACK,FIN SYN'
                elif word == 'tcp-flags':
                    rule_string.append('--tcp-flags')
                    rule_string.append(self.guts[index + 1])
                    rule_string.append(self.guts[index + 2])
                    index += 2

                elif word == 'dscp':
                    rule_string.append('-m')
                    rule_string.append('dscp')
                    rule_string.append('--dscp')

                    index += 1
                    word = self.guts[index]
                    rule_string.append(str(dscp_mapping.get(word)))

                elif word == 'icmp':
                    protocol = 'icmp'

                    if self.parent_acltype == 'ipv4':
                        rule_string.append('-p')
                        rule_string.append('icmp')

                    elif self.parent_acltype == 'ipv6':
                        rule_string.append('-p')
                        rule_string.append('ipv6-icmp')

                elif word in ('router-solicitation',
                              'router-advertisement',
                              'neighbour-solicitation',
                              'neighbour-advertisement'):
                    rule_string.append('-m')
                    rule_string.append('icmp6')
                    rule_string.append('--icmpv6-type')
                    rule_string.append(word)

                else:
                    log.warning("Invalid AccessListRule keyword %s, parent acltype %s" % (word, self.parent_acltype))

            # ebtables specific keywords
            elif self.parent_acltype == 'mac':

                if word == 'source-mac':
                    index += 1
                    word = self.guts[index]

                    if word != 'any':
                        rule_string.append('-s')

                        if word in mac_mapping.keys():
                            rule_string.append(mac_mapping[word])
                        else:
                            rule_string.append(word)

                elif word == 'dest-mac':
                    index += 1
                    word = self.guts[index]

                    if word != 'any':
                        rule_string.append('-d')
                        if word in mac_mapping.keys():
                            rule_string.append(mac_mapping[word])
                        else:
                            rule_string.append(word)

                elif word in ('ipv4', 'ipv6', 'arp'):
                    rule_string.append('-p')
                    rule_string.append(word)

                elif word == 'ipv6':
                    rule_string.append('-p')
                    rule_string.append('ipv6')

                elif word == 'protocol':
                    index += 1
                    word = self.guts[index]

                    if word != 'any':
                        rule_string.append('-p')
                        rule_string.append(word)

                else:
                    raise Exception("Invalid AccessListRule keyword %s, parent acltype %s" % (word, self.parent_acltype))

            else:
                raise Exception("Invalid AccessListRule keyword %s, parent acltype %s" % (word, self.parent_acltype))

            index += 1

        result = ' '.join(rule_string)

        if self.parent_acltype == 'mac':
            # This is a work-around for CM-13142
            #
            # For ebtables the following causes an 'hw sync failed (sync_acl hardware installation failed)' error
            #   -A INPUT --in-interface swp+ -j police --set-mode pkt --set-rate 100 --set-burst 100
            #
            # while
            #    -A INPUT -j police --set-mode pkt --set-rate 100 --set-burst 100
            #
            # works just fine
            re_ebtables_special = re.search('^-A INPUT --in-interface swp\+ -j police --set-mode pkt --set-rate (\d+) --set-burst (\d+)$', result)

            if re_ebtables_special:
                result = '-A INPUT -j police --set-mode pkt --set-rate %s --set-burst %s' %\
                    (re_ebtables_special.group(1), re_ebtables_special.group(2))

        return result


class AccessList(object):
    """
    An AccessList contains a dictionary of AccessListRule objects where
    the priority number is the dictionary key
    """

    def __init__(self, acltype, name):
        self.acltype = acltype
        self.name = name
        self.rules = {}

        if self.acltype == 'ipv4':
            self.header = '[iptables]'
        elif self.acltype == 'ipv6':
            self.header = '[ip6tables]'
        elif self.acltype == 'mac':
            self.header = '[ebtables]'
        else:
            raise Exception("Invalid ACL type %s" % self.acltype)

    def __str__(self):
        return "%s-%s" % (self.acltype, self.name)

    def dump(self):
        output = []

        for priority in sorted(self.rules.keys()):
            rule = self.rules[priority]
            output.append("%s %d: %s" % (self, priority, rule))

        return '\n'.join(output)

    def find_any_any_rule(self):
        for (priority, rule) in self.rules.iteritems():
            if rule.is_any_any():
                return priority
        return None

    def get_rule_strings(self, ifname, direction, policers):
        results = []

        for priority in sorted(self.rules.keys()):
            rule = self.rules[priority]
            rule_string = rule.get_rule_string(ifname, direction, policers)

            if rule_string:
                results.append(rule_string)

        return results

    def sets_inbound_interface(self):
        for rule in self.rules.itervalues():
            if rule.get_inbound_interface():
                return True
        return False

    def sets_outbound_interface(self):
        for rule in self.rules.itervalues():
            if rule.get_outbound_interface():
                return True
        return False


class Interface(object):

    def __init__(self, name):
        self.name = name
        self.reset()

    def __str__(self):
        return self.name

    def reset(self):
        self.acl = OrderedDict()
        self.acl[('ipv4', 'inbound')] = []
        self.acl[('ipv4', 'outbound')] = []
        self.acl[('ipv6', 'inbound')] = []
        self.acl[('ipv6', 'outbound')] = []
        self.acl[('mac', 'inbound')] = []
        self.acl[('mac', 'outbound')] = []

    def dump(self):
        output = []

        for ((acltype, direction), acls) in self.acl.items():
            for acl in acls:
                output.append("{0}: {1} {2} {3}".format(self, acltype, acl.name, direction))

        return '\n'.join(output)


def get_acl_from_name(acltype, aclname, ipv4_acl, ipv6_acl, mac_acl):
    """
    Given the name of an acl, return the AccessList object
    """

    if acltype == 'ipv4':
        return ipv4_acl.get(aclname)
    elif acltype == 'ipv6':
        return ipv6_acl.get(aclname)
    elif acltype == 'mac':
        return mac_acl.get(aclname)
    else:
        raise Exception("Invalid ACL type {0}".format(acltype))


def parse_nclu_conf(filename, acltype_to_renumber, acl_to_renumber, compress_to_swp_plus):
    """
    If we are editing the pending configuration, 'filename' will be /run/nclu/accesslist/nclu_acl.conf.

    If we are applying the configuration and building the iptables rules file,
    filename will be /var/lib/cumulus/nclu/nclu_acl.conf.
    """

    ifname = None
    ifaces = OrderedDict()
    ipv4_acl = OrderedDict()
    ipv6_acl = OrderedDict()
    mac_acl = OrderedDict()
    policers = OrderedDict()
    iface = None
    prev_priority = 0
    acl_tuples = {}

    if os.path.isfile(filename):
        with open(filename) as f:
            for line in f:
                line = line.strip().split()

                if not line or line[0].startswith('#'):
                    # Ignore comments.
                    continue

                if line[0] == "control-plane":
                    ifname = "control-plane"

                    if ifname not in ifaces:
                        ifaces[ifname] = Interface(ifname)
                    iface = ifaces[ifname]

                elif line[0] == "iface":
                    ifname = line[1]

                    if ifname not in ifaces:
                        ifaces[ifname] = Interface(ifname)
                    iface = ifaces[ifname]

                elif line[0] == "policer-template":
                    name = line[1]
                    policers[name] = ' '.join(line[2:])

                else:
                    acltype = line[1]

                    if line[-1] in ("inbound", "outbound"):
                        # The rule applies to an interface.

                        #   0    1   2       3
                        # --- ---- --- -------
                        # acl ipv4 FOO inbound
                        aclname = line[2]
                        direction = line[3]

                        # Once we have parsed the entire config we will replace
                        # the value here with the corresponding AccessList
                        # object for aclname (see the end of this function)
                        if aclname not in iface.acl[(acltype, direction)]:
                            iface.acl[(acltype, direction)].append(aclname)

                        # Remember which ACLs are applied where so we can see if
                        # any ACLs are applied to all interfaces....we use this
                        # to compress rules to swp+ rules
                        id_tuple = (acltype, aclname, direction)
                        if (id_tuple) not in acl_tuples:
                            acl_tuples[id_tuple] = []
                        acl_tuples[id_tuple].append(iface.name)

                    else:
                        # The rule is global (not specific to an interface).

                        #   0    1   2   3  4      5          6
                        # --- ---- --- --- -- ------ ----------
                        # acl ipv4 FOO priority 10 accept 1.1.1.1/32
                        aclname = line[2]
                        priority = int(line[4])

                        if acl_to_renumber and aclname == acl_to_renumber and acltype == acltype_to_renumber:
                            priority = prev_priority + 10
                            prev_priority = priority

                        if acltype == "ipv4":
                            if aclname not in ipv4_acl:
                                ipv4_acl[aclname] = AccessList(acltype, aclname)
                            acl = ipv4_acl[aclname]
                            acl.rules[priority] = AccessListRule("ipv4", aclname, priority, line[5:])

                        elif acltype == "ipv6":
                            if aclname not in ipv6_acl:
                                ipv6_acl[aclname] = AccessList(acltype, aclname)
                            acl = ipv6_acl[aclname]
                            acl.rules[priority] = AccessListRule("ipv6", aclname, priority, line[5:])

                        elif acltype == "mac":
                            if aclname not in mac_acl:
                                mac_acl[aclname] = AccessList(acltype, aclname)
                            acl = mac_acl[aclname]
                            acl.rules[priority] = AccessListRule("mac", aclname, priority, line[5:])

                        else:
                            raise Exception("Unsupported ACL type, {0}, in:\n{1}\n".format(acltype, ' '.join(line)))
    else:
        log.debug("{0} is not a regular file.".format(filename))

    if compress_to_swp_plus:
        swp_plus = 'swp+'
        all_swps = []

        # Parse /etc/network/interfaces and build a list of all swp interfaces
        etc_network_interfaces = "/etc/network/interfaces"
        if os.path.isfile(etc_network_interfaces):
            with open(etc_network_interfaces) as f:
                for line in f:
                    line = line.strip()

                    if line.startswith('iface swp') and '.' not in line:
                        ifname = line.split()[1]
                        all_swps.append(ifname)

        # Also consider the swp interfaces that are staged that have
        # not yet gone into /etc/network/interfaces
        if os.path.isdir("/run/nclu/ifupdown2/"):
            for ifname in os.listdir("/run/nclu/ifupdown2/"):
                if ifname.startswith("swp") and not ifname.endswith(".original"):
                    all_swps.append(ifname)

        all_swps = set(sort_for_humans(all_swps))

        # log.info("all_swps:\n%s\n" % pformat(all_swps))
        # log.info("acl_tuples:\n%s\n" % pformat(acl_tuples))

        for ((acltype, aclname, direction), ifnames) in acl_tuples.iteritems():
            ifnames = set(sort_for_humans(list(set(ifnames))))

            if ifnames >= all_swps:
                if swp_plus not in ifaces:
                    ifaces[swp_plus] = Interface(swp_plus)
                swp_plus_iface = ifaces[swp_plus]

                if aclname not in swp_plus_iface.acl[(acltype, direction)]:
                    swp_plus_iface.acl[(acltype, direction)].append(aclname)

                for ifname in ifnames:
                    iface = ifaces[ifname]
                    iface_acls = iface.acl[(acltype, direction)]

                    if aclname in iface_acls:
                        iface_acls.remove(aclname)

    # Currently each Interface object's acl dictionary has an aclname as the value.
    # Replace the aclname with the AccessList object for that aclname.
    for iface in ifaces.itervalues():
        for ((acltype, direction), aclnames) in iface.acl.iteritems():
            for (index, aclname) in enumerate(aclnames):
                iface.acl[(acltype, direction)][index] = get_acl_from_name(acltype, aclname, ipv4_acl, ipv6_acl, mac_acl)

    return (ifaces, ipv4_acl, ipv6_acl, mac_acl, policers)


def sort_ifaces_with_control_plane(ifnames):
    ifnames = sort_ifaces(ifnames)

    # move control-plane to the top of the list
    if 'control-plane' in ifnames or 'swp+' in ifnames:
        new_sorted_ifnames = []

        if 'control-plane' in ifnames:
            new_sorted_ifnames.append('control-plane')

        if 'swp+' in ifnames:
            new_sorted_ifnames.append('swp+')

        for ifname in ifnames:
            if ifname == 'control-plane' or ifname == 'swp+':
                continue
            new_sorted_ifnames.append(ifname)

        ifnames = new_sorted_ifnames

    return ifnames


def convert_to_ip_rules():
    """
    Parse /var/lib/cumulus/nclu/nclu_acl.conf and build /etc/cumulus/acl/policy.d/50_nclu_acl.rules
    """

    (ifaces, _, _, _, policers) = parse_nclu_conf(VAR_LIB_ACL_CONF, None, None, True)

    if ifaces:
        log.debug("Interfaces")
        for iface in ifaces.itervalues():
            log.debug("\n%s\n" % iface.dump())

    final_rules = []
    state = None

    for ifname in sort_ifaces_with_control_plane(ifaces.keys()):
        iface = ifaces[ifname]

        for ((acltype, direction), iface_acls) in iface.acl.iteritems():
            for acl in iface_acls:
                # write [iptables], [ebtables], etc to set the context
                if state != acl.acltype:
                    final_rules.append(acl.header)
                    state = acl.acltype

                # Add a comment so we can tell what in nclu_acl.conf caused us to add these rules
                final_rules.append("# %s: acl %s %s %s" % (ifname, acltype, acl.name, direction))
                for rule_string in acl.get_rule_strings(iface.name, direction, policers):
                    final_rules.append(rule_string)
                final_rules.append('')

    if final_rules:
        with open(RULES_50_NCLU, 'w') as f:
            for line in final_rules:
                f.write("%s\n" % line)
    else:
        if os.path.exists(RULES_50_NCLU):
            os.remove(RULES_50_NCLU)


def delete_access_list_references(ifaces, acl):
    for iface in ifaces.itervalues():
        for ((acltype, direction), iface_acls) in iface.acl.iteritems():
            for iface_acl in iface_acls:
                if iface_acl.name == acl.name:
                    iface.acl[(acltype, direction)].remove(iface_acl)


def save_run_acl_conf(ifaces, ipv4_acl, ipv6_acl, mac_acl, policers):

    with open(RUN_ACL_CONF, 'w') as f:

        if policers:
            # Write the policers.
            for policer_name in sort_for_humans(policers.keys()):
                f.write("policer-template {0} {1}\n".format(policer_name, policers[policer_name]))
            f.write('\n')

        # Write the ACLs.
        acls_to_write = []
        for aclname in sort_for_humans(ipv4_acl.keys()):
            acls_to_write.append(ipv4_acl[aclname])
        for aclname in sort_for_humans(ipv6_acl.keys()):
            acls_to_write.append(ipv6_acl[aclname])
        for aclname in sort_for_humans(mac_acl.keys()):
            acls_to_write.append(mac_acl[aclname])
        for acl in acls_to_write:
            for priority in sorted(acl.rules.keys()):
                rule = acl.rules[priority]
                f.write(rule.config_line + '\n')
            f.write('\n')

        # Write the interfaces.
        for ifname in sort_ifaces_with_control_plane(ifaces.keys()):
            iface = ifaces[ifname]
            print_iface = True

            for ((acltype, direction), iface_acls) in iface.acl.iteritems():
                for acl in iface_acls:
                    if print_iface:
                        if iface.name == "control-plane":
                            f.write("control-plane\n")
                        else:
                            f.write("iface {0}\n".format(iface.name))
                        print_iface = False
                    f.write("    acl {0} {1} {2}\n".format(acltype, acl.name, direction))
            f.write('\n')


def get_in_interfaces(target_aclname, ifaces):
    """ Return a list of interfaces that have aclname applied inbound. """

    results = []
    for (ifname, priorities) in ifaces.iteritems():
        for (priority, line) in priorities.iteritems():
            (_, direction, _, _, aclname) = line.split()

            if direction == 'inbound' and aclname == target_aclname:
                results.append(ifname)
                break

    return results


class ConfigWrapper(object):

    def __init__(self, show_linux_command, color_diffs):
        self.show_linux_command = show_linux_command
        self.color_diffs = color_diffs
        self.var_run_acl_conf_mod_time = None
        self.ifaces = OrderedDict()
        self.ipv4_acl = OrderedDict()
        self.ipv6_acl = OrderedDict()
        self.mac_acl = OrderedDict()
        self.policers = OrderedDict()

        if not os.path.exists(VAR_LIB_NCLU):
            mkdir_p(VAR_LIB_NCLU)

        if not os.path.exists(RUN_NCLU):
            mkdir_p(RUN_NCLU)

    def get_managed_files(self):
        return [VAR_LIB_ACL_CONF]

    def get_service_cmd_for_file(self, filename):
        cmds = []

        if filename == VAR_LIB_ACL_CONF:
            cmds.append((CL_ACLTOOL, '--install'))

        return cmds

    def abort_pending(self):
        self.var_run_acl_conf_mod_time = None

        if os.path.exists(RUN_NCLU):

            for filename in os.listdir(RUN_NCLU):
                full_filename = os.path.join(RUN_NCLU, filename)

                if os.path.isdir(full_filename):
                    shutil.rmtree(full_filename)
                else:
                    os.remove(full_filename)

    def del_all(self, cli):
        if os.path.isfile(VAR_LIB_ACL_CONF):
            with open(RUN_ACL_CONF, 'w') as f:
                f.write('\n')

    def commit_pending(self, verbose):
        """
        Persistent changes, and return a 3-tuple of (bool, str, [str]).  The boolean indicates
        if the commit succeeded.  The string includes information, including errors, for the user.
        The list contains the names of the files modified.
        """

        if not os.path.isfile(RUN_ACL_CONF) or files_match(VAR_LIB_ACL_CONF, RUN_ACL_CONF):
            # There are no changes to commit.
            return (True, '', [])

        # Create a copy of VAR_LIB_ACL_CONF in case something fails.
        shutil.copy(VAR_LIB_ACL_CONF, VAR_LIB_ACL_CONF_BACKUP)

        # Deploy the staged changes.
        shutil.copy(RUN_ACL_CONF, VAR_LIB_ACL_CONF)
        convert_to_ip_rules()

        problems = validate_syntax()
        if problems is not None:
            shutil.move(VAR_LIB_ACL_CONF_BACKUP, VAR_LIB_ACL_CONF)
            convert_to_ip_rules()
            return (False, problems, [])

        message = ''
        files_modified = []

        # The dry-run was okay.  Execute the real thing.
        try:
            check_output([CL_ACLTOOL, "--install"], stderr=STDOUT)
            commit_ok = True
            files_modified = [VAR_LIB_ACL_CONF]
        except CalledProcessError as e:
            commit_ok = False
            message = "\"cl-acltool --install\" failed:\n{0}\nReverting ACLs to the previous state.".format(e.output)

            # Revert to the previous state.
            shutil.move(VAR_LIB_ACL_CONF_BACKUP, VAR_LIB_ACL_CONF)
            convert_to_ip_rules()
            try:
                check_output([CL_ACLTOOL, "--install"], stderr=STDOUT)
            except CalledProcessError as e:
                message += "  Reverting failed too:\n{0}".format(e, e.output)

        if os.path.isfile(VAR_LIB_ACL_CONF_BACKUP):
            os.remove(VAR_LIB_ACL_CONF_BACKUP)

        if commit_ok:
            os.remove(RUN_ACL_CONF)

        return (commit_ok, message, files_modified)

    def get_pending(self):
        """
        Return the pending diff as a string.  If there are no changes, return the empty string.
        """

        if not os.path.isfile(RUN_ACL_CONF):
            return ''

        if not os.path.exists(VAR_LIB_ACL_CONF):
            with open(VAR_LIB_ACL_CONF, 'w') as f:
                f.write('')

        problems = validate_syntax()
        return make_pending_diff(VAR_LIB_ACL_CONF, RUN_ACL_CONF, self.color_diffs) if (problems is None) else problems

    def show_config_files(self, user_may_edit):
        # TODO - This method doesn't need user_may_edit.  This will be resolved via converstion to a plug-in.

        reply = ''

        if os.path.isfile(VAR_LIB_ACL_CONF) and os.path.getsize(VAR_LIB_ACL_CONF) > 0:
            reply += VAR_LIB_ACL_CONF + '\n'
            reply += '=' * len(VAR_LIB_ACL_CONF) + '\n'

            with open(VAR_LIB_ACL_CONF) as f:
                reply += f.read()

        return reply

    def show_config_summary(self, user_may_edit, summary):

        if not os.path.isfile(VAR_LIB_ACL_CONF):
            # TODO - This is "do_something_maybe".
            return

        for add_interfaces in (False, True):
            with open(VAR_LIB_ACL_CONF) as f:
                for line in f:
                    line = line.strip()

                    if not line:
                        continue

                    if line == 'control-plane':
                        if not add_interfaces:
                            continue

                        ifname = 'control-plane'

                        if ifname not in summary:
                            summary[ifname] = OrderedDict()

                        if 'COMMAND_LIST' not in summary[ifname]:
                            summary[ifname]['COMMAND_LIST'] = []

                    elif line.startswith('iface'):
                        if not add_interfaces:
                            continue

                        ifname = "INTERFACE:%s" % line.split()[1]

                        if ifname not in summary:
                            summary[ifname] = OrderedDict()

                        if 'COMMAND_LIST' not in summary[ifname]:
                            summary[ifname]['COMMAND_LIST'] = []

                    elif line.endswith('inbound') or line.endswith('outbound'):
                        if not add_interfaces:
                            continue

                        summary[ifname]['COMMAND_LIST'].append(line)

                    else:
                        if not add_interfaces:
                            summary[line] = OrderedDict()

    def show_config_commands(self, user_may_edit, ifupdown2_wrapper):
        supported = []
        not_supported = []

        if os.path.isfile(VAR_LIB_ACL_CONF):
            iface = None

            for add_interfaces in (False, True):
                with open(VAR_LIB_ACL_CONF) as f:
                    for line in f:
                        line = line.strip()

                        if not line:
                            continue

                        if line == 'control-plane':
                            if not add_interfaces:
                                continue

                            ifname = 'control-plane'

                        elif line.startswith('iface'):
                            if not add_interfaces:
                                continue

                            ifname = line.split()[1]
                            iface = EtcNetworkInterface(ifname, ifupdown2_wrapper.ifquery_all)

                            # If this is a bond we use "bond IFNAME" instead of "interface IFNAME"
                            if iface.is_bond():
                                ifname = 'bond %s' % ifname
                            elif iface.is_bridge():
                                ifname = 'bridge %s' % ifname
                            elif iface.is_loopback():
                                ifname = 'loopback %s' % ifname
                            elif iface.is_vlan_interface():
                                ifname = 'vlan %s' % ifname
                            elif iface.is_vxlan():
                                ifname = 'vxlan %s' % ifname
                            elif iface.is_vrf():
                                ifname = 'vrf %s' % ifname
                            else:
                                ifname = 'interface %s' % ifname

                        elif line.endswith('inbound') or line.endswith('outbound'):
                            if not add_interfaces:
                                continue

                            supported.append("net add %s %s" % (ifname, line))
                        else:
                            if not add_interfaces:
                                supported.append("net add %s" % line)

        return (supported, not_supported)

    def del_interfaces(self, ifname):

        assert isinstance(ifname, (str, unicode)) and ifname, "This method accepts an interface name or glob."

        command_ok = True

        ifnames_to_del = ifname_expand_glob(ifname)  # A list
        assert ifnames_to_del, "This list should not be empty."

        if os.path.isfile(VAR_LIB_ACL_CONF) and not os.path.isfile(RUN_ACL_CONF):
            shutil.copy(VAR_LIB_ACL_CONF, RUN_ACL_CONF)

        (ifaces, ipv4_acl, ipv6_acl, mac_acl, policers) = parse_nclu_conf(RUN_ACL_CONF, None, None, False)

        for ifname_to_del in ifnames_to_del:
            if ifname_to_del in ifaces:
                iface = ifaces[ifname_to_del]
                iface.reset()

            # Delete any sub-interfaces.
            for (acl_ifname, acl_iface) in ifaces.items():
                if '.' in acl_ifname:
                    (base, extension) = acl_ifname.split('.')
                    if base == ifname_to_del:
                        acl_iface.reset()

        save_run_acl_conf(ifaces, ipv4_acl, ipv6_acl, mac_acl, policers)

        return command_ok

    def renumber_access_list(self, cli):
        args = cli.args
        acl_type = None
        acl_to_renumber = None

        if args.get("ipv4") is not None:
            acl_type = "ipv4"
            acl_to_renumber = args.get("<acl-ipv4>")
        elif args.get("ipv6") is not None:
            acl_type = "ipv6"
            acl_to_renumber = args.get("<acl-ipv6>")
        elif args.get("mac") is not None:
            acl_type = "mac"
            acl_to_renumber = args.get("<acl-mac>")
        else:
            log.info("Could not determine the ACL type for %s." % pformat(cli.argv_expanded))

        if acl_type is not None and acl_to_renumber is not None:
            if os.path.isfile(VAR_LIB_ACL_CONF) and not os.path.isfile(RUN_ACL_CONF):
                shutil.copy(VAR_LIB_ACL_CONF, RUN_ACL_CONF)

            (self.ifaces, self.ipv4_acl, self.ipv6_acl, self.mac_acl, self.policers) = parse_nclu_conf(RUN_ACL_CONF, acl_type, acl_to_renumber, False)
            save_run_acl_conf(self.ifaces, self.ipv4_acl, self.ipv6_acl, self.mac_acl, self.policers)

    def edit_access_list(self, cli):
        args = cli.args
        command_ok = True

        if os.path.isfile(VAR_LIB_ACL_CONF) and not os.path.isfile(RUN_ACL_CONF):
            shutil.copy(VAR_LIB_ACL_CONF, RUN_ACL_CONF)

        # Avoid calling parse_nclu_conf() if RUN_ACL_CONF has not been
        # modified. We do this to save some CPU cycles in case the user is
        # adding hundreds of ACL lines.
        if (self.var_run_acl_conf_mod_time is None or
            self.var_run_acl_conf_mod_time != os.path.getmtime(RUN_ACL_CONF)):
            (self.ifaces, self.ipv4_acl, self.ipv6_acl, self.mac_acl, self.policers) =\
                parse_nclu_conf(RUN_ACL_CONF, None, None, False)

        # Apply changes
        #
        # If inbound/outbound are set we are tweaking an interface
        if args.get('inbound') or args.get('outbound'):

            if args.get('control-plane'):
                ifnames = ['control-plane', ]
            elif args.get('vlan') and args.get('<number-range-list>'):
                ifnames = []
                vlan_numbers = glob_to_numbers(str(args.get('<number-range-list>')))

                for number in vlan_numbers:
                    ifnames.append("vlan%d" % number)
            else:
                ifname = args.get('<interface>')

                if ifname_is_glob(ifname):
                    ifnames = ifname_expand_glob(ifname)
                else:
                    ifnames = [ifname, ]

            if args.get('ipv4'):
                acltype = 'ipv4'
                aclname = args.get('<acl-ipv4>')
            elif args.get('ipv6'):
                acltype = 'ipv6'
                aclname = args.get('<acl-ipv6>')
            elif args.get('mac'):
                acltype = 'mac'
                aclname = args.get('<acl-mac>')
            else:
                raise RuntimeError("Could not determine the ACL type.")

            if args.get('inbound'):
                direction = 'inbound'
            elif args.get('outbound'):
                direction = 'outbound'
            else:
                raise RuntimeError("Could not determine the ACL direction")

            if args.get('add'):
                for ifname in ifnames:
                    if ifname not in self.ifaces:
                        self.ifaces[ifname] = Interface(ifname)
                    iface = self.ifaces[ifname]
                    iface_acls = iface.acl.get((acltype, direction))
                    acl = get_acl_from_name(acltype, aclname, self.ipv4_acl, self.ipv6_acl, self.mac_acl)
                    inbound_interface = acl.sets_inbound_interface()
                    outbound_interface = acl.sets_outbound_interface()
                    found_acl = False

                    for iface_acl in iface_acls:
                        if iface_acl.name == aclname:
                            found_acl = True

                    if found_acl:
                        print "The \"{0}\" configuration already has \"acl {1} {2} {3}\".".format(ifname, acltype, aclname, direction)
                        command_ok = True
                    else:
                        if not args.get('control-plane') and direction == 'outbound' and outbound_interface:
                            print "'acl %s %s' already defines an outbound-interface, this ACL cannot be applied outbound to %s" % (acltype, aclname, ifname)
                            command_ok = False
                        elif not args.get('control-plane') and direction == 'inbound' and inbound_interface:
                            print "'acl %s %s' already defines an inbound-interface, this ACL cannot be applied inbound to %s" % (acltype, aclname, ifname)
                            command_ok = False
                        else:
                            iface.acl[(acltype, direction)].append(acl)

            elif args.get('del'):
                for ifname in ifnames:
                    if ifname not in self.ifaces:
                        print "'%s' is not in the acl configuration" % ifname
                        command_ok = False
                        continue
                    iface = self.ifaces[ifname]
                    iface_acls = iface.acl.get((acltype, direction))
                    found_acl = False

                    for iface_acl in iface_acls:
                        if iface_acl.name == aclname:
                            found_acl = True
                            iface_acls.remove(iface_acl)

                    if not found_acl:
                        print "'%s' configuration does not have 'acl %s %s %s'" % (ifname, acltype, aclname, direction)
                        command_ok = False

            else:
                raise RuntimeError("Could not determine ACL add/del.")

        # We are editing a policer
        elif args.get('policer-template'):
            policer_name = args.get('<text>')

            if not policer_name:
                policer_name = args.get('<policer-name>')

            policer_rule = ' '.join(map(str, cli.argv_expanded[4:]))

            if args.get('add'):
                add_policer = True

                if policer_name in self.policers:
                    if policer_rule == self.policers[policer_name]:
                        print "Policer {0} already has these settings.".format(policer_name)
                        add_policer = False
                        command_ok = True

                if add_policer:
                    self.policers[policer_name] = policer_rule

            elif args.get('del'):
                del_policer = True

                if policer_name in self.policers:
                    if policer_rule and policer_rule != self.policers[policer_name]:
                        print "policer %s does not have '%s', it has '%s'" % (policer_name, policer_rule, self.policers[policer_name])
                        del_policer = False
                        command_ok = False
                else:
                    print "policer %s does not exists" % policer_name
                    del_policer = False

                if del_policer:
                    del self.policers[policer_name]

                    # Delete any rule that uses this policer
                    for acl in self.ipv4_acl.values():
                        priority_to_delete = []
                        for (priority, rule) in acl.rules.iteritems():
                            if rule.action == "police %s" % policer_name:
                                priority_to_delete.append(priority)

                        for priority in priority_to_delete:
                            del acl.rules[priority]

                        # If there are no rules left delete all references to this ACL
                        if not acl.rules:
                            delete_access_list_references(self.ifaces, acl)

        # If not we are tweaking the acl itself
        else:
            acltype = cli.argv_expanded[3]
            priority = args.get('<number>')
            acl = None

            if acltype == 'ipv4':
                aclname = args.get('<acl-ipv4>')
            elif acltype == 'ipv6':
                aclname = args.get('<acl-ipv6>')
            elif acltype == 'mac':
                aclname = args.get('<acl-mac>')

            if aclname is None:
                aclname = args.get('<text>')

            # create the acl if needed
            if acltype == 'ipv4':

                if aclname in self.ipv4_acl:
                    acl = self.ipv4_acl[aclname]
                else:
                    if args.get('add'):
                        self.ipv4_acl[aclname] = AccessList(acltype, aclname)
                        acl = self.ipv4_acl[aclname]
                    elif args.get('del'):
                        print "acl '%s' does not exists" % aclname
                        command_ok = False

            elif acltype == 'ipv6':
                if aclname in self.ipv6_acl:
                    acl = self.ipv6_acl[aclname]
                else:
                    if args.get('add'):
                        self.ipv6_acl[aclname] = AccessList(acltype, aclname)
                        acl = self.ipv6_acl[aclname]
                    elif args.get('del'):
                        print "acl '%s' does not exists" % aclname
                        command_ok = False

            elif acltype == 'mac':
                if aclname in self.mac_acl:
                    acl = self.mac_acl[aclname]
                else:
                    if args.get('add'):
                        self.mac_acl[aclname] = AccessList(acltype, aclname)
                        acl = self.mac_acl[aclname]
                    elif args.get('del'):
                        print "acl '%s' does not exists" % aclname
                        command_ok = False

            else:
                raise RuntimeError("Could not determine the ACL type for \"%s\"." % pformat(cli.argv_expanded))

            # Auto generate the priority number if it wasn't specified
            if args.get('add') and priority is None:
                priorities = list(reversed(sorted(acl.rules.keys())))

                if priorities:
                    priority = priorities[0] + 10
                else:
                    priority = 10
                argv_start = 5
            else:
                argv_start = 7

            if args.get('add'):
                new_rule = AccessListRule(acltype, aclname, priority, cli.argv_expanded[argv_start:])
                add_rule = True

                if priority in acl.rules:
                    current_rule = acl.rules[priority]

                    if current_rule.config_line == new_rule.config_line:
                        print "acl '%s' already has '%s'" % (aclname, new_rule.config_line)
                        add_rule = False
                        command_ok = True

                # If this rule specifies an inbound-interface we need to make sure this
                # rule isn't applied inbound somewhere. Same logic applies for
                # specifying an outbound-interface and checking to see if the interface
                # is applied outbound somewhere.
                if new_rule.get_inbound_interface():
                    for iface in self.ifaces.itervalues():
                        for iface_acl in iface.acl[(acltype, 'inbound')]:
                            if iface_acl == acl:
                                print "'acl %s %s' is already applied inbound to %s, this ACL cannot specify an inbound-interface" % (acltype, aclname, iface.name)
                                add_rule = False
                                command_ok = False
                                break

                        if not add_rule:
                            break

                elif new_rule.get_outbound_interface():
                    for iface in self.ifaces.itervalues():
                        for iface_acl in iface.acl[(acltype, 'outbound')]:
                            if iface_acl == acl:
                                print "'acl %s %s' is already applied outbound to %s, this ACL cannot specify an outbound-interface" % (acltype, aclname, iface.name)
                                add_rule = False
                                command_ok = False
                                break

                        if not add_rule:
                            break

                if add_rule:
                    acl.rules[priority] = new_rule

            elif args.get('del'):

                # If acl is None we already printed a "does not exists" message
                if acl:

                    priority_range = args.get('<number-range-list>')

                    # Delete all rules
                    if priority is None and priority_range is None:
                        acl.rules = {}

                    # Delete specific rule(s)
                    else:
                        if priority_range:
                            priority_to_delete = glob_to_numbers(str(priority_range))
                        else:
                            priority_to_delete = [priority, ]

                        if len(priority_to_delete) > 1:
                            print_does_not_have = False
                        else:
                            print_does_not_have = True

                        for priority in priority_to_delete:
                            if priority in acl.rules:
                                # don't bother matching the contents of the rule, just
                                # delete it based on priority number
                                del acl.rules[priority]
                            else:
                                if print_does_not_have:
                                    print "acl '%s' does not have priority %s" % (aclname, priority)
                                    command_ok = False

                    # If there are no rules left delete all references to this ACL
                    if not acl.rules:
                        delete_access_list_references(self.ifaces, acl)

            else:
                raise RuntimeError("Could not determine ACL add/del.")

        save_run_acl_conf(self.ifaces, self.ipv4_acl, self.ipv6_acl, self.mac_acl, self.policers)
        self.var_run_acl_conf_mod_time = os.path.getmtime(RUN_ACL_CONF)

        return command_ok

    def eval_command_line_args(self, cli):
        """
        NetworkDocopt will populate the self.args dictionary based on the command entered by the user.
        """
        if cli.args.get("renumber") is not None:
            self.renumber_access_list(cli)
            return True
        elif cli.args.get("add") is not None or cli.args.get("del") is not None:
            return self.edit_access_list(cli)

        # This is a programming error.
        raise RuntimeError("NCLU could not determine what to do.")


def get_config_lines(target):
    final = []

    for filename in (VAR_LIB_ACL_CONF, RUN_ACL_CONF):
        if os.path.isfile(filename):
            with open(filename) as f:
                for line in f:
                    line = line.strip()

                    if line.startswith(target):
                        final.append(line)

    return final


def get_aclnames(acl_type):
    final = []

    for line in get_config_lines('acl %s' % acl_type):
        # acl ipv4 FOO
        final.append(line.split()[2])

    final = sort_for_humans(list(set(final)))
    return final


def match_acl(argv_word, use_fuzzy, tab_completing, acl_type):
    if use_fuzzy:
        if ' ' not in argv_word:
            return True
    else:
        if argv_word in get_aclnames(acl_type):
            return True

        if tab_completing:
            for aclname in get_aclnames(acl_type):
                if aclname.startswith(argv_word):
                    return True
    return False


def match_acl_ipv4(argv_word, use_fuzzy, tab_completing):
    return match_acl(argv_word, use_fuzzy, tab_completing, 'ipv4')


def match_acl_ipv6(argv_word, use_fuzzy, tab_completing):
    return match_acl(argv_word, use_fuzzy, tab_completing, 'ipv6')


def match_acl_mac(argv_word, use_fuzzy, tab_completing):
    return match_acl(argv_word, use_fuzzy, tab_completing, 'mac')


def tab_acl_ipv4(args, ended_with_space, last_argv):
    final = []

    for x in get_aclnames('ipv4'):
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'access-list'))

    if not final:
        final.append(('<acl-ipv4>', 'access-list'))

    return final


def tab_acl_ipv6(args, ended_with_space, last_argv):
    final = []

    for x in get_aclnames('ipv6'):
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'access-list'))

    if not final:
        final.append(('<acl-ipv6>', 'access-list'))

    return final


def tab_acl_mac(args, ended_with_space, last_argv):
    final = []

    for x in get_aclnames('mac'):
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'access-list'))

    if not final:
        final.append(('<acl-mac>', 'access-list'))

    return final


def get_policer_names():
    final = []

    for line in get_config_lines('policer-template '):
        # policer-template GOLD mode packet rate 4000 burst 8000
        final.append(line.split()[1])

    final = sort_for_humans(list(set(final)))
    return final


def match_policer_name(argv_word, use_fuzzy, tab_completing):
    """
    <policer-name>
    """
    if use_fuzzy:
        if ' ' not in argv_word:
            return True
    else:
        if argv_word in get_policer_names():
            return True

        if tab_completing:
            for policer_name in get_policer_names():
                if policer_name.startswith(argv_word):
                    return True
    return False


def tab_policer_name(args, ended_with_space, last_argv):
    final = []

    for x in get_policer_names():
        if ended_with_space or x.startswith(last_argv):
            final.append((x, 'policer template'))

    if not final:
        final.append(('<policer-name>', 'policer template'))

    return final


def validate_syntax():
    """
    Return None if the pending changes to /etc/network/interfaces are syntactically valid.
    Otherwise, return a string describing the problems.
    """

    command = [CL_ACLTOOL, "--install", "--dry-run"]
    try:
        check_output(command, stderr=STDOUT)
    except CalledProcessError as e:
        # Return a description of the problems.
        return "{0} failed:\n{1}".format(' '.join(command), e.output)

    return None


# This is for testing only.
# TODO - Move this to a separate unit test file, and remove the bang from this file.
if __name__ == '__main__':

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)7s %(filename)12s: %(message)s")
    log = logging.getLogger(__name__)

    # Color the errors and warnings in red
    logging.addLevelName(logging.ERROR, "\033[91m  %s\033[0m" % logging.getLevelName(logging.ERROR))
    logging.addLevelName(logging.WARNING, "\033[91m%s\033[0m" % logging.getLevelName(logging.WARNING))

    if not os.path.isfile(RUN_ACL_CONF):
        if os.path.isfile(VAR_LIB_ACL_CONF):
            shutil.copy(VAR_LIB_ACL_CONF, RUN_ACL_CONF)

    convert_to_ip_rules()
