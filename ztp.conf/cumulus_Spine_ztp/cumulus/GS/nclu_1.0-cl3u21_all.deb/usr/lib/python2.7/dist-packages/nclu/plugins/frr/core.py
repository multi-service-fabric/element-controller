from collections import OrderedDict
from nclu import WORKING_DIRECTORY
import os
import re

USR_LIB_FRR_PIMD = "/usr/lib/frr/pimd"
FRR_RELOAD_PY = "/usr/lib/frr/frr-reload.py"
show_linux_command = False


if os.path.exists("/run/frr/.qcompat"):
    SERVICE_NAME = "quagga"
    SCRATCHPAD_DIRECTORY = os.path.join(WORKING_DIRECTORY, "quagga")
    ETC_FRR = "/etc/quagga/"
    ETC_FRR_DAEMONS = "/etc/quagga/daemons"
    ETC_FRR_CONF = "/etc/quagga/Quagga.conf"

else:
    SERVICE_NAME = "frr"
    SCRATCHPAD_DIRECTORY = os.path.join(WORKING_DIRECTORY, "frr")
    ETC_FRR = "/etc/frr/"
    ETC_FRR_DAEMONS = "/etc/frr/daemons"
    ETC_FRR_CONF = "/etc/frr/frr.conf"

ETC_FRR_DAEMONS_SCRATCHPAD = os.path.join(SCRATCHPAD_DIRECTORY, "daemons.scratchpad")
ETC_FRR_DAEMONS_BACKUP = ETC_FRR_DAEMONS_SCRATCHPAD + ".bak"
ETC_FRR_DAEMONS_BASELINE = ETC_FRR_DAEMONS_SCRATCHPAD + ".baseline"

ETC_FRR_CONF_SCRATCHPAD = SCRATCHPAD_DIRECTORY + "/frr.conf.scratchpad"
ETC_FRR_CONF_BACKUP = ETC_FRR_CONF_SCRATCHPAD + ".bak"
ETC_FRR_CONF_BASELINE = ETC_FRR_CONF_SCRATCHPAD + ".baseline"


def get_daemons():
    """
    Return an OrderedDict from the uncommented "<daemon>=<yes|no>" lines
    in ETC_FRR_DAEMONS_SCRATCHPAD or ETC_FRR_DAEMONS
    """
    daemons = {}

    if os.path.isfile(ETC_FRR_DAEMONS_SCRATCHPAD):
        filename = ETC_FRR_DAEMONS_SCRATCHPAD
    elif os.path.isfile(ETC_FRR_DAEMONS):
        filename = ETC_FRR_DAEMONS
    else:
        filename = None

    if filename is not None:
        with open(filename) as f:
            pending_daemons_text = f.read()
        daemon_settings = re.findall(r"""^\s*(\w+)\s*=\s*(yes|no)\s*$""", pending_daemons_text, re.I | re.M)
        daemons = OrderedDict(daemon_settings)

    return daemons


def frr_reload_exception_to_string(filename, e):
    if hasattr(e, 'output'):
        return "Failed to load {0} due to {1}\n\n{2} output\n=======================\n{3}\n".format(filename, e, FRR_RELOAD_PY, e.output)
    return "Failed to load {0} due to {1}".format(filename, e)
