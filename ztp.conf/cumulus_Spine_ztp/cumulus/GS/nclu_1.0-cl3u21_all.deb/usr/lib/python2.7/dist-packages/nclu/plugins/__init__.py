"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""


from nclu import files_match, get_file_contents, make_pending_diff, WORKING_DIRECTORIES_PERMISSIONS
from shutil import copy, copyfile
from subprocess import CalledProcessError, check_output, STDOUT
import os

# The modular paradigm should be used for these components.
MODULARIZED_COMPONENTS = frozenset([
    "dhcp",
    "dns",
    "frr",
    "ntp",
    "ports",
    "ptp",
    "run",
    "snmp",
    "syslog",
    "transponders",
])

# Some plug-ins (and wrappers) contain sensitive information, such as passwords, in their managed files.
# show_config_summary/files/commands will be called with an extra parameter for modules in this tuple.
PERMISSIONS_SENSITIVE_COMPONENTS = frozenset([
    "dot1x",
    "frr",
    "snmp",
])

# These plug-ins have non-static restart commands depending on the specific changes.
# Their get_restart_commands function will receive an additional parameter.
DYNAMIC_RESTART = frozenset([
    "dns",
    "frr",
])


def is_modular(component):
    """
    Are commands involving the given component executable using the modular paradigm?  Return a boolean.
    Components are functional areas or protocols.  For example: interfaces (ifupdown2), dhcp, dns, etc.
    """

    assert isinstance(component, str)
    return component in MODULARIZED_COMPONENTS


def execute_modular(component, net_daemon):
    """
    Execute the command, and return a two-tuple.  The first tuple value
    is a boolean indicating if the command succeeded.  The second is a
    dictionary with an "output" field and some, possibly empty, combination
    of the others:

        {
            "output"  : A string (possibly JSON),
            "info"    : [string],
            "warning" : [string],
            "error"   : [string],
        }

    component - A string; i.e. dns, ifupdown2, syslog, etc.
    net_daemon - An instance of NetDaemon
    """

    assert len(net_daemon.wrappers) > 0, "If the wrappers paradigm has been removed, edit this function."
    assert isinstance(component, str)

    m = __import__("nclu.plugins." + component, fromlist=["execute_command"])
    outcome, messages = m.execute_command(net_daemon)
    assert isinstance(outcome, bool)
    assert isinstance(messages, dict)
    assert "output" in messages
    assert not (outcome and "error" in messages), "A command that generates error messages shouldn't be considered a success."
    assert "info" not in messages or isinstance(messages["info"], list)
    assert "warning" not in messages or isinstance(messages["warning"], list)
    assert "error" not in messages or isinstance(messages["error"], list)

    return (outcome, messages)


def format_messages(messages, use_color):
    """
    Given a dictionary, as described in execute_modular, return a string.
    """

    assert isinstance(messages, dict)
    assert isinstance(use_color, bool)

    result = messages["output"]

    if "info" in messages:
        assert isinstance(messages["info"], list)
        if result and not result.endswith('\n'):
            result += '\n'
        # The info text should not have any special color.
        result += '\n'.join(messages["info"])

    if "warning" in messages:
        assert isinstance(messages["warning"], list)
        if result and not result.endswith('\n'):
            result += '\n'

        # The warning text should be yellow.
        result += ("\033[0;33m{0}\033[0m" if use_color else "{0}").format('\n'.join(messages["warning"]))

    if "error" in messages:
        assert isinstance(messages["error"], list)
        if result and not result.endswith('\n'):
            result += '\n'

        # The error text should be red.
        result += ("\033[0;31m{0}\033[0m" if use_color else "{0}").format('\n'.join(messages["error"]))

    return result


def merge_messages(m1, m2):
    """
    Given two dictionaries as described in execute_modular, append the contents of m2 to m1.
    """

    if m2["output"]:
        m1["output"] += '\n' + m2["output"]

    for field in ("info", "warning", "error"):
        if field in m2:
            if field in m1:
                m1[field].extend(m2[field])
            else:
                m1[field] = m2[field]


def make_scratchpads(configuration_files):
    """
    Given an iterable of 3-tuples or lists like (configuration file, scratchpad file, default text), create
    configuration file scratchpads.  If the given configuration file exists, create the scratchpad by copying
    the existing configuration.  If the given configuration file does not exist, create a scratchpad file
    containing the given default text, if any, or an empty file.

    The given scratchpad files should not already exist.
    """

    for config, scratch, default_text in configuration_files:
        assert isinstance(config, str) and isinstance(scratch, str) and isinstance(default_text, str)
        assert not os.path.isfile(scratch), "{0} does not need to be created.".format(scratch)

        if not os.path.isdir(os.path.dirname(scratch)):
            # Create the scratchpad directory.
            os.makedirs(os.path.dirname(scratch), mode=WORKING_DIRECTORIES_PERMISSIONS)

        # Create the scratchpad file.
        if os.path.isfile(config):
            # Copy the existing configuration file to the scratchpad directory.
            copyfile(config, scratch)
        else:
            # Create a new scratchpad file.
            with open(scratch, 'w') as f:
                if default_text:
                    f.write(default_text)


def persist_configurations(pending_files, make_backup=True):
    """
    Copy pending scratchpad files over the existing configuration after making backups of
    the existing configurations.  Unlike most functions in this code base, this function
    intentionally is a "do something maybe."  If a given scratchpad file doesn't exist,
    it is ignored.

    Note that backups are only created if the current and prospective configurations
    have differences.

    pending_files - An iterable of 2-tuples of (str, str).  The first value is a
        configuration/destination file path; the second, the scratchpad/source file path.
    """

    # Copy scratchpad files over the real configuration files.
    for config, scratch in pending_files:
        if os.path.isfile(scratch) and not files_match(config, scratch):
            if make_backup and os.path.isfile(config):
                copy(config, "{0}/{1}.bak".format(os.path.dirname(scratch), os.path.basename(config)))
            copy(scratch, config)


def run_commands(commands, verbose):
    """
    Run the given commands, and return a 3-tuple of (bool, int, dict).  Use this function,
    for example, to execute a batch of commands after committing changes or for a rollback.

    The boolean is True if there are no problems during the execution; otherwise, False.  If a
    command fails, do not run the subsequent commands.  The integer is the number of commands
    successfully executed, and the dict follows the format discussed in execute_modular.

    commands - An iterable of iterables of strings; ex. (("/bin/systemctl", "status", "netd"), ["net", "pending"])
    verbose - A boolean; Display the executed commands and their output?
    """

    assert isinstance(commands, (list, tuple, set, frozenset))
    messages = {"output": ''}

    for index, command in enumerate(commands):
        assert isinstance(command, (list, tuple, set, frozenset))

        try:
            output = check_output(command, stderr=STDOUT)

            if verbose:
                if output:
                    messages["output"] += "{0}\n---------\n{1}\n\n".format(' '.join(command), output)
                else:
                    messages["output"] += "Ran {0}.\n\n".format(' '.join(command))
        except CalledProcessError as e:
            messages["error"] = ["\"{0}\" failed: {1}".format(' '.join(command), e)]
            return (False, index, messages)

    return (True, len(commands), messages)


def remove_scratch_files_and_backups(scratch_files):
    """
    Remove the given scratchpad files and their associated backups, if any.  Unlike most functions
    in this code base, this function intentionally is a "do something maybe."  If a given scratchpad
    file doesn't exist, it is ignored.

    scratch_files - An iterable of strings; the scratchpad file paths.
    """

    assert isinstance(scratch_files, (list, tuple, set, frozenset)), "The input should not be a string."

    for scratch in scratch_files:
        if os.path.isfile(scratch):
            os.remove(scratch)
        if os.path.isfile(scratch + ".bak"):
            os.remove(scratch + ".bak")

        # TODO - This is particular to frr and should probably be handled in that plug-in.
        if os.path.isfile(scratch + ".baseline"):
            os.remove(scratch + ".baseline")


def get_pending_diffs(pending_files, use_colors):
    """
    Return diff text for the given configuration and scratchpad file pairs.  This might be an
    empty string.

    pending_files - An iterable of 2-tuples of (str, str).  The first value is a
        configuration file path; the second, the scratchpad path.
    """

    the_diff = ''

    for config, scratch in pending_files:
        if os.path.isfile(scratch):
            the_diff += make_pending_diff(config, scratch, use_colors)

    return the_diff


def get_config_files_helper(config_files):
    """
    Return a string with the content of all existing, non-empty configuration files managed with this plug-in.
    """

    assert isinstance(config_files, list), "This should be a list of strings."

    reply = ''

    for config_file in config_files:
        if os.path.isfile(config_file) and os.path.getsize(config_file) > 0:
            reply += "{0}\n{1}\n{2}\n\n".format(config_file, '=' * len(config_file), get_file_contents(config_file))

    return reply
