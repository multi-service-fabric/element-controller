#!/usr/bin/env python

"""
Copyright (C) 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement
available at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt


This file contains code modified from the deprecated "netshow" package.
It exists to remove NCLU's dependency on netshow.
"""

from collections import OrderedDict
from datetime import datetime, timedelta
from json import dumps, loads
from nclu import ifname_expand_glob, nclu_check_output, tabulate_remove_unicode, decode_dict, numbers_to_glob
from netshow2_BroadcomAsic import BroadcomAsic
from network_docopt import sort_ifaces
from network_docopt.match import ifname_is_glob
from os import listdir, readlink
from subprocess import CalledProcessError, check_output, STDOUT
import tabulate
from textwrap import wrap
import json
import logging
import os.path
import re
import glob
import xml.etree.ElementTree as ElementTree


log = logging.getLogger("netd")

# The Linux kernel populates this directory.
SYS_PATH_ROOT = "/sys/class/net"

SUMMARY_COLUMN_WIDTH = 50

# "tabulate" pads the "----" header separator with two extra hyphens. For
# "net show interface", we are pressed to fit everything in 80 characters
# or less.  Tell "tabulate" to not pad the separators.
tabulate.MIN_PADDING = 0


def exec_lldpctl(interface=None):
    """
    Execute lldpctl.  Return the output from LLDP, as an instance of
    xml.etree.ElementTree.Element, or None, if an error occurred.

    interface - A string, or None; an interface name

    If no interface is specified, lldpctl returns information for all
    interfaces.
    """

    assert interface is None or isinstance(interface, str)

    # lldpctl can output json, but this json is not formatted in a manner that is convenient
    # for how we want to display the output.  Stick with xml.
    cmd = "/usr/sbin/lldpctl -f xml"

    if interface is not None:
        # Append the interface name to the lldp command.
        cmd += ' ' + interface

    outcome, lldp_output = nclu_check_output(cmd.split(), "lldpd")
    if not outcome or not lldp_output:
        return None

    try:
        lldp_tree = ElementTree.fromstring(lldp_output)
    except ElementTree.ParseError as e:
        log.error("Could not parse the XML output by lldpctl.\ninterface={0}\n{1}".format(interface, e))
        return None

    return lldp_tree


def get_asic_info():
    """
    Return asic information like this::

        {
            'name': 'broadcom',
            'swp1s0': {
                    'asicname': 'xe0.0',
                    'initial_speed': 1000,
                },
            'swp1s1': {
                    'asicname': 'xe0.1',
                    'initial_speed': 1000,
                },
            ...
        }

    If the asic cannot be detected, return an empty dictionary.
    """

    try:
        lspci_output = check_output('lspci -nn'.split())
    except CalledProcessError:
        log.error("The asic cannot be detected.")
        return {}

    if re.search(r"""(Ethernet|Network)\s+controller.*Broadcom""", lspci_output, re.IGNORECASE) is not None:
        return BroadcomAsic().parse_speed_and_name_info()

    # The asic cannot be detected, or it is not Broadcom.
    # TODO - Support other manufacturers?
    return {}


def get_counters_info(interfaces=None):
    """
    Return a dictionary of the output from 'cl-netstat --json' for 'interfaces'

    interfaces - A non-empty list of interface names (strings), or None
    """

    assert interfaces is None or (isinstance(interfaces, list) and interfaces and isinstance(interfaces[0], str))

    try:
        cl_netstat_output = check_output(['/usr/cumulus/bin/cl-netstat', '--json'])
        counters = json.loads(cl_netstat_output, object_hook=decode_dict)
    except CalledProcessError as e:
        log.exception(e)
        return {}

    if interfaces is not None:

        # We cannot loop over the dict keys and delete keys as we go, build a
        # list of keys that need to be deleted
        ifnames_to_delete = []

        for ifname in counters:
            if ifname not in interfaces:
                ifnames_to_delete.append(ifname)

        for ifname in ifnames_to_delete:
            del counters[ifname]

    return counters


def get_ip_addresses():
    """
    Return a dictionary of all non-link-local IP addresses configured on the system,
    as output by the "ip" command.
    """

    ip_cmd = '/sbin/ip -o addr show'
    try:
        ip_output = check_output(ip_cmd.split())
    except CalledProcessError:
        return {}

    #                   name   ip_version     ip+CIDR
    ip_re = r"""^\d+:\s+(\S+)\s+(inet6?)\s+([\d:/a-f.]+)\s+.*?scope\s+(?:host|global)"""
    ips = {}

    # Scrape the output of "ip".
    for name, ip_version, ip in re.findall(ip_re, ip_output, re.IGNORECASE | re.MULTILINE):
        if name not in ips:
            ips[name] = {'ipv4': [], 'ipv6': []}
        ip_version = 'ipv4' if (ip_version == 'inet') else 'ipv6'
        ips[name][ip_version].append(ip)

    return ips  # {<interface_name>: {'ipv4': [...], 'ipv6': [...]}}


def get_ip_neighbors():
    """
    Return a dictionary of all IP neighbors configured on the system,
    as output by the "ip" command.  A neighbor is referenced by its MAC.
    """

    #                  ip (not captured)    name               mac
    neighbor_re = r"""^[\d:/a-f.]+\s+dev\s+(\S+)\s+lladdr\s+([\d:a-f]+)\s+(?:router\s+)?REACHABLE"""
    neighbors = {}
    ip_cmd = '/sbin/ip -{0} neighbor show'

    for ip_version in ('4', '6'):
        try:
            ip_output = check_output(ip_cmd.format(ip_version).split())
        except CalledProcessError:
            log.error('"/sbin/ip -{0} neighbor show" exited non-zero.'.format(ip_version))
            continue

        for name, mac in re.findall(neighbor_re, ip_output, re.IGNORECASE | re.MULTILINE):
            if name not in neighbors:
                neighbors[name] = {'ipv4': [], 'ipv6': []}
            neighbors[name]['ipv{0}'.format(ip_version)].append(mac)

    return neighbors  # {<interface_name>: {'ipv4': [...], 'ipv6': [...]}}


def get_lldp_info(interfaces=None):
    """
    Return a dictionary of LLDP information.  This function only works for Debian
    based systems that default to using lldpd or Redhat based systems on which the
    user has installed lldpd.  It does not support Redhat's recommended utility,
    lldpad.

    interfaces - A non-empty list of interface names (strings), or None
    """

    assert interfaces is None or (isinstance(interfaces, list) and interfaces and isinstance(interfaces[0], str))

    if not os.path.exists('/run/lldpd.socket'):
        # If the socket doesn't exist, we cannot interact with lldpctl.
        return {}

    # Create a list of instances of xml.etree.ElementTree.Element from the given interfaces, if any.
    lldp_elements = [exec_lldpctl()] if (interfaces is None) else [exec_lldpctl(interface) for interface in interfaces]

    lldp_info = OrderedDict()
    ipv4_re = re.compile(r"""(?:\d{1,3}\.){3}(?:\d{1,3})""")

    for element in lldp_elements:
        if element is None:
            # The call to exec_lldpctl should have logged an error.
            continue
        for interface in element.iter('interface'):
            local_port = interface.get('name')
            lldpobj = {}
            lldpobj['adj_mac'] = interface.findtext('chassis/id')
            lldpobj['adj_port'] = interface.findtext('port/id')
            lldpobj['adj_hostname'] = interface.findtext('chassis/name')
            lldpobj['adj_ttl'] = interface.findtext('port/ttl')
            lldpobj['system_descr'] = interface.findtext('chassis/descr')

            # The xml might contain two IP addresses (v4 and v6), but both have the same xml tags.
            ips = interface.findall('chassis/mgmt-ip')  # A list of subelements
            for ip in ips:
                if ipv4_re.match(ip.text) is not None:
                    lldpobj['adj_mgmt_ip4'] = ip.text  # IPv4
                elif ':' in ip.text:
                    lldpobj['adj_mgmt_ip6'] = ip.text  # Assume IPv6 (an associated regex would be very complicated)
                else:
                    raise RuntimeError("Got a prospective IP address not recognized as IPv4 nor IPv6.")

            # The xml might contain "capability" tags.
            capabilities = interface.findall('chassis/capability')  # A list of subelements
            if capabilities:
                lldpobj['capabilities'] = [(capability.attrib['type'], capability.attrib['enabled']) for capability in capabilities]

            if lldp_info.get(local_port) is None:
                lldp_info[local_port] = []
            lldp_info[local_port].append(lldpobj)

    return lldp_info  # Return an ordered dictionary structured like { <interface_name> : <info> }.


def get_portnames():
    """
    Return a sorted, deduplicated list of strings of all port names, physical and virtual.
    """

    # Get the port names discovered by the kernel.
    portnames = set([name for name in listdir(SYS_PATH_ROOT) if name not in ("bonding_masters", "swid0_eth") and
        os.path.islink(os.path.join(SYS_PATH_ROOT, name))])

    # Return a sorted list.
    return sorted(portnames)


def get_vlan_info():
    """
    Return a dictionary of all VLANs configured on the system,
    as output by the "bridge" command.
    """

    cmd = '/sbin/bridge -j -c vlan show'
    try:
        bridge_output = check_output(cmd.split())  # JSON dictionary string
    except CalledProcessError:
        return {}

    try:
        vlan_output = loads(bridge_output)
    except ValueError:
        return {}

    return vlan_output


def net_show_interface(interface, show_mac, use_json, show_details, show_all):
    """
    Print information about the given interface(s).

        net show interface all [json|mac]
        net show interface [<interface>] [json]
        net show interface <interface> detail

    interface - A string or None; an interface name or interface glob
    """

    assert (isinstance(interface, (str, unicode)) and interface) or interface is None
    assert isinstance(show_all, bool), "Show information about interfaces with linkstate ADMDN?"
    assert isinstance(show_details, bool), "Show additional information for a subset of data?"
    assert isinstance(show_mac, bool)
    assert isinstance(use_json, bool)

    if isinstance(interface, unicode):
        # Avoid downstream problems when checking if interface names are in a dictionary.
        # TODO - Get rid of this when converting to Python 3.
        interface = str(interface)

    # Get IP addresses and lldp data in bulk (all interfaces).  This is
    # appropriate irrespective of the value of "interface".

    # {<interface_name>: {'ipv4': [...], 'ipv6': [...]}}
    ip_addresses = get_ip_addresses()

    # ex.: OrderedDict([('eth0', [{'adj_port': 'swp45', 'adj_mac': '08:9e:01:e9:67:2e', 'adj_mgmt_ip4': '172.17.1.6', 'adj_hostname': 'pioneerMS9.mvlab.cumulusnetworks.com', 'capabilities': [('Bridge', 'on'), ('Router', 'on')], 'adj_ttl': '120', 'system_descr': 'Cumulus Linux version 2.5.4 running on quanta lb9'}])])
    # This includes remote_host and remote_port information, which are columns in non-JSON output.
    lldp = get_lldp_info()

    if interface is None:
        # Interfaces that are not configured are not keys in ip_addresses or the lldp information,
        # but we still need to display them.
        interfaces = get_portnames()

        if use_json:
            return net_show_interface_json(ip_addresses, interfaces, lldp, show_all)
        else:
            return net_show_interface_all(ip_addresses, interfaces, lldp, show_mac, show_all)

    # Else, the user wants to display information about a subset of interfaces.
    interfaces = ifname_expand_glob(interface)

    if use_json:
        return net_show_interface_json(ip_addresses, interfaces, lldp, show_all)
    else:
        return net_show_interface_subset(ip_addresses, interfaces, lldp, show_details)


def net_show_interface_all(ip_addresses, interfaces, lldp, show_mac, show_all):
    """
    Return a string of information about all interfaces.

    ip_addresses - A dictionary, as returned by get_ip_addresses
    interfaces - A list of strings, as returned by get_portnames
    lldp - A dictionary, as returned by get_lldp_info
    show_mac - A boolean; If true, include a "mac" column
    show_all - A boolean; If true, show information about interfaces with link state ADMDN

    The output looks like:

    State  Name     Master    Speed      MTU  Mode           Remote Host    Remote Port    Summary
    -----  -------  --------  -------  -----  -------------  -------------  -------------  ---------------------------------
    UP     lo       None      N/A      65536  Loopback                                     IP: 127.0.0.1/8, ::1/128
    UP     eth0     None      1G        1500  Mgmt           swr06tor1      swp21          IP: 10.0.1.137/22(DHCP)
    UP     swp2s0   None      10G       1500  Interface/L3   radius         swp1           IP: 101.0.0.1/24, 4101:1010::1/64
    ...
    """

    table = []

    # On a box with 54 interfaces this avoids 300ms of 'bridge -j -c vlan'
    # calls in get_port_category()
    vlans = get_vlan_info()

    sub_interfaces = get_sub_interfaces()

    # Return a non-JSON string in tabular format.
    header = ["State", "Name", "Spd", "MTU", "Mode", "LLDP", "Summary"]

    # Insert the MAC column right before the Speed column in the table header.
    if show_mac:
        header.insert(3, "MAC")

    # Populate the output table.
    for name in sort_ifaces(interfaces):
        linkstate = get_linkstate(name)
        if not (show_all or linkstate.upper() != "ADMDN"):
            continue

        summary = get_summary_list(name, ip_addresses, len(header) - 1)

        remote_host = lldp[name][0].get("adj_hostname") if (name in lldp) else ''
        remote_port = lldp[name][0].get("adj_port") if (name in lldp) else ''

        if remote_host:

            # Remove the domain name to save space
            if '.' in remote_host:
                remote_host = remote_host.split('.')[0]

            if remote_port:
                lldp_output = "{0} ({1})".format(remote_host, remote_port)
            else:
                lldp_output = remote_host
        else:
            lldp_output = ''

        row = [linkstate,
               name,
               get_speed(name),
               read_from_sys("mtu", name),
               get_bond_mode(name) if is_bond(name) else get_port_category(name, ip_addresses, vlans, sub_interfaces),  # Mode
               lldp_output,
               summary if isinstance(summary, str) else summary[0][-1]]

        # Insert the MAC column right before the Speed column in the new row.
        if show_mac:
            row.insert(3, read_from_sys("address", name))

        table.append(row)

        if isinstance(summary, list):
            # The summary is a list of rows.  Append the subsequent row(s) to the table.
            for row in summary[1:]:
                table.append(row)

    return tabulate.tabulate(tabulate_remove_unicode(table), header, numalign="left") + "\n\n"


def get_iface_obj(name, allentries, asic, bond_members, counters, ip_addresses, ip_neighbors, lldp, mtu, vlans):
    # TODO - These fields were part of the "iface_obj" subdictionary, which was a product of the old netshow
    # implementation.  Having a subdictionary is undesirable, but we are not changing the JSON output prior
    # to CL 4.0.
    return {
        'lldp': lldp.get(name),
        'native_vlan': get_native_vlan(name, vlans),
        'ip_neighbors': ip_neighbors.get(name),
        'description': read_from_sys('ifalias', name),
#       'ip_address': ip_addresses.get(name),  # TODO - Use this line, instead of the one below, if we get rid of iface_obj.
        'ip_address': {'allentries': allentries},
        'counters': counters.get(name),          # TODO - Good, but fewer fields than the legacy output.
        'vlan': vlans.get(name),
        'asic': asic.get(name),
        'mtu': int(mtu) if mtu else '',
        'mac': read_from_sys('address', name),
        'vlan_filtering': bool(vlans.get(name)),
        'vlan_list': get_vlan_list(name, vlans),
        'dhcp_enabled': is_dhcp_enabled(name, ip_addresses),     # TODO - renamed from ip_addr_assign
        'lacp': get_lacp_dict(name),
        'min_links': read_from_sys('bonding/min_links', name),
#       'members': ', '.join(get_bond_members(name)),
        'members': dict(zip(bond_members, bond_members)),  # Legacy kludge :(
    }


def net_show_interface_json(ip_addresses, interfaces, lldp, show_all):
    """
    Return a JSON string of information about the given interfaces.  The output is
    the same for all interfaces as it is for a subset of interfaces, so different
    functions are not necessary.

    ip_addresses - A dictionary, as returned by get_ip_addresses
    interfaces - A non-empty list of strings
    lldp - A dictionary, as returned by get_lldp_info
    show_all - A boolean; If true, show information about interfaces with link state ADMDN

    The output looks like:

    {
        "swp2s3": {
            "name": "swp2s3",
            "iface_obj": {
                "lldp": [
                    {
                        "adj_port": "swp1",
                        "adj_mac": "00:01:00:00:04:00",
                        "adj_mgmt_ip4": "192.168.0.15",
                        "adj_mgmt_ip6": "fe80::201:ff:fe00:400",
                        "adj_ttl": "120",
                        "capabilities": [
                            [
                                "Bridge",
                                "off"
                            ],
                            [
                                "Router",
                                "on"
                            ]
                        ],
                        "adj_hostname": "host3",
                        "system_descr": "Cumulus Linux version (hydra-03 /tmp/radhika/Dot1xAuthConfig/)3.4.0 running on QEMU Standard PC (i440FX + PIIX, 1996)"
                    }
                ],
                "native_vlan": [],
                "ip_neighbor": {
                    "allentries": {}
                },
                "description": "",
                "ip_address": {
                    "allentries": []
                },
                "counters": {
                    "total_tx": 71960,
                    "all": {
                        "rx": {
                            "broadcast": 0,
                            "unicast": 0,
                            "errors": 0,
                            "multicast": 36660
                        },
                        "tx": {
                            "broadcast": 0,
                            "unicast": 0,
                            "errors": 0,
                            "multicast": 71960
                        }
                    },
                    "total_rx": 36660,
                    "total_err": 0
                },
                "vlan": null,
                "asic": {
                    "asicname": "xe4.0"
                },
                "connector_type": 4,
                "linkstate": 2,
                "mtu": 1500,
                "mac": "44:38:39:00:6c:91",
                "vlan_filtering": false,
                "ip_addr_assign": 0,
                "vlan_list": {},
                "speed": 10000,
                "name": "swp2s3"
            },
            "linkstate": "UP",
            "summary": [
                ""
            ],
            "port_category": "NotConfigured",
            "connector_type": null,
            "speed": "10G"
        },
        ...
    }

    Output for a single interface does not have the interface name as a top level
    dictionary key.
    """

    assert isinstance(interfaces, list) and interfaces

    output = {}

    # {<interface_name>: {'ipv4': [...], 'ipv6': [...]}}
    ip_neighbors = get_ip_neighbors()

    # {<interface_name>: {'rx': {...}, 'tx': {...}}}
    counters = get_counters_info(interfaces)

    # Dictionaries
    vlans = get_vlan_info()
    asic = get_asic_info()
    sub_interfaces = get_sub_interfaces()

    # Populate the output dictionary.
    for name in interfaces:
        linkstate = get_linkstate(name)
        if not (show_all or linkstate.upper() != "ADMDN") and len(interfaces) > 1:
            # Ignore ADMDN interfaces unless the output is only for a single interface.
            continue

        # TODO - Delete the following line if we get rid of iface_obj.
        allentries = (ip_addresses[name]["ipv4"] + ip_addresses[name]["ipv6"]) if (name in ip_addresses) else []
        bond_members = get_bond_members(name)  # Support for legacy kludge below :(
        mtu = read_from_sys("mtu", name)       # A string; maybe empty

        output[name] = {
            "linkstate": linkstate,
            "summary": get_summary(name, ip_addresses),
            "mode": get_bond_mode(name) if is_bond(name) else get_port_category(name, ip_addresses, vlans, sub_interfaces),
            "connector_type": get_connector_type(name, asic.get(name)),
            "speed": get_speed(name),
            "iface_obj": get_iface_obj(name, allentries, asic, bond_members, counters, ip_addresses, ip_neighbors, lldp, mtu, vlans)
        }

    if len(interfaces) == 1:
        # The output for a single interface does not have the interface name as a top level dictionary key.
        return dumps(output.get(interfaces[0], {}))

    return dumps(output)


def show_interface_detail(ifname):
    """
    ethtool swp1
    ethtool -m swp1
    ethtool -S swp1
    """
    results = []
    log.info("show_interface_detail called for %s" % ifname)

    try:
        output = check_output(['/sbin/ethtool', ifname], stderr=STDOUT)
        results.extend(['Ethtool',
                        '-------'])
        results.extend(output.splitlines())
        results.append('')
    except Exception:
        pass

    try:
        output = check_output(['/sbin/ethtool', '-m', ifname], stderr=STDOUT)
        results.extend(['Ethtool Pluggables',
                        '-------------------'])
        results.extend(output.splitlines())
        results.append('')
    except Exception:
        pass

    try:
        output = check_output(['/sbin/ethtool', '-S', ifname], stderr=STDOUT)
        results.extend(['Ethtool Statistics',
                        '------------------'])
        results.extend(output.splitlines())
        results.append('')
    except Exception:
        pass

    return '\n'.join(results)


def net_show_interface_subset(ip_addresses, interfaces, lldp, detail):
    """
    Return a string of information about the given interface(s).  This function's output is
    formatted differently from that of net_show_interface_all.

    ip_addresses - A dictionary, as returned by get_ip_addresses
    interfaces - A non-empty list of strings
    lldp - A dictionary, as returned by get_lldp_info
    """

    assert isinstance(interfaces, list) and interfaces and isinstance(interfaces[0], str)

    output = ''
    table = []
    counters = get_counters_info(interfaces)
    vlans = get_vlan_info()
    sub_interfaces = get_sub_interfaces()
    asic = get_asic_info()

    # {<interface_name>: {'ipv4': [...], 'ipv6': [...]}, ...}
    ip_neighbors = get_ip_neighbors()

    vlan_protocol_re = re.compile(r"""vlan\s+protocol\s+(?P<protocol>\S+)""", re.IGNORECASE)

    for name in interfaces:

        # Output summary information.

        header = ['', 'Name', 'MAC', 'Speed', 'MTU', 'Mode']

        table = [[
            get_linkstate(name),
            name,
            read_from_sys('address', name),
            get_speed(name),
            read_from_sys('mtu', name),
            get_bond_mode(name) if is_bond(name) else get_port_category(name, ip_addresses, vlans, sub_interfaces)]]

        output += tabulate.tabulate(tabulate_remove_unicode(table), header, numalign="left") + "\n\n"

        alias = read_from_sys('ifalias', name)
        allentries = (ip_addresses[name]['ipv4'] + ip_addresses[name]['ipv6']) if (name in ip_addresses) else []
        bond_members = get_bond_members(name)  # Support for legacy kludge below :(
        mtu = read_from_sys('mtu', name)       # A string; maybe empty
        iface_obj = get_iface_obj(name, allentries, asic, bond_members, counters, ip_addresses, ip_neighbors, lldp, mtu, vlans)

        if alias:
            output += "Alias\n-----\n{0}\n\n".format(alias)

        if is_l3(name, ip_addresses):
            # Output IP details.

            header = ['IP Details', '']
            table = [('IP:', ip) for ip in (ip_addresses[name]['ipv4'] + ip_addresses[name]['ipv6'])]
            if name in ip_neighbors:
                table.append(('IP Neighbor(ARP) Entries:', len(ip_neighbors[name]['ipv4']) + len(ip_neighbors[name]['ipv6'])))
            else:
                table.append(('IP Neighbor(ARP) Entries:', 0))

            output += tabulate.tabulate(tabulate_remove_unicode(table), header) + "\n\n"

        if is_bond(name):
            # Output bond details.

            header = ['Bond Details', '']
            table = [
                ['Bond Mode:', get_bond_mode(name)],
                ['Load Balancing:', get_bond_xmit_hash_policy(name)],
                ['Minimum Links:', iface_obj.get("min_links")],
            ]

            if "lacp" in iface_obj:
                table.extend([
                    ['LACP Sys Priority:', iface_obj["lacp"].get("sys_priority")],
                    ['LACP Rate:', iface_obj["lacp"].get("rate")],
                    ['LACP Bypass:', "Active" if iface_obj["lacp"].get("bypass") == '1' else "Inactive"],
                ])

            output += tabulate.tabulate(tabulate_remove_unicode(table), header, numalign="left") + "\n\n"

        # VLAN output
        native_vlan = iface_obj.get("native_vlan")
        vlan_list = iface_obj.get("vlan_list")

        if vlan_list:
            output += "All VLANs on L2 Port\n"
            output += "--------------------\n"
            output += vlan_list + "\n\n"

        if native_vlan:
            output += "Untagged\n--------\n{0}\n\n".format(native_vlan)

        if name != "lo" and name in counters:
            # Output cl-netstat counters.

            output += "cl-netstat counters\n-------------------\n"
            header = ['RX_OK', 'RX_ERR', 'RX_DRP', 'RX_OVR', 'TX_OK', 'TX_ERR', 'TX_DRP', 'TX_OVR']
            row = [counters[name][column] for column in header]
            output += tabulate.tabulate(tabulate_remove_unicode([row]), header) + "\n\n"

        if name in lldp or is_bond(name):
            # Output LLDP details.

            if is_bond(name):
                names_for_lldp = get_bond_members(name)
            else:
                names_for_lldp = [name]

            output += "LLDP Details\n------------\n"
            header = ['LocalPort', 'RemotePort(RemoteHost)']
            table = []

            for tmp_name in names_for_lldp:
                if tmp_name in lldp:
                    table.append((tmp_name, '{0}({1})'.format(lldp[tmp_name][0]['adj_port'], lldp[tmp_name][0]['adj_hostname'])))

            output += tabulate.tabulate(tabulate_remove_unicode(table), header) + "\n\n"

        # Output routing information, if any.
        try:
            vtysh_output = check_output(['/usr/bin/vtysh', '-c', 'show interface {0}'.format(name)], stderr=STDOUT)
            results = ['Routing', '-------']
            results.extend([('  ' + line.strip()) for line in vtysh_output.splitlines()])
            output += '\n'.join(results) + "\n\n"
        except CalledProcessError as e:
            log.warning("Couldn't display routing information for {0}.  vtysh says, \"{1}\".".format(name, e.output))

        if '.' in name:
            # This might be a subinterface.  Output VLAN protocol information, if available.

            try:
                ip_output = check_output(['/sbin/ip', '-d', 'link', 'show', name], stderr=STDOUT)
                protocol = vlan_protocol_re.search(ip_output)
                if protocol is not None:
                    output += '\n  Vlan Protocol: ' + protocol.group('protocol')
            except CalledProcessError as e:
                log.warning("\"ip -d link show {0}\" failed: {1}".format(name, e.output))

        if detail:
            output += show_interface_detail(name)

        # Add newlines to separate output when displaying multiple interfaces
        output += "\n\n"

    return output


def read_from_sys(attr, interface):
    """
    Read an attribute, contained in a file, found in the
    /sys/class/net/<interface>/ directory.  If the file
    is not accessible or does not exist, return the empty
    string.

    attr - A string; an attribute with a corresponding file
    interface - A string; a single interface name (not a glob)
    """

    path = "{0}/{1}/{2}".format(SYS_PATH_ROOT, interface, attr)

    try:
        if os.path.isfile(path):
            with open(path) as f:
                return f.read().strip()
    except IOError:
        pass
    return ''


def get_linkstate(interface):
    """
    Return the link state (UP, DN, etc.) as a string.

    interface - A string; a single interface name (not a glob)
    """

    carrier = read_from_sys('carrier', interface)
    operstate = read_from_sys('operstate', interface)

    if operstate and operstate == 'dormant':
        return 'DRMNT'
    elif carrier:
        return 'DN' if (carrier == '0') else 'UP'
    return 'ADMDN'


def get_port_category(interface, ip_addresses, vlans, sub_interfaces):
    """
    Via interface discovery, determine and return the port type, a.k.a. "mode",
    as a string.  The method varies according to the type of interface.

    interface - A string; a single interface name (not a glob)
    ip_addresses - A dictionary with interface names as keys
    vlans - A dictionary with interface names as keys, or None
    """

    if not isinstance(ip_addresses, dict):
        raise TypeError("'ip_addresses' must be a dictionary.")

    if interface.startswith('lo'):
        return 'Loopback'

    if re.match(r"""eth\d+$""", interface) is not None:
        return 'Mgmt'

    if is_bond_member(interface):
        return "BondMember"

    l3 = is_l3(interface, ip_addresses)  # Boolean

    if is_bridge(interface):
        return 'Bridge/L3' if l3 else 'Bridge/L2'

    bridge_port_type = get_bridge_member_port_type(interface, vlans, sub_interfaces)

    if is_bond(interface):
        if l3:
            return 'Bond/L3'
        if bridge_port_type == 1:
            return 'Bond/Trunk'
        if bridge_port_type == 2:
            return 'Bond/Access'
        return 'Bond'

    # The interface is neither a bridge nor a bond, but it still might be a bridge member.
    if bridge_port_type == 1:
        return 'Access/L2'
    if bridge_port_type == 2:
        return 'Trunk/L2'
    assert bridge_port_type == 0

    # The interface is pysical, not a bond member, and not a management port.

    if l3:
        # This is a l3 interface because it has an IP address.

        if re.match(r""".*\.\d+$""", interface) is not None:
            # This is a subinterface.
            return 'SubInt/L3'
        else:
            # This is not a subinterface.
            return 'Interface/L3'

    return 'NotConfigured'


def get_bond_mode(bond_name):
    """
    Use this for the "Mode" display for bonds in the output
    of "net show interface ..." commands.
    """

    assert is_bond(bond_name)

    mode_number_str = read_from_sys('bonding/mode', bond_name)
    if mode_number_str:
        mode_number_str = mode_number_str.split()[1]
    else:
        return 'Unknown'

    if mode_number_str == '0':
        return 'Balance-RR'
    elif mode_number_str == '1':
        return 'Active-Backup'
    elif mode_number_str == '2':
        return 'Balance-XOR'
    elif mode_number_str == '3':
        return 'Broadcast'
    elif mode_number_str == '4':
        return 'LACP'

    log.warning("Could not determine the bond mode for {0}.".format(bond_name))
    return 'Unknown'


def get_bond_member_mode(member_name):
    """
    Use this for the "Mode" display for bond members in the output
    of "net show interface bondmems ..." commands.
    """

    assert is_bond_member(member_name)

    mode_number_str = read_from_sys("bonding_slave/ad_actor_oper_port_state", member_name)

    if mode_number_str:
        # mode_number_str might be "N/A".
        mode_number_str = int(mode_number_str) if mode_number_str.isdigit() else 0
        assert 0 <= mode_number_str < 256
    else:
        return "Unknown"

    if (mode_number_str & 0b00001000) == 8:
        return "LACP-UP"

    if (mode_number_str & 0b01000000) == 64:
        return "LACP-DOWN"

    log.warning("Could not determine the bond member mode for {0}.".format(member_name))
    return "BondMember"


def get_bond_xmit_hash_policy(bond_name):
    assert is_bond(bond_name)
    output = read_from_sys('bonding/xmit_hash_policy', bond_name).strip()

    # This file will contain a line such as "layer3+4 1", we want to return the "layer3+4" part.
    if output:
        try:
            return output.split()[0]
        except ValueError:
            log.warning("%s bonding/xmit_hash_policy contains '%s'" % (bond_name, output))
            return output

    return 'Unknown'


def get_speed(interface):
    """
    Return the given interface's port speed, as a string, in MB.

    interface - A string; a single interface name (not a glob)
    """

    speed = read_from_sys('speed', interface)

    assert isinstance(speed, str), "speed for %s is not a str, it is a %s" % (interface, type(speed))

    # speed could be -1 for virtual interfaces so we must lstrip
    # the - else isdigit() will return False
    assert (not speed or speed.lstrip('-').isdigit()), "speed for %s is %s, it must be False or a digit" % (interface, speed)

    if not speed or int(speed) > 4294967200 or int(speed) < 0:
        return 'N/A'

    if int(speed) < 1000:
        speed += 'M'
    else:
        # Python3 supports this true division thing so 40/10 gives you 4.0.
        # To not have the .0, double the forward slash.
        speed = str(int(speed) // 1000) + 'G'

    return speed


def is_l3(interface, ip_dict):
    """
    Return True if the given interface name is a key in the given dictionary
    and the dictionary value for that key, which is also a dictionary, contains
    a non-empty list for either the 'ipv4' key or the 'ipv6' key.

    >>> is_l3('eth0', {})
    False

    >>> is_l3('eth0', {'swp1': {'ipv4': [], 'ipv6': []}})
    False

    >>> is_l3('swp1', {'swp1': {'ipv4': [], 'ipv6': []}})
    False

    >>> is_l3('swp1', {'swp1': {'ipv4': ['1.1.1.1'], 'ipv6': []}})
    True

    >>> is_l3('swp1', {'swp1': {'ipv4': [], 'ipv6': ['1.1.1.1']}})
    True

    >>> is_l3('swp1', {'swp1': {'ipv4': ['1.1.1.1'], 'ipv6': ['2.2.2.2']}})
    True
    """

    assert isinstance(interface, (str, unicode)), "type(interface) = {0}".format(type(interface))
    assert isinstance(ip_dict, dict), "type(ip_dict) = {0}".format(type(ip_dict))
    return interface in ip_dict and bool(ip_dict[interface]["ipv4"] or ip_dict[interface]["ipv6"])


def net_show_system():
    """Print information about the system."""

    output = ''

    # Display the vendor and model, if available.

    try:
        platform_detect = check_output('/usr/bin/platform-detect').strip()
    except CalledProcessError:
        output += "The call to platform-detect failed.\n"
        platform_detect = None

    if platform_detect is not None:
        # platform_detect looks like "dell,s6000_s1220".
        vendor, second = platform_detect.split(',')
        model = second.split('_')[0]
        output += "{0} {1}\n".format(vendor.title(), model.upper())

    # Display the operating system name and version.

    try:
        with open("/etc/lsb-release") as f:
            lsb_release = f.read()
    except OSError:
        output += "Could not open lsb-release.\n"
        lsb_release = None

    if lsb_release is not None:

        os_version = re.search(r"""^\s*DISTRIB_RELEASE\s*=\s*(.+)""", lsb_release, re.IGNORECASE | re.MULTILINE)
        if os_version is not None:
            os_version = os_version.group(1)

        os_description = re.search(r'''^\s*DISTRIB_DESCRIPTION\s*=\s*"(.+)"''', lsb_release, re.IGNORECASE | re.MULTILINE)
        if os_description is not None:
            os_description = os_description.group(1)

        output += "Cumulus Linux {0}\n".format(os_version)
        output += "Build: {0}\n".format(os_description)

    # Display the chipset, port configuration, and CPU, if available.  This
    # information is stored as JSON in files, but the desired information might
    # not be in the file one would expect from the file names.  So aggregate
    # all the available information in a dictionary first.

    if platform_detect is not None:
        #                         new prefered location                            legacy location
        json_dirs = ["/usr/share/cumulus-platform/common/platform-info/", "/usr/share/cumulus/platform-info/"]

        aggregate_platform_dict = {}

        for directory in json_dirs:
            if not os.path.isdir(directory):
                continue

            for filename in listdir(directory):

                json_file_path = "{0}{1}".format(directory, filename)
                assert os.path.isfile(json_file_path)

                try:
                    with open(json_file_path) as f:
                        platform_info = f.read()
                except OSError:
                    log.warning("Could not open {0}.".format(json_file_path))
                    continue

                try:
                    platform_info = loads(platform_info)
                except ValueError:
                    log.warning("Could not parse {0}.".format(json_file_path))
                    continue

                if not isinstance(platform_info, dict):
                    log.warning("{0} contains JSON, but it is not a dictionary.".format(json_file_path))
                    continue

                for k, v in platform_info.iteritems():
                    # The value, v, is a list containing one dictionary.
                    aggregate_platform_dict[k] = v

        if platform_detect in aggregate_platform_dict:
            # Found relevant platform information above.  Display it here.  Substitute the empty string for None.

            try:
                # chipset
                chip_vendor = aggregate_platform_dict[platform_detect][0]["soc"]["vendor"]
                chip_model = aggregate_platform_dict[platform_detect][0]["soc"]["model"]
                chip_model_id = aggregate_platform_dict[platform_detect][0]["soc"]["model_id"]
                output += "\nChipset: {0} {1} {2}".format(
                    chip_vendor if (chip_vendor is not None) else '',
                    chip_model if (chip_model is not None) else '',
                    chip_model_id if (chip_model_id is not None) else '').rstrip() + '\n'

                # port configuration
                ports_layout = aggregate_platform_dict[platform_detect][0]["ports"]["layout"]
                output += "Port Config: {0}".format('' if (ports_layout is None) else ports_layout).rstrip() + '\n'

                # CPU
                if aggregate_platform_dict[platform_detect][0]["cpu"]["arch"] is not None:
                    cpu_architecture = "({0})".format(aggregate_platform_dict[platform_detect][0]["cpu"]["arch"])
                else:
                    cpu_architecture = ''
                cpu_vendor = aggregate_platform_dict[platform_detect][0]["cpu"]["vendor"]
                cpu_model = aggregate_platform_dict[platform_detect][0]["cpu"]["model"]
                cpu_model_id = aggregate_platform_dict[platform_detect][0]["cpu"]["model_id"]
                cpu_speed = aggregate_platform_dict[platform_detect][0]["cpu"]["speed"]
                output += "CPU: {0} {1} {2} {3} {4}".format(
                    cpu_architecture,
                    cpu_vendor if (cpu_vendor is not None) else '',
                    cpu_model if (cpu_model is not None) else '',
                    cpu_model_id if (cpu_model_id is not None) else '',
                    cpu_speed if (cpu_speed is not None) else '').rstrip() + '\n'

            except KeyError:
                log.warning("Could not detect platform information for \"{0}\".  Raised KeyError.".format(platform_detect))

        else:
            log.warning("Could not detect platform information for \"{0}\".".format(platform_detect))

    # Display the uptime.

    if os.path.isfile("/proc/uptime"):
        with open("/proc/uptime") as f:
            # Looks like "182794.74 653446.10", where the first number is the uptime in seconds.
            uptime = timedelta(seconds=float(f.read().split()[0]))

        output += "Uptime: {0}\n".format(uptime)
    else:
        output += "Uptime not available.\n"

    return output


def net_show_lldp(interface=None, use_json=False):
    """
    Print information about link layer neighbors.

    This function only works for Debian based systems that default to using lldpd
    or Redhat based systems on which the user has installed lldpd.  There is no
    support for lldpad, the Redhat recommended lldp application.

    interface - A string or None; an interface name or interface glob
    use_json - A boolean; return JSON output or not
    """

    # "interface" must be a non-empty string or None.
    assert (isinstance(interface, str) and interface) or interface is None
    assert isinstance(use_json, bool)

    if interface is not None:
        # Get a non-empty list of interface names.
        interface = ifname_expand_glob(interface)
        assert isinstance(interface, list) and interface

    command = ["/usr/sbin/lldpctl"]

    if use_json or interface is None:
        # When the user does not specify interfaces, non-JSON output will be in
        # tabular format.  Constructing this table is more easily accomplished
        # using JSON.
        command.extend(["-f", "json"])
    if interface is not None:
        command.extend(interface)

    try:
        lldpctl_output = check_output(command)
    except CalledProcessError:
        lldpctl_output = "lldpctl failed.  Is lldpd.service running?\n"

    if not use_json and interface is None and not lldpctl_output.startswith("ERROR"):
        # Output a summary of all interfaces in tabular format.
        return lldp_json_to_table(lldpctl_output)

    # Output the raw text from lldpctl.
    return lldpctl_output


def lldp_json_to_table(json_string):
    """
    Given a JSON string, return a summary string in tabular format.
    """

    try:
        interfaces_dict = loads(json_string)
    except ValueError as e:
        return "Couldn't parse the JSON: {0}".format(e)

    header = ['LocalPort', 'Speed', 'Mode', 'RemoteHost', 'RemotePort']
    table = []
    ip_addresses = get_ip_addresses()
    vlans = get_vlan_info()
    sub_interfaces = get_sub_interfaces()
    interfaces = {}

    # Build a dictionary of interfaces where the interface name is the key. We
    # need this so we can sort the interface names and add rows to 'table' so
    # that they are sorted by interface.
    if interfaces_dict.get('lldp') is not None and interfaces_dict['lldp'][0] is not None and interfaces_dict['lldp'][0].get('interface') is None:
        return "No interfaces found for LLDP."
    for interface in interfaces_dict['lldp'][0]['interface']:
        assert isinstance(interface, dict)

        # This should always be part of the JSON.
        name = interface['name']

        if name not in interfaces:
            interfaces[name] = []

        if 'chassis' in interface and 'name' in interface['chassis'][0]:
            # This interface includes neighbor information.
            interfaces[name].append(interface)

    for name in sort_ifaces(interfaces.keys()):
        # It is unusual to have multiple lldp neighbors on an interface, but it can
        # happen in some EVPN environments or if someone is using hubs. Sort the
        # rows of neighbors for this interface based on RemoteHost.
        for interface in sorted(interfaces[name], key=lambda x: x['chassis'][0]['name'][0]['value']):

            # Get the RemotePort value.
            if interface.get('port') is not None and interface['port'][0].get('descr') is not None:
                remote_port = str(interface['port'][0]['descr'][0].get('value', ''))
            else:
                remote_port = ''

            # Get the RemoteHost value.
            if interface.get('chassis') is not None and interface['chassis'][0].get('name') is not None:
                remote_host = str(interface['chassis'][0]['name'][0].get('value', ''))
            else:
                remote_host = ''

            table.append([name,
                          get_speed(name),
                          get_port_category(name, ip_addresses, vlans, sub_interfaces),        # Mode
                          remote_host,
                          remote_port])

    # Rows might have long summaries which will get wrapped in a terminal and
    # distort the output.

    table_wrapped = []                      # A list of lists of strings
    for row in table:
        if len(row[-1]) <= SUMMARY_COLUMN_WIDTH:
            # The summary does not need to be wrapped.  Keep the row as-is.
            table_wrapped.append(row)
            continue

        # The row needs to be wrapped.

        summary = wrap_summary(row[-1], 5)  # A list of lists of strings
        row[-1] = summary[0][-1]
        table_wrapped.append(row)

        # Append the remaining summary row(s) to the modified table.
        table_wrapped.extend(summary[1:])

    return '\n' + tabulate.tabulate(tabulate_remove_unicode(table_wrapped), header) + '\n'


def get_master(interface):
    """
    Return the master of the given interface, if any.  Otherwise, return None.
    """

    master_path = '/sys/class/net/{0}/master'.format(interface)

    if not os.path.exists(master_path):
        return None

    try:
        # readlink output looks lik '../br1'
        return os.path.basename(readlink(master_path))
    except OSError:
        return None


def get_summary_list(interface, ip_addresses, columns):
    result = []
    pre_summary_columns = ['', interface] + [''] * (columns - 2)

    master = get_master(interface)

    if master is not None:
        result.append(pre_summary_columns + ['Master: {0}({1})'.format(master, get_linkstate(master))])

    if is_bond(interface):
        bond_members = get_bond_members(interface)  # A list of strings
        bond_members_with_linkstate = ['{0}({1})'.format(member, get_linkstate(member)) for member in bond_members]

        for bond_member in bond_members_with_linkstate:
            result.append(pre_summary_columns + ['Bond Members: {0}'.format(bond_member)])

    if is_l3(interface, ip_addresses):

        if is_dhcp_enabled(interface, ip_addresses):
            result.append(pre_summary_columns + ["IP: {0}(DHCP)".format(ip_addresses[interface]['ipv4'][0])])
        else:
            for ip in ip_addresses[interface]['ipv4']:
                result.append(pre_summary_columns + ["IP: {0}".format(ip)])

            for ip in ip_addresses[interface]['ipv6']:
                result.append(pre_summary_columns + ["IP: {0}".format(ip)])

    if not result:
        result.append([''] * (columns + 1))

    return result


def get_summary(interface, ip_addresses):
    """
    Return the summary for the given interface, if any.  Otherwise, return None.
    """

    if is_bond(interface):
        bond_members = get_bond_members(interface)  # A list of strings
        bond_members_with_linkstate = ['{0}({1})'.format(member, get_linkstate(member)) for member in bond_members]
        summary = 'Bond Members: {0}'.format(', '.join(bond_members_with_linkstate))
    elif is_bond_member(interface):
        master = get_master(interface)
        summary = 'Master: {0}'.format(master if (master is not None) else 'unknown')

        if master is not None:
            # Add link state information for the bond master.
            summary += '({0})'.format(get_linkstate(master))
    else:
        summary = ''

    if is_l3(interface, ip_addresses):
        if summary:
            summary += '\n'

        if is_dhcp_enabled(interface, ip_addresses):
            # The IP has been assigned by DHCP.  Display the first known address.
            # TODO - Why?
            summary += "IP: {0}(DHCP)".format(ip_addresses[interface]['ipv4'][0])
        else:
            # Display all known IPs.
            summary += "IP: {0}".format(', '.join(ip_addresses[interface]['ipv4'] + ip_addresses[interface]['ipv6']))

    return summary


def is_dhcp_enabled(interface, ip_addresses):
    """
    Return True if the given interface is DHCP enabled; otherwise, False.
    """

    leasesfile = '/var/lib/dhcp/dhclient.{0}.leases'.format(interface)
    if not os.path.isfile(leasesfile):
        return False

    try:
        with open(leasesfile) as f:
            leasefile_text = f.read()
    except IOError:
        log.error("Could not open {0}.".format(leasesfile))
        return False

    # Get the "expire" datetime strings in the lease file.
    expiration_datetimes = re.findall(r'''expire\s+\d+\s+([\d/]+\s+[\d:]+)''', leasefile_text)
    if not expiration_datetimes:
        return False

    # Determine if the most recent expiration datetime has passed.
    fmt = '%Y/%m/%d %H:%M:%S'
    lease_valid = datetime.strptime(expiration_datetimes[-1], fmt) > datetime.now()
    if not lease_valid:
        return False

    # The lease is valid.  Get the most recent "fixed-address" and "subnet-mask" values.
    # TODO - These only match IPv4.  Is that an issue?
    fixed_addresses = re.findall(r'''fixed-address\s+([\d.]+)''', leasefile_text)
    subnet_masks = re.findall(r'''subnet-mask\s+([\d.]+)''', leasefile_text)
    if not (fixed_addresses and subnet_masks) or len(fixed_addresses) != len(subnet_masks):
        return False

    mask = netmask_to_cidr(subnet_masks[-1])
    dhcp_address_cidr = fixed_addresses[-1] + '/' + str(mask)

    # TODO - What about IPv6?
    return dhcp_address_cidr in ip_addresses[interface]['ipv4']


def netmask_to_cidr(netmask):
    """
    >>> netmask_to_cidr('255.255.255.0')
    24

    >>> netmask_to_cidr('255.255.0.0')
    16

    >>> netmask_to_cidr('255.0.0.0')
    8

    TODO - Tests for IPv6
    """

    is_ipv6 = ':' in netmask
    base = 16 if is_ipv6 else 10
    ip_split = re.split(r"""[.:]""", netmask)

    return sum([bin(int(x, base)).count('1') for x in ip_split])


def get_connector_type(interface, asic_info=None):
    """
    Return the type of physical connector the switch has.

    interface - A string; a single interface name (not glob)
    asic_info - A dictionary (entry in the output of get_asic_info for the given interface) or None
    """

    assert isinstance(interface, str) and not ifname_is_glob(interface)
    assert isinstance(asic_info, dict) or asic_info is None

    if re.match(r"""swp\d+s\d+""", interface) is not None:
        # Subinterface
        return 'QSFP (4x10G)'

    if asic_info is not None:
        if asic_info['asicname'].startswith('ge'):
            return 'RJ45 (1G/10G)'

        if 'initial_speed' in asic_info:
            if asic_info['initial_speed'] == 10000:
                return 'SFP+ (10G)'
            if asic_info['initial_speed'] == 40000:
                return 'QSFP (40G)'

    return 'Unknown'


def get_native_vlan(interface, vlans):
    """
    Return the "Egress Untagged" vlan or None

    interface - A string; a single interface name (not glob)
    vlans - A dictionary
    """
    assert isinstance(interface, str) and not ifname_is_glob(interface)
    assert isinstance(vlans, dict)

    if_vlans = vlans.get(interface, [])

    '''
    For a trunk if_vlans will look like
    [{u'flags': [u'PVID', u'Egress Untagged'], u'vlan': 1},
     {u'vlan': 8, u'vlanEnd': 9}]

    For an access port if_vlans will look like
    [{u'flags': [u'PVID', u'Egress Untagged'], u'vlan': 8}]
    '''
    for entry in if_vlans:
        flags = entry.get("flags", [])
        if "Egress Untagged" in flags and "vlan" in entry:
            return entry["vlan"]

    return None


def get_vlan_list(interface, vlans):
    assert isinstance(interface, str) and not ifname_is_glob(interface)
    assert isinstance(vlans, dict)

    if_vlans = vlans.get(interface, [])
    vlan_list = []

    for entry in if_vlans:
        if "vlan" in entry:
            vlan_start = entry["vlan"]

            if "vlanEnd" in entry:
                vlan_end = entry["vlanEnd"]
            else:
                vlan_end = vlan_start

            for x in range(vlan_start, vlan_end + 1):
                vlan_list.append(x)

    if vlan_list:
        vlan_list = numbers_to_glob(vlan_list)

    return vlan_list


def get_lacp_dict(interface):
    """
    Return a dictionary with Link Aggregation Control Protocol information.
    Although not enforced here, calling this function only makes sense when
    the input interface is a bond.

    interface - A string; a bond name
    """

    result = {
        'bypass': read_from_sys('bonding/lacp_bypass', interface),
        'partner_mac': read_from_sys('bonding/ad_partner_mac', interface),
        'rate': read_from_sys('bonding/lacp_rate', interface),
        'sys_priority': read_from_sys('bonding/ad_sys_priority', interface),
    }

    if result['bypass']:
        result['bypass'] = result['bypass'].split()[-1]

    if result['rate'] and len(result['rate'].split()) > 1:
        result['rate'] = result['rate'].split()[1]

    return result


def get_bond_members(interface):
    """
    Return a bond's members as a sorted list of strings.
    """

    return sorted(read_from_sys('bonding/slaves', interface).split())


def is_bond(interface):
    """
    Return True if the given interface is a bond; otherwise, False.
    """

    path = '{0}/{1}/{2}'.format(SYS_PATH_ROOT, interface, 'bonding')
    return os.path.isdir(path)


def is_bridge(interface):
    """
    Return True if the given interface is a bridge; otherwise, False.
    """

    path = os.path.join(SYS_PATH_ROOT, interface, 'bridge')
    return os.path.isdir(path)


def get_bridge_member_port_type(interface, vlans, sub_interfaces):
    """
    0: not a bridge member
    1: access port
    2: trunk port
    """

    if not isinstance(vlans, dict):
        raise TypeError("'vlans' must be a dictionary as returned by get_vlan_info().")

    port_type = 0

    if bool(vlans.get(interface)):
        # The interface is vlan filtering.
        if interface in vlans:
            # interface can have list of vlans
            # we check the vlan dictionary that came from bridge -c -j vlan show
            if len([v['vlan'] for v in vlans[interface] if not v.get('flags', None)]):
                port_type = 2
            else:
                # ports with only native vlan flags are access ports
                port_type = 1
        else:
            port_type = 1
    elif os.path.exists('/sys/class/net/{0}/brport'.format(interface)):
        port_type = 1

    if '.' not in interface:
        # The interface is not a subinterface.
        for subint in sub_interfaces.get(interface, []):
            if os.path.exists('/sys/class/net/{0}/brport'.format(subint)):
                port_type = 2
                break

    return port_type


def get_sub_interfaces():
    """
    Return a dictionary of sub interfaces where the keys are base interface names,
    and the values are subinterface names.  ex. {"swp1": ["s0", s1"]}
    """

    sub_interfaces = {}
    sub_interface_re = re.compile(r"""^(.*?)\.""")

    for interface in os.listdir(SYS_PATH_ROOT):
        if '.' in interface:
            search = sub_interface_re.search(interface)
            base_interface = search.group(1) if (search is not None) else interface

            if base_interface not in sub_interfaces:
                sub_interfaces[base_interface] = []

            sub_interfaces[base_interface].append(interface)

        else:
            if interface not in sub_interfaces:
                sub_interfaces[interface] = []

    return sub_interfaces


def get_interface_subdivisions(interface):
    """
    Returns all the subinterfaces or subdivision interfaces for an interface
    """
    sub_glob_name = "{}/{}s*".format(SYS_PATH_ROOT, interface)
    return [os.path.basename(ifpathname) for ifpathname in glob.glob(sub_glob_name)]


def is_bond_member(interface):
    """
    Return True if the given interface is a bond member; otherwise, False.
    """

    path = '{0}/{1}/{2}'.format(SYS_PATH_ROOT, interface, 'master/bonding')
    return os.path.isdir(path)


def is_bridge_member(interface):
    """
    Return True if the given interface is a bridge member; otherwise, False.
    """

    path = os.path.join(SYS_PATH_ROOT, interface, 'master', 'bridge')
    return os.path.isdir(path)


def net_show_counters(use_json=False):
    """
    Return counter information, as a string, for all interfaces
    using the output of cl-netstat.  This is the implementation
    for "net show counters [json]".

    use_json - A boolean; return JSON output or not
    """

    cmd = ['/usr/cumulus/bin/cl-netstat']

    if use_json:
        cmd.append('-j')

    try:
        output = check_output(cmd, stderr=STDOUT)
    except CalledProcessError as e:
        output = "\"{0}\" failed.\n".format(' '.join(cmd))
        output += e.output

    # Return the unchanged output of cl-netstat.  This is either a table or JSON that includes all interfaces.
    return output


def net_show_interface_bondmems(show_mac, use_json):
    bond_members = filter(is_bond_member, get_portnames())
    return net_show_interface_bonds_bondmems_helper(bond_members, False, show_mac, use_json)


def net_show_interface_bonds(show_mac, use_json):
    bonds = filter(is_bond, get_portnames())
    return net_show_interface_bonds_bondmems_helper(bonds, True, show_mac, use_json)


def net_show_interface_bonds_bondmems_helper(interfaces, bond_output, show_mac, use_json):
    """
    This is the implementation of "net show interface bonds" and "net show interface bondmems".
    The output of those commands differ only by the interfaces included in the output and the
    interfaces' "mode" value.

    interfaces - A list of strings; interface names
    bond_output - A boolean; True if the output is for bonds; False, bond members
    """

    assert not (show_mac and use_json), "MAC information should only be an option for non-JSON output."
    assert isinstance(bond_output, bool)

    if not interfaces:
        # There are no interfaces to show.
        return "{}" if use_json else ''

    if use_json:
        output = {}
    else:
        header = ['', 'Name', 'MAC', 'Speed', 'MTU', 'Mode', 'Summary'] if show_mac else ['', 'Name', 'Speed', 'MTU', 'Mode', 'Summary']
        table = []

    ip_addresses = get_ip_addresses()
    ip_neighbors = get_ip_neighbors()
    counters = get_counters_info()
    vlans = get_vlan_info()
    asic = get_asic_info()
    lldp = get_lldp_info()

    for name in interfaces:
        allentries = (ip_addresses[name]['ipv4'] + ip_addresses[name]['ipv6']) if (name in ip_addresses) else []
        bond_members = get_bond_members(name)  # Support for legacy kludge below :(
        mtu = read_from_sys('mtu', name)       # A string; maybe empty

        if use_json:
            output[name] = {
                    'linkstate': get_linkstate(name),
                    'speed': get_speed(name),
                    'mtu': read_from_sys('mtu', name),
                    'mode': get_bond_mode(name) if bond_output else get_bond_member_mode(name),
                    'summary': get_summary(name, ip_addresses),
                    'iface_obj': get_iface_obj(name, allentries, asic, bond_members, counters, ip_addresses, ip_neighbors, lldp, mtu, vlans)
                }

            if show_mac:
                output[name]['mac'] = read_from_sys('address', name)

        else:
            summary = get_summary(name, ip_addresses)  # A string; maybe empty
            if len(summary) > SUMMARY_COLUMN_WIDTH:
                # A list of lists of strings
                summary = wrap_summary(summary, 6 if show_mac else 5)

            new_line = [get_linkstate(name),
                        name,
                        get_speed(name),
                        read_from_sys('mtu', name),
                        get_bond_mode(name) if bond_output else get_bond_member_mode(name),
                        summary if isinstance(summary, str) else summary[0][-1]]
            if show_mac:
                new_line.insert(2, read_from_sys('address', name))

            table.append(new_line)

            if isinstance(summary, list):
                # The summary is a list of rows.  Append the subsequent row(s) to the table.
                table.extend(summary[1:])

    if use_json:
        return dumps(output)

    # Return a non-JSON string in tabular format.
    return tabulate.tabulate(tabulate_remove_unicode(table), header) + '\n\n'


def wrap_summary(summary, columns_to_pad, width=SUMMARY_COLUMN_WIDTH):
    """
    Some tables, constructed by calling "tabulate", include a summary as the right-most column.
    If the summary is wider than the space available on a terminal line, it gets wrapped and
    distorts the tabulation.

    This function takes a summary string and returns a list of strings representing multiple
    rows in a table where the columns before the the summary are empty.

    columns_to_pad - An integer, the number of columns before the summary

    >>> wrap_summary('a' * 50 + 'b' * 10, 2)
    [['', '', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'], ['', '', 'bbbbbbbbbb']]

    >>> wrap_summary('a' * 50 + 'b' * 10, 2, 25)
    [['', '', 'aaaaaaaaaaaaaaaaaaaaaaaaa'], ['', '', 'aaaaaaaaaaaaaaaaaaaaaaaaa'], ['', '', 'bbbbbbbbbb']]
    """

    if not isinstance(summary, str):
        raise TypeError("This function takes a summary as a string.  type(summary)={0}".format(type(summary)))

    if not summary:
        raise ValueError("Do not pass the empty string to this function.")

    result = []   # A list of lists of strings

    for line in wrap(summary, width):
        # Assign blanks to the non-summary columns, and append the line.
        row = ['' for _ in range(columns_to_pad)]
        row.append(line)

        # Append the row to the result.
        result.append(row)

    return result


if __name__ == '__main__':
    import doctest
    doctest.testmod()
