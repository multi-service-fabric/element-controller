# ---------------------------------------> IMPORTANT <-------------------------------------------
# PRETTY PLEASE, WITH SUGAR ON TOP, COMMENT YOUR CODE.  PEOPLE SHOULD NOT HAVE TO READ CODE LINE
# BY LINE TO KNOW WHAT IT DOES.  ANY FUNCTION OF MORE THAN A COUPLE OF LINES SHOULD HAVE A
# DOCSTRING EXPLAINING THE INPUTS AND RETURN VALUE.  THIS SHOULD INCLUDE EXPLICIT MENTION OF THE
# EXPECTED TYPE(S).
#
# FULLY SPELL OUT WORDS.  USE PROPER ENGLISH GRAMMAR, PUNCTUATION, AND CAPITALIZATION.  USE
# DESCRIPTIVE, UNABRIDGED VARIABLE NAMES.
#
# DO NOT USE C-STYLE STRING FORMATTING, WHICH IS DEPRECATED.  DO NOT TREAT None LIKE A BOOLEAN.
# COMPLY WITH THE SYTLE GUIDE: https://www.python.org/dev/peps/pep-0008/.
#
# DO NOT USE CLASSES; THERE IS NO STATE.  FUNCTIONS SHOULD TAKE INPUTS AND PRODUCE OUTPUTS WITH
# NO SIDE EFFECTS OTHER THAN LOGGING.  DO NOT PRINT.
#
# CODE THAT DOES NOT FOLLOW THIS GUIDANCE SHALL BE CONSIDERED UNMAINTAINABLE, AT BEST, AND
# THEREFORE NOT APPROPRIATE FOR RELEASE.
# -----------------------------------------------------------------------------------------------
"""
Copyright (C) 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt

----------------------------------------------------------------------------------------

Usage:
    TODO - YOUR USAGE SYNTAX HERE.  FOR EXAMPLE:
    net add dns nameserver (ipv4 <ipv4>|ipv6 <ipv6>) [vrf <interface>]

Options:
    TODO - YOUR OPTIONS HELP TEXT HERE.  FOR EXAMPLE:
    nameserver    : An IP address of a remote DNS server
    vrf           : Virtual routing and forwarding
"""

# TODO - ADD YOUR MODULE NAME TO THE GLOBAL MODULARIZED_COMPONENTS SET IN nclu/plugins/__init__.py.
# IF YOUR MODULE SYNTAX INCLUDES "net show configuration" COMMANDS, MODIFY THE BLOCK BEGINNING
# WITH "if tokens.get("configuration") is not None:" IN nclu/execute_command.py:execute_command.

# TODO - ENABLE YOUR MODULE IN /etc/netd.conf.

# TODO - IF YOUR MODULE'S IMPLEMENTATION REQUIRES "net show config (summary|files|commands)" TO KNOW
# IF THE USER HAS EDIT PERMISSION, ADD YOUR MODULE TO THE GLOBAL PERMISSIONS_SENSITIVE_COMPONENTS
# SET IN nclu/plugins/__init__.py.

# DO NOT MAKE ANY OTHER CHANGES OUTSIDE YOUR MODULE WITHOUT CONSULTING THE NCLU MAINTAINER.

import logging
import os
from nclu import WORKING_DIRECTORY
from nclu.NetDaemon import NetDaemon
# TODO - YOU ARE LIKELY TO USE SOME OR ALL OF THESE.
#from nclu.plugins import (
#    get_config_files_helper,
#    get_pending_diffs,
#    make_scratchpads,
#    merge_messages,
#    persist_configurations,
#    remove_scratch_files_and_backups,
#    run_commands,
#)

# TODO - DECLARE MANAGED FILE PATHS AS UPPERCASE CONSTANTS.
XXX_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "<YOUR MODULE NAME>", "<FILE NAME>")

log = logging.getLogger("netd")


# TODO - IF YOUR PLUG-IN'S SYNTAX MUST BE CONSTRUCTED DYNAMICALLY, IMPLEMENT THIS FUNCTION.
# REMOVE YOUR SYNTAX FROM THE MODULE __doc__, AND MOVE IT HERE, IF APPLICABLE.  SEE
# ports.py FOR AN EXAMPLE.
#def build_doc_string():
#    pass


def commit_pending(verbose):
    """
    Copy scratchpad files over configuration files, call necessary restart commands, etc.

    Return a 2-tuple of (bool, dict).  The boolean indicates if the commit succeeded.
    The dictionary is as described in nclu/plugins/__init__.py:execute_modular.
    """

    # TODO - YOU DON'T NEED TO WORRY ABOUT DISPLAYING THE OUTPUT OF get_pending HERE.  THAT HAPPENS OUTSIDE
    # THE PLUG-IN.

    # TODO - CHECK FOR THE EXISTENCE OF SCRATCHPAD FILES.  IF NONE EXIST, THERE ARE NO CHANGES TO COMMIT.  CONSIDER USING get_pending_diffs.

    # TODO - COPY THE SCRATCHPAD FILES OVER THE CURRENT CONFIGURATION FILES.  CONSIDER USING persist_configurations.

    # TODO - EXECUTE RESTART COMMANDS, IF NECESSARY.  CONSIDER USING your plug-ins get_restart_commands and nclu/plugins/__init__.py:run_commands.

    # TODO - RETURN A 2-TUPLE.
    return (True, {"output": ''})


def show_config_commands(ifupdown2_wrapper):
#def show_config_commands(user_may_edit, ifupdown2_wrapper):       <---- PERMISSIONS SENSITIVE
    """
    net show configuration commands
    """

    # TODO - IF YOUR MODULE IS PERMISSIONS SENSITIVE, USE THE COMMENTED-OUT FUNCTION SIGNATURE ABOVE.

    # TODO - IF THE PLUG-IN IMPLEMENTS build_doc_string, AND IF THIS FUNCTION REFERENCES __doc__, build_doc_string SHOULD
    # UPDATE __doc__.  SEE ifupdown2.py FOR AN EXAMPLE.

    # TODO - RETURN A 2-TUPLE OF (list, list).  THE FIRST LIST INCLUDES SUPPORTED COMMANDS; THE SECOND, UNSUPPORTED COMMANDS.
    return ([], [])


def show_config_summary(summary):
#def show_config_summary(user_may_edit, summary):       <---- PERMISSIONS SENSITIVE
    """
    net show configuration <YOUR MODULE NAME>

    Populate the "summary" dictionary with information about the <YOUR MODULE NAME> configuration.
    """

    assert isinstance(summary, dict)

    # TODO - IF YOUR MODULE IS PERMISSIONS SENSITIVE, USE THE COMMENTED-OUT FUNCTION SIGNATURE ABOVE.

    # TODO - POPULATE THE SUMMARY DICTIONARY.  DO NOT DELETE ANYTHING FROM THE DICTIONARY, AND DO NOT RETURN A VALUE.
    # IF YOUR MODULE DOESN'T IMPLEMENT A "net show configuration ..." COMMAND, RETURN IMMEDIATELY AFTER THE ASSERT.
    #summary["<YOUR MODULE NAME>"]["<PARAMETER NAME>"] =


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """

    assert isinstance(net_daemon, NetDaemon)

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert "configuration" not in tokens, "\"net show configuration <YOUR MODULE NAME MINUS .py>\" does not use this code path."
    assert "<YOUR MODULE NAME MINUS .py>" in tokens, "Why are you here?"

    # TODO - CONSIDER USING make_scratchpads.
    # if not os.path.isfile(<SCRATCHPAD>):
    #     make_scratchpads([(<CONFIG>, <SCRATCHPAD>, <DEFAULT>)])

    # TODO - DETERMINE THE APPROPRIATE ACTIONS TO TAKE FOR THE GIVEN TOKENS.  CALL HELPER FUNCTIONS AS NECESSARY.
    # DO NOT TURN THIS FUNCTION INTO A LONG CHAIN OF NESTED IF-ELSE BLOCKS.

    # IF YOU ARE CONVERTING AN EXISTING WRAPPER TO A PLUG-IN, VIEW THE CODE IN THE FUNCTION
    # nclu/execute_command.py:post_execution, WHICH WILL NOT BE RUN FOR PLUG-INS.  MAKE SURE
    # YOU INCLUDE ANY NECESSARY FUNCTIONALITY HERE.

    # TODO - RETURN A 2-TUPLE OF (bool, dict).  THE BOOLEAN INDICATES IF THE COMMAND SUCCEEDED.
    # THE DICTIONARY IS AS DESCRIBED IN nclu/plugins/__init__.py:execute_modular.
    # messages = {"output": ''}

    raise NotImplementedError
    return (False, {"output": '', "error": ["NCLU doesn't know how to process this command."]})


def del_all():
    """
    net del all

    Revert all configuration files associated with this plug-in to their defaults.
    """

    # TODO - THIS FUNCTION DOES NOT RETURN A VALUE.  UPSTREAM CALLS abort_pending, SO
    # THOSE ACTIONS DON'T NEED TO BE REPEATED HERE.
    pass


def get_config_files():
#def get_config_files(user_may_edit):       <---- PERMISSIONS SENSITIVE
    """
    Return a string with the content of all existing, non-empty configuration files managed with this plug-in.
    """

    # TODO - IF YOUR MODULE IS PERMISSIONS SENSITIVE, USE THE COMMENTED-OUT FUNCTION SIGNATURE ABOVE.

    # TODO - CONSIDER USING get_config_files_helper.
    # return get_config_files_helper(get_managed_files())

    return ''


def get_pending(use_colors):
    """ Return a string of the pending changes in all managed files. """

    # TODO - CONSIDER USING get_pending_diffs.
    # return get_pending_diffs([(<CONFIG FILE>, <SCRATCHPAD FILE>)], use_colors)

    return ''


def abort_pending():
    # TODO - THIS FUNCTION DOES NOT RETURN A VALUE.
    # TODO - CONSIDER USING remove_scratch_files_and_backups.
    pass


def get_managed_files():
    """ Return a list of managed files. """

    return []


def get_restart_commands(filename=None):
#def get_restart_commands(filename=None, diff_lines):       <---- DYNAMIC RESTART
    """
    Return a list of commands that should be called for the given file after a rollback.
    Some plug-ins use this in commit_pending as well.
    """

    # TODO - IF THE RESTART COMMANDS RETURNED DEPENDS ON THE PARTICULARS OF THE PENDING CHANGES,
    # USE THE COMMENTED-OUT FUNCTION SIGNATURE ABOVE, AND ADD YOUR MODULE TO THE DYNAMIC_RESTART
    # SET IN nclu/plugins/__init__.py.  SEE THE DNS PLUG-IN FOR AN EXAMPLE.  SUCH AN
    # IMPLEMENTATION MIGHT REQUIRE CHANGES IN nclu/rollback.py:rollback.  PLEASE CONSULT THE
    # PACKAGE MAINTAINER BEFORE MAKING ANY CHANGES TO THAT CODE.

    assert filename is None or filename in get_managed_files(), "filename = {0}".format(filename)
    return []


# TODO - MANUALLY TEST YOUR NEW CODE WHILE RUNNING netd IN THE FOREGROUND:
# $ sudo systemctl stop netd
# $ sudo netd --debug
#
# WHEN RUNNING AS A SERVICE, assert STATEMENTS IN THE PYTHON CODE ARE DISABLED, AND THE LOG LEVEL
# IS "info".  RUNNING IN THE FOREGROUND WITH --debug IMPROVES YOUR CHANCES OF FINDING PROBLEMS
# BY ENABLING assert STATEMENTS AND SETTING THE LOG LEVEL TO "debug".
