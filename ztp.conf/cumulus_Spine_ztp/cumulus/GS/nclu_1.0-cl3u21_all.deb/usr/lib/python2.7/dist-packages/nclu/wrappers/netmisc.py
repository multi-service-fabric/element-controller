"""
Copyright (C) 2016, 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt


Usage:
    # Linux Basics
    net add hostname <text>
    net show hostname
    net del hostname
    net show version
    net show vrf
    net show bfd [detail] [json]

    # interface show commands
    net clear counters
    net show counters [json]
    net show interface (all|bonds|bondmems) [mac|json]
    net show interface [<interface>] [json]
    net show interface <interface> detail
    net show interface pluggables [json]
    net show lldp [<interface>] [json]
    net show system

Options:
    version    : A software version number
    bondmems   : Summary of bond members
    bonds      : Summary of bonds
    counters   : net show counters
    interface  : Summary info of all interfaces
    lldp       : Link Layer Discovery Protocol
    system     : System information
    all        : Everything
    pluggables : SFPs
    json       : Print output in json
    mac        : Media Access Control
"""

from collections import OrderedDict
from nclu import (
    files_match,
    get_interfaces,
    nclu_check_output,
    NCLU_VERSION,
    netshow2,
    make_pending_diff,
    tabulate_remove_unicode as tru,
    WORKING_DIRECTORY,
    WORKING_DIRECTORIES_PERMISSIONS,
)
from os.path import isdir, isfile
from subprocess import check_output, STDOUT, CalledProcessError
from tabulate import tabulate
from socket import gethostbyname, gaierror
import json
import logging
import logging.handlers
import os
import re
import shlex
import shutil

log = logging.getLogger("netd")


# hostname file constants
ETC_HOSTS = "/etc/hosts"
ETC_HOSTS_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "netmisc", "etc_hosts")
ETC_HOSTS_SCRATCHPAD_BACKUP = ETC_HOSTS_SCRATCHPAD + ".backup"

ETC_HOSTNAME = "/etc/hostname"
ETC_HOSTNAME_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "netmisc", "etc_hostname")
ETC_HOSTNAME_SCRATCHPAD_BACKUP = ETC_HOSTNAME_SCRATCHPAD + ".backup"

EXECLIST = os.path.join(WORKING_DIRECTORY, "netmisc", "execlist")

ETC_DHCP_EXIT_HOOKS = "/etc/dhcp/dhclient-exit-hooks.d/dhcp-sethostname"
ETC_DHCP_EXIT_HOOKS_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "netmisc", os.path.basename(ETC_DHCP_EXIT_HOOKS))
ETC_DHCP_EXIT_HOOKS_SCRATCHPAD_BACKUP = ETC_DHCP_EXIT_HOOKS_SCRATCHPAD + ".backup"


def hostname_valid(hostname):
    return re.match(r"""[-a-zA-Z\d\.]{1,63}""", hostname) is not None


def is_fqdn(name):
    return '.' in name


def hostname_edit(new_hostname):
    if not hostname_valid(new_hostname):
        print "\"{0}\" is an invalid hostname.  Hostnames may only contain letters, numbers, or '-'.".format(new_hostname)
        return False

    if is_fqdn(new_hostname):
        try:
            # Check with DNS to see if this (potential) FQDN can be resolved.
            gethostbyname(new_hostname)
        except gaierror:
            # The FQDN cannot be resolved. Warn the user.
            print "WARNING: DNS could not resolve the hostname entered. Please make sure the Fully Qualified Domain Name is valid."

    # Hostname changes should be made in /etc/hostname and /etc/hosts.
    # Execute the 'hostname' command to persist the change.

    # execlist
    with open(EXECLIST, 'w') as f:
        f.write("hostname {0}\n".format(new_hostname))
        f.write('echo "You must re-login for your bash prompt to reflect the hostname change"\n')

    # /etc/hostname
    with open(ETC_HOSTNAME_SCRATCHPAD, 'w') as f:
        f.write(new_hostname + '\n')

    try:
        old_hostname = check_output(["/bin/hostname"]).strip()
    except CalledProcessError as e:
        print str(e)
        return False

    with open(ETC_HOSTS) as f:
        etc_hosts_lines = [line.strip() for line in f]
        old_hostname_re = re.compile(r"""\b{0}\b""".format(old_hostname), re.IGNORECASE)

    with open(ETC_HOSTS_SCRATCHPAD, 'w') as f:
        for line in etc_hosts_lines:
            if not line.startswith('#'):
                line = old_hostname_re.sub(new_hostname, line)
            f.write(line + '\n')

    # The action succeeded.
    return True


def modify_dhcp_exit_hooks(old, new):
    """
    Modify the DHCP exit hooks sethostname file.
    If old is "yes" and new is "no", SETHOSTNAME="yes" will change to SETHOSTNAME="no"

    If NCLU sets the hostname, the DHCP sethostname file should not let DHCP change
    the hostname on system reboot.
    """

    with open(ETC_DHCP_EXIT_HOOKS) as f:
        exit_hooks_l = []
        for line in f:
            if line.startswith('SETHOSTNAME="{}"'.format(old)):
                line = 'SETHOSTNAME="{}"\n'.format(new)
            exit_hooks_l.append(line)
        new_exit_hooks = ''.join(exit_hooks_l)

    with open(ETC_DHCP_EXIT_HOOKS_SCRATCHPAD, 'w') as f:
        f.write(new_exit_hooks)


def get_pluggables(ifnames):
    data = OrderedDict()

    for ifname in ifnames:
        if re.match('swp\d+', ifname) or re.match('swp\d+s\d+', ifname):
            try:
                output = check_output(['/sbin/ethtool', '-m', ifname], stderr=STDOUT)
            except Exception:
                continue

            data[ifname] = {}

            for line in output.splitlines():
                # compress multiple spaces
                line = ' '.join(line.strip().split())

                if 'No such device' in line or 'Cannot get Module EEPROM data' in line:
                    break

                (key, value) = line.split(':', 1)
                key = key.strip()
                value = value.strip()

                if value:
                    if key == 'Identifier':
                        (number, description) = value.split(' ', 1)

                        if number.startswith('0x'):
                            number = int(number, 16)
                        elif number.isdigit():
                            number = int(number)

                        if 'no module' in description:
                            description = '(empty)'

                        data[ifname]['identifier'] = number
                        data[ifname]['identifierDescription'] = description
                    elif key == 'Vendor PN':
                        data[ifname]['vendorPartNumber'] = value
                    elif key == 'Vendor rev':
                        data[ifname]['vendorRev'] = value
                    elif key == 'Vendor name':
                        data[ifname]['vendorName'] = value
                    elif key == 'Vendor SN':
                        data[ifname]['vendorSerialNumber'] = value

    return data


def show_pluggables(cli):

    if cli.args.get("<interface>") is not None:
        assert isinstance(cli.args.get("<interface>"), str), "This should not be a list."
        ifnames = [cli.args.get("<interface>")]
    else:
        ifnames = get_interfaces()

    data = get_pluggables(ifnames)

    if cli.args.get("json") is not None:
        reply = json.dumps(data, indent=4)
    else:
        header = ("Interface", "Identifier", "Vendor Name", "Vendor PN", "Vendor SN", "Vendor Rev")
        table = []
        for (ifname, value) in data.iteritems():
            table.append((ifname,
                          "0x%02x %s" % (value.get("identifier", 0), value.get("identifierDescription")),
                          value.get("vendorName"),
                          value.get("vendorPartNumber"),
                          value.get("vendorSerialNumber"),
                          value.get("vendorRev")))
        reply = '\n' + tabulate(tru(table), header, tablefmt="simple") + "\n\n"

    return reply


def get_ifname_to_master():
    """
    Example output:

54: swp52: <BROADCAST,MULTICAST> mtu 1500 qdisc pfifo_fast state DOWN mode DEFAULT group default qlen 1000\    link/ether 00:e0:ec:27:68:e6 brd ff:ff:ff:ff:ff:ff
55: swp53: <BROADCAST,MULTICAST> mtu 1500 qdisc pfifo_fast state DOWN mode DEFAULT group default qlen 1000\    link/ether 00:e0:ec:27:68:ea brd ff:ff:ff:ff:ff:ff
56: swp54: <BROADCAST,MULTICAST> mtu 1500 qdisc pfifo_fast state DOWN mode DEFAULT group default qlen 1000\    link/ether 00:e0:ec:27:68:ee brd ff:ff:ff:ff:ff:ff
370: vrf1001: <NOARP,MASTER,UP,LOWER_UP> mtu 65536 qdisc pfifo_fast state UP mode DEFAULT group default qlen 1000\    link/ether 4a:2d:c6:02:a9:71 brd ff:ff:ff:ff:ff:ff
371: swp4.1001@swp4: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master vrf1001 state UP mode DEFAULT group default \    link/ether 00:e0:ec:27:68:ad brd ff:ff:ff:ff:ff:ff
372: swp3.1001@swp3: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master vrf1001 state UP mode DEFAULT group default \    link/ether 00:e0:ec:27:68:ac brd ff:ff:ff:ff:ff:ff
    """
    result = {}
    output = check_output(['/bin/ip', '-o', 'link', 'show'])

    for line in output.splitlines():
        re_master = re.search('^\d+:\s+(\S+):.*master\s+(\S+)', line)

        if re_master:
            ifname = re_master.group(1)

            # For swp3.1057@swp3: keep the "swp3.1057'
            if '@' in ifname:
                ifname = ifname.split('@')[0]

            result[ifname] = re_master.group(2)

    return result


def get_bgp_peers():
    """
    Return a set of all bgp peers
    """
    try:
        data = json.loads(check_output(['/usr/bin/vtysh', '-c', 'show ip bgp neighbor json']))
        return set(data.keys())
    except Exception:
        return set()


class ConfigWrapper(object):
    """
    Note that this class does not inherit from __init__.py:ConfigWrapperBase.
    """

    def __init__(self, show_linux_command, color_diffs):
        self.show_linux_command = show_linux_command
        self.color_diffs = color_diffs

    def get_managed_files(self):
        """
        TODO - This could be a free function, but the "wrappers" execution loop for rollbacks
        expects it to be a method of a ConfigWrapper instance.
        """

        return [ETC_HOSTNAME, ETC_HOSTS, ETC_DHCP_EXIT_HOOKS]

    def get_service_cmd_for_file(self, filename):
        """
        TODO - This could be a free function, but the "wrappers" execution loop for rollbacks
        expects it to be a method of a ConfigWrapper instance.
        """

        cmds = []

        if filename == ETC_HOSTNAME:
            new_hostname = None

            with open(ETC_HOSTNAME) as f:
                for line in f:
                    line = line.strip()

                    if line:
                        new_hostname = line
                        break

            if new_hostname:
                cmds.append(('hostname', new_hostname))
                cmds.append(('hostnamectl', 'set-hostname', new_hostname, '--static'))

        return cmds

    def abort_pending(self):
        """
        TODO - This could be a free function, but the "wrappers" execution loop
        expects it to be a method of a ConfigWrapper instance.
        """

        if isdir(os.path.join(WORKING_DIRECTORY, "netmisc")):
            for filename in os.listdir(os.path.join(WORKING_DIRECTORY, "netmisc")):
                full_filename = os.path.join(WORKING_DIRECTORY, "netmisc", filename)

                if os.path.isdir(full_filename):
                    shutil.rmtree(full_filename)
                else:
                    os.remove(full_filename)

    def del_all(self, cli):
        """
        TODO - This could be a free function, but the "wrappers" execution loop
        expects it to be a method of a ConfigWrapper instance.
        """

        # There's nothing to do.
        return

    def commit_pending(self, verbose):
        """
        Persistent changes, and return a 3-tuple of (bool, str, [str]).  The boolean indicates
        if the commit succeeded.  The string includes information, including errors, for the user.
        The list contains the names of the files modified.
        """

        # These files already shouldn't exist, but better safe than sorry.
        for backup_file in (ETC_HOSTS_SCRATCHPAD_BACKUP,
                            ETC_HOSTNAME_SCRATCHPAD_BACKUP,
                            ETC_DHCP_EXIT_HOOKS_SCRATCHPAD_BACKUP):
            if isfile(backup_file):
                os.remove(backup_file)

        commit_ok = True
        message = ''
        files_modified = []

        # "copyfile", used below, raises OSError is the destination directory does not exist.
        if not isdir(os.path.join(WORKING_DIRECTORY, "netmisc")):
            os.makedirs(os.path.join(WORKING_DIRECTORY, "netmisc"))

        # hostname
        if isfile(ETC_HOSTS_SCRATCHPAD) and not files_match(ETC_HOSTS, ETC_HOSTS_SCRATCHPAD):
            shutil.copyfile(ETC_HOSTS, ETC_HOSTS_SCRATCHPAD_BACKUP)
            shutil.copyfile(ETC_HOSTS_SCRATCHPAD, ETC_HOSTS)
            files_modified.append(ETC_HOSTS)

        if commit_ok and isfile(ETC_HOSTNAME_SCRATCHPAD) and not files_match(ETC_HOSTNAME, ETC_HOSTNAME_SCRATCHPAD):
            shutil.copyfile(ETC_HOSTNAME, ETC_HOSTNAME_SCRATCHPAD_BACKUP)
            shutil.copyfile(ETC_HOSTNAME_SCRATCHPAD, ETC_HOSTNAME)
            files_modified.append(ETC_HOSTNAME)

        if commit_ok and isfile(ETC_DHCP_EXIT_HOOKS_SCRATCHPAD) and not files_match(ETC_DHCP_EXIT_HOOKS, ETC_DHCP_EXIT_HOOKS_SCRATCHPAD):
            shutil.copyfile(ETC_DHCP_EXIT_HOOKS, ETC_DHCP_EXIT_HOOKS_SCRATCHPAD_BACKUP)
            shutil.copyfile(ETC_DHCP_EXIT_HOOKS_SCRATCHPAD, ETC_DHCP_EXIT_HOOKS)
            files_modified.append(ETC_DHCP_EXIT_HOOKS)

        if commit_ok and isfile(EXECLIST):
            with open(EXECLIST) as f:
                for line in f.readlines():
                    command = shlex.split(line.strip())

                    if self.show_linux_command:
                        message += "exec: %s".format(' '.join(command))

                    try:
                        output = check_output(command, stderr=STDOUT)
                        if verbose:
                            message += output
                    except CalledProcessError as e:
                        commit_ok = False
                        message += "\n\"{0}\" failed:\n{1}\n".format(' '.join(command), e)
                        revert_hostname()
                        return (False, message, [])

            os.remove(EXECLIST)

        # The commit succeeded.  Remove the scratchpad and backup files.
        for filename in (ETC_HOSTS_SCRATCHPAD,
                         ETC_HOSTNAME_SCRATCHPAD,
                         ETC_DHCP_EXIT_HOOKS_SCRATCHPAD,
                         ETC_HOSTS_SCRATCHPAD_BACKUP,
                         ETC_HOSTNAME_SCRATCHPAD_BACKUP):
            if isfile(filename):
                os.remove(filename)

        return (commit_ok, message, files_modified)

    def get_pending(self):
        """
        Return the pending diff as a string.  If there are no changes, return the empty string.
        """

        the_diff = make_pending_diff(ETC_HOSTS, ETC_HOSTS_SCRATCHPAD, self.color_diffs) \
                 + make_pending_diff(ETC_DHCP_EXIT_HOOKS, ETC_DHCP_EXIT_HOOKS_SCRATCHPAD, self.color_diffs) \
                 + make_pending_diff(ETC_HOSTNAME, ETC_HOSTNAME_SCRATCHPAD, self.color_diffs)

        return the_diff

    def show_config_files(self, user_may_edit):
        # TODO - This method doesn't need user_may_edit.

        reply = ''

        for filename in (ETC_HOSTNAME,
                         ETC_HOSTS,
                         ETC_DHCP_EXIT_HOOKS):
            if isfile(filename) and os.path.getsize(filename) > 0:
                reply += filename + '\n'
                reply += '=' * len(filename) + '\n'

                with open(filename) as f:
                    reply += f.read() + '\n'

        return reply

    def show_config_commands(self, user_may_edit, ifupdown2_wrapper):
        commands = []
        hostname = get_configured_hostname()

        if not check_dhcp_sethostname_yes() and hostname is not None:
            commands.append("net add hostname {0}".format(hostname))

        return (commands, [])

    def show_config_summary(self, user_may_edit, summary, print_json=False):
        """
        Populate the "summary" dictionary with information about the hostname.

        summary - A dictionary to hold results (call by reference)

        TODO - This should just return a value and not require passing a dictionary to hold results.
        """

        assert isinstance(summary, dict)

        hostname = get_configured_hostname()
        if not check_dhcp_sethostname_yes() and hostname is not None:
            # net show configuration [json]
            summary["hostname %s" % hostname] = []

        if print_json:
            print json.dumps(summary, indent=4)

    def eval_command_line_args(self, cli):
        """
        NetworkDocopt will populate the cli.args dictionary based on the command line args entered by the user.

        TODO - This could be a free function, but the "wrappers" execution loop in execute_command.py
        expects it to be a method of a ConfigWrapper instance.
        """

        tokens = cli.args
        command_ok = None
        output = ''

        if not os.path.isdir(os.path.join(WORKING_DIRECTORY, "netmisc")):
            # Create the scratchpad directory.
            os.makedirs(os.path.join(WORKING_DIRECTORY, "netmisc"), mode=WORKING_DIRECTORIES_PERMISSIONS)

        if "clear" in tokens and "counters" in tokens:
            # net clear counters

            cmd = ["/usr/cumulus/bin/cl-netstat", "-c"]
            try:
                check_output(cmd, stderr=STDOUT)
                command_ok = True
            except Exception as e:
                output = "\"{0}\" failed.\n{1}".format(' '.join(cmd), e)
                command_ok = False

        elif "hostname" in tokens:
            # net add|del hostname <text>
            if "add" in tokens:
                command_ok = hostname_edit(tokens.get("<text>"))
                modify_dhcp_exit_hooks("yes", "no")
            elif "del" in tokens:
                command_ok = hostname_edit("cumulus")
                modify_dhcp_exit_hooks("no", "yes")
            else:
                # net show hostname
                try:
                    output = check_output("/bin/hostname")
                    command_ok = True
                except CalledProcessError as e:
                    output = "Could not get the hostname: {0}".format(e.output)
                    command_ok = False

        elif "version" in tokens:
            # net show version

            output = "NCLU_VERSION={0}\n".format(NCLU_VERSION)

            try:
                with open("/etc/lsb-release") as f:
                    output += f.read()
                command_ok = True
            except OSError as e:
                output += str(e)
                command_ok = False

        elif "pluggables" in tokens:
            # net show interface pluggables [json]
            output = show_pluggables(cli)
            command_ok = True

        elif "vrf" in tokens:
            # net show vrf

            try:
                output = check_output(["/usr/bin/vrf", "list"])
                command_ok = True
            except CalledProcessError as e:
                output = str(e.output)
                command_ok = False

        elif "bfd" in tokens:
            command = ["/usr/bin/ptmctl", "-b"]
            if "detail" in tokens:
                command.append("-d")
            if "json" in tokens:
                command.append("-j")
            command_ok, output = nclu_check_output(command, "ptmd")

        else:
            # The remaining commands are executed with netshow2.

            if "interface" in tokens:
                if "bondmems" in tokens:
                    # net show interface bondmems [json|mac]
                    output = netshow2.net_show_interface_bondmems("mac" in tokens, "json" in tokens)
                elif "bonds" in tokens:
                    # net show interface bonds [json|mac]
                    output = netshow2.net_show_interface_bonds("mac" in tokens, "json" in tokens)
                else:
                    # net show interface all [json|mac]
                    # net show interface [<interface>] [json]
                    # net show interface <interface> detail
                    output = netshow2.net_show_interface(tokens.get("<interface>"), "mac" in tokens, "json" in tokens,
                                                         "detail" in tokens, "all" in tokens)

            elif "system" in tokens:
                # net show system
                output = netshow2.net_show_system()

            elif "lldp" in tokens:
                # net show lldp [<interface>] [json]
                output = netshow2.net_show_lldp(tokens.get("<interface>"), "json" in tokens)

            elif "counters" in tokens:
                # net show counters [json]
                output = netshow2.net_show_counters("json" in tokens)

            else:
                # This is a programming error.
                raise RuntimeError("NCLU couldn't decide how to process the command.")

            command_ok = "error:" not in output.lower()
            if not command_ok:
                # TODO - Modify netshow2.py to avoid having to strip "ERROR" from the output.
                # Have the functions return a (bool, str) 2-tuple.
                output = re.sub(r"""^\s*ERROR:\s*""", '', output, re.IGNORECASE)

        if command_ok is None:
            # This is a programming error.
            raise RuntimeError("NCLU couldn't decide how to process the command.")

        # TODO - Don't print output from wrappers.
        print output
        return command_ok


def get_configured_hostname():
    """
    Return the hostname as a string, or return None.
    """

    if isfile(ETC_HOSTNAME):
        with open(ETC_HOSTNAME) as f:
            for line in f:
                line = line.strip()

                if line:
                    return line
    return None


def revert_hostname():
    if isfile(ETC_HOSTS_SCRATCHPAD_BACKUP):
        shutil.copyfile(ETC_HOSTS_SCRATCHPAD_BACKUP, ETC_HOSTS)

    if isfile(ETC_HOSTNAME_SCRATCHPAD_BACKUP):
        shutil.copyfile(ETC_HOSTNAME_SCRATCHPAD_BACKUP, ETC_HOSTNAME)

    if isfile(ETC_DHCP_EXIT_HOOKS_SCRATCHPAD_BACKUP):
        shutil.copyfile(ETC_DHCP_EXIT_HOOKS_SCRATCHPAD_BACKUP, ETC_DHCP_EXIT_HOOKS)


def check_dhcp_sethostname_yes():
    """ If SETHOSTNAME="yes", return True; otherwise, False. """

    if os.path.isfile(ETC_DHCP_EXIT_HOOKS):
        with open(ETC_DHCP_EXIT_HOOKS) as f:
            return re.search(r'''^SETHOSTNAME="yes"''', f.read(), re.MULTILINE) is not None

    return False
