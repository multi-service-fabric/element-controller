"""
Copyright (C) 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt

----------------------------------------------------------------------------------------
Use this module to specify SNMP Agent parameters

Usage:
    # snmp-server commands
    snmp-server (add|del) snmp-server listening-address (localhost|localhost-v6)
    snmp-server (add|del) snmp-server listening-address (all|all-v6)
    snmp-server (add|del) snmp-server listening-address <ip> [vrf <text>]
    snmp-server (add|del) snmp-server listening-address <ip> <ip>
    snmp-server (add|del) snmp-server listening-address <ip> <ip> <ip>
    snmp-server (add|del) snmp-server listening-address <ip> <ip> <ip> <ip>
    snmp-server (add|del) snmp-server listening-address <ip> <ip> <ip> <ip> <ip>
    snmp-server (add|del) snmp-server listening-address <ip> <ip> <ip> <ip> <ip> <ip>
    snmp-server del       snmp-server viewname <text>
    snmp-server (add|del) snmp-server viewname <text> (included|excluded) <text>
    snmp-server del       snmp-server readonly-community <text>
    snmp-server (add|del) snmp-server readonly-community <text> access (any|localhost|<ipv4>|<ipv4/prefixlen>)
    snmp-server (add|del) snmp-server readonly-community <text> access (any|localhost|<ipv4>|<ipv4/prefixlen>) oid <text>
    snmp-server (add|del) snmp-server readonly-community <text> access (any|localhost|<ipv4>|<ipv4/prefixlen>) view <text>
    snmp-server del       snmp-server readonly-community-v6 <text>
    snmp-server (add|del) snmp-server readonly-community-v6 <text> access (any|localhost|<ipv6>|<ipv6/prefixlen>)
    snmp-server (add|del) snmp-server readonly-community-v6 <text> access (any|localhost|<ipv6>|<ipv6/prefixlen>) oid <text>
    snmp-server (add|del) snmp-server readonly-community-v6 <text> access (any|localhost|<ipv6>|<ipv6/prefixlen>) view <text>
    snmp-server del       snmp-server username <text>
    snmp-server add       snmp-server username <text>     auth-none
    snmp-server add       snmp-server username <text>     auth-none oid <text>
    snmp-server add       snmp-server username <text>     auth-none view <text>
    snmp-server add       snmp-server username <text>     (auth-md5|auth-sha) <text>
    snmp-server add       snmp-server username <text>     (auth-md5|auth-sha) <text> oid <text>
    snmp-server add       snmp-server username <text>     (auth-md5|auth-sha) <text> view <text>
    snmp-server add       snmp-server username <text>     (auth-md5|auth-sha) <text> (encrypt-des|encrypt-aes) <text>
    snmp-server add       snmp-server username <text>     (auth-md5|auth-sha) <text> (encrypt-des|encrypt-aes) <text> oid <text>
    snmp-server add       snmp-server username <text>     (auth-md5|auth-sha) <text> (encrypt-des|encrypt-aes) <text> view <text>
    snmp-server add snmp-server system-location <wildcard>
    snmp-server del snmp-server system-location [<wildcard>]
    snmp-server add snmp-server system-contact  <wildcard>
    snmp-server del snmp-server system-contact  [<wildcard>]
    snmp-server add snmp-server system-name     <wildcard>
    snmp-server del snmp-server system-name     [<wildcard>]
    # snmpv3 traps are special
    snmp-server add snmp-server trap-destination (localhost|localhost-v6|<ip>) [vrf <text>] username <text> (auth-md5|auth-sha) <text> engine-id <text> [inform]
    snmp-server add snmp-server trap-destination (localhost|localhost-v6|<ip>) [vrf <text>] username <text> (auth-md5|auth-sha) <text> (encrypt-des|encrypt-aes) <text> engine-id <text> [inform]
    # the rest
    snmp-server add snmp-server trap-destination (localhost|localhost-v6|<ip>) [vrf <text>] community-password <text>
    snmp-server add snmp-server trap-destination (localhost|localhost-v6|<ip>) [vrf <text>] community-password <text> version (1|2c)
    snmp-server del snmp-server trap-destination (localhost|localhost-v6|<ip>) [vrf <text>]
    # specific traps
    snmp-server add snmp-server trap-link-up [check-frequency <5-300>]
    snmp-server del snmp-server trap-link-up
    snmp-server add snmp-server trap-link-down [check-frequency <5-300>]
    snmp-server del snmp-server trap-link-down
    snmp-server (add|del) snmp-server trap-snmp-auth-failures
    snmp-server add snmp-server trap-cpu-load-average one-minute <text-cpu-load>
    snmp-server add snmp-server trap-cpu-load-average one-minute <text-cpu-load> five-minute <text-cpu-load>
    snmp-server add snmp-server trap-cpu-load-average one-minute <text-cpu-load> five-minute <text-cpu-load> fifteen-minute <text-cpu-load>
    snmp-server del snmp-server trap-cpu-load-average
    snmp-server del snmp-server all
    snmp-server show snmp-server status
    snmp-server example snmp-server
    net show configuration snmp-server

Options:
    snmp-server : Configure the SNMP server
    listening-address : Configure the one or more (comma separated) listening IP address(s).
    trap-destination : Configure the destination IP address where TRAP/INFORM messages are sent.
    trap-snmp-auth-failures : Enable or disable Traps for SNMP Authentication failures.
    trap-cpu-load-average : Enable or disable Traps for CPU Load Average thresholds.
    one-minute : One Minute load average threshold to send SNMP Trap (e.g.  2.76)
    five-minute : Five Minute load average threshold to send SNMP Trap (e.g.  2.76)
    fifteen-minute : Fifteen Minute load average threshold to send SNMP Trap (e.g.  2.76)
    trap-link-up : Enable or disable SNMP Traps for interface link-up status.
    trap-link-down : Enable or disable SNMP Traps for interface link-down status.
    check-frequency : Sets the link up or link down checking frequency in seconds (default is 60s)
    localhost : Defines the IPv4 loopback for listening-address or localhost sourced requests for access restriction.
    all-v6 : Defines any IPv6 address configured.
    localhost-v6 : Defines the IPv6 loopback for listening-address or localhost sourced requests for access restriction.
    <text-cpu-load> : Numerical value for CPU Load Average (e.g. 2.45, 4, 10)
    any : Allows requests from any source.
    2c : SNMP Version 2c
    included : Includes a OID MIB Tree or name in a viewname
    excluded : Excludes a OID MIB Tree or name in a viewname
    viewname : Define a view name to restrict MIB tree exposure.  This can be linked to a community string or SNMPv3 username
    view : Refers to a view name for restricting MIB tree exposure.
    oid : SNMP Object Identifer as either a dotted decimal string or object name
    readonly-community : Defines a read-only community string password for version 1 or 2c access for IPv4.
    readonly-community-v6 : Defines a read-only community string password for version 1 or 2c access for IPv6.
    community-password : A text string that will be used as a password for SNMP version 1 or 2c.
    access : For bridging, a type of port that is non-trunking.  For dot1x, an IP source address or network that will be serviced.
    username : Defines an SNMPv3 username.
    system-location : Sets the SNMPv2-MIB system location field
    system-contact : Sets the SNMPv2-MIB system contact field
    system-name : Sets the SNMPv2-MIB system name field
    auth-none : No SNMPv3 authentication or encryption
    auth-sha : Sets SNMPv3 Secure Hash Algorithm for authentication
    auth-md5 : Sets SNMPv3 Message Digest 5 Algorithm for authentication
    encrypt-des : Sets SNMPv3 Data Encryption Algorithm for encryption
    encrypt-aes : Sets SNMPv3 Advanced Encryption Standard for encryption

"""

from difflib import Differ
from nclu import tabulate_remove_unicode as tru, WORKING_DIRECTORIES_PERMISSIONS
from nclu.NetDaemon import NetDaemon
from nclu.plugins import (
    get_config_files_helper,
    get_pending_diffs,
    make_scratchpads,
    merge_messages,
    persist_configurations,
    remove_scratch_files_and_backups,
    run_commands)
from collections import OrderedDict
from subprocess import check_output, CalledProcessError
from tabulate import tabulate
from ipaddr import IPNetwork, IPAddress, IPv6Address, IPv4Address
import json
import logging
import logging.handlers
import os
import re
import shutil
import glob
import copy

log = logging.getLogger("netd")

USERNAME_CACHE = "/var/lib/snmp/snmpd.conf"
SNMP_SCRATCH_DIR = "/run/nclu/snmp/"
SCRATCH_CONFIG_FILE = "/run/nclu/snmp/snmpd.conf"
TEMP_CONFIG_FILE = "/run/nclu/snmp/temp_snmpd.conf"
SNMPD_CONFIG_FILE = "/etc/snmp/snmpd.conf"

'''
config_array is indexed by the nclu configuration keywords.  It
contains the following:
    config-name: a list of snmpd.conf keywords used for this keyword
    handler    : function used to convert from nclu to snmpd.conf settings.
    field-name : used when a single field can be selected from nclu
    regex_nclu_to_conf: array indexed by snmpd conf keyword that contains
      list of tuples for (pattern, replacement) for writing snmpd.conf.
    regex_conf_to_nclu: array indexed by snmpd conf keyword that
      contains list of tuples for (pattern, replacement) for
      converting snmpd.conf to nclu config
    hidden-entries: list of keywords used internally that will not be shown
'''
config_array = {'listening-address' : {'config-name'  : ['agentaddress'],
                                       'handler'      : 'listening_address_handler',
                                       'hidden-entries' : [],
                                       'field-name'   : '<ip>',
                                       'regex_nclu_to_conf' : {
                                           'agentaddress' : [
                                               (r'''(?P<ipaddress>\S+)\s+vrf\s+(?P<vrfname>\S+)''', '{}%{}'),
                                               (r'''(?P<ipaddress>\S+)''', '{}'),
                                           ],
                                       },
                                       'regex_conf_to_nclu' : {
                                           'agentaddress' : [
                                               # just show all the IP addresses given.  These have already been converted
                                               (r'''(?P<ipaddr>\S+)%(?P<vrfname>\S+)''', '{} vrf {}'),
                                               (r'''(?P<ipaddr>\S+)''', '{}'),
                                           ],
                                       },
                                       # these substitutions are for going from a config file to nclu keywords
                                       'sub_conf_to_nclu' : {
                                           'agentaddress' : [(r',', ' '),
                                                             (r'\[::1\]', 'localhost-v6'),
                                                             (r'\[::\]', 'all-v6'),
                                                             (r'\[', ''),
                                                             (r'\]', ''),
                                                             (r'udp:161', 'all'),
                                                             (r'127.0.0.1', 'localhost')]},
                                       'sub_nclu_to_conf' : {
                                           'agentaddress' : [(r'all-v6', '::'),
                                                             (r'all', 'udp:161'),
                                                             (r'localhost-v6', '::1'),
                                                             (r'localhost', '127.0.0.1')]},
                                      },
                'viewname': {'config-name'  : ['view'],
                             'handler'      : 'viewname_handler',
                             'hidden-entries' : [],
                             'field-name'   : '<text>',
                             'regex_conf_to_nclu' : {
                                 'view' : [
                                     (r'''(?P<viewname>\S+)\s+included\s+(?P<oidname>\S+)''', '{} included {}'),
                                     (r'''(?P<viewname>\S+)\s+excluded\s+(?P<oidname>\S+)''', '{} excluded {}'),
                                 ],
                             },
                            },
                'trap-snmp-auth-failures': {'config-name' : ['authtrapenable'],
                                            'handler'      : 'trap_auth_handler',
                                            'hidden-entries' : ['2'],
                                            'regex_nclu_to_conf' : [
                                                (r'''trap-snmp-auth-failures''', '1'),
                                            ],
                                            'regex_conf_to_nclu' : {
                                                'authtrapenable' : [
                                                    # only handle a 1 since other values will not show up
                                                    # when showing this config, we show a space
                                                    (r'''(1)''', ' '),
                                                ],
                                            },
                                           },
                'trap-destination': {'config-name'  : ['trapsink', 'trap2sink', 'trapsess'],
                                     'handler'      : 'trap_destination_handler',
                                     'hidden-entries' : [],
                                     'field-name'   : '<text>',
                                     'regex_nclu_to_conf' :
                                         # for snmp v3 traps and informs looks something like this
                                         # trapsess -Ci -e  0x80ccff112233445566778899  -v3 -l authPriv -u  trapuser1 -a MD5 -A  trapuser1password -x  DES -X  trapuser1encryption  192.168.1.1
                                         # Here, we can construct lists with comprehensions to keep things simple
                                         # do both authentication and encryption
                                         [('(?P<ipaddr>\S+)\s+vrf\s+(?P<vrfname>\S+)\s+username\s+(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+encrypt-%s\s+(?P<encrypt>\S+)\s+engine-id\s+(?P<engineid>\S+)\s+inform' % (auth, encr),
                                           r'trapsess -Ci -e {5} -v3 -l authPriv -u {2} -a %s -A {3} -x %s -X {4} {0}%%{1}' % (auth.upper(), encr.upper())) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                         # no inform
                                         + [('(?P<ipaddr>\S+)\s+vrf\s+(?P<vrfname>\S+)\s+username\s+(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+encrypt-%s\s+(?P<encrypt>\S+)\s+engine-id\s+(?P<engineid>\S+)' % (auth, encr),
                                             r'trapsess -e {5} -v3 -l authPriv -u {2} -a %s -A {3} -x %s -X {4} {0}%%{1}' % (auth.upper(), encr.upper())) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                         # now with no VRF
                                         + [('(?P<ipaddr>\S+)\s+username\s+(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+encrypt-%s\s+(?P<encrypt>\S+)\s+engine-id\s+(?P<engineid>\S+)\s+inform' % (auth, encr),
                                             r'trapsess -Ci -e {4} -v3 -l authPriv -u {1} -a %s -A {2} -x %s -X {3} {0}' % (auth.upper(), encr.upper())) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                         # no inform
                                         + [('(?P<ipaddr>\S+)\s+username\s+(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+encrypt-%s\s+(?P<encrypt>\S+)\s+engine-id\s+(?P<engineid>\S+)' % (auth, encr),
                                             r'trapsess -e {4} -v3 -l authPriv -u {1} -a %s -A {2} -x %s -X {3} {0}' % (auth.upper(), encr.upper())) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                         ##################################
                                         # VRF and inform do only authentication
                                         + [('(?P<ipaddr>\S+)\s+vrf\s+(?P<vrfname>\S+)\s+username\s+(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+engine-id\s+(?P<engineid>\S+)\s+inform' % (auth),
                                             r'trapsess -Ci -e {4} -v3 -l authNoPriv -u {2} -a %s -A {3} {0}%%{1}' % (auth.upper())) for auth in ['md5', 'sha']]
                                         # no inform
                                         + [('(?P<ipaddr>\S+)\s+vrf\s+(?P<vrfname>\S+)\s+username\s+(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+engine-id\s+(?P<engineid>\S+)' % (auth),
                                             r'trapsess -e {4} -v3 -l authNoPriv -u {2} -a %s -A {3} {0}%%{1}' % (auth.upper())) for auth in ['md5', 'sha']]
                                         # now with no VRF
                                         + [('(?P<ipaddr>\S+)\s+username\s+(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+engine-id\s+(?P<engineid>\S+)\s+inform' % (auth),
                                             r'trapsess -Ci -e {3} -v3 -l authNoPriv -u {1} -a %s -A {2} {0}' % (auth.upper())) for auth in ['md5', 'sha']]
                                         # no inform
                                         + [('(?P<ipaddr>\S+)\s+username\s+(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+engine-id\s+(?P<engineid>\S+)' % (auth),
                                             r'trapsess -e {3} -v3 -l authNoPriv -u {1} -a %s -A {2} {0}' % (auth.upper())) for auth in ['md5', 'sha']]
                                         # trapsink and trap2sink
                                         + [(r'''(?P<ipaddr>\S+)\s+vrf\s+(?P<vrfname>\S+)\s+community-password\s+(?P<password>\S+)\s+version\s+1''', 'trapsink {}%{} {}'),
                                            (r'''(?P<ipaddr>\S+)\s+community-password\s+(?P<password>\S+)\s+version\s+1''', 'trapsink {} {}'),
                                            (r'''(?P<ipaddr>\S+)\s+vrf\s+(?P<vrfname>\S+)\s+community-password\s+(?P<password>\S+)\s+version\s+2c''', 'trap2sink {}%{} {}'),
                                            (r'''(?P<ipaddr>\S+)\s+community-password\s+(?P<password>\S+)\s+version\s+2c''', 'trap2sink {} {}'),
                                            (r'''(?P<ipaddr>\S+)\s+vrf\s+(?P<vrfname>\S+)\s+community-password\s+(?P<password>\S+)''', 'trap2sink {}%{} {}'),
                                            (r'''(?P<ipaddr>\S+)\s+community-password\s+(?P<password>\S+)''', 'trap2sink {} {}'),
                                            (r'''(?P<ipaddr>\S+)\s+vrf\s+(?P<vrfname>\S+)''', 'trap2sink {}%{}'),
                                            (r'''(?P<ipaddr>\S+)''', 'trap2sink {}'),
                                           ],
                                     'regex_conf_to_nclu' : {
                                             'trapsink' : [
                                                 (r'''(?P<ipaddr>\S+)%(?P<vrfname>\S+)\s+(?P<password>\S+)''', '{} vrf {} community-password {} version 1'),
                                                 (r'''(?P<ipaddr>\S+)\s+(?P<password>\S+)''', '{} community-password {} version 1'),
                                             ],
                                             'trap2sink' : [
                                                 (r'''(?P<ipaddr>\S+)%(?P<vrfname>\S+)\s+(?P<password>\S+)''', '{} vrf {} community-password {} version 2c'),
                                                 (r'''(?P<ipaddr>\S+)\s+(?P<password>\S+)''', '{} community-password {} version 2c'),
                                             ],
                                             'trapsess'  :
                                                 # Here, we can construct lists with comprehensions to keep things simple
                                                 # do both authentication and encryption
                                                 # VRF, inform, and auth with encrypt
                                                 [(r'-Ci\s+-e\s+(?P<engineid>\S+)\s+-v3\s+-l\s+authPriv\s+-u\s+(?P<name>\S+)\s+-a\s+%s\s+-A\s+(?P<auth>\S+)\s+-x\s+%s\s+-X\s+(?P<encrypt>\S+)\s+(?P<ipaddr>\S+)%%(?P<vrfname>\S+)' % (auth.upper(), encr.upper()),
                                                   '{4} vrf {5} username {1} auth-%s {2} encrypt-%s {3} engine-id {0} inform' % (auth, encr)) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                                 # no inform
                                                 + [(r'-e\s+(?P<engineid>\S+)\s+-v3\s+-l\s+authPriv\s+-u\s+(?P<name>\S+)\s+-a\s+%s\s+-A\s+(?P<auth>\S+)\s+-x\s+%s\s+-X\s+(?P<encrypt>\S+)\s+(?P<ipaddr>\S+)%%(?P<vrfname>\S+)' % (auth.upper(), encr.upper()),
                                                     '{4} vrf {5} username {1} auth-%s {2} encrypt-%s {3} engine-id {0}' % (auth, encr)) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                                 # no VRF
                                                 + [(r'-Ci\s+-e\s+(?P<engineid>\S+)\s+-v3\s+-l\s+authPriv\s+-u\s+(?P<name>\S+)\s+-a\s+%s\s+-A\s+(?P<auth>\S+)\s+-x\s+%s\s+-X\s+(?P<encrypt>\S+)\s+(?P<ipaddr>\S+)' % (auth.upper(), encr.upper()),
                                                     '{4} username {1} auth-%s {2} encrypt-%s {3} engine-id {0} inform' % (auth, encr)) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                                 # no VRF no inform
                                                 + [(r'-e\s+(?P<engineid>\S+)\s+-v3\s+-l\s+authPriv\s+-u\s+(?P<name>\S+)\s+-a\s+%s\s+-A\s+(?P<auth>\S+)\s+-x\s+%s\s+-X\s+(?P<encrypt>\S+)\s+(?P<ipaddr>\S+)' % (auth.upper(), encr.upper()),
                                                     '{4} username {1} auth-%s {2} encrypt-%s {3} engine-id {0}' % (auth, encr)) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                                 #######################################
                                                 # VRF, inform, and auth without encrypt
                                                 + [(r'-Ci\s+-e\s+(?P<engineid>\S+)\s+-v3\s+-l\s+authNoPriv\s+-u\s+(?P<name>\S+)\s+-a\s+%s\s+-A\s+(?P<auth>\S+)\s+(?P<ipaddr>\S+)%%(?P<vrfname>\S+)' % (auth.upper()),
                                                     '{3} vrf {4} username {1} auth-%s {2} engine-id {0} inform' % (auth)) for auth in ['md5', 'sha']]
                                                 # no inform
                                                 + [(r'-e\s+(?P<engineid>\S+)\s+-v3\s+-l\s+authNoPriv\s+-u\s+(?P<name>\S+)\s+-a\s+%s\s+-A\s+(?P<auth>\S+)\s+(?P<ipaddr>\S+)%%(?P<vrfname>\S+)' % (auth.upper()),
                                                     '{3} vrf {4} username {1} auth-%s {2} engine-id {0}' % (auth)) for auth in ['md5', 'sha']]
                                                 # no VRF
                                                 + [(r'-Ci\s+-e\s+(?P<engineid>\S+)\s+-v3\s+-l\s+authNoPriv\s+-u\s+(?P<name>\S+)\s+-a\s+%s\s+-A\s+(?P<auth>\S+)\s+(?P<ipaddr>\S+)' % (auth.upper()),
                                                     '{3} username {1} auth-%s {2} engine-id {0} inform' % (auth)) for auth in ['md5', 'sha']]
                                                 # no VRF no inform
                                                 + [(r'-e\s+(?P<engineid>\S+)\s+-v3\s+-l\s+authNoPriv\s+-u\s+(?P<name>\S+)\s+-a\s+%s\s+-A\s+(?P<auth>\S+)\s+(?P<ipaddr>\S+)' % (auth.upper()),
                                                     '{3} username {1} auth-%s {2} engine-id {0}' % (auth)) for auth in ['md5', 'sha']]
                                                 },
                                     'sub_conf_to_nclu' : {
                                         'trapsink'  : [(r'127.0.0.1', 'localhost'),
                                                        (r'\[::1\]',   'localhost-v6')],
                                         'trap2sink' : [(r'127.0.0.1', 'localhost'),
                                                        (r'\[::1\]',   'localhost-v6')],
                                         'trapsess'  : [(r'127.0.0.1', 'localhost'),
                                                        (r'\[::1\]',   'localhost-v6')],
                                     },
                                     'sub_nclu_to_conf' : [(r'localhost-v6', '[::1]'), (r'localhost', '127.0.0.1')],
                                     },
                'trap-link-up': {'config-name'  : ['monitor'],
                                 'handler'      : 'trap_link_handler',
                                 'hidden-entries' : [],
                                 'field-name'   : '<5-300>',
                                 'regex_nclu_to_conf' : [
                                     (r'''trap-link-up\s+check-frequency\s+(?P<frequency>\S+)''',
                                      'CumulusLinkUP -S -r {} -o ifName -o ifIndex -o ifAdminStatus -o ifOperStatus ifOperStatus != 2'),
                                     (r'''trap-link-up''',
                                      'CumulusLinkUP -S -r 60 -o ifName -o ifIndex -o ifAdminStatus -o ifOperStatus ifOperStatus != 2'),
                                 ],
                                 'regex_conf_to_nclu' : {
                                     'monitor' : [
                                         (r'''CumulusLinkUP -S -r\s+(?P<frequency>\S+)\s+-o ifName -o ifIndex -o ifAdminStatus -o ifOperStatus ifOperStatus != 2''',
                                          'check-frequency {}'),
                                     ],
                                 },
                                },
                'trap-link-down': {'config-name'  : ['monitor'],
                                   'handler'      : 'trap_link_handler',
                                   'hidden-entries' : [],
                                   'field-name'   : '<5-300>',
                                   'regex_nclu_to_conf' : [
                                       (r'''trap-link-down\s+check-frequency\s+(?P<frequency>\S+)''',
                                        'CumulusLinkDOWN -S -r {} -o ifName -o ifIndex -o ifAdminStatus -o ifOperStatus ifOperStatus == 2'),
                                       (r'''trap-link-down''',
                                        'CumulusLinkDOWN -S -r 60 -o ifName -o ifIndex -o ifAdminStatus -o ifOperStatus ifOperStatus == 2'),
                                   ],
                                   'regex_conf_to_nclu' : {
                                       'monitor' : [
                                           (r'''CumulusLinkDOWN -S -r\s+(?P<frequency>\S+)\s+-o ifName -o ifIndex -o ifAdminStatus -o ifOperStatus ifOperStatus == 2''',
                                            'check-frequency {}'),
                                       ],
                                   },
                                  },
                'trap-cpu-load-average': {'config-name'  : ['load'],
                                          'handler'      : 'trap_load_handler',
                                          'hidden-entries' : [],
                                          'field-name'   : '<text>',
                                          'regex_nclu_to_conf' : [
                                              (r'''one-minute\s+(?P<onemin>\S+)\s+five-minute\s+(?P<fivemin>\S+)\s+fifteen-minute\s+(?P<fifteenmin>\S+)''',
                                               '{} {} {}'),
                                              (r'''one-minute\s+(?P<onemin>\S+)\s+five-minute\s+(?P<fivemin>\S+)''',
                                               '{} {} 0'),
                                              (r'''one-minute\s+(?P<onemin>\S+)''',
                                               '{} 0 0')
                                          ],
                                          'regex_conf_to_nclu' : {
                                              'load' : [
                                                  (r'''(?P<onemin>\S+)\s+(?P<fivemin>\S+)\s+(?P<fifteenmin>\S+)''',
                                                   'one-minute {} five-minute {} fifteen-minute {}'),
                                              ],
                                          },
                                         },
                'readonly-community': {'config-name'  : ['rocommunity'],
                                       'handler'      : 'readonly_community_handler',
                                       'hidden-entries' : [],
                                       'field-name'   : '<text>',
                                       'regex_nclu_to_conf' : {
                                           'rocommunity' : [
                                               (r'''(?P<password>\S+)\s+access\s+(?P<accessname>\S+)\s+view\s+(?P<viewname>\S+)''', '{} {} -V {}'),
                                               (r'''(?P<password>\S+)\s+access\s+(?P<accessname>\S+)\s+oid\s+(?P<oidname>\S+)''', '{} {} {}'),
                                               (r'''(?P<password>\S+)\s+access\s+(?P<accessname>\S+)''', '{} {}'),
                                               (r'''(?P<password>\S+)''', '{}')
                                           ],
                                       },
                                       'regex_conf_to_nclu' : {
                                           'rocommunity' : [
                                               (r'''(?P<roname>\S+)\s+(?P<accessname>\S+)\s+-V\s+(?P<viewname>\S+)''', '{} access {} view {}'),
                                               (r'''(?P<roname>\S+)\s+(?P<accessname>\S+)\s+(?P<oidname>\S+)''', '{} access {} oid {}'),
                                               (r'''(?P<roname>\S+)\s+(?P<accessname>\S+)''', '{} access {}'),
                                           ],
                                       },
                                       'sub_conf_to_nclu' : {
                                           'rocommunity' : [(r'default', 'any'), ('127.0.0.1', 'localhost')],
                                       },
                                       'sub_nclu_to_conf' : {
                                           'rocommunity' : [(r'any', 'default'), (r'localhost', '127.0.0.1')],
                                       },
                                      },
                'readonly-community-v6': {'config-name'  : ['rocommunity6'],
                                          'handler'      : 'readonly_community_handler',
                                          'hidden-entries' : [],
                                          'field-name'   : '<text>',
                                          'regex_nclu_to_conf' : {
                                              'rocommunity6' : [
                                                  (r'''(?P<password>\S+)\s+access\s+(?P<accessname>\S+)\s+view\s+(?P<viewname>\S+)''', '{} {} -V {}'),
                                                  (r'''(?P<password>\S+)\s+access\s+(?P<accessname>\S+)\s+oid\s+(?P<oidname>\S+)''', '{} {} {}'),
                                                  (r'''(?P<password>\S+)\s+access\s+(?P<accessname>\S+)''', '{} {}'),
                                                  (r'''(?P<password>\S+)''', '{}')
                                              ],
                                          },
                                          'regex_conf_to_nclu' : {
                                              'rocommunity6' : [
                                                  (r'''(?P<roname>\S+)\s+(?P<accessname>\S+)\s+-V\s+(?P<viewname>\S+)''', '{} access {} view {}'),
                                                  (r'''(?P<roname>\S+)\s+(?P<accessname>\S+)\s+(?P<oidname>\S+)''', '{} access {} oid {}'),
                                                  (r'''(?P<roname>\S+)\s+(?P<accessname>\S+)''', '{} access {}'),
                                              ],
                                          },
                                          'sub_conf_to_nclu' : {
                                              'rocommunity6' : [(r'default', 'any'), (' +::1', ' localhost')]
                                          },
                                          'sub_nclu_to_conf' : { 'rocommunity6' : [(r'any', 'default'), (r' +localhost', ' ::1')]
                                                               },
                                         },
                'system-location': {'config-name' : ['syslocation'],
                                    'handler'      : 'sys_handler',
                                    'hidden-entries' : [],
                                    'field-name'   : '<wildcard>',
                                    'regex_conf_to_nclu' : {
                                        'syslocation' : [
                                            (r'''(.*)''', '{}'),
                                        ],
                                    },
                                   },
                'system-contact': {'config-name' : ['syscontact'],
                                   'handler'      : 'sys_handler',
                                   'hidden-entries' : [],
                                   'field-name'   : '<wildcard>',
                                   'regex_conf_to_nclu' : {
                                       'syscontact' : [
                                           (r'''(.*)''', '{}'),
                                       ],
                                   },
                                  },
                'system-name': {'config-name' : ['sysname'],
                                'handler'      : 'sys_handler',
                                'hidden-entries' : [],
                                'field-name'   : '<wildcard>',
                                'regex_conf_to_nclu' : {
                                    'sysname' : [
                                        (r'''(.*)''', '{}'),
                                    ],
                                },
                               },
                'username': {'config-name'  : ['createuser', 'rouser'],
                             'hidden-entries' : ['_snmptrapusernameX'],
                             'handler'      : 'username_handler',
                             'field-name'   : '<text>',
                             'regex_nclu_to_conf' : {
                                 # again, we create a list of tuples (pattern, replacement)
                                 # that will be used to convert between NCLU configs and snmpd.conf config lines.
                                 # And also in the other direction.
                                 'createuser' :
                                     [('(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+encrypt-%s\s+(?P<encr>\S+)\s+view\s+\S+' % (auth, encr),
                                       r'{0} %s {1} %s {2}' % (auth.upper(), encr.upper())) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                     + [('(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+encrypt-%s\s+(?P<encr>\S+)\s+oid\s+\S+' % (auth, encr),
                                         r'{0} %s {1} %s {2}' % (auth.upper(), encr.upper())) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                     + [('(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+encrypt-%s\s+(?P<encr>\S+)' % (auth, encr),
                                         r'{0} %s {1} %s {2}' % (auth.upper(), encr.upper())) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                     + [('(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)\s+%s\s+\S+' % (auth, oidview),
                                         r'{0} %s {1}' % (auth.upper())) for auth in ['md5', 'sha'] for oidview in ['oid', 'view']]
                                     + [(r'(?P<name>\S+)\s+auth-%s\s+(?P<auth>\S+)' % (auth), r'{0} %s {1}' % (auth.upper())) for auth in ['md5', 'sha']]
                                     + [(r'(?P<name>\S+)\s+auth-none\s+%s\s+(?P<auth>\S+)' % (oidview), r'{0}') for oidview in ['oid', 'view']]
                                     + [(r'(?P<name>\S+)\s+auth-none', '{}'),
                                        (r'(?P<name>\S+)', '{}')],
                                 'rouser' :
                                     [('(?P<name>\S+)\s+auth-%s\s+\S+\s+encrypt-%s\s+\S+\s+view\s+(?P<view>\S+)' % (auth, encr),
                                       r'{0} priv -V {1}') for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                     + [('(?P<name>\S+)\s+auth-%s\s+\S+\s+encrypt-%s\s+\S+\s+oid\s+(?P<oid>\S+)' % (auth, encr),
                                       r'{0} priv {1}') for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                     + [('(?P<name>\S+)\s+auth-%s\s+\S+\s+encrypt-%s\s+\S+' % (auth, encr), r'{0} priv') for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                     + [('(?P<name>\S+)\s+auth-%s\s+\S+\s+view\s+(?P<view>\S+)' % (auth), r'{0} auth -V {1}') for auth in ['md5', 'sha']]
                                     + [('(?P<name>\S+)\s+auth-%s\s+\S+\s+oid\s+(?P<oid>\S+)' % (auth), r'{0} auth {1}') for auth in ['md5', 'sha']]
                                     + [('(?P<name>\S+)\s+auth-%s\s+\S+' % (auth), r'{0} auth') for auth in ['md5', 'sha']]
                                     + [(r'(?P<name>\S+)\s+auth-none\s+view\s+(?P<view>\S+)', '{} noauth -V {}'),
                                        (r'(?P<name>\S+)\s+auth-none\s+oid\s+(?P<oid>\S+)', '{} noauth {}'),
                                        (r'(?P<name>\S+)\s+auth-none', '{} noauth'),
                                        (r'(?P<name>\S+)', '{}'),
                                       ]},
                             'regex_conf_to_nclu' : {
                                 'createuser' :
                                     [(r'(?P<name>\S+)\s+%s\s+(?P<auth>\S+)\s+%s\s+(?P<encr>\S+)' % (auth.upper(), encr.upper()),
                                       '{} auth-%s {} encrypt-%s {}' % (auth, encr)) for auth in ['md5', 'sha'] for encr in ['aes', 'des']]
                                     + [(r'(?P<name>\S+)\s+%s\s+(?P<auth>\S+)' % (auth.upper()), '{} auth-%s {}' % (auth)) for auth in ['md5', 'sha']]
                                     + [(r'(?P<name>\S+)', '{} auth-none')],
                                 'rouser' :
                                     [(r'(?P<name>\S+)\s+%s\s+-V\s+(?P<view>\S+)' % (auth), '{} view {}') for auth in ['noauth', 'priv', 'auth']]
                                     + [(r'(?P<name>\S+)\s+%s\s+(?P<oid>\S+)' % (auth), '{} oid {}') for auth in ['noauth', 'priv', 'auth']],
                             },
                            }
                }

default_config_array = {'agentaddress': ['127.0.0.1'],
                        'agentxperms': ['777 777 snmp snmp'],
                        'agentxsocket': ['/var/agentx/master'],
                        'createuser': ['_snmptrapusernameX'],
                        'iquerysecname': ['_snmptrapusernameX'],
                        'master': ['agentx'],
                        'monitor' : ['-r 60 -o laNames -o laErrMessage "laTable" laErrorFlag != 0'],
                        'pass': ['-p 10 1.3.6.1.2.1.1.1 /usr/share/snmp/sysDescr_pass.py'],
                        'pass_persist': [
                            '1.3.6.1.2.1.31.1.1.1.18 /usr/share/snmp/snmpifAlias_pp.py',
                            '1.3.6.1.4.1.40310.1 /usr/share/snmp/resq_pp.py',
                            '1.3.6.1.4.1.40310.2 /usr/share/snmp/cl_drop_cntrs_pp.py',
                            '1.3.6.1.2.1.17 /usr/share/snmp/bridge_pp.py',
                            '1.3.6.1.2.1.47 /usr/share/snmp/entity_pp.py',
                            '1.3.6.1.2.1.99 /usr/share/snmp/entity_sensor_pp.py',
                            '1.2.840.10006.300.43 /usr/share/snmp/ieee8023_lag_pp.py'
                        ],
                        'rouser': ['_snmptrapusernameX'],
                        'sysobjectid': ['1.3.6.1.4.1.40310'],
                        'sysservices': ['72']
                       }

def sys_handler(running_array, conf_word, args, argv_expanded):
    '''
    sys_handler() is a simple method that converts nclu
    config for system-location, contact, and name.
    '''
    cli_dict = config_array.get(conf_word, {})
    config_names = cli_dict.get('config-name', [])
    for config_name in config_names:
        current_list = running_array.get(config_name, [])
        add_del = args.get('add') or args.get('del')
        field_name = cli_dict.get('field-name', None)
        entered_value = args.get(field_name, [])
        if add_del == 'add' and field_name:
            # and add will just overwrite the value
            running_array[config_name] = [entered_value]
        elif add_del == 'del' and running_array.has_key(config_name):
            del running_array[config_name]

    return (True, running_array, {})

def trap_destination_handler(running_array, conf_word, args, argv_expanded):
    '''
    The trap destination handler creates the trapsink or trap2sink in
    snmpd.conf. If it contains a version parameter, it will get get
    set accordingly: version 1 creates trapsink, version 2c creates
    trap2sink config.  If no version is specified, version 2c will be
    used.
    '''
    # this should be a list of 1 item
    cli_dict = config_array.get(conf_word, {})
    add_del = args.get('add') or args.get('del')
    msg = ''

    if argv_expanded and len(argv_expanded) > 4 and \
       argv_expanded[3] == 'trap-destination':
        # we can only deal with strings for joining
        entered_line = [str(i) for i in argv_expanded[4:]]
        entered_line = ' '.join(entered_line)
    else:
        return (False, running_array, {'error' : ['Invalid trap-destination command entered']})

    sublist = cli_dict.get('sub_nclu_to_conf', [])
    regexlist = cli_dict.get('regex_nclu_to_conf', [])
    # entered line will include either the trapsink or trap2sink
    # keyword.  This is different then other conversions
    entered_line = converter(entered_line, sublist, regexlist)
    trap_word = entered_line.split()[0]
    # now we can remove the leading trapsink or trap2sink for a match
    entered_line = ' '.join(entered_line.split()[1:])
    if add_del == 'add':
        # now fix up syntax when converting from nclu to config
        # grab the current config list to fix up
        current_trap_list = running_array.get(trap_word, [])
        if entered_line not in current_trap_list:
            current_trap_list.append(entered_line)
            running_array[trap_word] = current_trap_list
        else:
            msg += 'trap-destination already exists: %s' % entered_line
    elif add_del == 'del':
        # for deleting we only key off the destination
        # and vrf (if there) when deleting, we could have only
        # the ip address
        destination = entered_line.split()[0]
        notfound = True
        words = cli_dict.get('config-name', [])
        msg = ''
        for word in words:
            current_trap_list = running_array.get(word, [])
            delete_list = []
            for line in current_trap_list:
                if destination in line.split(' '):
                    delete_list.append(line)
                    notfound = False

            for line in delete_list:
                current_trap_list.remove(line)
            running_array[word] = current_trap_list
        if notfound:
            msg += 'trap destination %s not found.' % destination

    return (True, running_array, {'warning' : [msg]})

def trap_auth_handler(running_array, conf_word, args, argv_expanded):
    '''
    The trap auth SNMP Failure handler creates the authtrapenable command
    If this is set to 1, it will be enabled.  To disable, we
    remove it from the config.
    '''
    # this should be a list of 1 item
    cli_dict = config_array.get(conf_word, {})
    add_del = args.get('add') or args.get('del')
    config_name = cli_dict.get('config-name', [])[0]
    msg = ''

    trap_word = argv_expanded[3]

    if add_del == 'add':
        # now fix up syntax when converting from nclu to config
        sublist = cli_dict.get('sub_nclu_to_conf', [])
        regexlist = cli_dict.get('regex_nclu_to_conf', [])
        converted_line = converter(trap_word, sublist, regexlist)
        # grab the current config list to fix up
        current_list = running_array.get(config_name, [])
        if not current_list:
            # we can only have one instance of authtrapenable
            # so it is either disabled (2) or enabled (1)
            current_list.append(converted_line)
            running_array[config_name] = current_list
        else:
            msg += 'a command exists in the config,\n'
            msg += 'possibly not added by NCLU.\n'
            msg += 'Please run delete first.\n'
            return (True, running_array, {'warning' : [msg]})

    elif add_del == 'del':
        current_list = running_array.get(config_name, [])
        sublist = cli_dict.get('sub_nclu_to_conf', [])
        regexlist = cli_dict.get('regex_nclu_to_conf', [])
        converted_line = converter(trap_word, sublist, regexlist)
        current_list = running_array.get(config_name, [])
        # for deletes we remove any lines with authtrapenable in it.
        del_word = converted_line.split()[0]
        del_list = []
        for line in current_list:
            # we will delete even disabled (2) entries
            # there should only be one anyway
            del_list.append(line)
        for line in del_list:
            current_list.remove(line)

        running_array[config_name] = current_list
        if not del_list:
            msg += '%s command not found' % trap_word

    return (True, running_array, {'warning' : [msg]})

def trap_link_handler(running_array, conf_word, args, argv_expanded):
    '''
    The trap link handler creates the monitor command for link uo or
    link down in snmpd.conf. If it contains a monitor command with
    all the parameters needed to identifty the interface.
    '''
    # this should be a list of 1 item
    cli_dict = config_array.get(conf_word, {})
    add_del = args.get('add') or args.get('del')
    config_name = cli_dict.get('config-name', [])[0]
    running_array.setdefault(config_name, [])
    msg = ''

    if argv_expanded:
        # we can only deal with strings for joining
        # the entered line includes the trap-link-up or down word
        entered_line = [str(i) for i in argv_expanded[3:]]
        entered_line = ' '.join(entered_line)
    else:
        return (False, running_array, {'error' : ['invalid command']})

    if add_del == 'add':
        # now fix up syntax when converting from nclu to config
        sublist = cli_dict.get('sub_nclu_to_conf', [])
        regexlist = cli_dict.get('regex_nclu_to_conf', [])
        converted_line = converter(entered_line, sublist, regexlist)
        # grab the current monitor config list to fix up
        current_monitor_list = running_array.get(config_name, [])
        # just set it since there can only be one
        del_list = []
        for line in current_monitor_list:
            if converted_line.split()[0] == line.split()[0]:
                # we have a CumulusLinkDown or CumulusLinkUp match
                # just replace it
                del_list.append(line)

        # Fist remove any existing linkup or linkdown lines
        for d in del_list:
            current_monitor_list.remove(d)
        # and add what is new
        running_array[config_name].append(converted_line)

    elif add_del == 'del':
        current_monitor_list = running_array.get(config_name, [])
        sublist = cli_dict.get('sub_nclu_to_conf', [])
        regexlist = cli_dict.get('regex_nclu_to_conf', [])
        converted_line = converter(entered_line, sublist, regexlist)
        # For deletes we remove any monitor lines with the CumulusLinkUP
        # or CumulusLinkDown word in them.  We leave other monitor commands
        # alone.
        del_word = converted_line.split()[0]
        del_list = []
        for line in current_monitor_list:
            if del_word in line:
                del_list.append(line)
        for line in del_list:
            current_monitor_list.remove(line)

        running_array[config_name] = current_monitor_list
        if not del_list:
            msg += '%s command not found' % entered_line

    return (True, running_array, {'warning' : [msg]})

def trap_load_handler(running_array, conf_word, args, argv_expanded):
    '''
    The trap load handler creates the load command for link uo or
    link down in snmpd.conf. If it contains a monitor command with
    all the parameters needed to identifty the interface.
    '''
    # this should be a list of 1 item
    cli_dict = config_array.get(conf_word, {})
    add_del = args.get('add') or args.get('del')
    config_name = cli_dict.get('config-name', [])[0]
    msg = ''

    if argv_expanded:
        # we can only deal with strings for joining
        # the entered line does not include the load word
        entered_line = [str(i) for i in argv_expanded[4:]]
        entered_line = ' '.join(entered_line)
    else:
        return (False, running_array, {'error' : ['invalid command']})

    myfloats = [str(i) for i in argv_expanded[4:]]
    for i in range(1, len(myfloats), 2):
        # numbers are only in positions 1 3 and 5
        x = myfloats[i]
        y = x.replace('.','')
        if y.isdigit() and int(y) >= 0:
            # int or float is good
            pass
        else:
            msg += 'Only positive integers or floating point numbers allowed for cpu load values'
            return (False, running_array, {'error' : msg})
    # we can have only one load line in the config
    # the monitor command for this has to always exists in the conf
    if add_del == 'add':
        # now fix up syntax when converting from nclu to config
        sublist = cli_dict.get('sub_nclu_to_conf', [])
        regexlist = cli_dict.get('regex_nclu_to_conf', [])
        converted_line = converter(entered_line, sublist, regexlist)
        # grab the current config list to fix up
        running_array[config_name] = [converted_line]
    elif add_del == 'del':
        current_load_list = running_array.get(config_name, [])
        # For deletes we remove all load lines.
        current_load_list = running_array.get(config_name, [])
        if not current_load_list:
            msg += '%s command not found' % config_name
        else:
            running_array[config_name] = []

    return (True, running_array, {'warning' : [msg]})

def viewname_handler(running_array, conf_word, args, argv_expanded):
    '''
    The view handler grabs the <text> list and takes the view name
    as the fist entry and the OID as the second entry.
    We can have multiple lines with the same view name, e.g.
    view foo1  included  .1
    view foo1  exclused  .1.3.6
    view foo2  included  .1.3.6.1.2
    view foo3  included  .1

    The entered value is a list of the view name and the OID
    '''
    # grab views in currently running config
    cli_dict = config_array.get(conf_word, {})
    config_names = cli_dict.get('config-name', [])
    msg = ''
    for config_name in config_names:
        current_list = running_array.get(config_name, [])
        add_del = args.get('add') or args.get('del')
        field_name = cli_dict.get('field-name', None)
        entered_value = args.get(field_name, [])
        # make sure we have a list to work with
        if not isinstance(entered_value, list):
            # when deleting, we only have one string. when adding, an odd
            # case where the view name and oid are the same doc-opt
            # returns a single value list so we need to expand it and
            # this is valid since users can enter view system included system
            entered_value = [entered_value, entered_value]

        # Next, add or delete the entered value
        # entered values are viewname and oid
        # and the view entry in the running array is just a list
        viewname = entered_value[0]
        current_view = running_array.get(config_name, [])
        temp_view = copy.deepcopy(current_view)
        if add_del == 'add':
            oid = entered_value[1]
            viewtype = args.get('included') or args.get('excluded')
            viewline = '%s %s %s' % (viewname, viewtype, oid)
            if viewline not in current_view:
                current_view.append(viewline)
            else:
                msg += '%s %s already in view %s' % (oid, viewtype, viewname)
        else:
            # for deleting, we only look at view name
            for line in temp_view:
                if viewname == line.split(' ')[0]:
                    current_view.remove(line)

        running_array[config_name] = current_view
    return (True, running_array, {'warning' : [msg]})

def check_vrf_listeners(listeners=[]):
    '''
    check_vrf_listeners takes an input list of IP addresses with or without
    VRFs and checks to make sure they are in the right VRFs.
    Returns True if there are no problems.  False if the IP address is not
    the VRF specified or should be in a VRF.  Since NCLU creates a VRF if
    one does not already exist, we only need to check that the IP address
    matches the VRF (or default).
    '''
    if not listeners:
        return False

    rc = True
    # grab all VRFs
    vrfs = [i.split(':')[1].strip()
             for i in check_output('vrf link list'.split()).split('\n')
             if 'VRF:' in i]

    ip_to_vrf = {}
    for vrf in vrfs:
        command = 'ip -br addr show vrf %s' % vrf
        ip_list = [str(IPNetwork(i.strip().split()[2]).ip)
                   for i in check_output(command.split()).split('\n')
                   if i and len(i)>2]

        for ip in ip_list:
            ip_to_vrf.setdefault(ip, []).append(vrf)


    for ipvrf in listeners:
        if '%' in ipvrf:
            (ip,vrf) =ipvrf.split('%')
            # we have been given a vrf, check it
            if ip in ip_to_vrf.keys() and vrf not in ip_to_vrf.get(ip):
                rc = False

        else:
            # no VRF
            if ipvrf in ip_to_vrf.keys() and len(ip_to_vrf.get(ipvrf, [])) > 0:
                rc = False

    return rc

def listening_address_handler(running_array, conf_word, args, argv_expanded):
    '''
    The listening address handler may need to split the existing
    value and add or remove one part. In the snmpd.conf file,
    agentaddress can have multiple lines but can contain lines with
    comma separated values.  The entered value could
    be a single IP address or a list of IP addresses.
    (udp:1.1.1.1:161,2.2.2.2,udp6:5.5.5.5:161)
    If the config has comma separated values, we will
    convert these to multiple agentaddress lines.
    '''
    # this should be a list of 1 item
    cli_dict = config_array.get(conf_word, {})
    config_names = cli_dict.get('config-name', [])
    msg = ''
    for config_name in config_names:
        current_val = running_array.get(config_name, [])
        listeners = current_val
        if len(current_val) > 0 and ',' in current_val[0]:
            listeners = current_val[0].split(',')
            # make sure we have a list to work with
        add_del = args.get('add') or args.get('del')
        field_name = cli_dict.get('field-name', None)
        # translate words like all to snmpd.conf words like udp:161
        keyword = get_keyword(conf_word, args)
        # grab the keywords or the entered value
        entered_values = args.get(field_name, None) or keyword
        if not isinstance(entered_values, list):
            entered_values = [entered_values]

        for ip in entered_values:
            try:
                if isinstance(IPAddress(ip), IPv6Address):
                    # for IPv6 addresses, we require square brackets to avoid
                    # confusion with specifying a port (which also uses colons)
                    ip = '[%s]' % ip
            except ValueError:
                # we have a non ip address
                pass

            if (ip == 'udp:161' or ip == '[::]') and add_del == 'add':
                listeners = [ip]
                msg+='configuring all removes other listening addresses\n'
                break
            else:
                # if a vrf exists, add it to the ip address line ip%vrf
                if args.get('vrf'):
                    # if a VRF was specified, there is only one IP address allowed
                    # and create the new ip%vrf
                    ip = '{0}%{1}'.format(entered_values[0], args.get('<text>'))

                # listeners should be list of one or more ip addresses
                if add_del == 'add' and ('udp:161' in listeners or \
                                         '[::]' in listeners):
                    msg += 'Removing all to add address %s.\n' % ip
                    listeners.append(ip)
                    if 'udp:161' in listeners:
                        listeners.remove('udp:161')
                    if '[::]' in listeners:
                        listeners.remove('[::]')
                elif add_del == 'add' and ip in listeners:
                    msg += 'Cannot add %s. It is already a listener-address' %  ip
                elif add_del == 'add' and ip not in listeners:
                    listeners.append(ip)
                elif add_del == 'del' and ip not in listeners:
                    msg += 'Cannot delete %s. It is not a listener-address' %  ip
                elif add_del == 'del' and ip in listeners:
                    listeners.remove(ip)
                    # rest of code expects a list of comma separated IP addresses
        if len(listeners) == 0:
            msg += 'No listening addresses configured.  Restoring localhost'
            listeners = ['127.0.0.1']
        else:
            try:
                check_vrf_listeners(listeners)
            except Exception as e:
                msg += 'Could not run vrf or ip link commands.'

        # at this point we should only have a list of addresses (and maybe vfs)
        running_array[config_name] = listeners

    return (True, running_array, {'warning' : [msg]})

def readonly_community_handler(running_array, conf_word, args, argv_expanded):
    '''
    The rocommunity handler creates the rocommunity config in snmpd.conf
    and must include an access field.  It can also contain an optional
    oid or view field at the end.
    It should be able to handle readonly-community or
    readonly-community-v6.
    '''
    # this should be a list of 1 item
    cli_dict = config_array.get(conf_word, {})
    config_names = cli_dict.get('config-name', [])
    msg = ''
    if not config_names:
        msg += 'Invalid config-name defined for rocommunity'
        return (False, running_array, {'error' : msg})

    # make sure we have a list to work with
    add_del = args.get('add') or args.get('del')
    if argv_expanded and len(argv_expanded) > 4:
        entered_line = ' '.join(argv_expanded[4:])
    else:
        msg += 'Invalid readonly community command entered'
        return (False, running_array, {'warning' : [msg]})

    if args.get('<ipv4/prefixlen>') or args.get('<ipv6/prefixlen>'):
        fullip = IPNetwork(args.get('<ipv6/prefixlen>') or args.get('<ipv4/prefixlen>'))
        if fullip and (fullip.network != fullip.ip):
            msg += 'network/mask mismatch'
            return (False, running_array, {'warning' : [msg]})

    # now fix up syntax when converting from config file to nclu
    for config_name in config_names:
        sublist = cli_dict.get('sub_nclu_to_conf', []).get(config_name, [])
        regexlist = cli_dict.get('regex_nclu_to_conf', []).get(config_name, [])
        entered_line = converter(entered_line, sublist, regexlist)
        entered_word = entered_line.split()[0]
        current_ro_list = running_array.get(config_name, [])
        current_ro_words = [i.split()[0] for i in current_ro_list]
        if add_del == 'add':
            if entered_line not in current_ro_list:
                current_ro_list.append(entered_line)
            else:
                msg += 'readonly community already exists: %s' % \
                        (entered_line)
        else:
            removed = False
            removed_list = []
            for line in current_ro_list:
                if len(entered_line.split()) > 1:
                    # we are given a community string along with more info
                    # so we only remove that line
                    if entered_line == line:
                        removed_list.append(line)
                        removed = True
                else:
                    # if we are only given the community string, we need to remove
                    # all lines that have this string
                    if entered_word == line.split()[0]:
                        removed_list.append(line)
                        removed = True

            if not removed:
                msg += 'readonly community %s does not exist.' % \
                        (entered_line)

            for line in removed_list:
                current_ro_list.remove(line)

        running_array[config_name] = current_ro_list

    return (True, running_array, {'warning' : [msg]})

def username_handler(running_array, conf_word, args, argv_expanded):
    '''
    The username handler creates both createuser and
    rouser commands in snmpd.conf.
    '''
    cli_dict = config_array.get(conf_word, {})
    # this should be a list of 1 item
    wordlist = cli_dict.get('config-name', [])
    msg = ''
    if not wordlist:
        return (False, running_array, {'error' : ['invalid config-name defined for username']})

    # need to handle both createuser and rouser for the username
    for myword in wordlist:
        current_val = running_array.get(myword, [])

        # make sure we have a list to work with
        add_del = args.get('add') or args.get('del')
        username = None

        if argv_expanded and len(argv_expanded) > 4 and \
           argv_expanded[3] == 'username':
            entered_line = ' '.join(argv_expanded[4:])
            username = argv_expanded[4]
        else:
            return (False, running_array, {'error' : ['Invalid username command entered']})

        # min length of passwords must be 8 characters
        if len(argv_expanded) > 6 and \
           ('auth-md5' in argv_expanded or 'auth-sha' in argv_expanded):
            if len(argv_expanded[6]) < 8:
                return (False, running_array, {'error' : ['authentication passphrase must be greater then 8 characters']})

        # min length of passwords must be 8 characters
        if len(argv_expanded) > 8 and \
           ('encrypt-aes' in argv_expanded or 'encrypt-des' in argv_expanded):
            if len(argv_expanded[8]) < 8:
                return (False, running_array, {'error' : ['encryption passphrase must be greater then 8 characters']})

        # now fix up syntax when converting from config file to nclu
        sublist = cli_dict.get('sub_nclu_to_conf', {}).get(myword, [])
        regexlist = cli_dict.get('regex_nclu_to_conf', {}).get(myword, [])
        entered_line = converter(entered_line, sublist, regexlist)
        if add_del == 'add':
            if [i for i in current_val if username == i.split()[0]] == []:
                # only adds user if it was not there
                current_val.append(entered_line)
            else:
                return (False,
                        running_array, {'error' : ['username %s exists: delete it before re-adding it.' % \
                                        username]})
        else:
            # for deleting, we only care about the useranme
            if [i for i in current_val if username == i.split()[0]]:
                # if the username is in the current commands, collect
                # all the others.
                current_val = [i for i in current_val if username != i.split()[0]]
            else:
                return (False, running_array, {'error' : ['username %s does not exist: ' % username]})

        running_array[myword] = current_val

    return (True, running_array, {'warning' : [msg]})

def get_keyword(conf_word, args):
    # the actual arg value if they did not use default keyword
    # we convert from the nclu keywords to the snmpd.conf words required
    cli_dict = config_array.get(conf_word, {})
    conf_name = cli_dict.get('config-name', [])
    trans_array = cli_dict.get('sub_nclu_to_conf', {})
    if not cli_dict or len(conf_name)==0 or not trans_array.get(conf_name[0], []):
        return None
    # we should only have 1 translation list
    trans_list = trans_array.get(conf_name[0], [])
    # check cli-keywords
    translated_word = None
    for word, newword in trans_list:
        # was the word entered
        if args.get(word):
            translated_word = newword
            break
    # return the translation so we can use it
    return (translated_word)

def get_config(config_file=None):
    """
    get_config() parses snmpd.conf and returns a dictionary keyed by the
    first configuration word.  For single line and multiline commands,
    the value is a list.

    Some values in the configuration are not shown or changeable in NCLU.
    They are not changed.

    For Example, an snmpd.conf snippet like . . .

        master agentx
        rocommunity public default
        rocommunity mycom default -V myview

    . . . results in:

        config_array = {
            "rocommunity" : ["public default", "mycom default -V myview"],
            "master" : ["agentx"],
        }
    """

    # TODO - This is a "do something maybe" function.  It shouldn't be
    # called if the configuration file doesn't exist.
    if not os.path.isfile(config_file):
        return {}

    with open(config_file) as f:
        config_lines = [line.strip() for line in f if not line.lstrip().startswith('#')]

    config_array = {}

    for line in config_lines:
        l = line.split()
        if len(l) > 1:
            keyword = l[0].lower()
            if keyword == "agentaddress" and ',' in l[1]:
                # Split the agentaddress into a list.
                ips = l[1].split(',')
                if keyword in config_array:
                    config_array[keyword].extend(ips)
                else:
                    config_array[keyword] = ips
            elif keyword in config_array:
                config_array[keyword].append(' '.join(l[1:]))
            else:
                config_array[keyword] = [' '.join(l[1:])]

    return config_array

def add_default_config(config_array={}):
    """
    There are some defaults in the config file that we inist must exist
    for the rest of the possible nclu configs to work correctly (e.g.
    monitoring commands). Here, we make sure they exist.
    """

    for conf_word in default_config_array.keys():
        if not config_array.has_key(conf_word):
            config_array[conf_word] = default_config_array[conf_word]
        else:
            # the config exists but we need to make sure some parameters
            # exist so our configs will work. The only exception is the
            # agentaddress
            if conf_word == 'agentaddress':
                continue
            # everything is a list so we just loop
            for option in default_config_array[conf_word]:
                if option not in config_array[conf_word]:
                    config_array[conf_word].append(option)

    return config_array

def clear_username_cache():
    """
    clear_username_cache() reads the current cache file, usually
    in /var/lib/snmp/snmpd.conf, and then loops over the existing
    SNMPv3 usernames.  Lines with these usernames are then removed
    from the cache file as a new file is written out.  This forces
    snmpd to rehash the usernames contained in /etc/snmp/snmpd.conf
    to make sure they are correct.
    """

    if not os.path.exists(USERNAME_CACHE):
        # we have no cache to clear so bale out.
        return
    fd = open(USERNAME_CACHE, 'r')
    oldcache = fd.readlines()
    fd.close()

    oldconfig = get_config(SNMPD_CONFIG_FILE)
    newconfig = get_config(SCRATCH_CONFIG_FILE)
    delete_set = set([])
    oldusers = set([u.split()[0] for u in oldconfig.get('createuser', [])])
    newusers = set([u.split()[0] for u in newconfig.get('createuser', [])])
    # we need to delete any users that were removed
    delete_set = delete_set | (oldusers - newusers)
    # we need to add in the users that were added
    delete_set = delete_set | (newusers - oldusers)
    # for the users that did not change, we need to check their passwords
    stableusers = oldusers.intersection(newusers)
    oldconfigs = oldconfig.get('createuser', [])
    newconfigs = newconfig.get('createuser', [])
    for userconfig in oldconfigs:
        if userconfig.split()[0] in stableusers and userconfig in newconfigs:
            # the config did not change
            pass
        else:
            # passwords must have changed, delete it
            delete_set.add(userconfig.split()[0])

    if not delete_set:
        return

    # before writing out the new file, make sure to stop snmpd if it is
    # running
    try:
        enabled = check_output(['/bin/systemctl', 'is-active', 'snmpd'])
        # if we get here, we may be enabled
        if 'active' in enabled:
            # need to stop before modifying file
            # the rest of commit_pending should just restart it
            enabled = check_output(['/bin/systemctl', 'stop', 'snmpd'])
    except:
        # if snmpd is not active, we return subprocess.CalledProcessError
        # since it is not active, just pass
        pass

    newfd = open(USERNAME_CACHE, 'w')
    for line in oldcache:
        notfound = True
        for user in delete_set:
            # make sure to add quotes to catch the exact username
            if ('"%s"' % user) in line:
                notfound = False
                break

        if notfound:
            newfd.write(line)

    newfd.close()
    return

def save_scratch_config(config_array=None):
    """
    Write the sorted values of config_array to the scratchpad.  If config_array
    is an empty dictionary, write a default configuration.
    """

    if config_array is None:
        config_array = default_config_array.copy()
    assert isinstance(config_array, dict)

    with open(SCRATCH_CONFIG_FILE, 'w') as f:
        f.write("#### Auto-generated config file: do not edit. ####\n")

        for key in sorted(config_array.keys()):
            for value in sorted(config_array[key]):
                if value:
                    f.write("{0} {1}\n".format(key, value))

    os.chmod(SCRATCH_CONFIG_FILE, 0o600)


def del_all():
    """
    Wipe the config clean in the scratch area.  Don't stop the snmpd daemon.
    """
    if not os.path.isdir(SNMP_SCRATCH_DIR):
        # Create the directory that will hold scratchpad files.
        os.makedirs(SNMP_SCRATCH_DIR, mode=WORKING_DIRECTORIES_PERMISSIONS)

    save_scratch_config()
    return (True, {"output": ''})


def abort_pending():
    # need to delete the /run/nclu/snmp configs
    for filename in glob.glob('%s*' % SNMP_SCRATCH_DIR):
        os.remove(filename)
    return


def commit_pending(verbose):
    """ Persistent changes, and return the standard 2-tuple. """

    the_diff = get_pending_diffs([(SNMPD_CONFIG_FILE, SCRATCH_CONFIG_FILE)], False)
    if not the_diff:
        # There are no changes to commit.
        for filename in glob.glob(SNMP_SCRATCH_DIR + '*'):
            os.remove(filename)

        return (True, {"output": ''})

    message = ''
    problems = validate_syntax()
    if problems:
        # snmpd will not run if these changes are committed.

        # TODO - Why are we letting a user commit an invalid configuration?
        # I'm letting this continue because our automated tests expect this behavior.
        # return (False, problems, [])
        pass

    # The configuration has changed.  For SNMPv3, we have to clear any user we
    # control from the cache file since it will be recreated with a restart.
    clear_username_cache()

    # Copy the new configuration to the right place.
    shutil.copyfile(SNMPD_CONFIG_FILE, TEMP_CONFIG_FILE)
    shutil.copyfile(SCRATCH_CONFIG_FILE, SNMPD_CONFIG_FILE)
    os.chmod(SNMPD_CONFIG_FILE, 0o600)
    modified = [SNMPD_CONFIG_FILE]

    commit_ok = True

    try:
        try:
            command = ["/bin/systemctl", "is-enabled", "snmpd"]
            check_output(command)
        except CalledProcessError:
            # snmpd is disabled.  Try to enable it.
            command = ["/bin/systemctl", "enable", "snmpd"]
            check_output(command)

        # Restart or stop snmpd.
        command = ["/bin/systemctl", "stop" if problems else "restart", "snmpd"]
        check_output(command)
    except CalledProcessError as e:
        message += "\"{0}\" failed: {1}\n".format(' '.join(command), e)
        commit_ok = False

    try:
        check_output(["/bin/systemctl", "is-active", "snmpd"])
    except:
        message += "WARNING: snmpd is not running.  Run \"journalctl -u snmpd\" for error messages."

    if commit_ok:
        for filename in glob.glob(SNMP_SCRATCH_DIR + '*'):
            os.remove(filename)
    elif os.path.exists(TEMP_CONFIG_FILE):
            shutil.copyfile(TEMP_CONFIG_FILE, SNMPD_CONFIG_FILE)
            modified = []

    return (commit_ok, {'output' : message})


def get_pending(use_colors):
    """
    Return the pending diff as a string.  If there are no changes, return the empty string.
    """

    return get_pending_diffs([(SNMPD_CONFIG_FILE, SCRATCH_CONFIG_FILE)], use_colors)


def validate_syntax():
    """
    If there are problems with the configuration file that preempt starting snmpd, return a description
    of the problems as a string.  If there are no problems, return the empty string.
    """

    result = ''
    newconfig = get_config(SCRATCH_CONFIG_FILE)
    assert isinstance(newconfig, dict), "This should be a dictionary with string keys and list values."

    if not bool(newconfig.get("agentaddress", [])):
        result += "snmpd.conf must configure agentaddress."

    if not (bool(newconfig.get("rocommunity", [])) or bool(newconfig.get("rocommunity6", [])) or
            ("createuser" in newconfig and newconfig["createuser"] != ["_snmptrapusernameX"])):
        result += ('\n' if result else '') + "snmpd.conf must configure rocommunity, rocommunity6, or createuser."

    return result

def do_show():
    '''
    This handles net show snmp-server status
    '''
    try:
        myshow = check_output(['/bin/systemctl', 'show', 'snmpd'])
    except CalledProcessError as ex:
        myshow = ex.output

    current = get_showarray()
    if current.get('readonly-community') or current.get('readonly-community-v6'):
        rocommunity = 'Configured'
    else:
        rocommunity = 'Not Configured'

    if current.get('username', []):
        v3users = 'Configured'
    else:
        v3users = 'Not Configured'

    myshow = myshow.split('\n')
    output = {l.split('=')[0]: l.split('=')[1] for l in myshow if l}

    listeners = ', '.join(current.get('listening-address', [' ']))
    # grab the output for the ExecMainPID, if failed, MainPID==0
    try:
        if output.get('ActiveState') == 'failed':
            pid = '_PID=%s' % output.get('ExecMainPID')
            myerrors = check_output(['/bin/journalctl', pid]).split('\n')
        else:
            myerrors = []
    except CalledProcessError as ex:
        myerrors = []

    headers = ["Attribute", "Value"]
    table = []
    table.append(['Current Status', '%s (%s)' % (output.get('ActiveState', None),
                                                 output.get('SubState', None))])
    table.append(['Reload Status', output.get('UnitFileState')])
    table.append(['Listening IP Addresses', listeners])
    table.append(['Main snmpd PID', output.get('MainPID')])
    table.append(['Version 1 and 2c Community String', rocommunity])
    table.append(['Version 3 Usernames', v3users])
    for i in range(len(myerrors)):
        if i == 0:
            table.append(['Last Logs (with Errors)', myerrors[i]])
        else:
            table.append(['', myerrors[i]])

    outstring = '\n%s\n%s' % \
            (output.get('Description'), tabulate(tru(table), tablefmt="simple"))
    return (True, {'output': outstring})


def get_config_files(user_may_edit):
    """
    This is called when user does "net show configuration files".
    """

    reply = ''

    if os.path.isfile(SNMPD_CONFIG_FILE):
        reply += SNMPD_CONFIG_FILE + '\n'
        reply += "=======================\n"

        if user_may_edit:
            # The user has edit privileges.  Do not bother hiding passwords.
            with open(SNMPD_CONFIG_FILE) as f:
                reply += f.read()
        else:
            output = []
            with open(SNMPD_CONFIG_FILE) as f:
                for line in f:
                    # send through the hider
                    output.append(hider(line))
            reply += ''.join(output)

    return reply + '\n'


def hider(line):
    """
    This hider function works in both directions: hiding attributes from
    the config and also from the nclu commands.
    """

    line = re.sub(r'''agentx.*''', 'agentx PARAMS REMOVED', line, flags=re.I)
    line = re.sub(r'''community (\S+)''', 'community PASSWORD REMOVED', line, flags=re.I)
    line = re.sub(r'''createuser (\S+)''', 'createuser USERNAME PASSWORD REMOVED', line, flags=re.I)
    line = re.sub(r'''iquerySecName (\S+)''', 'iquerySecName USERNAME PASSWORD REMOVED', line, flags=re.I)
    line = re.sub(r'''trap-destination.*''', 'trap-destination REMOVED-PARAMS', line, flags=re.I)
    line = re.sub(r'''trapsink.*''', 'trapsink DESTINATION PASSWORD REMOVED', line, flags=re.I)
    line = re.sub(r'''trap2sink.*''', 'trap2sink DESTINATION PASSWORD REMOVED', line, flags=re.I)
    line = re.sub(r'''trapsess.*''', 'trapsess PASSWORD REMOVED', line, flags=re.I)
    line = re.sub(r'''rouser (\S+)''', 'rouser USERNAME PASSWORD REMOVED', line, flags=re.I)
    line = re.sub(r'''createuser.*''', 'createuser REMOVED AUTH REMOVED', line, flags=re.I)
    line = re.sub(r'''username.*''', 'username REMOVED restrict-access REMOVED', line, flags=re.I)
    return (line)


def get_managed_files():
    return [SNMPD_CONFIG_FILE]


def get_combined_usernames(showarray):
    """
    get_combined_usernames() is given an array indexed by usernames.
    Each entry is a list of converted values taken from createuser and rouser
    values but converted via regex to nclu cli keywords.
    """

    if not showarray.get('username'):
        return showarray
    userlist = showarray.get('username', [])
    cli_dict = config_array.get('username', None)
    hidden = cli_dict.get('hidden-entries', [])
    userarray = {}
    for userstring in userlist:
        uservals = userstring.split(' ')
        name = uservals[0]
        if name in hidden:
            continue
        # only collect the auth keywords we care about. the encrypt
        # keywords may also exist an they will be added as well.
        if 'auth-none' in uservals or 'auth-md5' in uservals or 'auth-sha' in uservals:
            userarray[uservals[0]] = ' '.join(uservals[1:])
    # now attach the oid or view
    for userstring in userlist:
        uservals = userstring.split()
        if 'oid' in uservals or 'view' in uservals:
            name = uservals[0]
            if name in hidden:
                continue
            if userarray.get(name):
                # add on an oid or a view name if it exists
                userarray[name] = '%s %s' % (userarray[name],
                                             ' '.join(uservals[1:]))
    # need to create a list of entries with username attributes
    userlist = []
    entries = userarray.keys()
    entries.sort()
    for entry in entries:
       userlist.append('%s %s' % (entry, userarray[entry]))
    showarray['username'] = userlist

    return (showarray)


def get_showarray(running_array = None):
    """
    get_showarray() loops over all the nclu snmp-server keywords
    and for each keyword, loops over the snmpd.conf keywords for it.
    It collects the configs from snmpd.conf and correlates them
    to nclu keywords so we can show them. For a specific username,
    it collects the 'createuser' and 'rouser' configs and creates
    a single 'username' entry to show.
    """
    if running_array is None:
        running_array = get_config(SNMPD_CONFIG_FILE)
    # now show the supported commands
    entries = config_array.keys()
    entries.sort()
    showarray = {}
    for entry in entries:
        cli_dict = config_array[entry]
        newindexlist = cli_dict.get('config-name', [])
        for newindex in newindexlist:
            hidden = cli_dict.get('hidden-entries', [])
            vals = running_array.get(newindex, [])
            if vals:
                for val in running_array.get(newindex, []):
                    if val in hidden:
                        # some things we do not want to show
                        # if you cannot configure it, you will not see it
                        # except when you look in the conf file
                        continue
                    sublist = cli_dict.get('sub_conf_to_nclu', {}).get(newindex, [])
                    regexlist = cli_dict.get('regex_conf_to_nclu', {}).get(newindex, [])
                    # make sure to convert the snmpd.config into usable nclu commands.
                    conv_val = converter(val, sublist, regexlist)
                    if not conv_val:
                        # we do not show what we cannot configure
                        continue
                    if showarray.get(entry):
                        # we are combining the createuser attributes with
                        # the rouser attributes in a list.
                        showarray.get(entry).append(conv_val)
                    else:
                        showarray[entry] = [conv_val]

    # now convert these two entries into one username array
    showarray = get_combined_usernames(showarray)
    return (showarray)


def show_config_commands(user_may_edit, ifupdown2_wrapper):
    supported = []
    unsupported = []
    showarray = get_showarray()
    showkeys = showarray.keys()
    showkeys.sort()
    for entry in showkeys:
        for val in showarray[entry]:
            # for each item in list
            full_line = '%s %s' % (entry, val)
            if not user_may_edit:
                supported.append('net add snmp-server %s' % (hider(full_line)))
            else:
                supported.append('net add snmp-server %s' % (full_line))

    return (supported, unsupported)


def show_config_summary(user_may_edit, summary):
    showarray = get_showarray()
    summary['snmp-server'] = OrderedDict()
    showkeys = showarray.keys()
    showkeys.sort()
    for entry in showkeys:
        for val in showarray[entry]:
            # for each item in list
            full_line = '%s %s' % (entry, val)
            if not user_may_edit:
                summary['snmp-server'][hider(full_line)] = []
            else:
                summary['snmp-server'][full_line] = []

    return


def converter(val, sublist, regexlist):
    """
    This should translate the config line into nclu options users are
    familar with.  Like udp:161 to all  and 127.0.0.1 to localhost.
    We also have to replace -V with view and insert OID for rocommunity.
    """

    # Handle substitutions first.
    for pattern, replacement in sublist:
        val = re.sub(pattern, replacement, val)

    # Fix up syntax when converting from the configuration file to NCLU.
    conv_val = ''
    for pattern, replacement in regexlist:
        m = re.match(pattern, val)
        if m:
            conv_val = replacement.format(*m.groups())
            break

    return (conv_val)


def do_config(args, argv_expanded):
    if not os.path.isdir(SNMP_SCRATCH_DIR):
        # Create the directory that will hold scratchpad files.
        os.makedirs(SNMP_SCRATCH_DIR, mode=WORKING_DIRECTORIES_PERMISSIONS)

    if os.path.isfile(SCRATCH_CONFIG_FILE):
        running_array = get_config(SCRATCH_CONFIG_FILE)
    else:
        # we always make a copy of the config if it does not exist
        shutil.copyfile(SNMPD_CONFIG_FILE, SCRATCH_CONFIG_FILE)
        os.chmod(SCRATCH_CONFIG_FILE, 0o600)
        running_array = get_config(SCRATCH_CONFIG_FILE)
        running_array = add_default_config(running_array)

    initial_array = copy.deepcopy(running_array)
    # running_array should have valid values for snmpd.conf, no special
    # words.
    msg = {"output": ''}
    result = True
    for conf_word in config_array.keys():
        # before doing anything, check that the keyword was entered
        # or if we have no handler function to call, just continue
        # some keywords (view) could occur elsewhere in other commands
        if argv_expanded and len(argv_expanded) > 3:
            command = argv_expanded[3]
        else:
            command = ''
        if conf_word != command or not args.get(conf_word, None) or \
           not config_array.get(conf_word, None).get('handler', None):
            # we continue if command entered is not the current loop index or
            # the commanded was not entered
            # or there is no array to work with
            continue
        cli_dict = config_array.get(conf_word, {})
        handler = globals().get(cli_dict.get('handler', None), None)
        if handler:
            result, running_array, msg = handler(running_array, conf_word, args, argv_expanded)

    changed = False
    if args.get('add'):
        keylist = running_array.keys()
    else:
        keylist = initial_array.keys()

    for i in keylist:
        if running_array.get(i, None) != initial_array.get(i, None):
            changed = True
    if changed:
        save_scratch_config(running_array)
    else:
        msg = {"warning": ["Configuration has not changed"]}

    # We do not return output, but it has to be there.
    msg.setdefault('output', '')

    return (result, msg)


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """

    assert isinstance(net_daemon, NetDaemon)

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert "configuration" not in tokens, "\"net show configuration snmp\" does not use this code path."
    assert "snmp-server" in tokens, "Why are you here?"

    argv_expanded = net_daemon.nclu_parser.argv_expanded

    if "show" in tokens:
        rc = do_show()
    elif "del" in tokens and argv_expanded[3] == 'all':
        rc = del_all()
    else:
        rc = do_config(tokens, argv_expanded)

    # make sure to return tuple (True, {'output':'', 'error' : []})
    return rc

def check_command(command=None,
                  assertion='', invert_assertion=False,
                  verbose=False,
                  warn_only=False, counter=1):
    '''
    This method simply runs the command provided and asserts
    the assertion string to make sure it worked.  In some cases,
    we have to run with warn_only=True to continue running.
    We can use regular expressions here to check long string.
    '''

    #if verbose:
    #    print("\ncheck_command: command=%s assert=%s warn=%s invert=%s" %
    #          (command, assertion, warn_only, invert_assertion))
    # we need this because commands return non-zero, we need
    # to continue the test
    result = subprocess.check_output(command.split(), shell=False).strip()
    print('command=%s\nresult=%s' % (command, result))

    if (isinstance(assertion, types.ListType)):
        for a in assertion:
            match = re.search(a, result, re.DOTALL)
            # everything in the assertion list must match or we fail
            if not match:
                # fail on first non match
                break
    else:
        # not a list, just check the one assertion
        match = re.search(assertion, result, re.DOTALL)
    # sometimes, we need to invert and the warn_only
    if (invert_assertion):
        if match:
            print("\tcheck_command step %s FAIL: We SHOULD NOT have seen the asserion in the result\ncommand=%s\nassert=%s\nresult=%s\ninversion=%s" % \
                  (counter, command, assertion, result, invert_assertion))
            return False
    else:
        if not match:
            print("\tcheck_command step %s FAIL:  We SHOULD have seen the asserion in the result\ncommand=%s\nassert=%s\nresult=%s\ninversion=%s" % \
                  (counter, command, assertion, result, invert_assertion))
            return False

    return(match)

def test_commands(command_list):
    pass_count = 0
    fail_count = 0
    nd = NetDaemon()
    for nclu_command, command, assertion, invert, verbose, warn_only  in command_list:
        #nd = NetDaemon()
        argv = nclu_command.split()
        outcome, message = nd.nclu_parser.run(argv)
        # first, run the NCLU command
        result,reply = nclu.execute_command.execute_command(nd.nclu_parser.argv_expanded, nd)
        print('NCLU Command: %s\nresult: %s' % (nclu_command, result))
        if command:
            if check_command(command=command, assertion=assertion,
                             invert_assertion=invert, verbose=verbose,
                             warn_only=warn_only):
                pass_count += 1
                print('\ttest: %s result: PASS' % command)
            else:
                fail_count += 1
                print('\ttest: %s result: FAIL' % command)
        else:
            pass_count += 1
            print('test: %s result: PASS' % nclu_command)

    return (pass_count, fail_count)


if __name__ == "__main__":
    # run some tests if called from commandline
    from nclu.NetDaemon import NetDaemon
    import nclu.execute_command
    import subprocess
    import types
    # this is a list of tuples containig
    # (nclu command, shell command to check)
    command_list = [
        ("net del snmp-server all", "", '', False, True, False),
        ("net commit", "", '', False, True, False),
        ("net pend", "grep agentaddress /etc/snmp/snmpd.conf", '127.0.0.1', False, True, False),
        ("net show snmp-server status", "", '', False, True, False),
    ]
    pc, fc = test_commands(command_list)
    print('Total PASS: %s  Total FAIL: %s' % (pc, fc))


def get_restart_commands(filename=None):
    """
    Return a list of commands that should be called for the given file after a rollback.
    """
    assert filename is None or filename in get_managed_files(), "filename = {0}".format(filename)
    return [("/bin/systemctl", "restart", "snmpd")]


def test_do_config(args, argv_expanded):
    running_array = {}
    # running_array should have valid values for snmpd.conf, no special
    # words.
    msg = {"output": ''}
    result = True
    if argv_expanded and len(argv_expanded) > 3:
        command = argv_expanded[3]
    else:
        command = ''
    cli_dict = config_array.get(command, {})
    handler = globals().get(cli_dict.get('handler', None), None)
    if handler:
        result, running_array, msg = handler(running_array, command,
                                             args, argv_expanded)
    return (result, running_array)

def test_syntax_conversions():
    '''
    This tests all of the nclu snmp-server commands by converting them
    into snmpd.conf config commands and then back again to make sure
    the syntax conversions are correct.  This doesn't check the
    parser syntax (except for args being {} for invalid commands)
    '''
    testcommands = """
    net add snmp-server listening-address 10.10.10.10
    net add snmp-server listening-address all-v6
    net add snmp-server listening-address localhost
    net add snmp-server listening-address 11.11.11.11 22.22.22.22 33.33.33.33
    net add snmp-server listening-address localhost-v6
    net add snmp-server listening-address all
    net add snmp-server listening-address 10.10.10.10 vrf mgmt
    net add snmp-server listening-address 10.10.10.10 20.20.20.20
    net add snmp-server viewname testviewxxxxxxx included 1.3.6.1.2.1.1
    net add snmp-server viewname testviewxxxxxxx excluded 1.3.6.1.2.1.1
    net add snmp-server readonly-community testpublic access any
    net add snmp-server readonly-community testpublic access any oid 1.3.6.1.2.1.1
    net add snmp-server readonly-community testpublic access any view testview
    net add snmp-server readonly-community testpublic access 10.10.10.10
    net add snmp-server readonly-community testpublic access 10.10.10.10 oid 1.3.6.1.2.1.1
    net add snmp-server readonly-community testpublic access 10.10.10.10 view testview
    net add snmp-server readonly-community testpublic access localhost
    net add snmp-server readonly-community testpublic access localhost oid 1.3.6.1.2.1.1
    net add snmp-server readonly-community testpublic access localhost view testview
    net add snmp-server readonly-community-v6 testpublic access any
    net add snmp-server readonly-community-v6 testpublic access any oid 1.3.6.1.2.1.1
    net add snmp-server readonly-community-v6 testpublic access any view testview
    net add snmp-server readonly-community-v6 testpublic access 2001::666
    net add snmp-server readonly-community-v6 testpublic access 2001::666 oid 1.3.6.1.2.1.1
    net add snmp-server readonly-community-v6 testpublic access 2001::666 view testview
    net add snmp-server readonly-community-v6 testpublic access localhost
    net add snmp-server readonly-community-v6 testpublic access localhost oid 1.3.6.1.2.1.1
    net add snmp-server readonly-community-v6 testpublic access localhost view testview
    net add snmp-server username testuser auth-none
    net add snmp-server username testuser auth-none oid 1.3.6.1.2.1.1
    net add snmp-server username testuser auth-none view testview
    net add snmp-server username testuser auth-md5 testauthmd5
    net add snmp-server username testuser auth-md5 testauthmd5 oid 1.3.6.1.2.1.1
    net add snmp-server username testuser auth-md5 testauthmd5 view testview
    net add snmp-server username testuser auth-sha testauthsha
    net add snmp-server username testuser auth-sha testauthsha oid 1.3.6.1.2.1.1
    net add snmp-server username testuser auth-sha testauthsha oid system
    net add snmp-server username testuser auth-sha testauthsha view testview
    net add snmp-server username testuser auth-md5 testauthmd5 encrypt-aes testencraes
    net add snmp-server username testuser auth-md5 testauthmd5 encrypt-aes testencraes oid 1.3.6.1.2.1.1
    net add snmp-server username testuser auth-md5 testauthmd5 encrypt-aes testencraes view testview
    net add snmp-server username testuser auth-md5 testauthmd5 encrypt-des testencrdes
    net add snmp-server username testuser auth-md5 testauthmd5 encrypt-des testencrdes oid 1.3.6.1.2.1.1
    net add snmp-server username testuser auth-md5 testauthmd5 encrypt-des testencrdes view testview
    net add snmp-server username testuser auth-sha testauthsha encrypt-aes testencraes
    net add snmp-server username testuser auth-sha testauthsha encrypt-aes testencraes oid 1.3.6.1.2.1.1
    net add snmp-server username testuser auth-sha testauthsha encrypt-aes testencraes view testview
    net add snmp-server username testuser auth-sha testauthsha encrypt-des testencrdes
    net add snmp-server username testuser auth-sha testauthsha encrypt-des testencrdes oid 1.3.6.1.2.1.1
    net add snmp-server username testuser auth-sha testauthsha encrypt-des testencrdes view testview
    net add snmp-server system-location  this is my location
    net add snmp-server system-contact   John Doe jdoe@example.com
    net add snmp-server system-name      My Special Machine
    net add snmp-server trap-destination localhost   community-password testpassword
    net add snmp-server trap-destination localhost   community-password testpassword version 1
    net add snmp-server trap-destination localhost   community-password testpassword version 2c
    net add snmp-server trap-destination localhost-v6   community-password testpassword version 2c
    net add snmp-server trap-destination 10.10.10.10 community-password testpassword version 1
    net add snmp-server trap-destination 10.10.10.10 community-password testpassword version 2c
    net add snmp-server trap-destination 2001::666   community-password testpassword version 1
    net add snmp-server trap-destination 2001::666   community-password testpassword version 2c
    net add snmp-server trap-destination localhost   vrf testvrf community-password testpassword
    net add snmp-server trap-destination localhost   vrf testvrf community-password testpassword version 1
    net add snmp-server trap-destination localhost   vrf testvrf community-password testpassword version 2c
    net add snmp-server trap-destination localhost-v6   vrf testvrf community-password testpassword version 2c
    net add snmp-server trap-destination 10.10.10.10 vrf testvrf community-password testpassword version 1
    net add snmp-server trap-destination 10.10.10.10 vrf testvrf community-password testpassword version 2c
    net add snmp-server trap-destination 2001::666   vrf testvrf community-password testpassword version 1
    net add snmp-server trap-destination 2001::666   vrf testvrf community-password testpassword version 2c
    net add snmp-server trap-destination localhost   username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination 10.10.10.10 username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination 2001::666   username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination localhost   username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination 10.10.10.10 username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination 2001::666   username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination localhost   username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination 10.10.10.10 username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination 2001::666   username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination localhost   username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination 10.10.10.10 username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination 2001::666   username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination localhost   vrf testvrf username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination 10.10.10.10 vrf testvrf username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination 2001::666   vrf testvrf username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination localhost   vrf testvrf username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination 10.10.10.10 vrf testvrf username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination 2001::666   vrf testvrf username testuser auth-md5 testauthmd5 engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination localhost   vrf testvrf username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination 10.10.10.10 vrf testvrf username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination 2001::666   vrf testvrf username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000
    net add snmp-server trap-destination localhost   vrf testvrf username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination 10.10.10.10 vrf testvrf username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination 2001::666   vrf testvrf username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-destination localhost-v6   vrf testvrf username testuser auth-md5 testauthmd5 encrypt-aes testenctaes engine-id 0x80001f8880e632093353efc45a00000000 inform
    net add snmp-server trap-link-up
    net add snmp-server trap-link-up check-frequency 10
    net add snmp-server trap-link-down
    net add snmp-server trap-link-down check-frequency 66
    net add snmp-server trap-snmp-auth-failures
    net add snmp-server trap-cpu-load-average one-minute 1.66
    net add snmp-server trap-cpu-load-average one-minute 1.76   five-minute 3.14
    net add snmp-server trap-cpu-load-average one-minute 4.3    five-minute 3      fifteen-minute 6.66
    """
    nd = NetDaemon()
    passcount = 0
    failcount = 0
    for commandline in [l.strip() for l in testcommands.split('\n') if l.strip() != '']:
        command = commandline.split()[3]
        argv = commandline.split()
        nd.nclu_parser.args = {}
        outcome, message = nd.nclu_parser.run(argv)
        args = nd.nclu_parser.args
        running_array = {}
        if args == {}:
            print("Test FAIL: command is: %s" % commandline)
            failcount += 1
            continue
        result, running_array = test_do_config(args, argv)
        new_running_array = get_showarray(running_array)
        innie = ' '.join(commandline.split()[4:])
        outie = ' '.join(new_running_array.get(command))
        if innie == outie:
            passcount += 1
        elif innie in outie and innie != outie:
            passcount += 1
            print("\n\nTest PASS: but not equal: command is: %s\ninnie=%s\noutie=%s" % \
                  (commandline, innie, outie))
        else:
            print("\n\nTest FAIL: command is: %s=%s\ninnie=%s\noutie=%s" % \
                  (commandline, innie, outie))
            failcount += 1
    print('')
    return (passcount, failcount)


if __name__ == "__main__":
    from nclu.NetDaemon import NetDaemon
    # run some tests if called from commandline
    import sys, pprint
    #results = {}
    result = test_syntax_conversions()
    print('Test: Total PASS: %s  Total FAIL: %s' % (result[0], result[1]))
