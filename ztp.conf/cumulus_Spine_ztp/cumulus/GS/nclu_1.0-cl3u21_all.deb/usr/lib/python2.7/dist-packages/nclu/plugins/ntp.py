"""
Copyright (C) 2016, 2017, 2018 Cumulus Networks, inc.

All Rights reserved.

This software is subject to the Cumulus Networks End User License Agreement available
at the following locations:.

Internet: https://cumulusnetworks.com/downloads/eula/latest/view/

Cumulus Linux systems: /usr/share/cumulus/EULA.txt
"""

import logging
import os
import re
from collections import OrderedDict
from nclu import files_match, ifname_expand_glob, WORKING_DIRECTORY
from nclu.NetDaemon import NetDaemon
from nclu.plugins import (
    get_config_files_helper,
    get_pending_diffs,
    make_scratchpads,
    merge_messages,
    persist_configurations,
    remove_scratch_files_and_backups,
    run_commands,
)
from subprocess import CalledProcessError, check_output

NTP_CONF = "/etc/ntp.conf"
NTP_CONF_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "ntp", os.path.basename(NTP_CONF))
ETC_TIMEZONE = "/etc/timezone"
ETC_TIMEZONE_SCRATCHPAD = os.path.join(WORKING_DIRECTORY, "ntp", os.path.basename(ETC_TIMEZONE))

log = logging.getLogger("netd")


def build_doc_string():
    """
    All of the timezones are stored in a dictionary at the bottom of the
    file. Use that dictionary to build the doc string.
    """

    docstring = """\
Usage:
    net add time zone ({0})
    net (add|del) time ntp source <interface>
    net add time ntp server <text> [iburst]
    net del time ntp server <text>
    net show time [zone]
    net show time ntp servers

Options:
    iburst  : When the server is unreachable, send a burst of eight packets instead of the usual one
    ntp     : Network Time Protocol
    server  : Server
    servers : Servers
    source  : Source
    time    : Time
    zone    : Time zone
""".format('|'.join(TIMEZONES.iterkeys()))  # "timezones" is global

    help_strings = ["    {0}  : UTC {1}, UTC DST {2}".format(key, value["UTC"], value["UTC DST"]) for key, value in TIMEZONES.iteritems()]
    return docstring + '\n'.join(help_strings)


def commit_pending(verbose):
    """
    Copy scratchpad files over configuration files, call necessary restart commands, etc.

    Return a 2-tuple of (bool, dict).  The boolean indicates if the commit succeeded.
    The dictionary is as described in nclu/plugins/__init__.py:execute_modular.
    """

    if (not os.path.isfile(NTP_CONF_SCRATCHPAD) or files_match(NTP_CONF, NTP_CONF_SCRATCHPAD)) and \
            (not os.path.isfile(ETC_TIMEZONE_SCRATCHPAD) or files_match(ETC_TIMEZONE, ETC_TIMEZONE_SCRATCHPAD)):
        # There are no changes to commit.
        return (True, {"output": ''})

    persist_configurations([(NTP_CONF, NTP_CONF_SCRATCHPAD), (ETC_TIMEZONE, ETC_TIMEZONE_SCRATCHPAD)])

    restart_commands = get_restart_commands(NTP_CONF) + get_restart_commands(ETC_TIMEZONE)

    outcome, _, messages = run_commands(restart_commands, verbose)

    if outcome:
        # The commit succeeded.
        remove_scratch_files_and_backups([NTP_CONF_SCRATCHPAD, ETC_TIMEZONE_SCRATCHPAD])

    else:
        # The commit failed.  Revert the configuration.
        if os.path.isfile(NTP_CONF_SCRATCHPAD + ".bak"):
            persist_configurations([(NTP_CONF, NTP_CONF_SCRATCHPAD + ".bak"), (ETC_TIMEZONE, ETC_TIMEZONE_SCRATCHPAD + ".bak")], False)
            revert_outcome, _, revert_messages = run_commands(restart_commands, verbose)
            merge_messages(messages, revert_messages)

    return (outcome, messages)


def show_config_commands(ifupdown2_wrapper):
    """
    net show configuration commands
    """

    summary = {}
    show_config_summary(summary)

    supported = ["net add time zone {0}".format(summary["time"]["zone"])]

    if "ntp" in summary["time"]:
        if "servers" in summary["time"]["ntp"]:
            supported.extend(["net add time ntp server {0}".format(server) for server in summary["time"]["ntp"]["servers"]])

        if "source" in summary["time"]["ntp"]:
            supported.append("net add time ntp source {0}".format(summary["time"]["ntp"]["source"]))

    return (supported, [])


def show_config_summary(summary):
    """ net show configuration """

    assert isinstance(summary, dict)

    summary["time"] = OrderedDict()

    if os.path.isfile(ETC_TIMEZONE):
        with open(ETC_TIMEZONE) as f:
            summary["time"]["zone"] = f.readline().strip()

    servers, source = get_servers_and_source(NTP_CONF)
    if servers or source is not None:
        summary["time"]["ntp"] = OrderedDict()

        if servers:
            summary["time"]["ntp"]["servers"] = servers

        if source is not None:
            summary["time"]["ntp"]["source"] = source


def execute_command(net_daemon):
    """
    Given an instance of NetDaemon that has already run an input command through NetworkDocopt,
    perform the appropriate actions, and return the standard 2-tuple.
    """

    assert isinstance(net_daemon, NetDaemon)

    # Convenience variable
    tokens = net_daemon.nclu_parser.args
    assert "configuration" not in tokens, "\"net show configuration\" does not use this code path."
    assert "time" in tokens, "Why are you here?"

    if "add" in tokens or "del" in tokens:
        if "ntp" in tokens:
            if "server" in tokens or "source" in tokens:
                return execute_command_ntp(net_daemon)

        elif "zone" in tokens:
            # net add time zone (...)

            with open(ETC_TIMEZONE_SCRATCHPAD, 'w') as f:
                # This file should only have one line, so overwrite anything that already exists.
                f.write(net_daemon.nclu_parser.argv_expanded[-1] + '\n')

            return (True, {"output": ''})

    elif "show" in tokens:
        messages = {"output": ''}

        if "ntp" in tokens:
            # net show time ntp servers

            # The ntpq command gets information from a server via L3 traffic.  If VRF is enabled
            # and ntpq is invoked from outside the VRF, ntpq will return the empty string.
            ntpq_command = "/usr/bin/ntpq -p"

            # Try to find a command that works rather or not VRF is enabled.
            command = "/bin/systemctl show -p MainPID ntp*"
            try:
                systemctl_output = check_output(command.split())

                # Get the first non-zero PID, if any, from the output.
                pid = re.search(r"""MainPID=(?P<pid>[1-9]\d*)""", systemctl_output)

                if pid is not None:
                    command = "/usr/bin/vrf task identify {0}".format(pid.group("pid"))
                    vrf_output = check_output(command.split())

                    # This command should work rather or not VRF is enabled.
                    ntpq_command = "/usr/bin/vrf task exec {0} ntpq -p".format(vrf_output)
            except CalledProcessError as e:
                # Hope for the best, which is that VRF is not enabled.
                messages["warning"] = ["If VRF is enabled, this output might be incomplete or incorrect."]
                log.warning("\"{0}\" failed: {1}.".format(command, e))

            # Call the command determined above.
            try:
                ntpq_output = check_output(ntpq_command.split())
                messages["output"] = ntpq_output.strip()
                return (True, messages)
            except CalledProcessError as e:
                log.exception(e)
                messages["error"] = ["The call to \"{0}\" failed.  See the log for details.".format(ntpq_command)]
                return (False, messages)

        elif "zone" in tokens:
            # net show time zone

            if os.path.isfile(ETC_TIMEZONE):
                with open(ETC_TIMEZONE) as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            messages["output"] = line
                            break
                    else:
                        messages["info"] = ["\"{0}\" is an empty file.  No timezone is set.".format(ETC_TIMEZONE)]
            else:
                messages["info"] = ["No timezone is set."]

            return (True, messages)

        else:
            # net show time

            try:
                messages["output"] = check_output("/bin/date")
                return (True, messages)
            except CalledProcessError as e:
                log.exception(e)
                messages["error"] = ["The call to /bin/date failed.  See the log for details."]
                return (False, messages)

    return (False, {"output": '', "error": ["NCLU doesn't know how to process this command."]})


def execute_command_ntp(net_daemon):
    """
    Return the standard 2-tuple for the following commands:

    net add time ntp server <text> [iburst]
    net del time ntp server <text>
    net (add|del) time ntp source <interface>
    """

    # Convenience variable
    tokens = net_daemon.nclu_parser.args

    if not os.path.isfile(NTP_CONF_SCRATCHPAD):
        make_scratchpads([(NTP_CONF, NTP_CONF_SCRATCHPAD, NTP_CONF_DEFAULT)])

    with open(NTP_CONF_SCRATCHPAD, "r+") as f:
        ntp_conf = f.read()

        if "server" in tokens:
            server_re = re.compile(r"""^\s*server\s+{0}(?P<iburst>\s+iburst)?\s*$""".format(re.escape(tokens["<text>"])), re.MULTILINE)
            server_line = server_re.search(ntp_conf)

            if "add" in tokens:
                if server_line is None:
                    # The server is not configured.  Append it.
                    f.write("server {0}{1}\n".format(tokens["<text>"], " iburst" if ("iburst" in tokens) else ''))
                    return (True, {"output": ''})

                # The server is already configured.  Test for a no-op command.
                if ("iburst" in tokens and server_line.group("iburst") is not None) or \
                        ("iburst" not in tokens and server_line.group("iburst") is None):
                    log.info("ntp.py:execute_command_ntp: {0} already has \"{1}\".".format(NTP_CONF_SCRATCHPAD, server_line.group(0)))
                    return (True, {"output": '', "info": ["\"{0}\" is already configured.".format(server_line.group(0))]})

                # The existing server line needs to be modified.
                ntp_conf = server_re.sub(tokens["<text>"] + (" iburst" if ("iburst" in tokens) else ''), ntp_conf)

            elif "del" in tokens:
                if server_line is None:
                    log.info("ntp.py:execute_command_ntp: {0} does not have server \"{1}\".".format(NTP_CONF_SCRATCHPAD, tokens["<text>"]))
                    return (True, {"output": '', "info": ["\"{0}\" is not configured.".format(tokens["<text>"])]})

                # The existing server line needs to be removed.
                ntp_conf = server_re.sub('', ntp_conf)

        elif "source" in tokens:
            assert "<interface>" in tokens and isinstance(tokens["<interface>"], basestring)
            if len(ifname_expand_glob(tokens["<interface>"])) > 1:
                return (False, {"output": '', "error": ["This command does not accept a glob.  There is only one source."]})

            source_re = re.compile(r"""^\s*interface\s+listen\s+(?P<interface>\S+)\s*$""", re.MULTILINE)
            source_line = source_re.search(ntp_conf)

            if "add" in tokens:
                if source_line is None:
                    # The source is not configured.  Append it.
                    f.write("interface listen {0}\n".format(tokens["<interface>"]))
                    return (True, {"output": ''})

                # The source is already configured.  Test for a no-op command.
                if tokens["<interface>"] == source_line.group("interface"):
                    log.info("ntp.py: {0} already has \"{1}\".".format(NTP_CONF_SCRATCHPAD, tokens["<interface>"]))
                    return (True, {"output": '', "info": ["\"{0}\" is already configured.".format(tokens["<interface>"])]})

                # The existing source needs to be replaced.
                ntp_conf = source_re.sub("interface listen {0}".format(tokens["<interface>"]), ntp_conf)

            if "del" in tokens:
                if source_line is None:
                    log.info("ntp.py:execute_command_ntp: {0} does not have source \"{1}\".".format(NTP_CONF_SCRATCHPAD, tokens["<interface>"]))
                    return (True, {"output": '', "info": ["\"{0}\" is not configured.".format(tokens["<interface>"])]})

                # The existing source needs to be removed.
                ntp_conf = source_re.sub('', ntp_conf)

        else:
            return (False, {"output": '', "error": ["NCLU doesn't know how to process this command."]})

        # Update the scratchpad with the staged changes.
        f.seek(0)
        f.write(ntp_conf)
        f.truncate()

    return (True, {"output": ''})


def del_all():
    """
    net del all

    Revert all configuration files associated with this plug-in to their defaults.
    """

    # Reset the time zone to "Etc/UTC".
    with open(ETC_TIMEZONE_SCRATCHPAD, 'w') as f:
        f.write("Etc/UTC\n")

    # Reset NTP_CONF.
    with open(NTP_CONF_SCRATCHPAD, 'w') as f:
        f.write(NTP_CONF_DEFAULT)


def get_config_files():
    """
    Return a string with the content of all existing, non-empty configuration files managed with this plug-in.
    """

    return get_config_files_helper(get_managed_files())


def get_pending(use_colors):
    """ Return a string of the pending changes in all managed files. """

    return get_pending_diffs([(NTP_CONF, NTP_CONF_SCRATCHPAD), (ETC_TIMEZONE, ETC_TIMEZONE_SCRATCHPAD)], use_colors)


def abort_pending():
    remove_scratch_files_and_backups([NTP_CONF_SCRATCHPAD, ETC_TIMEZONE_SCRATCHPAD])


def get_managed_files():
    """ Return a list of managed files. """

    return [NTP_CONF, ETC_TIMEZONE]


def get_restart_commands(filename):
    """
    Return a list of commands that should be called for the given file after a rollback.
    Some plug-ins use this in commit_pending as well.
    """

    assert filename in get_managed_files(), "filename = {0}".format(filename)

    if filename == ETC_TIMEZONE:
        return [("/usr/sbin/dpkg-reconfigure", "--frontend", "noninteractive", "tzdata")]

    if filename == NTP_CONF:
        return [("/bin/systemctl", "enable", "ntp.service"),
                ("/bin/systemctl", "reset-failed", "ntp.service"),
                ("/bin/systemctl", "restart", "ntp.service")]

    raise RuntimeError("Unable to retreive restart commands for \"{0}\".".format(filename))


def get_servers_and_source(configuration):
    """
    Return the "server" and "source" components of the given configuration file.
    "server" lines include "iburst", if present.  The return type is (list, str or None).
    """

    assert configuration in (NTP_CONF, NTP_CONF_SCRATCHPAD)

    if not os.path.isfile(configuration):
        log.warning("ntp.py:get_servers_and_source: {0} is not a regular file.".format(configuration))
        return ([], None)

    servers = []
    source = None

    with open(configuration) as f:
        for line in f:
            line = line.strip()
            if line.startswith("server "):
                servers.append(line[7:])
            elif line.startswith("interface listen "):
                if source is not None:
                    # There should only be one source.  The file might have been manually misconfigured.
                    log.warning("{0} contains multiple \"source\" lines.".format(configuration))
                source = line[17:]

    return (servers, source)


NTP_CONF_DEFAULT = """\
# /etc/ntp.conf, configuration for ntpd; see ntp.conf(5) for help

driftfile /var/lib/ntp/ntp.drift

# Enable this if you want statistics to be logged.
#statsdir /var/log/ntpstats/

statistics loopstats peerstats clockstats
filegen loopstats file loopstats type day enable
filegen peerstats file peerstats type day enable
filegen clockstats file clockstats type day enable


# You do need to talk to an NTP server or two (or three).
#pool ntp.your-provider.example
# OR
#server ntp.your-provider.example

# pool.ntp.org maps to about 1000 low-stratum NTP servers.  Your server will
# pick a different set every time it starts up.  Please consider joining the
# pool: <http://www.pool.ntp.org/join.html>
server 0.cumulusnetworks.pool.ntp.org iburst
server 1.cumulusnetworks.pool.ntp.org iburst
server 2.cumulusnetworks.pool.ntp.org iburst
server 3.cumulusnetworks.pool.ntp.org iburst

# Access control configuration; see /usr/share/doc/ntp-doc/html/accopt.html for
# details.  The web page <http://support.ntp.org/bin/view/Support/AccessRestrictions>
# might also be helpful.
#
# Note that "restrict" applies to both servers and clients, so a configuration
# that might be intended to block requests from certain clients could also end
# up blocking replies from your own upstream servers.

# By default, exchange time with everybody, but don't allow configuration.
restrict -4 default kod notrap nomodify nopeer noquery limited
restrict -6 default kod notrap nomodify nopeer noquery limited

# Local users may interrogate the ntp server more closely.
restrict 127.0.0.1
restrict ::1

# Needed for adding pool entries
restrict source notrap nomodify noquery

# Clients from this (example!) subnet have unlimited access, but only if
# cryptographically authenticated.
#restrict 192.168.123.0 mask 255.255.255.0 notrust


# If you want to provide time to your local subnet, change the next line.
# (Again, the address is an example only.)
#broadcast 192.168.123.255

# If you want to listen to time broadcasts on your local subnet, de-comment the
# next lines.  Please do this only if you trust everybody on the network!
#disable auth
#broadcastclient

# Specify interfaces, don't listen on switch ports

interface listen eth0
"""


TIMEZONES = {
    "Africa/Abidjan": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Accra": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Addis_Ababa": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Africa/Algiers": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Asmara": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Africa/Bamako": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Bangui": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Banjul": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Bissau": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Blantyre": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Brazzaville": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Bujumbura": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Cairo": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Casablanca": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Africa/Ceuta": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Africa/Conakry": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Dakar": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Dar_es_Salaam": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Africa/Djibouti": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Africa/Douala": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/El_Aaiun": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Africa/Freetown": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Gaborone": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Harare": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Johannesburg": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Juba": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Africa/Kampala": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Africa/Khartoum": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Africa/Kigali": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Kinshasa": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Lagos": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Libreville": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Lome": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Luanda": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Lubumbashi": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Lusaka": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Malabo": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Maputo": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Maseru": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Mbabane": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Mogadishu": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Africa/Monrovia": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Nairobi": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Africa/Ndjamena": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Niamey": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Nouakchott": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Ouagadougou": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Porto-Novo": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Sao_Tome": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Timbuktu": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Africa/Tripoli": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Africa/Tunis": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Africa/Windhoek": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "America/Adak": {
        "UTC": "-10:00",
        "UTC DST": "-09:00"
    },
    "America/Anchorage": {
        "UTC": "-09:00",
        "UTC DST": "-08:00"
    },
    "America/Anguilla": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Antigua": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Araguaina": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/Buenos_Aires": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/Catamarca": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/ComodRivadavia": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/Cordoba": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/Jujuy": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/La_Rioja": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/Mendoza": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/Rio_Gallegos": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/Salta": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/San_Juan": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/San_Luis": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/Tucuman": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Argentina/Ushuaia": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Aruba": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Asuncion": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "America/Atikokan": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Atka": {
        "UTC": "-10:00",
        "UTC DST": "-09:00"
    },
    "America/Bahia": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Bahia_Banderas": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Barbados": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Belem": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Belize": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "America/Blanc-Sablon": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Boa_Vista": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Bogota": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Boise": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "America/Buenos_Aires": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Cambridge_Bay": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "America/Campo_Grande": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "America/Cancun": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Caracas": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Catamarca": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Cayenne": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Cayman": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Chicago": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Chihuahua": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "America/Coral_Harbour": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Cordoba": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Costa_Rica": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "America/Creston": {
        "UTC": "-07:00",
        "UTC DST": "-07:00"
    },
    "America/Cuiaba": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "America/Curacao": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Danmarkshavn": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "America/Dawson": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "America/Dawson_Creek": {
        "UTC": "-07:00",
        "UTC DST": "-07:00"
    },
    "America/Denver": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "America/Detroit": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Dominica": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Edmonton": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "America/Eirunepe": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/El_Salvador": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "America/Ensenada": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "America/Fort_Nelson": {
        "UTC": "-07:00",
        "UTC DST": "-07:00"
    },
    "America/Fort_Wayne": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Fortaleza": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Glace_Bay": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "America/Godthab": {
        "UTC": "-03:00",
        "UTC DST": "-02:00"
    },
    "America/Goose_Bay": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "America/Grand_Turk": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Grenada": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Guadeloupe": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Guatemala": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "America/Guayaquil": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Guyana": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Halifax": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "America/Havana": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Hermosillo": {
        "UTC": "-07:00",
        "UTC DST": "-07:00"
    },
    "America/Indiana/Indianapolis": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Indiana/Knox": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Indiana/Marengo": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Indiana/Petersburg": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Indiana/Tell_City": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Indiana/Vevay": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Indiana/Vincennes": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Indiana/Winamac": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Indianapolis": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Inuvik": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "America/Iqaluit": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Jamaica": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Jujuy": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Juneau": {
        "UTC": "-09:00",
        "UTC DST": "-08:00"
    },
    "America/Kentucky/Louisville": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Kentucky/Monticello": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Knox_IN": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Kralendijk": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/La_Paz": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Lima": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Los_Angeles": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "America/Louisville": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Lower_Princes": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Maceio": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Managua": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "America/Manaus": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Marigot": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Martinique": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Matamoros": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Mazatlan": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "America/Mendoza": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Menominee": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Merida": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Metlakatla": {
        "UTC": "-09:00",
        "UTC DST": "-08:00"
    },
    "America/Mexico_City": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Miquelon": {
        "UTC": "-03:00",
        "UTC DST": "-02:00"
    },
    "America/Moncton": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "America/Monterrey": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Montevideo": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Montreal": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Montserrat": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Nassau": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/New_York": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Nipigon": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Nome": {
        "UTC": "-09:00",
        "UTC DST": "-08:00"
    },
    "America/Noronha": {
        "UTC": "-02:00",
        "UTC DST": "-02:00"
    },
    "America/North_Dakota/Beulah": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/North_Dakota/Center": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/North_Dakota/New_Salem": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Ojinaga": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "America/Panama": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Pangnirtung": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Paramaribo": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Phoenix": {
        "UTC": "-07:00",
        "UTC DST": "-07:00"
    },
    "America/Port-au-Prince": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Port_of_Spain": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Porto_Acre": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Porto_Velho": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Puerto_Rico": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Rainy_River": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Rankin_Inlet": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Recife": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Regina": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "America/Resolute": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Rio_Branco": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "America/Rosario": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Santa_Isabel": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "America/Santarem": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "America/Santiago": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "America/Santo_Domingo": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Sao_Paulo": {
        "UTC": "-03:00",
        "UTC DST": "-02:00"
    },
    "America/Scoresbysund": {
        "UTC": "-01:00",
        "UTC DST": "+00:00"
    },
    "America/Shiprock": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "America/Sitka": {
        "UTC": "-09:00",
        "UTC DST": "-08:00"
    },
    "America/St_Barthelemy": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/St_Johns": {
        "UTC": "-03:30",
        "UTC DST": "-02:30"
    },
    "America/St_Kitts": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/St_Lucia": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/St_Thomas": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/St_Vincent": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Swift_Current": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "America/Tegucigalpa": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "America/Thule": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "America/Thunder_Bay": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Tijuana": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "America/Toronto": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "America/Tortola": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Vancouver": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "America/Virgin": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "America/Whitehorse": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "America/Winnipeg": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "America/Yakutat": {
        "UTC": "-09:00",
        "UTC DST": "-08:00"
    },
    "America/Yellowknife": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "Antarctica/Casey": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Antarctica/Davis": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Antarctica/DumontDUrville": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Antarctica/Macquarie": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Antarctica/Mawson": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Antarctica/McMurdo": {
        "UTC": "+12:00",
        "UTC DST": "+13:00"
    },
    "Antarctica/Palmer": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "Antarctica/Rothera": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "Antarctica/South_Pole": {
        "UTC": "+12:00",
        "UTC DST": "+13:00"
    },
    "Antarctica/Syowa": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Antarctica/Troll": {
        "UTC": "+00:00",
        "UTC DST": "+02:00"
    },
    "Antarctica/Vostok": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Arctic/Longyearbyen": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Asia/Aden": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Asia/Almaty": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Asia/Amman": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Asia/Anadyr": {
        "UTC": "+12:00",
        "UTC DST": "+12:00"
    },
    "Asia/Aqtau": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Aqtobe": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Ashgabat": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Ashkhabad": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Atyrau": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Baghdad": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Asia/Bahrain": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Asia/Baku": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Asia/Bangkok": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Barnaul": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Beirut": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Asia/Bishkek": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Asia/Brunei": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Calcutta": {
        "UTC": "+05:30",
        "UTC DST": "+05:30"
    },
    "Asia/Chita": {
        "UTC": "+09:00",
        "UTC DST": "+09:00"
    },
    "Asia/Choibalsan": {
        "UTC": "+08:00",
        "UTC DST": "+09:00"
    },
    "Asia/Chongqing": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Chungking": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Colombo": {
        "UTC": "+05:30",
        "UTC DST": "+05:30"
    },
    "Asia/Dacca": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Asia/Damascus": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Asia/Dhaka": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Asia/Dili": {
        "UTC": "+09:00",
        "UTC DST": "+09:00"
    },
    "Asia/Dubai": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Asia/Dushanbe": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Famagusta": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Asia/Gaza": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Asia/Harbin": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Hebron": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Asia/Ho_Chi_Minh": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Hong_Kong": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Hovd": {
        "UTC": "+07:00",
        "UTC DST": "+08:00"
    },
    "Asia/Irkutsk": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Istanbul": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Asia/Jakarta": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Jayapura": {
        "UTC": "+09:00",
        "UTC DST": "+09:00"
    },
    "Asia/Jerusalem": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Asia/Kabul": {
        "UTC": "+04:30",
        "UTC DST": "+04:30"
    },
    "Asia/Kamchatka": {
        "UTC": "+12:00",
        "UTC DST": "+12:00"
    },
    "Asia/Karachi": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Kashgar": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Asia/Kathmandu": {
        "UTC": "+05:45",
        "UTC DST": "+05:45"
    },
    "Asia/Katmandu": {
        "UTC": "+05:45",
        "UTC DST": "+05:45"
    },
    "Asia/Khandyga": {
        "UTC": "+09:00",
        "UTC DST": "+09:00"
    },
    "Asia/Kolkata": {
        "UTC": "+05:30",
        "UTC DST": "+05:30"
    },
    "Asia/Krasnoyarsk": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Kuala_Lumpur": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Kuching": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Kuwait": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Asia/Macao": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Macau": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Magadan": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Asia/Makassar": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Manila": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Muscat": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Asia/Nicosia": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Asia/Novokuznetsk": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Novosibirsk": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Omsk": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Asia/Oral": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Phnom_Penh": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Pontianak": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Pyongyang": {
        "UTC": "+08:30",
        "UTC DST": "+08:30"
    },
    "Asia/Qatar": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Asia/Qyzylorda": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Asia/Rangoon": {
        "UTC": "+06:30",
        "UTC DST": "+06:30"
    },
    "Asia/Riyadh": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Asia/Saigon": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Sakhalin": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Asia/Samarkand": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Seoul": {
        "UTC": "+09:00",
        "UTC DST": "+09:00"
    },
    "Asia/Shanghai": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Singapore": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Srednekolymsk": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Asia/Taipei": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Tashkent": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Tbilisi": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Asia/Tehran": {
        "UTC": "+03:30",
        "UTC DST": "+04:30"
    },
    "Asia/Tel_Aviv": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Asia/Thimbu": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Asia/Thimphu": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Asia/Tokyo": {
        "UTC": "+09:00",
        "UTC DST": "+09:00"
    },
    "Asia/Tomsk": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Ujung_Pandang": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Asia/Ulaanbaatar": {
        "UTC": "+08:00",
        "UTC DST": "+09:00"
    },
    "Asia/Ulan_Bator": {
        "UTC": "+08:00",
        "UTC DST": "+09:00"
    },
    "Asia/Urumqi": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Asia/Ust-Nera": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Asia/Vientiane": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Asia/Vladivostok": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Asia/Yakutsk": {
        "UTC": "+09:00",
        "UTC DST": "+09:00"
    },
    "Asia/Yangon": {
        "UTC": "+06:30",
        "UTC DST": "+06:30"
    },
    "Asia/Yekaterinburg": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Asia/Yerevan": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Atlantic/Azores": {
        "UTC": "-01:00",
        "UTC DST": "+00:00"
    },
    "Atlantic/Bermuda": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "Atlantic/Canary": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Atlantic/Cape_Verde": {
        "UTC": "-01:00",
        "UTC DST": "-01:00"
    },
    "Atlantic/Faeroe": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Atlantic/Faroe": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Atlantic/Jan_Mayen": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Atlantic/Madeira": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Atlantic/Reykjavik": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Atlantic/South_Georgia": {
        "UTC": "-02:00",
        "UTC DST": "-02:00"
    },
    "Atlantic/St_Helena": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Atlantic/Stanley": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "Australia/ACT": {
        "UTC": "+10:00",
        "UTC DST": "+11:00"
    },
    "Australia/Adelaide": {
        "UTC": "+09:30",
        "UTC DST": "+10:30"
    },
    "Australia/Brisbane": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Australia/Broken_Hill": {
        "UTC": "+09:30",
        "UTC DST": "+10:30"
    },
    "Australia/Canberra": {
        "UTC": "+10:00",
        "UTC DST": "+11:00"
    },
    "Australia/Currie": {
        "UTC": "+10:00",
        "UTC DST": "+11:00"
    },
    "Australia/Darwin": {
        "UTC": "+09:30",
        "UTC DST": "+09:30"
    },
    "Australia/Eucla": {
        "UTC": "+08:45",
        "UTC DST": "+08:45"
    },
    "Australia/Hobart": {
        "UTC": "+10:00",
        "UTC DST": "+11:00"
    },
    "Australia/LHI": {
        "UTC": "+10:30",
        "UTC DST": "+11:00"
    },
    "Australia/Lindeman": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Australia/Lord_Howe": {
        "UTC": "+10:30",
        "UTC DST": "+11:00"
    },
    "Australia/Melbourne": {
        "UTC": "+10:00",
        "UTC DST": "+11:00"
    },
    "Australia/NSW": {
        "UTC": "+10:00",
        "UTC DST": "+11:00"
    },
    "Australia/North": {
        "UTC": "+09:30",
        "UTC DST": "+09:30"
    },
    "Australia/Perth": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Australia/Queensland": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Australia/South": {
        "UTC": "+09:30",
        "UTC DST": "+10:30"
    },
    "Australia/Sydney": {
        "UTC": "+10:00",
        "UTC DST": "+11:00"
    },
    "Australia/Tasmania": {
        "UTC": "+10:00",
        "UTC DST": "+11:00"
    },
    "Australia/Victoria": {
        "UTC": "+10:00",
        "UTC DST": "+11:00"
    },
    "Australia/West": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Australia/Yancowinna": {
        "UTC": "+09:30",
        "UTC DST": "+10:30"
    },
    "Brazil/Acre": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "Brazil/DeNoronha": {
        "UTC": "-02:00",
        "UTC DST": "-02:00"
    },
    "Brazil/East": {
        "UTC": "-03:00",
        "UTC DST": "-02:00"
    },
    "Brazil/West": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "Canada/Atlantic": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "Canada/Central": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "Canada/East-Saskatchewan": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "Canada/Eastern": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "Canada/Mountain": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "Canada/Newfoundland": {
        "UTC": "-03:30",
        "UTC DST": "-02:30"
    },
    "Canada/Pacific": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "Canada/Saskatchewan": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "Canada/Yukon": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "Chile/Continental": {
        "UTC": "-04:00",
        "UTC DST": "-03:00"
    },
    "Chile/EasterIsland": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "Etc/GMT": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Etc/GMT+0": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Etc/GMT+1": {
        "UTC": "-01:00",
        "UTC DST": "-01:00"
    },
    "Etc/GMT+10": {
        "UTC": "-10:00",
        "UTC DST": "-10:00"
    },
    "Etc/GMT+11": {
        "UTC": "-11:00",
        "UTC DST": "-11:00"
    },
    "Etc/GMT+12": {
        "UTC": "-12:00",
        "UTC DST": "-12:00"
    },
    "Etc/GMT+2": {
        "UTC": "-02:00",
        "UTC DST": "-02:00"
    },
    "Etc/GMT+3": {
        "UTC": "-03:00",
        "UTC DST": "-03:00"
    },
    "Etc/GMT+4": {
        "UTC": "-04:00",
        "UTC DST": "-04:00"
    },
    "Etc/GMT+5": {
        "UTC": "-05:00",
        "UTC DST": "-05:00"
    },
    "Etc/GMT+6": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "Etc/GMT+7": {
        "UTC": "-07:00",
        "UTC DST": "-07:00"
    },
    "Etc/GMT+8": {
        "UTC": "-08:00",
        "UTC DST": "-08:00"
    },
    "Etc/GMT+9": {
        "UTC": "-09:00",
        "UTC DST": "-09:00"
    },
    "Etc/GMT-0": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Etc/GMT-1": {
        "UTC": "+01:00",
        "UTC DST": "+01:00"
    },
    "Etc/GMT-10": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Etc/GMT-11": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Etc/GMT-12": {
        "UTC": "+12:00",
        "UTC DST": "+12:00"
    },
    "Etc/GMT-13": {
        "UTC": "+13:00",
        "UTC DST": "+13:00"
    },
    "Etc/GMT-14": {
        "UTC": "+14:00",
        "UTC DST": "+14:00"
    },
    "Etc/GMT-2": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Etc/GMT-3": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Etc/GMT-4": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Etc/GMT-5": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Etc/GMT-6": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Etc/GMT-7": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Etc/GMT-8": {
        "UTC": "+08:00",
        "UTC DST": "+08:00"
    },
    "Etc/GMT-9": {
        "UTC": "+09:00",
        "UTC DST": "+09:00"
    },
    "Etc/GMT0": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Etc/Greenwich": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Etc/UTC": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Etc/Universal": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Etc/Zulu": {
        "UTC": "+00:00",
        "UTC DST": "+00:00"
    },
    "Europe/Amsterdam": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Andorra": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Astrakhan": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Europe/Athens": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Belfast": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Europe/Belgrade": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Berlin": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Bratislava": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Brussels": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Bucharest": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Budapest": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Busingen": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Chisinau": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Copenhagen": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Dublin": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Europe/Gibraltar": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Guernsey": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Europe/Helsinki": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Isle_of_Man": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Europe/Istanbul": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Europe/Jersey": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Europe/Kaliningrad": {
        "UTC": "+02:00",
        "UTC DST": "+02:00"
    },
    "Europe/Kiev": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Kirov": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Europe/Lisbon": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Europe/Ljubljana": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/London": {
        "UTC": "+00:00",
        "UTC DST": "+01:00"
    },
    "Europe/Luxembourg": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Madrid": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Malta": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Mariehamn": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Minsk": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Europe/Monaco": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Moscow": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Europe/Nicosia": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Oslo": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Paris": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Podgorica": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Prague": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Riga": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Rome": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Samara": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Europe/San_Marino": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Sarajevo": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Saratov": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Europe/Simferopol": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Europe/Skopje": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Sofia": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Stockholm": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Tallinn": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Tirane": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Tiraspol": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Ulyanovsk": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Europe/Uzhgorod": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Vaduz": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Vatican": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Vienna": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Vilnius": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Volgograd": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Europe/Warsaw": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Zagreb": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Europe/Zaporozhye": {
        "UTC": "+02:00",
        "UTC DST": "+03:00"
    },
    "Europe/Zurich": {
        "UTC": "+01:00",
        "UTC DST": "+02:00"
    },
    "Indian/Antananarivo": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Indian/Chagos": {
        "UTC": "+06:00",
        "UTC DST": "+06:00"
    },
    "Indian/Christmas": {
        "UTC": "+07:00",
        "UTC DST": "+07:00"
    },
    "Indian/Cocos": {
        "UTC": "+06:30",
        "UTC DST": "+06:30"
    },
    "Indian/Comoro": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Indian/Kerguelen": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Indian/Mahe": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Indian/Maldives": {
        "UTC": "+05:00",
        "UTC DST": "+05:00"
    },
    "Indian/Mauritius": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Indian/Mayotte": {
        "UTC": "+03:00",
        "UTC DST": "+03:00"
    },
    "Indian/Reunion": {
        "UTC": "+04:00",
        "UTC DST": "+04:00"
    },
    "Mexico/BajaNorte": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "Mexico/BajaSur": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "Mexico/General": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "Pacific/Apia": {
        "UTC": "+13:00",
        "UTC DST": "+14:00"
    },
    "Pacific/Auckland": {
        "UTC": "+12:00",
        "UTC DST": "+13:00"
    },
    "Pacific/Bougainville": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Pacific/Chatham": {
        "UTC": "+12:45",
        "UTC DST": "+13:45"
    },
    "Pacific/Chuuk": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Pacific/Easter": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "Pacific/Efate": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Pacific/Enderbury": {
        "UTC": "+13:00",
        "UTC DST": "+13:00"
    },
    "Pacific/Fakaofo": {
        "UTC": "+13:00",
        "UTC DST": "+13:00"
    },
    "Pacific/Fiji": {
        "UTC": "+12:00",
        "UTC DST": "+13:00"
    },
    "Pacific/Funafuti": {
        "UTC": "+12:00",
        "UTC DST": "+12:00"
    },
    "Pacific/Galapagos": {
        "UTC": "-06:00",
        "UTC DST": "-06:00"
    },
    "Pacific/Gambier": {
        "UTC": "-09:00",
        "UTC DST": "-09:00"
    },
    "Pacific/Guadalcanal": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Pacific/Guam": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Pacific/Honolulu": {
        "UTC": "-10:00",
        "UTC DST": "-10:00"
    },
    "Pacific/Johnston": {
        "UTC": "-10:00",
        "UTC DST": "-10:00"
    },
    "Pacific/Kiritimati": {
        "UTC": "+14:00",
        "UTC DST": "+14:00"
    },
    "Pacific/Kosrae": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Pacific/Kwajalein": {
        "UTC": "+12:00",
        "UTC DST": "+12:00"
    },
    "Pacific/Majuro": {
        "UTC": "+12:00",
        "UTC DST": "+12:00"
    },
    "Pacific/Marquesas": {
        "UTC": "-09:30",
        "UTC DST": "-09:30"
    },
    "Pacific/Midway": {
        "UTC": "-11:00",
        "UTC DST": "-11:00"
    },
    "Pacific/Nauru": {
        "UTC": "+12:00",
        "UTC DST": "+12:00"
    },
    "Pacific/Niue": {
        "UTC": "-11:00",
        "UTC DST": "-11:00"
    },
    "Pacific/Norfolk": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Pacific/Noumea": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Pacific/Pago_Pago": {
        "UTC": "-11:00",
        "UTC DST": "-11:00"
    },
    "Pacific/Palau": {
        "UTC": "+09:00",
        "UTC DST": "+09:00"
    },
    "Pacific/Pitcairn": {
        "UTC": "-08:00",
        "UTC DST": "-08:00"
    },
    "Pacific/Pohnpei": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Pacific/Ponape": {
        "UTC": "+11:00",
        "UTC DST": "+11:00"
    },
    "Pacific/Port_Moresby": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Pacific/Rarotonga": {
        "UTC": "-10:00",
        "UTC DST": "-10:00"
    },
    "Pacific/Saipan": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Pacific/Samoa": {
        "UTC": "-11:00",
        "UTC DST": "-11:00"
    },
    "Pacific/Tahiti": {
        "UTC": "-10:00",
        "UTC DST": "-10:00"
    },
    "Pacific/Tarawa": {
        "UTC": "+12:00",
        "UTC DST": "+12:00"
    },
    "Pacific/Tongatapu": {
        "UTC": "+13:00",
        "UTC DST": "+14:00"
    },
    "Pacific/Truk": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "Pacific/Wake": {
        "UTC": "+12:00",
        "UTC DST": "+12:00"
    },
    "Pacific/Wallis": {
        "UTC": "+12:00",
        "UTC DST": "+12:00"
    },
    "Pacific/Yap": {
        "UTC": "+10:00",
        "UTC DST": "+10:00"
    },
    "US/Alaska": {
        "UTC": "-09:00",
        "UTC DST": "-08:00"
    },
    "US/Aleutian": {
        "UTC": "-10:00",
        "UTC DST": "-09:00"
    },
    "US/Arizona": {
        "UTC": "-07:00",
        "UTC DST": "-07:00"
    },
    "US/Central": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "US/East-Indiana": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "US/Eastern": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "US/Hawaii": {
        "UTC": "-10:00",
        "UTC DST": "-10:00"
    },
    "US/Indiana-Starke": {
        "UTC": "-06:00",
        "UTC DST": "-05:00"
    },
    "US/Michigan": {
        "UTC": "-05:00",
        "UTC DST": "-04:00"
    },
    "US/Mountain": {
        "UTC": "-07:00",
        "UTC DST": "-06:00"
    },
    "US/Pacific": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "US/Pacific-New": {
        "UTC": "-08:00",
        "UTC DST": "-07:00"
    },
    "US/Samoa": {
        "UTC": "-11:00",
        "UTC DST": "-11:00"
    }
}
